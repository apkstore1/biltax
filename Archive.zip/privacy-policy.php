<?php
$page_title = "Privacy Policy — Biltax";
include 'php/header.php';
?>
<div class="page-hero" style="background:var(--black-2);">
  <span class="section-tag">Legal</span>
  <h1 class="section-title">Privacy <span>Policy</span></h1>
  <p class="section-sub">We are committed to protecting your privacy. This policy explains what data we collect, why we collect it, and how we use it.</p>
  <div style="margin-top:20px;font-family:'JetBrains Mono',monospace;font-size:.78rem;color:var(--gray);">Last updated: April 1, 2026</div>
</div>
<section style="background:var(--black);padding:80px 60px;">
  <div style="max-width:860px;margin:0 auto;">
    <div class="legal-intro reveal">Biltax Technologies (Pvt.) Ltd. ("Biltax", "we", "our") operates the Biltax platform at biltax.com. This Privacy Policy explains how we collect, use, share, and protect your personal information when you use our services.</div>
    <?php $sections=[
      ['information-we-collect','1. Information We Collect','<h3>Information You Provide</h3><p>Account information (name, email, phone, business name, password), business data (inventory items, supplier info, purchase orders), payment information (processed by payment partners), and communications you send us.</p><h3>Information We Collect Automatically</h3><p>Usage data, device data (IP address, browser type, OS), server log data, and cookies (session tokens, preference cookies, analytics cookies).</p>'],
      ['how-we-use','2. How We Use Your Information','<p>We use your information to: provide and improve the Biltax platform, process payments, send transactional emails, provide customer support, send product updates (with your consent), detect fraud, comply with legal obligations, and analyse platform usage to improve our product.</p><p>We do <strong>not</strong> sell your personal data to third parties, ever.</p>'],
      ['sharing','3. Sharing Your Information','<p>We may share your information with service providers (AWS, SendGrid, Stripe/JazzCash), legal authorities when required by law, and in the event of a merger or acquisition. We do not share your business inventory data with any third party for advertising purposes.</p>'],
      ['data-retention','4. Data Retention','<p>We retain your data for as long as your account is active. Upon cancellation, you may export all data from Settings → Export Data. Personal information is deleted within 30 days of account closure. Data required for legal compliance may be retained for up to 7 years.</p>'],
      ['security','5. Security','<p>We implement: AES-256 encryption at rest, TLS 1.3 in transit, ISO 27001-certified cloud infrastructure (AWS), role-based access control, daily encrypted backups, and regular third-party penetration testing.</p>'],
      ['cookies','6. Cookies','<p>We use essential cookies (required for login), analytics cookies (self-hosted, opt-out available in account settings), and preference cookies (language, timezone). We do not use third-party advertising cookies or tracking pixels.</p>'],
      ['your-rights','7. Your Rights','<p>You have the right to: access your personal data, correct inaccurate information, request deletion, export your data (CSV/JSON), unsubscribe from marketing emails, and withdraw consent at any time. Email privacy@biltax.com to exercise these rights. We respond within 30 days.</p>'],
      ['children','8. Children\'s Privacy','<p>Biltax is intended for businesses and individuals aged 18 and over. We do not knowingly collect personal information from children under 18. Contact privacy@biltax.com if you believe a minor has provided us their information.</p>'],
      ['changes','9. Changes to This Policy','<p>We will notify all registered users by email at least 14 days before material changes take effect. Continued use of Biltax after changes constitutes acceptance of the revised policy.</p>'],
      ['contact','10. Contact Us','<div style="background:var(--black-3);border:1px solid rgba(255,107,0,0.15);border-radius:6px;padding:24px 28px;margin-top:16px;"><div style="font-weight:700;color:var(--white);margin-bottom:6px;">Biltax Technologies (Pvt.) Ltd.</div><div style="font-size:.88rem;color:var(--gray-light);line-height:1.8;font-weight:500;">Office 401, The Plaza, Block 9, Clifton, Karachi, Sindh 75600, Pakistan<br>📧 <a href="mailto:privacy@biltax.com" style="color:var(--orange);">privacy@biltax.com</a><br>📞 +92 21 3456 7890</div></div>'],
    ];
    foreach($sections as $s): ?>
    <div class="legal-section reveal" id="<?=$s[0]?>">
      <h2><?=$s[1]?></h2>
      <?=$s[2]?>
    </div>
    <?php endforeach; ?>
  </div>
</section>
<?php include 'php/footer.php'; ?>
