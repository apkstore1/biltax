<?php
$page_title = "Industries — Biltax Inventory Management";
include 'php/header.php';
$industries=[
  ['id'=>'restaurants','icon'=>'🍽️','name'=>'Restaurants & Food Service','tagline'=>'Control Every Ingredient, Every Shift','desc'=>'Managing a restaurant means managing dozens of ingredients, recipes, waste, and multiple shifts. Biltax gives your kitchen complete control with recipe-level costing, ingredient tracking by gram, automatic par-level alerts, and integration with your KDS system.','features'=>['Recipe & ingredient-level costing','Expiry date & FEFO tracking','Waste and spoilage logging','Multi-outlet ingredient transfers','Kitchen display system integration','Daily consumption reporting']],
  ['id'=>'retail','icon'=>'🛍️','name'=>'Retail Stores','tagline'=>'Manage Thousands of SKUs Effortlessly','desc'=>'Whether you run a single boutique or a chain of stores, Biltax gives retail businesses the tools to manage their full product catalog, run promotions, handle returns, and sync with their online store — all in real time.','features'=>['Multi-variant product management','Promotion and discount tracking','POS and e-commerce sync','Purchase order automation','Size/colour/style tracking','Loss prevention reports']],
  ['id'=>'grocery','icon'=>'🥬','name'=>'Grocery & Supermarkets','tagline'=>'Master Perishables at Scale','desc'=>'Grocery and supermarket inventory is uniquely complex — perishables, short shelf lives, high volume, and constant receiving. Biltax is purpose-built for this with FEFO enforcement, expiry alerts, and category-level shrinkage reports.','features'=>['FIFO and FEFO enforcement','Batch and lot number tracking','Shrinkage and wastage reports','Supplier lead time management','Seasonal demand forecasting','Category P&L reporting']],
  ['id'=>'pharmacy','icon'=>'💊','name'=>'Pharmacies','tagline'=>'Compliance-Ready Inventory Control','desc'=>'Pharmacies face strict regulatory requirements around controlled substances, batch traceability, and expiry management. Biltax handles it all, with built-in compliance reporting and full audit trails.','features'=>['Controlled substance tracking','Batch and serialization support','Full regulatory audit trail','Expiry management & alerts','Supplier returns management','Bin and shelf location tracking']],
  ['id'=>'warehouse','icon'=>'🏭','name'=>'Warehouses & Distribution','tagline'=>'Optimize Every Square Meter','desc'=>'Warehouses need precision at scale. Biltax delivers with bin-level location tracking, receiving and shipping workflows, pallet management, cycle count tools, and real-time inventory accuracy across your entire facility.','features'=>['Bin and zone location tracking','Receiving & put-away workflows','Pick, pack & ship management','Pallet and container tracking','Cycle count tools','3PL and carrier integrations']],
  ['id'=>'cafe','icon'=>'☕','name'=>'Cafes & Bakeries','tagline'=>'From Bean to Cup, Track It All','desc'=>'Cafes and bakeries depend on fresh ingredients and consistent recipes. Biltax tracks ingredient consumption per recipe, manages daily production schedules, logs waste, and automatically generates supplier orders.','features'=>['Recipe costing per beverage/dish','Daily production scheduling','Waste and yield tracking','Ingredient consumption reports','Automated supplier orders','Multi-outlet ingredient management']],
  ['id'=>'fashion','icon'=>'👗','name'=>'Fashion & Apparel','tagline'=>'Manage Every Variant, Every Season','desc'=>'Fashion inventory is complex — hundreds of variants by size, color, and style, seasonal collections, and fast-moving trends. Biltax handles it all with attribute-based tracking, seasonal planning, and return management.','features'=>['Size, color & style variants','Seasonal collection planning','Markdown & clearance tracking','Inter-store transfer management','Return and exchange handling','Slow-mover identification']],
  ['id'=>'auto','icon'=>'🔧','name'=>'Auto Parts & Hardware','tagline'=>'Every Part Number, Perfectly Tracked','desc'=>'Auto parts and hardware businesses deal with thousands of part numbers, complex supplier catalogs, and compatibility requirements. Biltax keeps your catalog organized and your stock always available.','features'=>['Complex part number management','Compatibility cross-referencing','Bulk supplier catalog import','Core return tracking','Bin and shelf location system','Min/max auto-ordering']],
];
?>
<div class="page-hero">
  <span class="section-tag">Industry Solutions</span>
  <h1 class="section-title">Biltax for <span>Every Industry</span></h1>
  <p class="section-sub">Every business type has unique inventory challenges. Biltax comes pre-configured for yours — with industry-specific workflows, fields, and reports ready out of the box.</p>
</div>
<section style="background:var(--black-2);padding:60px 60px 0;">
  <div style="display:flex;flex-wrap:wrap;gap:10px;justify-content:center;" class="reveal">
    <?php foreach($industries as $ind):?>
    <a href="#<?=$ind['id']?>" style="display:inline-flex;align-items:center;gap:8px;background:var(--black-3);border:1px solid rgba(255,255,255,0.06);border-radius:100px;padding:9px 20px;font-size:.82rem;font-weight:600;color:var(--gray-light);transition:.2s;cursor:none;text-decoration:none;" onmouseenter="this.style.borderColor='var(--orange)';this.style.color='var(--orange)'" onmouseleave="this.style.borderColor='rgba(255,255,255,0.06)';this.style.color='var(--gray-light)'">
      <?=$ind['icon']?> <?=$ind['name']?>
    </a><?php endforeach;?>
  </div>
</section>
<?php foreach($industries as $idx=>$ind): $bg=($idx%2===0)?'var(--black-2)':'var(--black)';?>
<section id="<?=$ind['id']?>" style="background:<?=$bg?>;padding:100px 60px;">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center;">
    <div class="reveal">
      <span class="section-tag"><?=$ind['name']?></span>
      <h2 class="section-title"><?=$ind['tagline']?></h2>
      <p class="section-sub"><?=$ind['desc']?></p>
      <a href="demo.php" class="btn btn-primary" style="margin-top:28px;">See <?=explode(' ',$ind['name'])[0]?> Demo →</a>
    </div>
    <div class="reveal">
      <div style="background:var(--black-3);border:1px solid rgba(255,107,0,0.15);border-radius:6px;padding:40px 36px;">
        <div style="font-size:3rem;margin-bottom:20px;"><?=$ind['icon']?></div>
        <h3 style="font-size:1.05rem;font-weight:700;color:var(--white);margin-bottom:24px;">Key Features</h3>
        <ul style="display:flex;flex-direction:column;gap:12px;">
          <?php foreach($ind['features'] as $feat):?><li style="display:flex;align-items:center;gap:10px;font-size:.86rem;color:var(--gray-light);font-weight:500;"><span style="color:var(--orange);font-weight:700;min-width:14px;">✓</span><?=$feat?></li><?php endforeach;?>
        </ul>
      </div>
    </div>
  </div>
</section><?php endforeach;?>
<section id="cta-section">
  <div class="cta-tag">Your industry. Your way.</div>
  <div class="cta-title">TRY BILTAX<br>FOR FREE</div>
  <p class="cta-sub">Configure Biltax for your industry in minutes. No credit card required.</p>
  <div class="cta-actions">
    <a href="demo.php" class="btn btn-dark">Start Free Trial →</a>
    <a href="contact.php" class="btn" style="background:transparent;color:var(--black);border:2px solid rgba(0,0,0,0.3);">Talk to an Expert</a>
  </div>
</section>
<?php include 'php/footer.php'; ?>
