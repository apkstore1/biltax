<?php
$page_title = "API Documentation — Biltax Developer Hub";
include 'php/header.php';

$endpoints = [
  ['GET',   '/v1/inventory',             'List inventory items',          ['location_id','category','low_stock','limit','offset'], '{"data":[{"id":"itm_1a2b","sku":"TOM-KG","name":"Tomatoes","quantity":4.5,"unit":"kg","location":"Main Kitchen","reorder_point":5,"status":"low"}],"total":1,"limit":50,"offset":0}'],
  ['POST',  '/v1/inventory',             'Create an inventory item',      ['sku (required)','name (required)','quantity (required)','unit (required)','location_id (required)','reorder_point'], '{"data":{"id":"itm_4d5e","sku":"CHK-KG","name":"Chicken Breast","quantity":20,"unit":"kg","status":"ok"},"message":"Item created"}'],
  ['PATCH', '/v1/inventory/{id}',        'Update an item',                ['quantity','reorder_point','name','notes'], '{"data":{"id":"itm_1a2b","quantity":12.5,"updated_at":"2025-04-06T10:32:00Z"},"message":"Item updated"}'],
  ['GET',   '/v1/locations',             'List all locations',            ['active (boolean)'], '{"data":[{"id":"loc_abc","name":"Main Branch","city":"Karachi","type":"retail","active":true}]}'],
  ['POST',  '/v1/purchase-orders',       'Create a purchase order',       ['supplier_id (required)','items (array, required)','expected_delivery','notes'], '{"data":{"id":"po_x9y8","status":"draft","supplier":"Al-Amin Traders","total_items":3},"message":"Purchase order created"}'],
  ['GET',   '/v1/reports/stock-summary', 'Get a stock summary report',    ['location_id','date_from','date_to','format (json|csv)'], '{"data":{"total_skus":4821,"low_stock_count":47,"total_value":2400000,"currency":"PKR"}}'],
];
$mc = ['GET'=>'#4ADE80','POST'=>'var(--orange)','PATCH'=>'#60A5FA','DELETE'=>'#F87171'];
?>

<div class="page-hero" style="background:var(--black);">
  <div style="display:inline-flex;align-items:center;gap:8px;background:rgba(255,107,0,.09);border:1px solid rgba(255,107,0,.25);border-radius:100px;padding:6px 18px;font-size:.73rem;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:var(--orange-light);margin-bottom:24px;">
    <span style="font-family:'JetBrains Mono',monospace;">v1.0</span> · REST API
  </div>
  <h1 class="section-title">Biltax <span>Developer</span> API</h1>
  <p class="section-sub">Integrate Biltax inventory data into your own apps, dashboards, and workflows. Simple, predictable REST API.</p>
  <div style="margin-top:28px;display:flex;gap:14px;flex-wrap:wrap;">
    <a href="#endpoints" class="btn btn-primary">Browse Endpoints →</a>
    <a href="contact.php" class="btn btn-outline">Request API Key</a>
  </div>
</div>

<section style="background:var(--black);padding:80px 60px;">
  <div style="display:grid;grid-template-columns:220px 1fr;gap:48px;align-items:start;" class="api-doc-grid">

    <div style="position:sticky;top:100px;" class="legal-toc-col">
      <div style="font-size:.72rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--gray);margin-bottom:16px;">Getting Started</div>
      <ul style="display:flex;flex-direction:column;gap:0;margin-bottom:28px;">
        <?php foreach(['Authentication','Base URL','Rate Limits','Errors'] as $item): ?>
        <li><a href="#<?= strtolower(str_replace(' ','-',$item)) ?>" style="display:block;padding:9px 14px;font-size:.85rem;font-weight:600;color:var(--gray);border-left:2px solid rgba(255,255,255,.06);transition:.2s;text-decoration:none;" onmouseenter="this.style.color='var(--orange)';this.style.borderColor='var(--orange)'" onmouseleave="this.style.color='var(--gray)';this.style.borderColor='rgba(255,255,255,.06)'"><?= $item ?></a></li>
        <?php endforeach; ?>
      </ul>
      <div style="font-size:.72rem;font-weight:700;letter-spacing:.2em;text-transform:uppercase;color:var(--gray);margin-bottom:16px;">Endpoints</div>
      <ul style="display:flex;flex-direction:column;gap:0;">
        <?php foreach(['Inventory','Locations','Purchase Orders','Reports'] as $item): ?>
        <li><a href="#endpoints" style="display:block;padding:9px 14px;font-size:.85rem;font-weight:600;color:var(--gray);border-left:2px solid rgba(255,255,255,.06);transition:.2s;text-decoration:none;" onmouseenter="this.style.color='var(--orange)';this.style.borderColor='var(--orange)'" onmouseleave="this.style.color='var(--gray)';this.style.borderColor='rgba(255,255,255,.06)'"><?= $item ?></a></li>
        <?php endforeach; ?>
      </ul>
    </div>

    <div class="legal-content-col">
      <div id="authentication" style="margin-bottom:56px;" class="reveal">
        <h2 style="font-family:'Bebas Neue',sans-serif;font-size:2.2rem;letter-spacing:.04em;color:var(--white);margin-bottom:16px;">Authentication</h2>
        <p style="font-size:.92rem;color:var(--gray-light);line-height:1.8;font-weight:500;margin-bottom:20px;">All API requests require a Bearer token in the Authorization header. Generate API keys from <strong style="color:var(--white);">Settings → API Access</strong>.</p>
        <div class="code-block"><div class="code-topbar"><span class="code-lang">HTTP</span><button class="copy-btn" onclick="copyCode(this)">Copy</button></div><pre><code>Authorization: Bearer biltax_live_xxxxxxxxxxxxxxxxxxxxxxxx</code></pre></div>
        <div style="background:rgba(255,107,0,.07);border:1px solid rgba(255,107,0,.2);border-radius:6px;padding:14px 18px;font-size:.84rem;color:var(--gray-light);font-weight:500;margin-top:14px;">⚠ Never expose your API key in client-side code. Use environment variables or a server-side proxy.</div>
      </div>

      <div id="base-url" style="margin-bottom:56px;" class="reveal">
        <h2 style="font-family:'Bebas Neue',sans-serif;font-size:2.2rem;letter-spacing:.04em;color:var(--white);margin-bottom:16px;">Base URL</h2>
        <div class="code-block"><div class="code-topbar"><span class="code-lang">URL</span><button class="copy-btn" onclick="copyCode(this)">Copy</button></div><pre><code>https://api.biltax.com/v1</code></pre></div>
      </div>

      <div id="rate-limits" style="margin-bottom:56px;" class="reveal">
        <h2 style="font-family:'Bebas Neue',sans-serif;font-size:2.2rem;letter-spacing:.04em;color:var(--white);margin-bottom:16px;">Rate Limits</h2>
        <div style="overflow-x:auto;">
          <table style="width:100%;border-collapse:collapse;font-size:.85rem;">
            <tr style="border-bottom:1px solid rgba(255,107,0,.15);">
              <th style="text-align:left;padding:12px 16px;color:var(--gray);font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;font-weight:700;">Plan</th>
              <th style="text-align:center;padding:12px 16px;color:var(--gray);font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;font-weight:700;">Requests/Min</th>
              <th style="text-align:center;padding:12px 16px;color:var(--gray);font-size:.72rem;letter-spacing:.12em;text-transform:uppercase;font-weight:700;">Requests/Day</th>
            </tr>
            <?php foreach([['Starter','60','10,000'],['Business','300','100,000'],['Enterprise','Unlimited','Unlimited']] as $i=>$r): ?>
            <tr style="border-bottom:1px solid rgba(255,255,255,.04);background:<?= $i%2===0?'rgba(255,255,255,.015)':'transparent' ?>">
              <td style="padding:12px 16px;color:var(--gray-light);font-weight:600;"><?= $r[0] ?></td>
              <td style="padding:12px 16px;color:var(--white);font-weight:700;text-align:center;"><?= $r[1] ?></td>
              <td style="padding:12px 16px;color:var(--white);font-weight:700;text-align:center;"><?= $r[2] ?></td>
            </tr>
            <?php endforeach; ?>
          </table>
        </div>
      </div>

      <div id="errors" style="margin-bottom:56px;" class="reveal">
        <h2 style="font-family:'Bebas Neue',sans-serif;font-size:2.2rem;letter-spacing:.04em;color:var(--white);margin-bottom:16px;">Error Codes</h2>
        <div class="code-block"><div class="code-topbar"><span class="code-lang">JSON</span><button class="copy-btn" onclick="copyCode(this)">Copy</button></div><pre><code>{"error":{"code":"ITEM_NOT_FOUND","message":"No item found with that ID","status":404}}</code></pre></div>
        <div style="margin-top:16px;display:flex;flex-direction:column;gap:8px;">
          <?php foreach([['200','OK','Request successful','#4ADE80'],['201','Created','Resource created','#4ADE80'],['400','Bad Request','Invalid parameters','var(--orange)'],['401','Unauthorized','Invalid or missing API key','var(--orange)'],['404','Not Found','Resource not found','var(--orange)'],['429','Too Many Requests','Rate limit exceeded','#F87171'],['500','Server Error','Internal server error','#F87171']] as $e): ?>
          <div style="display:flex;align-items:center;gap:16px;background:var(--black-3);border:1px solid rgba(255,255,255,.05);border-radius:4px;padding:11px 17px;">
            <span style="font-family:'JetBrains Mono',monospace;font-size:.85rem;font-weight:700;color:<?= $e[3] ?>;min-width:38px;"><?= $e[0] ?></span>
            <span style="font-size:.82rem;font-weight:700;color:var(--white);min-width:130px;"><?= $e[1] ?></span>
            <span style="font-size:.82rem;color:var(--gray);font-weight:500;"><?= $e[2] ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>

      <div id="endpoints" class="reveal">
        <h2 style="font-family:'Bebas Neue',sans-serif;font-size:2.5rem;letter-spacing:.04em;color:var(--white);margin-bottom:8px;">API <span style="color:var(--orange)">Endpoints</span></h2>
        <p style="font-size:.92rem;color:var(--gray-light);line-height:1.8;font-weight:500;margin-bottom:36px;">Complete reference for all available endpoints.</p>
        <?php foreach($endpoints as $ep):
          $color = $mc[$ep[0]] ?? 'var(--gray)';
        ?>
        <div style="background:var(--black-3);border:1px solid rgba(255,255,255,.06);border-radius:6px;margin-bottom:20px;overflow:hidden;" class="reveal">
          <div style="display:flex;align-items:center;gap:12px;padding:16px 22px;border-bottom:1px solid rgba(255,255,255,.05);flex-wrap:wrap;">
            <span style="font-family:'JetBrains Mono',monospace;font-size:.76rem;font-weight:700;color:<?= $color ?>;background:rgba(0,0,0,.3);border:1px solid <?= $color ?>;border-radius:3px;padding:3px 10px;letter-spacing:.08em;"><?= $ep[0] ?></span>
            <code style="font-family:'JetBrains Mono',monospace;font-size:.88rem;color:var(--white);font-weight:600;"><?= $ep[1] ?></code>
            <span style="font-size:.8rem;color:var(--gray);font-weight:500;margin-left:auto;"><?= $ep[2] ?></span>
          </div>
          <div style="padding:18px 22px;">
            <div style="font-size:.72rem;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:var(--gray);margin-bottom:9px;">Parameters</div>
            <div style="display:flex;flex-wrap:wrap;gap:7px;margin-bottom:18px;">
              <?php foreach($ep[3] as $p): ?>
              <span style="font-family:'JetBrains Mono',monospace;font-size:.76rem;background:rgba(255,107,0,.06);border:1px solid rgba(255,107,0,.18);border-radius:3px;padding:3px 9px;color:var(--orange-light);"><?= htmlspecialchars($p) ?></span>
              <?php endforeach; ?>
            </div>
            <div style="font-size:.72rem;font-weight:700;letter-spacing:.15em;text-transform:uppercase;color:var(--gray);margin-bottom:9px;">Example Response</div>
            <div class="code-block" style="margin:0;"><div class="code-topbar"><span class="code-lang">JSON</span><button class="copy-btn" onclick="copyCode(this)">Copy</button></div><pre><code><?= htmlspecialchars($ep[4]) ?></code></pre></div>
          </div>
        </div>
        <?php endforeach; ?>
      </div>

      <div style="margin-top:56px;" class="reveal">
        <h2 style="font-family:'Bebas Neue',sans-serif;font-size:2.2rem;letter-spacing:.04em;color:var(--white);margin-bottom:16px;">SDKs & Libraries</h2>
        <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;" class="api-sdk-grid">
          <?php foreach([['Node.js','npm install biltax-node','🟢'],['Python','pip install biltax','🐍'],['PHP','composer require biltax/sdk','🐘']] as $s): ?>
          <div style="background:var(--black-3);border:1px solid rgba(255,255,255,.06);border-radius:6px;padding:22px;">
            <div style="font-size:1.8rem;margin-bottom:10px;"><?= $s[2] ?></div>
            <div style="font-size:.88rem;font-weight:700;color:var(--white);margin-bottom:10px;"><?= $s[0] ?></div>
            <div class="code-block" style="margin:0;"><pre style="font-size:.76rem;padding:9px 12px;"><code><?= $s[1] ?></code></pre></div>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
  </div>
</section>

<section id="cta-section">
  <div class="cta-tag">Start building today</div>
  <div class="cta-title">GET YOUR<br>API KEY FREE</div>
  <p class="cta-sub">Starter plan includes 10,000 API calls per day — free forever.</p>
  <div class="cta-actions">
    <a href="demo.php" class="btn btn-dark">Create Free Account →</a>
    <a href="contact.php" class="btn" style="background:transparent;color:var(--black);border:2px solid rgba(0,0,0,.3);">Talk to Developer Support</a>
  </div>
</section>

<?php include 'php/footer.php'; ?>
