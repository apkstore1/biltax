<?php
$page_title = "Mobile App — Biltax Inventory on the Go";
include 'php/header.php';
?>
<style>
.app-store-btn{display:inline-flex;align-items:center;gap:11px;background:var(--black-3);border:1px solid rgba(255,255,255,.12);border-radius:10px;padding:12px 20px;color:var(--white);transition:.2s;cursor:none;text-decoration:none;min-width:160px;}
.app-store-btn:hover{border-color:var(--orange);background:rgba(255,107,0,.06);transform:translateY(-2px);box-shadow:0 8px 28px rgba(255,107,0,.15);}
.phone-mockup{width:240px;background:var(--black-3);border:2px solid rgba(255,107,0,.2);border-radius:32px;overflow:hidden;position:relative;box-shadow:0 40px 80px rgba(0,0,0,.6),0 0 50px rgba(255,107,0,.06);margin:0 auto;}
.phone-notch{width:80px;height:20px;background:var(--black);border-radius:0 0 12px 12px;margin:0 auto;position:relative;z-index:10;}
.phone-screen{padding:8px 14px 14px;}.phone-topbar{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;}
.phone-greeting{font-size:.75rem;font-weight:700;color:var(--white);margin-bottom:12px;}
.phone-kpis{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:14px;}
.phone-kpi{background:var(--black-4);border-radius:8px;padding:8px 6px;text-align:center;}
.phone-kpi-num{font-family:'Bebas Neue',sans-serif;font-size:1.3rem;line-height:1;color:var(--white);}
.phone-kpi-lbl{font-size:.58rem;color:var(--gray);letter-spacing:.08em;text-transform:uppercase;font-weight:600;margin-top:2px;}
.phone-section-title{font-size:.65rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--gray);margin-bottom:7px;}
.phone-actions{display:grid;grid-template-columns:1fr 1fr;gap:6px;}
.phone-action{background:var(--black-4);border:1px solid rgba(255,107,0,.12);border-radius:7px;padding:9px 8px;font-size:.67rem;font-weight:600;color:var(--gray-light);}
.phone-item{font-size:.67rem;color:var(--gray-light);font-weight:500;padding:5px 0;border-bottom:1px solid rgba(255,255,255,.04);display:flex;align-items:center;gap:7px;}
.phone-home-bar{width:70px;height:3px;background:rgba(255,255,255,.15);border-radius:2px;margin:10px auto;}
</style>

<section class="hero" style="min-height:90vh;padding:140px 60px 80px;">
  <div class="hero-grid"></div><div class="hero-glow-1"></div><div class="hero-glow-2"></div>
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center;max-width:1200px;" class="mobile-hero-grid">
    <div>
      <div class="hero-badge">📱 Available on iOS & Android</div>
      <h1 class="hero-title" style="font-size:clamp(3.5rem,7vw,7rem);">Your Inventory.<br><span class="accent">In Your</span><br><span class="outline">Pocket.</span></h1>
      <p class="hero-sub">The Biltax mobile app is a lightweight, powerful companion to our web platform — built for owners, managers, and staff who need real-time inventory control on the go.</p>
      <div class="hero-actions" style="flex-wrap:wrap;gap:14px;margin-top:36px;">
        <a href="https://play.google.com/store" target="_blank" rel="noopener" class="app-store-btn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M3.18 23.76a2 2 0 001.94-.21l12.26-7.09-2.93-2.93-11.27 10.23zm-1.5-21.22v20.92c0 .6.34 1.12.84 1.39L14.04 12 2.52.21A1.63 1.63 0 001.68 2.54zm20.33 8.66l-2.83-1.64-3.2 3.2 3.2 3.2 2.87-1.66a1.63 1.63 0 000-3.1zM5.12.45L17.38 7.54l-2.93 2.93L3.18.24A2 2 0 005.12.45z"/></svg>
          <div><div style="font-size:.65rem;opacity:.7;letter-spacing:.08em;text-transform:uppercase;">Download on</div><div style="font-size:1rem;font-weight:700;line-height:1.2;">Google Play</div></div>
        </a>
        <a href="https://apps.apple.com" target="_blank" rel="noopener" class="app-store-btn">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98l-.09.06c-.22.15-2.18 1.27-2.16 3.8.03 3.02 2.65 4.03 2.68 4.04l-.07.28zM13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
          <div><div style="font-size:.65rem;opacity:.7;letter-spacing:.08em;text-transform:uppercase;">Download on the</div><div style="font-size:1rem;font-weight:700;line-height:1.2;">App Store</div></div>
        </a>
      </div>
      <div style="margin-top:24px;font-size:.8rem;color:var(--gray);font-weight:500;">⭐⭐⭐⭐⭐ &nbsp;4.8 / 5 &nbsp;·&nbsp; 2,400+ ratings &nbsp;·&nbsp; Free to download</div>
    </div>
    <div class="phone-mockup-wrap" style="display:flex;justify-content:center;align-items:center;position:relative;">
      <div class="phone-mockup">
        <div class="phone-notch"></div>
        <div class="phone-screen">
          <div class="phone-topbar">
            <img src="images/biltax-logo-horizontal.png" alt="Biltax" style="height:22px;width:auto;">
            <span style="font-size:.7rem;color:var(--gray);">9:41</span>
          </div>
          <div class="phone-greeting">Good morning, Ahmed 👋</div>
          <div class="phone-kpis">
            <div class="phone-kpi"><div class="phone-kpi-num" style="color:var(--orange);">47</div><div class="phone-kpi-lbl">Low Stock</div></div>
            <div class="phone-kpi"><div class="phone-kpi-num">128</div><div class="phone-kpi-lbl">Orders</div></div>
            <div class="phone-kpi"><div class="phone-kpi-num" style="color:#4ADE80;">98%</div><div class="phone-kpi-lbl">Accuracy</div></div>
          </div>
          <div class="phone-section-title">Quick Actions</div>
          <div class="phone-actions">
            <div class="phone-action">📦 Scan Stock</div><div class="phone-action">🛒 New Order</div>
            <div class="phone-action">📊 Reports</div><div class="phone-action">🔔 Alerts</div>
          </div>
          <div class="phone-section-title" style="margin-top:16px;">Recent Activity</div>
          <div class="phone-item"><span style="color:var(--orange);">●</span> Tomatoes — Low stock alert</div>
          <div class="phone-item"><span style="color:#4ADE80;">●</span> PO #1042 sent to Al-Amin</div>
          <div class="phone-item"><span style="color:var(--gray-light);">●</span> Ahmed scanned 48 items</div>
        </div>
        <div class="phone-home-bar"></div>
      </div>
    </div>
  </div>
</section>

<div class="ticker"><div class="ticker-track" id="tickerTrack"><span>Barcode Scanning</span><span class="dot">◆</span><span>Live Stock Levels</span><span class="dot">◆</span><span>Push Alerts</span><span class="dot">◆</span><span>Purchase Orders</span><span class="dot">◆</span><span>Offline Mode</span><span class="dot">◆</span><span>Multi-Location</span><span class="dot">◆</span><span>Role-Based Access</span><span class="dot">◆</span><span>Instant Reports</span><span class="dot">◆</span><span>Barcode Scanning</span><span class="dot">◆</span><span>Live Stock Levels</span><span class="dot">◆</span><span>Push Alerts</span><span class="dot">◆</span><span>Purchase Orders</span><span class="dot">◆</span></div></div>

<section style="background:var(--black-2);padding:110px 60px;">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center;">
    <div class="reveal">
      <span class="section-tag">About the App</span>
      <h2 class="section-title">A Lighter Version of<br>Our <span>Web Platform</span></h2>
      <p class="section-sub" style="max-width:100%;">The Biltax mobile app is designed to keep your team moving — without the full complexity of the web dashboard. It puts the most critical actions in the palm of your hand: scanning, stock checks, alerts, and quick reports.</p>
      <p style="margin-top:18px;font-size:.95rem;color:var(--gray);line-height:1.8;font-weight:500;">Think of it as your inventory remote control. Your web dashboard is mission control; the app is what your floor staff, delivery team, and branch managers use every day without needing a laptop.</p>
      <div style="margin-top:32px;display:flex;gap:14px;flex-wrap:wrap;">
        <a href="https://play.google.com/store" target="_blank" class="btn btn-primary">Download on Play Store</a>
        <a href="https://apps.apple.com" target="_blank" class="btn btn-outline">Download on App Store</a>
      </div>
    </div>
    <div class="reveal comparison-table-wrap" style="overflow-x:auto;">
      <?php $cmp=[['Feature','Web Platform','Mobile App'],['Full Analytics Dashboard','✓','✓ (Summary)'],['Barcode Scanning','✓','✓'],['Live Stock Levels','✓','✓'],['Push Notifications','—','✓'],['AI Forecasting & Reports','✓','—'],['Purchase Order Creation','✓','✓ (Quick)'],['Multi-Location Switch','✓','✓'],['Offline Mode','—','✓'],['Bulk Import/Export','✓','—'],['Supplier Management','✓','View only'],['User & Role Management','✓','—']];?>
      <table style="width:100%;border-collapse:collapse;font-size:.84rem;min-width:400px;">
        <?php foreach($cmp as $i=>$row):?>
        <tr style="border-bottom:1px solid rgba(255,255,255,0.06);background:<?=($i===0)?'rgba(255,107,0,0.06)':(($i%2===0)?'rgba(255,255,255,0.015)':'transparent')?>">
          <?php foreach($row as $j=>$cell):$c=($i===0)?'var(--gray)':($j===0?'var(--gray-light)':($cell==='✓'?'#4ADE80':($cell==='—'?'var(--gray)':'var(--orange)')));?>
          <td style="padding:12px 16px;color:<?=$c?>;font-weight:<?=($i===0||$j===0)?'700':'500'?>;text-align:<?=$j===0?'left':'center'?>;font-size:<?=$i===0?'.72rem':'.84rem'?>;letter-spacing:<?=$i===0?'.12em':'0'?>;text-transform:<?=$i===0?'uppercase':'none'?>;"><?=$cell?></td>
          <?php endforeach;?>
        </tr><?php endforeach;?>
      </table>
    </div>
  </div>
</section>

<section style="background:var(--black);padding:110px 60px;">
  <div style="text-align:center;margin-bottom:70px;" class="reveal">
    <span class="section-tag">App Features</span>
    <h2 class="section-title">Built for the <span>Shop Floor</span></h2>
    <p class="section-sub" style="margin:0 auto;">Every feature is optimised for speed, one-handed use, and low-light warehouse environments.</p>
  </div>
  <div class="features-grid">
    <?php $af=[['📷','Barcode & QR Scanning','Use your phone camera to scan any barcode or QR code. Instantly look up stock levels, update quantities, or add new stock.'],['🔔','Smart Push Notifications','Get instant alerts for low stock, pending purchase orders, and expiry warnings — even when the app is closed.'],['📶','Full Offline Mode','Keep working even without internet. All scans and updates sync automatically when connectivity is restored.'],['🔄','Real-Time Sync','Every action syncs instantly with your web dashboard. No delays, no manual reconciliation.'],['🏪','Multi-Location Switch','Switch between branches and warehouses in one tap. See stock at any location instantly.'],['📋','Quick Stock Count','Run a stocktake from your phone. Scan items, enter quantities, and submit — all within the app.']];
    foreach($af as $i=>$f):?>
    <div class="feature-card reveal"><div class="feature-icon"><?=$f[0]?></div><h3><?=$f[1]?></h3><p><?=$f[2]?></p><div class="feature-num">0<?=$i+1?></div></div>
    <?php endforeach;?>
  </div>
</section>

<section id="scanner" style="background:var(--black-2);padding:110px 60px;">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center;">
    <div class="reveal">
      <div style="background:var(--orange);width:80px;height:80px;border-radius:18px;display:flex;align-items:center;justify-content:center;font-size:2.5rem;margin-bottom:28px;box-shadow:0 0 40px rgba(255,107,0,0.3);">📡</div>
      <span class="section-tag">Companion Tool</span>
      <h2 class="section-title">Biltax <span>Scanner</span> App</h2>
      <p class="section-sub" style="max-width:100%;">A dedicated, ultra-lightweight barcode scanner app — completely separate from the main Biltax app. No login required after setup. Designed for high-volume scanning environments like warehouses and stockrooms.</p>
      <p style="margin-top:18px;font-size:.95rem;color:var(--gray);line-height:1.8;font-weight:500;">The Scanner app connects to your Biltax account via a QR-code pairing system. Staff members can scan hundreds of items per minute, and all data flows directly into your inventory.</p>
      <div style="margin-top:32px;">
        <div style="font-size:.78rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--gray);margin-bottom:16px;">Download Biltax Scanner</div>
        <div style="display:flex;gap:12px;flex-wrap:wrap;">
          <a href="https://play.google.com/store" target="_blank" rel="noopener" class="app-store-btn" style="background:rgba(255,107,0,0.08);border-color:rgba(255,107,0,0.3);"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M3.18 23.76a2 2 0 001.94-.21l12.26-7.09-2.93-2.93-11.27 10.23zm-1.5-21.22v20.92c0 .6.34 1.12.84 1.39L14.04 12 2.52.21A1.63 1.63 0 001.68 2.54zm20.33 8.66l-2.83-1.64-3.2 3.2 3.2 3.2 2.87-1.66a1.63 1.63 0 000-3.1zM5.12.45L17.38 7.54l-2.93 2.93L3.18.24A2 2 0 005.12.45z"/></svg><div><div style="font-size:.62rem;opacity:.7;letter-spacing:.08em;text-transform:uppercase;">Get it on</div><div style="font-size:.95rem;font-weight:700;">Google Play</div></div></a>
          <a href="https://apps.apple.com" target="_blank" rel="noopener" class="app-store-btn" style="background:rgba(255,107,0,0.08);border-color:rgba(255,107,0,0.3);"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98l-.09.06c-.22.15-2.18 1.27-2.16 3.8.03 3.02 2.65 4.03 2.68 4.04l-.07.28zM13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg><div><div style="font-size:.62rem;opacity:.7;letter-spacing:.08em;text-transform:uppercase;">Download on the</div><div style="font-size:.95rem;font-weight:700;">App Store</div></div></a>
        </div>
        <div style="margin-top:20px;"><a href="#" style="display:inline-flex;align-items:center;gap:8px;font-size:.84rem;font-weight:600;color:var(--orange);text-decoration:none;">⬇ Download APK directly (Android) →</a></div>
      </div>
    </div>
    <div class="reveal">
      <?php $sf=[['⚡','Lightning Fast Scanning','Scans up to 200 barcodes per minute using your device camera or a paired Bluetooth scanner.'],['🔗','One-Tap Pairing','Pair with your Biltax account by scanning a QR code — no typing, no complex setup.'],['📦','Receive & Dispatch','Scan incoming stock receipts or outbound shipments and update inventory instantly.'],['🔋','Battery Optimised','Designed to run all day on a single charge. Works even on older Android devices.']];
      foreach($sf as $s):?>
      <div style="display:flex;gap:18px;margin-bottom:28px;background:var(--black-3);border:1px solid rgba(255,107,0,0.1);border-radius:6px;padding:24px;">
        <div style="font-size:1.8rem;flex-shrink:0;"><?=$s[0]?></div>
        <div><h4 style="font-size:.95rem;font-weight:700;color:var(--white);margin-bottom:6px;"><?=$s[1]?></h4><p style="font-size:.84rem;color:var(--gray);line-height:1.6;font-weight:500;"><?=$s[2]?></p></div>
      </div><?php endforeach;?>
    </div>
  </div>
</section>

<section id="cta-section">
  <div class="cta-tag">Free on iOS & Android</div>
  <div class="cta-title">DOWNLOAD<br>BILTAX NOW</div>
  <p class="cta-sub">Start managing your inventory from anywhere. Fully free — no credit card required.</p>
  <div class="cta-actions">
    <a href="https://play.google.com/store" target="_blank" class="btn btn-dark">Get it on Google Play</a>
    <a href="https://apps.apple.com" target="_blank" class="btn" style="background:transparent;color:var(--black);border:2px solid rgba(0,0,0,0.3);">Download on App Store</a>
  </div>
</section>
<?php include 'php/footer.php'; ?>
