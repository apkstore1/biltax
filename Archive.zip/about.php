<?php
$page_title = "About Us — Biltax Inventory Management";
include 'php/header.php';
$team=[['AG','Azka Abdul Ghafoor','CEO & Co-Founder','Former supply chain director with 15 years experience across retail and distribution.'],['MM','Muhammad Mushariq','CTO & Co-Founder','Full-stack engineer and ex-lead developer at a major logistics tech firm in Dubai.'],['SA','Sufyan Ahmed','Head of Product','Product strategist passionate about making complex operations simple for every business.'],['AA','Ayesha Ahmed','Head of Customer Success','Ensures every Biltax customer gets maximum value and grows their business faster.']];
$values=[['⚡','Speed First','We build fast, ship fast, and help your business move fast. No bloat, no bureaucracy.'],['🎯','Customer Obsessed','Every feature we build starts and ends with a real customer problem. We listen before we code.'],['🔒','Data You Can Trust','Accuracy is non-negotiable. We hold ourselves to the highest standards of data integrity and security.'],['🌍','Built for Pakistan','We understand the local business landscape — from Karachi markets to Lahore malls — and build accordingly.']];
?>
<div class="page-hero">
  <span class="section-tag">Our Story</span>
  <h1 class="section-title">We're Building <span>Better Business</span> Infrastructure</h1>
  <p class="section-sub">Biltax was founded in Karachi in 2021 by operators who had lived the pain of broken inventory management firsthand. We decided to fix it.</p>
</div>
<section style="background:var(--black);padding:100px 60px;">
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:80px;align-items:center;">
    <div class="reveal">
      <span class="section-tag">Our Mission</span>
      <h2 class="section-title">Give Every Business <span>Visibility</span></h2>
      <p class="section-sub" style="max-width:100%;">Too many businesses in Pakistan and across South Asia are still running inventory on spreadsheets, paper logs, or outdated systems that weren't built for them.</p>
      <p style="margin-top:18px;font-size:.98rem;color:var(--gray);line-height:1.8;font-weight:500;">Biltax was built to change that. We believe every business — from a single-chair barbershop to a 20-branch restaurant chain — deserves the same real-time visibility into their inventory that Fortune 500 companies have.</p>
      <p style="margin-top:18px;font-size:.98rem;color:var(--gray);line-height:1.8;font-weight:500;">Our platform is built from the ground up for local market conditions: multi-currency support, Urdu interface, local payment gateways, and integrations with the POS systems that Pakistani businesses actually use.</p>
    </div>
    <div class="reveal">
      <div style="background:var(--orange);border-radius:6px;padding:56px 48px;position:relative;overflow:hidden;">
        <div style="position:absolute;top:-20px;right:-20px;font-family:'Bebas Neue',sans-serif;font-size:8rem;color:rgba(0,0,0,0.08);line-height:1;pointer-events:none;">2026</div>
        <div style="font-family:'Bebas Neue',sans-serif;font-size:1rem;letter-spacing:.2em;color:rgba(0,0,0,0.5);margin-bottom:20px;text-transform:uppercase;">Founded</div>
        <blockquote style="font-family:'Bebas Neue',sans-serif;font-size:2.4rem;line-height:1.1;color:var(--black);letter-spacing:.02em;margin-bottom:24px;">"We built the system we always wished we had."</blockquote>
        <div style="font-size:.88rem;font-weight:700;color:rgba(0,0,0,0.65);">— Azka Abdul Ghafoor, CEO & Co-Founder</div>
      </div>
    </div>
  </div>
</section>
<section style="background:var(--black-2);padding:0 60px;">
  <div class="about-stats reveal">
    <div class="about-stat"><div class="about-stat-num">12K+</div><div class="about-stat-label">Active Businesses</div></div>
    <div class="about-stat"><div class="about-stat-num">5M+</div><div class="about-stat-label">Products Tracked Daily</div></div>
    <div class="about-stat"><div class="about-stat-num">8</div><div class="about-stat-label">Industries Served</div></div>
    <div class="about-stat"><div class="about-stat-num">99.9%</div><div class="about-stat-label">Platform Uptime</div></div>
  </div>
</section>
<section style="background:var(--black-2);padding:60px 60px 100px;">
  <div style="text-align:center;margin-bottom:60px;" class="reveal">
    <span class="section-tag">Our Values</span><h2 class="section-title">What We <span>Stand For</span></h2>
  </div>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;" class="perks-grid">
    <?php foreach($values as $v):?>
    <div class="feature-card reveal" style="text-align:center;padding:44px 28px;">
      <div style="font-size:2.4rem;margin-bottom:20px;"><?=$v[0]?></div>
      <h3 style="margin-bottom:12px;"><?=$v[1]?></h3><p><?=$v[2]?></p>
    </div><?php endforeach;?>
  </div>
</section>
<section style="background:var(--black);padding:100px 60px;">
  <div style="margin-bottom:60px;" class="reveal">
    <span class="section-tag">The Team</span>
    <h2 class="section-title">Meet the <span>Founders</span></h2>
    <p class="section-sub">A small, focused team of operators and engineers obsessed with solving real business problems.</p>
  </div>
  <div class="team-grid">
    <?php foreach($team as $m):?>
    <div class="team-card reveal">
      <div class="team-photo"><?=$m[0]?></div>
      <div class="team-info">
        <div class="team-name"><?=$m[1]?></div>
        <div class="team-role"><?=$m[2]?></div>
        <p style="font-size:.82rem;color:var(--gray);margin-top:10px;line-height:1.6;font-weight:500;"><?=$m[3]?></p>
      </div>
    </div><?php endforeach;?>
  </div>
</section>
<section id="cta-section">
  <div class="cta-tag">Join the Biltax family</div>
  <div class="cta-title">LET'S BUILD<br>TOGETHER</div>
  <p class="cta-sub">12,000+ Pakistani businesses trust Biltax to run their inventory. Will you be next?</p>
  <div class="cta-actions">
    <a href="demo.php" class="btn btn-dark">Get Started Free →</a>
    <a href="contact.php" class="btn" style="background:transparent;color:var(--black);border:2px solid rgba(0,0,0,0.3);">Contact Us</a>
  </div>
</section>
<?php include 'php/footer.php'; ?>
