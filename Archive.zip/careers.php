<?php
$page_title = "Careers — Join the Biltax Team";
require_once __DIR__ . '/php/db.php';
$jobs = careers_fetch_active();
$departments = careers_departments($jobs);
$job_count = count($jobs);
$db_error = (biltax_db() === null);
$type_colors=['Full-time'=>'rgba(74,222,128,0.1)','Part-time'=>'rgba(255,107,0,0.1)','Contract'=>'rgba(96,165,250,0.1)','Internship'=>'rgba(192,132,252,0.1)'];
$type_borders=['Full-time'=>'rgba(74,222,128,0.3)','Part-time'=>'rgba(255,107,0,0.3)','Contract'=>'rgba(96,165,250,0.3)','Internship'=>'rgba(192,132,252,0.3)'];
$type_text=['Full-time'=>'#4ADE80','Part-time'=>'var(--orange)','Contract'=>'#60A5FA','Internship'=>'#C084FC'];
$dept_colors=['Engineering'=>'var(--orange)','Product'=>'#C084FC','Sales'=>'#4ADE80','Customer Success'=>'#60A5FA','Marketing'=>'#FBBF24','Operations'=>'#F87171'];
include 'php/header.php';
?>
<section class="hero" style="min-height:70vh;padding:140px 60px 80px;">
  <div class="hero-grid"></div><div class="hero-glow-1"></div>
  <?php if($job_count>0):?><div class="hero-badge">🚀 We're hiring — <?=$job_count?> open role<?=$job_count!==1?'s':''?></div><?php else:?><div class="hero-badge">🌟 Join our growing team</div><?php endif;?>
  <h1 class="hero-title" style="font-size:clamp(3.5rem,8vw,8rem);">Build the<br><span class="accent">Future of</span><br><span class="outline">Business.</span></h1>
  <p class="hero-sub">We're a small, focused team obsessed with solving real problems for Pakistani businesses. If you want to do the best work of your career — you're in the right place.</p>
  <div class="hero-stats" style="margin-top:60px;">
    <div class="stat-item"><div class="stat-num">24</div><div class="stat-label">Team Members</div></div>
    <div class="stat-item"><div class="stat-num">4.9</div><div class="stat-label">Glassdoor Rating</div></div>
    <div class="stat-item"><div class="stat-num"><?=$job_count?></div><div class="stat-label">Open Position<?=$job_count!==1?'s':''?></div></div>
    <div class="stat-item"><div class="stat-num">100%</div><div class="stat-label">Remote Friendly</div></div>
  </div>
</section>
<div class="ticker"><div class="ticker-track" id="tickerTrack"><span>Remote-First Culture</span><span class="dot">◆</span><span>Competitive Salaries</span><span class="dot">◆</span><span>Equity for All</span><span class="dot">◆</span><span>Health Insurance</span><span class="dot">◆</span><span>Learning Budget</span><span class="dot">◆</span><span>Flexible Hours</span><span class="dot">◆</span><span>Annual Retreats</span><span class="dot">◆</span><span>Real Impact</span><span class="dot">◆</span><span>Remote-First Culture</span><span class="dot">◆</span><span>Competitive Salaries</span><span class="dot">◆</span><span>Equity for All</span><span class="dot">◆</span></div></div>
<section style="background:var(--black-2);padding:110px 60px;">
  <div style="text-align:center;margin-bottom:70px;" class="reveal"><span class="section-tag">Why Biltax?</span><h2 class="section-title">Work That <span>Matters.</span><br>Benefits That Do Too.</h2></div>
  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:20px;" class="perks-grid">
    <?php $perks=[['💰','Competitive Pay','Market-rate salaries benchmarked against top Pakistani and regional tech companies — reviewed annually.'],['📈','Equity / ESOP','We believe everyone who builds Biltax should own a piece of it. Equity offered to all full-time employees.'],['🏥','Health Insurance','Full family health coverage from day one — for you, your spouse, and children.'],['🎓','₨50K Learning Budget','Annual budget for courses, books, conferences, or certifications. Use it for anything that makes you better.'],['🏠','Remote-First','Work from anywhere in Pakistan. We have offices in Karachi and Lahore for those who prefer them.'],['⏰','Flexible Hours','Ship great work on your schedule. Core hours are 11am–4pm PKT; the rest is yours to manage.'],['✈️','Annual Retreat','Whole team comes together once a year for a company retreat — fully paid travel, accommodation & food.'],['🛒','Team Perks','Biltax account for your own business, equipment budget, paid leave, and festival bonuses.']];
    foreach($perks as $p):?><div class="feature-card reveal" style="text-align:center;padding:40px 26px;"><div style="font-size:2.2rem;margin-bottom:18px;"><?=$p[0]?></div><h3 style="margin-bottom:10px;"><?=$p[1]?></h3><p><?=$p[2]?></p></div><?php endforeach;?>
  </div>
</section>
<section id="jobs" style="background:var(--black);padding:110px 60px;">
  <?php if($db_error):?>
  <div class="reveal" style="text-align:center;padding:80px 0;"><div style="font-size:3rem;margin-bottom:20px;">⚠️</div><h2 class="section-title" style="font-size:2.5rem;">Listings Temporarily Unavailable</h2><p style="font-size:.95rem;color:var(--gray);max-width:480px;margin:0 auto 32px;line-height:1.8;font-weight:500;">We're having trouble loading our open positions right now. Please send your CV directly.</p><a href="mailto:careers@biltax.com" class="btn btn-primary">Email careers@biltax.com →</a></div>
  <?php elseif($job_count===0):?>
  <div class="reveal" style="text-align:center;padding:80px 0;"><div style="font-size:3rem;margin-bottom:20px;">🔍</div><h2 class="section-title" style="font-size:2.5rem;">No Open Positions <span>Right Now</span></h2><p style="font-size:.95rem;color:var(--gray);max-width:500px;margin:0 auto 32px;line-height:1.8;font-weight:500;">We don't have any active roles at the moment, but we're always growing. Send us your CV — if you're exceptional, we'll make room.</p><a href="mailto:careers@biltax.com" class="btn btn-primary">Send Your CV →</a></div>
  <?php else:?>
  <div style="display:flex;align-items:flex-end;justify-content:space-between;margin-bottom:56px;flex-wrap:wrap;gap:24px;" class="reveal">
    <div><span class="section-tag">Open Positions</span><h2 class="section-title"><?=$job_count?> Role<?=$job_count!==1?'s':''?> <span>Available Now</span></h2></div>
    <?php if(count($departments)>2):?>
    <div style="display:flex;flex-wrap:wrap;gap:8px;" id="filterBtns">
      <?php foreach($departments as $i=>$dept):?><button onclick="filterJobs('<?=htmlspecialchars($dept,ENT_QUOTES)?>')" class="filter-btn<?=$i===0?' active':''?>" data-dept="<?=htmlspecialchars($dept,ENT_QUOTES)?>"><?=htmlspecialchars($dept)?></button><?php endforeach;?>
    </div><?php endif;?>
  </div>
  <div id="jobList" style="display:flex;flex-direction:column;gap:16px;">
    <?php foreach($jobs as $job):
      $tb=$type_colors[$job['employment_type']]??'rgba(255,255,255,0.05)';
      $tbd=$type_borders[$job['employment_type']]??'rgba(255,255,255,0.1)';
      $tc=$type_text[$job['employment_type']]??'var(--gray-light)';
      $dc=$dept_colors[$job['department']]??'var(--orange)';
      $href=!empty($job['apply_url'])?htmlspecialchars($job['apply_url'],ENT_QUOTES):'mailto:'.htmlspecialchars($job['apply_email']??'careers@biltax.com',ENT_QUOTES).'?subject=Application: '.rawurlencode($job['title']);
      $tgt=!empty($job['apply_url'])?'target="_blank" rel="noopener"':'';
    ?>
    <div class="job-card reveal" data-dept="<?=htmlspecialchars($job['department'],ENT_QUOTES)?>">
      <div style="display:flex;align-items:flex-start;justify-content:space-between;gap:24px;flex-wrap:wrap;">
        <div style="flex:1;min-width:0;">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:10px;flex-wrap:wrap;">
            <span style="font-size:.72rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:<?=$dc?>;"><?=htmlspecialchars($job['department'])?></span>
            <span style="width:3px;height:3px;border-radius:50%;background:var(--gray);display:inline-block;flex-shrink:0;"></span>
            <span style="font-size:.8rem;color:var(--gray);font-weight:500;">📍 <?=htmlspecialchars($job['location'])?></span>
            <?php if(!empty($job['level'])):?><span style="font-size:.8rem;color:var(--gray);font-weight:500;">· <?=htmlspecialchars($job['level'])?></span><?php endif;?>
          </div>
          <h3 style="font-size:1.15rem;font-weight:700;color:var(--white);margin-bottom:10px;line-height:1.3;"><?=htmlspecialchars($job['title'])?></h3>
          <p style="font-size:.86rem;color:var(--gray);line-height:1.7;font-weight:500;max-width:620px;"><?=nl2br(htmlspecialchars($job['description']))?></p>
          <?php if(!empty($job['skills_array'])):?>
          <div style="display:flex;flex-wrap:wrap;gap:7px;margin-top:14px;">
            <?php foreach($job['skills_array'] as $sk):?><span style="font-size:.73rem;font-weight:600;background:var(--black-4);border:1px solid rgba(255,255,255,0.08);border-radius:3px;padding:4px 10px;color:var(--gray-light);"><?=htmlspecialchars($sk)?></span><?php endforeach;?>
          </div><?php endif;?>
        </div>
        <div style="display:flex;flex-direction:column;align-items:flex-end;gap:12px;flex-shrink:0;" class="job-card-meta">
          <span style="font-size:.72rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:5px 13px;border-radius:100px;background:<?=$tb?>;border:1px solid <?=$tbd?>;color:<?=$tc?>;white-space:nowrap;"><?=htmlspecialchars($job['employment_type'])?></span>
          <a href="<?=$href?>" <?=$tgt?> class="btn btn-primary" style="padding:10px 22px;font-size:.8rem;white-space:nowrap;">Apply Now →</a>
        </div>
      </div>
    </div><?php endforeach;?>
  </div>
  <div id="noJobs" style="display:none;text-align:center;padding:80px;color:var(--gray);font-size:.95rem;font-weight:500;">No open positions in this department right now. <a href="mailto:careers@biltax.com" style="color:var(--orange);">Send us your CV anyway →</a></div>
  <?php endif;?>
</section>
<section style="background:var(--black-2);padding:110px 60px;">
  <div style="text-align:center;margin-bottom:70px;" class="reveal">
    <span class="section-tag">Hiring Process</span><h2 class="section-title">Simple, <span>Fast, Respectful</span></h2>
    <p class="section-sub" style="margin:0 auto;">We respect your time. Our entire process takes 2–3 weeks.</p>
  </div>
  <div class="steps">
    <div class="step reveal"><div class="step-ring">1</div><h3>Apply Online</h3><p>Send your CV and a short cover note telling us why you're excited about Biltax.</p></div>
    <div class="step reveal"><div class="step-ring">2</div><h3>Intro Call</h3><p>30-minute video call with someone from the team. No prep needed — just a conversation.</p></div>
    <div class="step reveal"><div class="step-ring">3</div><h3>Skills Assessment</h3><p>A short take-home task (max 3 hours) relevant to the role. Paid for senior positions.</p></div>
    <div class="step reveal"><div class="step-ring">4</div><h3>Final Interview &amp; Offer</h3><p>Meet the founders. If it's a match, you'll have an offer within 24 hours.</p></div>
  </div>
</section>
<section id="cta-section">
  <div class="cta-tag">Don't see a perfect fit?</div>
  <div class="cta-title">SEND US YOUR<br>CV ANYWAY</div>
  <p class="cta-sub">We're always looking for exceptional people. Drop us a line and we'll keep you in mind.</p>
  <div class="cta-actions">
    <a href="mailto:careers@biltax.com" class="btn btn-dark">Email careers@biltax.com →</a>
    <a href="about.php" class="btn" style="background:transparent;color:var(--black);border:2px solid rgba(0,0,0,0.3);">Meet the Team</a>
  </div>
</section>
<?php include 'php/footer.php'; ?>
