<?php
$page_title = "Get a Free Demo — Biltax";
include 'php/header.php';
?>
<div class="page-hero" style="background:var(--black);">
  <span class="section-tag">Free Trial</span>
  <h1 class="section-title">See Biltax <span>Live</span> — Free</h1>
  <p class="section-sub">Book a personalised 30-minute demo with one of our inventory experts. We'll show you exactly how Biltax works for your specific business type.</p>
</div>
<section style="background:var(--black);padding:80px 60px 120px;">
  <div class="demo-layout" style="display:grid;grid-template-columns:1fr 1.2fr;gap:80px;align-items:start;max-width:1100px;margin:0 auto;">
    <div>
      <h2 style="font-family:'Bebas Neue',sans-serif;font-size:2.4rem;letter-spacing:.04em;color:var(--white);margin-bottom:24px;" class="reveal">What to Expect</h2>
      <?php $expects=[['30 mins','Live product walkthrough tailored to your industry and business size.'],['Q&A','Ask our experts anything — no question is too technical or too basic.'],['Pricing','Get a clear breakdown of costs with no surprises or hidden fees.'],['Setup','See how quickly we can import your existing data and go live.']];
      foreach($expects as $e):?>
      <div style="display:flex;gap:18px;margin-bottom:28px;" class="reveal">
        <div style="background:var(--orange-glow);border:1px solid rgba(255,107,0,0.2);border-radius:4px;padding:10px 14px;font-family:'Bebas Neue',sans-serif;font-size:1rem;color:var(--orange);letter-spacing:.05em;white-space:nowrap;height:fit-content;"><?=$e[0]?></div>
        <p style="font-size:.9rem;color:var(--gray-light);line-height:1.7;font-weight:500;padding-top:10px;"><?=$e[1]?></p>
      </div><?php endforeach;?>
      <div style="margin-top:48px;padding:32px;background:var(--black-3);border:1px solid rgba(255,107,0,0.12);border-radius:6px;" class="reveal">
        <div style="font-size:.78rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--gray);margin-bottom:20px;">Trusted by 12,000+ businesses</div>
        <div style="display:flex;flex-wrap:wrap;gap:16px;">
          <?php foreach(['No credit card required','Setup in hours, not weeks','Cancel anytime','Free data migration'] as $t):?>
          <div style="font-size:.84rem;color:var(--gray-light);font-weight:500;">✓ <?=$t?></div><?php endforeach;?>
        </div>
      </div>
      <div style="margin-top:24px;" class="reveal">
        <div class="testi-card">
          <div class="stars">★★★★★</div><div class="quote-mark">"</div>
          <p class="testi-text">The demo was incredibly specific to our restaurant setup. The Biltax team knew exactly what we needed before we even asked.</p>
          <div class="testi-author"><div class="t-avatar">AK</div><div><div class="t-name">Ahmed Khan</div><div class="t-role">Owner, Khana Khazana Restaurants</div></div></div>
        </div>
      </div>
    </div>
    <div class="reveal">
      <div class="form-card">
        <h3 style="font-family:'Bebas Neue',sans-serif;font-size:2rem;letter-spacing:.04em;color:var(--white);margin-bottom:6px;">Book Your Free Demo</h3>
        <p style="font-size:.85rem;color:var(--gray);margin-bottom:30px;font-weight:500;">Our team will contact you within 2 hours to confirm your slot.</p>
        <div id="demoMsg" class="form-msg"></div>
        <form id="demoForm" novalidate>
          <div class="form-row">
            <div class="form-group"><label for="d_fname">First Name *</label><input type="text" id="d_fname" name="first_name" placeholder="Ahmed" required></div>
            <div class="form-group"><label for="d_lname">Last Name *</label><input type="text" id="d_lname" name="last_name" placeholder="Khan" required></div>
          </div>
          <div class="form-group"><label for="d_email">Work Email *</label><input type="email" id="d_email" name="email" placeholder="ahmed@yourbusiness.pk" required></div>
          <div class="form-group"><label for="d_phone">Phone / WhatsApp *</label><input type="tel" id="d_phone" name="phone" placeholder="+92 300 1234567" required></div>
          <div class="form-group"><label for="d_business">Business Name *</label><input type="text" id="d_business" name="business_name" placeholder="e.g. Khan Restaurants" required></div>
          <div class="form-group"><label for="d_industry">Industry *</label>
            <select id="d_industry" name="industry" required>
              <option value="">Select your industry...</option>
              <option>Restaurant / Food Service</option><option>Retail Store</option>
              <option>Grocery / Supermarket</option><option>Pharmacy</option>
              <option>Warehouse / Distribution</option><option>Cafe / Bakery</option>
              <option>Fashion / Apparel</option><option>Auto Parts / Hardware</option>
              <option>Electronics</option><option>Other</option>
            </select>
          </div>
          <div class="form-row">
            <div class="form-group"><label for="d_locations">No. of Locations</label><input type="number" id="d_locations" name="locations" placeholder="e.g. 3" min="1"></div>
            <div class="form-group"><label for="d_skus">Approx. SKUs</label><input type="text" id="d_skus" name="sku_count" placeholder="e.g. 500-1000"></div>
          </div>
          <div class="form-group"><label for="d_notes">Anything else we should know?</label><textarea id="d_notes" name="notes" placeholder="Tell us about your current setup or pain points..." style="min-height:100px;"></textarea></div>
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;padding:16px;">Book My Free Demo →</button>
          <p style="text-align:center;font-size:.78rem;color:var(--gray);margin-top:14px;font-weight:500;">By submitting, you agree to our <a href="privacy-policy.php" style="color:var(--orange);">Privacy Policy</a>. No spam — ever.</p>
        </form>
      </div>
    </div>
  </div>
</section>
<?php include 'php/footer.php'; ?>
