<?php
$page_title = "Contact Us — Biltax";
include 'php/header.php';
?>
<div class="page-hero">
  <span class="section-tag">Get In Touch</span>
  <h1 class="section-title">We'd Love to <span>Hear From You</span></h1>
  <p class="section-sub">Have a question about Biltax? Want a personalised demo? Our team responds within 2 business hours.</p>
</div>
<section style="background:var(--black);padding:0;">
  <div class="contact-layout">
    <div>
      <?php $info=[['📍','Our Office','Office 401, The Plaza, Block 9<br>Clifton, Karachi, Sindh 75600<br>Pakistan'],['📞','Phone & WhatsApp','+92 300 BILTAX1<br>+92 21 3456 7890'],['✉️','Email','hello@biltax.com<br>support@biltax.com'],['🕐','Business Hours','Monday – Saturday: 9am – 7pm<br>Sunday: 11am – 4pm (PKT)']];
      foreach($info as $i):?>
      <div class="contact-info-item reveal">
        <div class="contact-icon"><?=$i[0]?></div>
        <div class="contact-info-text"><h4><?=$i[1]?></h4><p><?=$i[2]?></p></div>
      </div><?php endforeach;?>
      <div style="background:var(--black-3);border:1px solid rgba(255,107,0,0.15);border-radius:6px;height:220px;display:flex;align-items:center;justify-content:center;margin-top:16px;" class="reveal">
        <div style="text-align:center;"><div style="font-size:2.5rem;margin-bottom:10px;">🗺️</div>
          <div style="font-size:.84rem;color:var(--gray);font-weight:600;">Clifton, Karachi, Pakistan</div>
          <a href="https://maps.google.com" target="_blank" style="font-size:.8rem;color:var(--orange);font-weight:600;text-decoration:none;display:inline-block;margin-top:8px;">View on Google Maps →</a>
        </div>
      </div>
    </div>
    <div class="reveal">
      <div class="form-card">
        <h2 style="font-family:'Bebas Neue',sans-serif;font-size:2.2rem;letter-spacing:.04em;color:var(--white);margin-bottom:6px;">Send a Message</h2>
        <p style="font-size:.86rem;color:var(--gray);font-weight:500;margin-bottom:32px;">Fill in the form and our team will get back to you within 2 hours.</p>
        <div id="formMsg" class="form-msg"></div>
        <form id="contactForm" novalidate>
          <div class="form-row">
            <div class="form-group"><label for="first_name">First Name *</label><input type="text" id="first_name" name="first_name" placeholder="Ahmed" required></div>
            <div class="form-group"><label for="last_name">Last Name *</label><input type="text" id="last_name" name="last_name" placeholder="Khan" required></div>
          </div>
          <div class="form-group"><label for="email">Email Address *</label><input type="email" id="email" name="email" placeholder="ahmed@yourbusiness.pk" required></div>
          <div class="form-group"><label for="phone">Phone / WhatsApp</label><input type="tel" id="phone" name="phone" placeholder="+92 300 1234567"></div>
          <div class="form-group"><label for="business">Business Name</label><input type="text" id="business" name="business" placeholder="Your Business Name"></div>
          <div class="form-group"><label for="subject">Subject *</label>
            <select id="subject" name="subject" required>
              <option value="">Select a topic...</option>
              <option>Request a Demo</option><option>Sales Inquiry</option>
              <option>Technical Support</option><option>Billing Question</option>
              <option>Partnership</option><option>Other</option>
            </select>
          </div>
          <div class="form-group"><label for="message">Message *</label><textarea id="message" name="message" placeholder="Tell us how we can help you..." required></textarea></div>
          <button type="submit" class="btn btn-primary" style="width:100%;justify-content:center;">Send Message →</button>
        </form>
      </div>
    </div>
  </div>
</section>
<?php include 'php/footer.php'; ?>
