<?php
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['success'=>false,'message'=>'Invalid method.']); exit; }

function s($v){ return htmlspecialchars(strip_tags(trim($v??'')),ENT_QUOTES,'UTF-8'); }

$first  = s($_POST['first_name']); $last   = s($_POST['last_name']);
$email  = filter_var(trim($_POST['email']??''), FILTER_SANITIZE_EMAIL);
$phone  = s($_POST['phone']); $biz = s($_POST['business_name']);
$ind    = s($_POST['industry']); $plan = s($_POST['plan']); $notes = s($_POST['notes']);

$errs = [];
if (!$first) $errs[] = 'First name is required.';
if (!$last)  $errs[] = 'Last name is required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errs[] = 'A valid email is required.';
if (!$phone) $errs[] = 'Phone number is required.';
if (!$biz)   $errs[] = 'Business name is required.';
if (!$ind)   $errs[] = 'Please select your industry.';
if ($errs)  { echo json_encode(['success'=>false,'message'=>implode(' ',$errs)]); exit; }

$rf = sys_get_temp_dir().'/bl_dm_'.md5($_SERVER['REMOTE_ADDR']??'');
$rd = file_exists($rf) ? json_decode(file_get_contents($rf),true) : ['c'=>0,'r'=>time()+3600];
if (time()>$rd['r']) $rd=['c'=>0,'r'=>time()+3600];
if ($rd['c']>=3) { echo json_encode(['success'=>false,'message'=>'Demo request already submitted. Our team will contact you shortly.']); exit; }
$rd['c']++; @file_put_contents($rf,json_encode($rd));

$body = "NEW DEMO REQUEST\n".str_repeat('=',40)."\nName:     {$first} {$last}\nEmail:    {$email}\nPhone:    {$phone}\nBusiness: {$biz}\nIndustry: {$ind}\nPlan:     {$plan}\nNotes:    {$notes}\n\nTime: ".date('Y-m-d H:i:s');
@mail('demos@biltax.com',"Demo Request — {$first} {$last} ({$ind})",$body,"From: noreply@biltax.com\r\nReply-To: {$email}\r\n");

$ld = __DIR__.'/../logs'; if (!is_dir($ld)) @mkdir($ld,0755,true);
@file_put_contents($ld.'/demos.log', json_encode(['time'=>date('c'),'name'=>"$first $last",'email'=>$email,'phone'=>$phone,'business'=>$biz,'industry'=>$ind,'plan'=>$plan])."\n", FILE_APPEND);

echo json_encode(['success'=>true,'message'=>"🎉 Demo request received, {$first}! Our team will contact you within 2 hours."]);
