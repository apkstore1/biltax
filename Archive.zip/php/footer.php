<?php
// ============================================================
//  php/footer.php
// ============================================================
if (!function_exists('careers_active_count')) {
    require_once __DIR__ . '/db.php';
}
$_footer_hiring = (careers_active_count() > 0);
?>
<footer>
  <div class="footer-grid">

    <div class="footer-brand-col">
      <a href="index.php" class="footer-logo-link" aria-label="Biltax Home">
        <img src="images/biltax-logo-horizontal.png" alt="Biltax" class="footer-logo-img" width="200" height="58" loading="lazy">
      </a>
      <p class="footer-desc">World's leading inventory management platform. Built for every industry, designed for growth. Trusted by 12,000+ businesses.</p>

      <div class="footer-social">
        <a href="https://www.facebook.com/share/1aigYNdin6/?mibextid=wwXIfr" target="_blank" rel="noopener" class="social-a" aria-label="Facebook">
          <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073C0 18.1 4.388 23.094 10.125 24v-8.437H7.078v-3.49h3.047V9.41c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.97h-1.513c-1.491 0-1.956.93-1.956 1.874v2.25h3.328l-.532 3.49h-2.796V24C19.612 23.094 24 18.1 24 12.073z"/></svg>
        </a>
        <a href="https://www.instagram.com/bil_tax?igsh=ZzR3NXdwMHQ3MmEw&utm_source=qr" target="_blank" rel="noopener" class="social-a" aria-label="Instagram">
          <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
        </a>
        <a href="https://www.tiktok.com/@biltax1?_r=1&_t=ZS-95ijbGJ80Yc" target="_blank" rel="noopener" class="social-a" aria-label="TikTok">
          <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-2.88 2.5 2.89 2.89 0 01-2.89-2.89 2.89 2.89 0 012.89-2.89c.28 0 .54.04.79.1V9.01a6.32 6.32 0 00-.79-.05 6.34 6.34 0 00-6.34 6.34 6.34 6.34 0 006.34 6.34 6.34 6.34 0 006.33-6.34V8.69a8.18 8.18 0 004.79 1.54V6.78a4.85 4.85 0 01-1.02-.09z"/></svg>
        </a>
        <a href="https://youtube.com/@biltax" target="_blank" rel="noopener" class="social-a" aria-label="YouTube">
          <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M23.498 6.186a3.016 3.016 0 00-2.122-2.136C19.505 3.545 12 3.545 12 3.545s-7.505 0-9.377.505A3.017 3.017 0 00.502 6.186C0 8.07 0 12 0 12s0 3.93.502 5.814a3.016 3.016 0 002.122 2.136c1.871.505 9.376.505 9.376.505s7.505 0 9.377-.505a3.015 3.015 0 002.122-2.136C24 15.93 24 12 24 12s0-3.93-.502-5.814zM9.545 15.568V8.432L15.818 12l-6.273 3.568z"/></svg>
        </a>
        <a href="https://linkedin.com/company/biltax" target="_blank" rel="noopener" class="social-a" aria-label="LinkedIn">
          <svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24" fill="currentColor"><path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z"/></svg>
        </a>
      </div>

      <div class="footer-app-badges">
        <div class="footer-app-label">Get the App</div>
        <a href="https://play.google.com/store" target="_blank" rel="noopener" class="footer-app-btn" aria-label="Google Play">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="currentColor" style="color:var(--orange)"><path d="M3.18 23.76a2 2 0 001.94-.21l12.26-7.09-2.93-2.93-11.27 10.23zm-1.5-21.22v20.92c0 .6.34 1.12.84 1.39L14.04 12 2.52.21A1.63 1.63 0 001.68 2.54zm20.33 8.66l-2.83-1.64-3.2 3.2 3.2 3.2 2.87-1.66a1.63 1.63 0 000-3.1zM5.12.45L17.38 7.54l-2.93 2.93L3.18.24A2 2 0 005.12.45z"/></svg>
          Google Play
        </a>
        <a href="https://apps.apple.com" target="_blank" rel="noopener" class="footer-app-btn" aria-label="App Store">
          <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="currentColor" style="color:var(--orange)"><path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98l-.09.06c-.22.15-2.18 1.27-2.16 3.8.03 3.02 2.65 4.03 2.68 4.04l-.07.28zM13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/></svg>
          App Store
        </a>
      </div>
    </div>

    <div class="footer-col">
      <h4>Product</h4>
      <ul>
        <li><a href="features.php">Features</a></li>
        <li><a href="pricing.php">Pricing</a></li>
        <li><a href="demo.php">Live Demo</a></li>
        <li><a href="mobile-app.php">Mobile App</a></li>
        <li><a href="mobile-app.php#scanner">Scanner App</a></li>
        <li><a href="api-docs.php">API Docs</a></li>
        <li><a href="changelog.php">Changelog</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Industries</h4>
      <ul>
        <li><a href="industries.php#restaurants">Restaurants</a></li>
        <li><a href="industries.php#retail">Retail</a></li>
        <li><a href="industries.php#grocery">Grocery</a></li>
        <li><a href="industries.php#pharmacy">Pharmacy</a></li>
        <li><a href="industries.php#warehouse">Warehouse</a></li>
        <li><a href="industries.php#cafe">Cafe &amp; Bakery</a></li>
        <li><a href="industries.php#fashion">Fashion</a></li>
        <li><a href="industries.php#auto">Auto Parts</a></li>
      </ul>
    </div>

    <div class="footer-col">
      <h4>Company</h4>
      <ul>
        <li><a href="about.php">About Us</a></li>
        <li>
          <a href="careers.php">Careers<?php if ($_footer_hiring): ?>
            <span class="footer-hiring-badge">Hiring</span>
          <?php endif; ?></a>
        </li>
        <li><a href="contact.php">Contact</a></li>
        <li><a href="#">Blog</a></li>
        <li><a href="privacy-policy.php">Privacy Policy</a></li>
        <li><a href="terms-of-service.php">Terms of Service</a></li>
      </ul>
    </div>

  </div>

  <div class="footer-bottom">
    <div class="footer-copy">&copy; <?php echo date('Y'); ?> Biltax Technologies (Pvt.) Ltd. All rights reserved. Made with &#10084;&#65039; in Hypertex.</div>
    <div class="footer-bottom-right">
      <a href="privacy-policy.php" class="footer-legal-link">Privacy</a>
      <a href="terms-of-service.php" class="footer-legal-link">Terms</a>
      <span class="footer-version">v2.4.1 &middot; </span>
    </div>
  </div>
</footer>

<script src="js/main.js"></script>
</body>
</html>
