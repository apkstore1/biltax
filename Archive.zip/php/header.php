<?php
// ============================================================
//  php/header.php — Reusable navbar & <head>
//  Horizontal logo (icon + wordmark) in navbar
//  Full stacked logo in mobile menu
// ============================================================

$current_page = basename($_SERVER['PHP_SELF']);

function is_active(string $page): string {
    global $current_page;
    return ($current_page === $page) ? 'active' : '';
}

$site_url     = 'https://biltax.com'; // ← update to your live domain
$og_image_url = $site_url . '/images/og-preview.png';
$logo_url     = $site_url . '/images/biltax-logo.png';

$default_title       = 'Biltax — Inventory Management for Every Business';
$default_description = 'Pakistan\'s leading inventory management platform for restaurants, retail, grocery, pharmacy & every business. Real-time tracking, AI forecasting, offline-ready mobile app.';

$og_title       = $og_title       ?? $page_title       ?? $default_title;
$og_description = $og_description ?? $page_description ?? $default_description;
$og_image       = $og_image       ?? $og_image_url;
$canonical      = $site_url . '/' . $current_page;

switch ($current_page) {
    case 'features.php':   $og_description = 'Explore all Biltax features: real-time tracking, AI demand forecasting, automated purchase orders, multi-location management, POS integrations & more.'; break;
    case 'pricing.php':    $og_description = 'Simple, transparent pricing for Biltax. Starter plan free forever. Business from ₨4,999/mo. No hidden fees, no contracts.'; break;
    case 'industries.php': $og_description = 'Biltax inventory solutions for restaurants, retail stores, grocery chains, pharmacies, warehouses, cafes, fashion brands & auto parts businesses.'; break;
    case 'about.php':      $og_description = 'Founded in Karachi in 2021, Biltax is on a mission to give every Pakistani business the same inventory visibility that Fortune 500 companies have.'; break;
    case 'careers.php':    $og_description = 'Join the Biltax team. We\'re hiring across engineering, product, sales, and customer success. Remote-friendly, equity for all, competitive pay.'; break;
    case 'contact.php':    $og_description = 'Get in touch with Biltax. Our team responds within 2 business hours. Office in Karachi. Available 7 days a week.'; break;
    case 'demo.php':       $og_description = 'Book a free 30-minute personalised Biltax demo. See exactly how it works for your business type. No credit card required.'; break;
    case 'mobile-app.php': $og_description = 'The Biltax mobile app and Scanner App — barcode scanning, real-time stock levels, offline mode, and push alerts on iOS & Android.'; break;
}
?>
<!DOCTYPE html>
<html lang="en" prefix="og: https://ogp.me/ns#">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">

  <title><?php echo htmlspecialchars($page_title ?? $default_title); ?></title>
  <meta name="description" content="<?php echo htmlspecialchars($og_description); ?>">
  <meta name="keywords"    content="inventory management Pakistan, POS system, restaurant inventory, retail stock management, Biltax, stock tracking software Karachi">
  <meta name="author"      content="Biltax Technologies (Pvt.) Ltd.">
  <meta name="robots"      content="index, follow">
  <link  rel="canonical"   href="<?php echo htmlspecialchars($canonical); ?>">

  <!-- Open Graph -->
  <meta property="og:type"         content="website">
  <meta property="og:site_name"    content="Biltax">
  <meta property="og:url"          content="<?php echo htmlspecialchars($canonical); ?>">
  <meta property="og:title"        content="<?php echo htmlspecialchars($og_title); ?>">
  <meta property="og:description"  content="<?php echo htmlspecialchars($og_description); ?>">
  <meta property="og:image"        content="<?php echo htmlspecialchars($og_image); ?>">
  <meta property="og:image:width"  content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:image:type"   content="image/png">
  <meta property="og:image:alt"    content="Biltax — Control Your Stock. Scale Your Business.">
  <meta property="og:locale"       content="en_PK">

  <!-- Twitter / X Card -->
  <meta name="twitter:card"        content="summary_large_image">
  <meta name="twitter:site"        content="@biltax">
  <meta name="twitter:creator"     content="@biltax">
  <meta name="twitter:url"         content="<?php echo htmlspecialchars($canonical); ?>">
  <meta name="twitter:title"       content="<?php echo htmlspecialchars($og_title); ?>">
  <meta name="twitter:description" content="<?php echo htmlspecialchars($og_description); ?>">
  <meta name="twitter:image"       content="<?php echo htmlspecialchars($og_image); ?>">
  <meta name="twitter:image:alt"   content="Biltax — Control Your Stock. Scale Your Business.">

  <!-- PWA / Browser -->
  <meta name="theme-color"                       content="#FF6B00">
  <meta name="apple-mobile-web-app-capable"      content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title"        content="Biltax">
  <meta name="msapplication-TileColor"           content="#FF6B00">

  <!-- Favicons -->
  <link rel="icon"             type="image/png" sizes="32x32"  href="images/favicon-32.png">
  <link rel="icon"             type="image/png" sizes="16x16"  href="images/favicon-16.png">
  <link rel="apple-touch-icon" sizes="180x180"                 href="images/apple-touch-icon.png">
  <link rel="shortcut icon"                                     href="images/favicon.ico">

  <!-- Structured Data -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    "name": "Biltax",
    "description": "<?php echo addslashes($og_description); ?>",
    "url": "<?php echo $site_url; ?>",
    "logo": "<?php echo $logo_url; ?>",
    "applicationCategory": "BusinessApplication",
    "operatingSystem": "Web, iOS, Android",
    "offers": { "@type": "Offer", "price": "0", "priceCurrency": "PKR" },
    "publisher": {
      "@type": "Organization",
      "name": "Biltax Technologies (Pvt.) Ltd.",
      "url": "<?php echo $site_url; ?>",
      "sameAs": [
        "https://facebook.com/biltax",
        "https://instagram.com/biltax",
        "https://tiktok.com/@biltax",
        "https://youtube.com/@biltax",
        "https://linkedin.com/company/biltax"
      ]
    }
  }
  </script>

  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Syne:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="css/style.css">
</head>
<body>

<div class="cursor" id="cursor"></div>
<div class="cursor-ring" id="cursorRing"></div>

<!-- NAVBAR -->
<nav class="navbar" id="navbar">
  <a href="index.php" class="nav-logo" aria-label="Biltax Home">
    <!-- Horizontal logo: icon left + wordmark right – clean on dark bg -->
    <img
      src="images/biltax-logo-horizontal.png"
      alt="Biltax"
      class="nav-logo-img"
      width="160" height="52">
  </a>

  <div class="nav-links">
    <a href="index.php"      class="<?php echo is_active('index.php'); ?>">Home</a>
    <a href="features.php"   class="<?php echo is_active('features.php'); ?>">Features</a>
    <a href="industries.php" class="<?php echo is_active('industries.php'); ?>">Industries</a>
    <a href="pricing.php"    class="<?php echo is_active('pricing.php'); ?>">Pricing</a>
    <a href="mobile-app.php" class="<?php echo is_active('mobile-app.php'); ?>">App</a>
    <a href="about.php"      class="<?php echo is_active('about.php'); ?>">About</a>
    <a href="contact.php"    class="<?php echo is_active('contact.php'); ?>">Contact</a>
    <a href="demo.php"       class="nav-cta">Get Demo &rarr;</a>
  </div>

  <button class="hamburger" id="hamburger" aria-label="Toggle navigation menu" aria-expanded="false">
    <span></span><span></span><span></span>
  </button>
</nav>

<!-- MOBILE MENU — full stacked logo, large & centred -->
<div class="mobile-menu" id="mobileMenu" role="dialog" aria-label="Navigation menu">
  <img src="images/biltax-logo.png" alt="Biltax" class="mobile-menu-logo">
  <a href="index.php">Home</a>
  <a href="features.php">Features</a>
  <a href="industries.php">Industries</a>
  <a href="pricing.php">Pricing</a>
  <a href="mobile-app.php">Mobile App</a>
  <a href="api-docs.php">API Docs</a>
  <a href="careers.php">Careers</a>
  <a href="about.php">About</a>
  <a href="contact.php">Contact</a>
  <a href="demo.php" style="color:var(--orange)">Get Demo &rarr;</a>
</div>
