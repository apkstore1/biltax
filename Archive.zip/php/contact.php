<?php
header('Content-Type: application/json');
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { echo json_encode(['success'=>false,'message'=>'Invalid method.']); exit; }

function s($v){ return htmlspecialchars(strip_tags(trim($v??'')),ENT_QUOTES,'UTF-8'); }

$first = s($_POST['first_name']); $last  = s($_POST['last_name']);
$email = filter_var(trim($_POST['email']??''), FILTER_SANITIZE_EMAIL);
$phone = s($_POST['phone']); $biz = s($_POST['business']);
$subj  = s($_POST['subject']); $msg = s($_POST['message']);

$errs = [];
if (!$first) $errs[] = 'First name is required.';
if (!$last)  $errs[] = 'Last name is required.';
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) $errs[] = 'A valid email is required.';
if (!$subj)  $errs[] = 'Please select a subject.';
if (strlen($msg) < 10) $errs[] = 'Message must be at least 10 characters.';
if ($errs) { echo json_encode(['success'=>false,'message'=>implode(' ',$errs)]); exit; }

$rf = sys_get_temp_dir().'/bl_ct_'.md5($_SERVER['REMOTE_ADDR']??'');
$rd = file_exists($rf) ? json_decode(file_get_contents($rf),true) : ['c'=>0,'r'=>time()+3600];
if (time()>$rd['r']) $rd=['c'=>0,'r'=>time()+3600];
if ($rd['c']>=5) { echo json_encode(['success'=>false,'message'=>'Too many requests. Try again later.']); exit; }
$rd['c']++; @file_put_contents($rf,json_encode($rd));

$body = "Biltax Contact Form\n".str_repeat('=',40)."\nName:     {$first} {$last}\nEmail:    {$email}\nPhone:    {$phone}\nBusiness: {$biz}\nSubject:  {$subj}\n\nMessage:\n{$msg}\n\nTime: ".date('Y-m-d H:i:s');
@mail('hello@biltax.com',"Contact: {$subj} — {$first} {$last}",$body,"From: noreply@biltax.com\r\nReply-To: {$email}\r\n");

$ld = __DIR__.'/../logs'; if (!is_dir($ld)) @mkdir($ld,0755,true);
@file_put_contents($ld.'/contacts.log', json_encode(['time'=>date('c'),'name'=>"$first $last",'email'=>$email,'subject'=>$subj,'message'=>$msg])."\n", FILE_APPEND);

echo json_encode(['success'=>true,'message'=>"Thank you, {$first}! Our team will reply within 2 business hours."]);
