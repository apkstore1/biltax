<?php
function biltax_db(): ?PDO {
    static $pdo = false;
    if ($pdo !== false) return $pdo;
    $host=$_ENV['DB_HOST']??getenv('DB_HOST')?:'localhost';
    $name=$_ENV['DB_NAME']??getenv('DB_NAME')?:'biltax_db';
    $user=$_ENV['DB_USER']??getenv('DB_USER')?:'biltax_user';
    $pass=$_ENV['DB_PASS']??getenv('DB_PASS')?:'';
    try {
        $pdo = new PDO("mysql:host={$host};dbname={$name};charset=utf8mb4", $user, $pass, [
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES=>false,
            PDO::ATTR_TIMEOUT=>3,
        ]);
    } catch (PDOException $e) {
        error_log('[Biltax DB] '.$e->getMessage());
        $pdo = null;
    }
    return $pdo;
}

function careers_active_count(): int {
    $db = biltax_db();
    if (!$db) return 0;
    try { return (int)$db->query("SELECT COUNT(*) FROM careers WHERE status='active'")->fetchColumn(); }
    catch (PDOException $e) { error_log('[Biltax DB] careers_count: '.$e->getMessage()); return 0; }
}

function careers_fetch_active(): array {
    $db = biltax_db();
    if (!$db) return [];
    try {
        $stmt = $db->prepare("SELECT id,title,department,location,employment_type,level,description,skills,apply_email,apply_url,posted_at FROM careers WHERE status='active' ORDER BY sort_order ASC,posted_at DESC");
        $stmt->execute();
        return array_map(function($row){ $row['skills_array']=json_decode($row['skills']??'[]',true)??[]; return $row; }, $stmt->fetchAll());
    } catch (PDOException $e) { error_log('[Biltax DB] careers_fetch: '.$e->getMessage()); return []; }
}

function careers_departments(array $jobs): array {
    $depts = array_unique(array_filter(array_column($jobs,'department')));
    sort($depts);
    return array_merge(['All'],array_values($depts));
}
