<?php
session_start();
/**
 * Admin Login for Biltax
 * Authenticates via the database provided in the user-specified path.
 */
require_once '/ims/config/db_connect.php'; 
// Note: We assume $conn or $db is the mysqli/PDO connection variable defined in db_connect.php.
// For this example, I will assume a variable named $conn (mysqli) is used.

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';

    if (!empty($email) && !empty($password)) {
        // Using prepared statements for security
        $stmt = $conn->prepare("SELECT id, email, password FROM admin_users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($user = $result->fetch_assoc()) {
            // Use password_verify if you use hashing, otherwise direct comparison (not recommended for production)
            if (password_verify($password, $user['password']) || $password === $user['password']) {
                $_SESSION['admin_logged_in'] = true;
                $_SESSION['admin_user'] = $user['email'];
                header('Location: index.php');
                exit;
            } else {
                $error = 'Invalid credentials.';
            }
        } else {
            $error = 'Admin user not found.';
        }
    } else {
        $error = 'Please fill in all fields.';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login — Biltax</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { cursor: default; display: flex; align-items: center; justify-content: center; min-height: 100vh; background: var(--black); }
        .login-card { background: var(--black-3); padding: 40px; border-radius: 8px; border: 1px solid var(--orange-glow); width: 100%; max-width: 400px; }
        .error-msg { color: #F87171; background: rgba(248,113,113,0.1); padding: 10px; border-radius: 4px; margin-bottom: 20px; font-size: 0.85rem; }
    </style>
</head>
<body>
    <div class="login-card">
        <div style="text-align:center; margin-bottom:30px;">
            <img src="../images/biltax-logo-horizontal.png" alt="Biltax" style="height:40px; margin: 0 auto;">
            <h2 style="font-family:'Bebas Neue'; color:var(--white); margin-top:10px;">Admin Panel</h2>
        </div>

        <?php if ($error): ?>
            <div class="error-msg"><?php echo $error; ?></div>
        <?php endif; ?>

        <form method="POST">
            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" required placeholder="admin@biltax.com">
            </div>
            <div class="form-group">
                <label>Password</label>
                <input type="password" name="password" required placeholder="••••••••">
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%; margin-top:10px;">Login to Dashboard</button>
        </form>
    </div>
</body>
</html>