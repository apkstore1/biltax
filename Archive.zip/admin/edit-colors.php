<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit; }

$css_path = __DIR__ . '/../css/style.css';
$css_content = file_get_contents($css_path);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_colors'])) {
    $updates = [
        '--orange' => $_POST['color_orange'],
        '--black'  => $_POST['color_black'],
        '--white'  => $_POST['color_white'],
    ];

    foreach ($updates as $var => $val) {
        $css_content = preg_replace('/' . preg_quote($var) . ':\s*#[a-fA-F0-9]{3,6}/', $var . ': ' . $val, $css_content);
    }

    file_put_contents($css_path, $css_content);
    $success = true;
}

// Simple regex to find current values
preg_match('/--orange:\s*(#[a-fA-F0-9]+)/', $css_content, $m_orange);
preg_match('/--black:\s*(#[a-fA-F0-9]+)/', $css_content, $m_black);
preg_match('/--white:\s*(#[a-fA-F0-9]+)/', $css_content, $m_white);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Colors — Biltax Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { cursor: default; background: var(--black); }
        .admin-header { background: var(--black-2); padding: 20px 60px; border-bottom: 1px solid rgba(255,107,0,0.1); margin-bottom: 40px; }
        .color-input-wrap { display: flex; align-items: center; gap: 20px; background: var(--black-3); padding: 15px; border-radius: 4px; margin-bottom: 15px; }
        input[type="color"] { width: 50px; height: 50px; border: none; background: transparent; cursor: pointer; }
    </style>
</head>
<body>
    <div class="admin-header">
        <a href="index.php" style="color:var(--orange); text-decoration:none; font-weight:700;">← Back to Dashboard</a>
    </div>

    <div class="container" style="max-width: 600px;">
        <h1 class="section-title">Brand <span>Colors</span></h1>
        
        <?php if (isset($success)): ?>
            <div class="form-msg success">CSS variables updated successfully!</div>
        <?php endif; ?>

        <form method="POST">
            <div class="color-input-wrap">
                <input type="color" name="color_orange" value="<?php echo $m_orange[1] ?? '#FF6B00'; ?>">
                <div>
                    <label>Primary Brand Color (--orange)</label>
                    <code style="color:var(--gray);"><?php echo $m_orange[1] ?? '#FF6B00'; ?></code>
                </div>
            </div>
            <div class="color-input-wrap">
                <input type="color" name="color_black" value="<?php echo $m_black[1] ?? '#0A0A0A'; ?>">
                <div>
                    <label>Main Background (--black)</label>
                    <code style="color:var(--gray);"><?php echo $m_black[1] ?? '#0A0A0A'; ?></code>
                </div>
            </div>
            <div class="color-input-wrap">
                <input type="color" name="color_white" value="<?php echo $m_white[1] ?? '#F5F0EB'; ?>">
                <div>
                    <label>Primary Text Color (--white)</label>
                    <code style="color:var(--gray);"><?php echo $m_white[1] ?? '#F5F0EB'; ?></code>
                </div>
            </div>
            <button type="submit" name="save_colors" class="btn btn-primary" style="margin-top:20px;">Update CSS File</button>
        </form>
    </div>
</body>
</html>