<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Biltax Admin — Dashboard</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { cursor: default; background: var(--black); }
        .admin-nav { background: var(--black-2); padding: 20px 60px; border-bottom: 1px solid rgba(255,107,0,0.1); display: flex; justify-content: space-between; align-items: center; }
        .admin-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 20px; padding: 60px; }
        .admin-card { background: var(--black-3); border: 1px solid rgba(255,255,255,0.05); padding: 30px; border-radius: 8px; transition: 0.3s; text-decoration: none; }
        .admin-card:hover { border-color: var(--orange); background: var(--black-4); transform: translateY(-3px); }
        .admin-card h3 { color: var(--white); margin-bottom: 10px; font-family: 'Bebas Neue'; font-size: 1.5rem; }
        .admin-card p { color: var(--gray); font-size: 0.85rem; }
    </style>
</head>
<body>
    <nav class="admin-nav">
        <img src="../images/biltax-logo-horizontal.png" alt="Biltax" style="height:32px;">
        <div style="display:flex; gap:20px; align-items:center;">
            <span style="color:var(--gray); font-size:0.8rem;">Logged in as: <strong><?php echo $_SESSION['admin_user']; ?></strong></span>
            <a href="logout.php" class="btn btn-outline" style="padding: 8px 15px; font-size: 0.7rem;">Logout</a>
        </div>
    </nav>

    <div class="container" style="padding-top:40px;">
        <span class="section-tag">Management</span>
        <h1 class="section-title">Admin <span>Control Panel</span></h1>
        <p class="section-sub">Customize your site content, colors, and features directly from here.</p>
    </div>

    <div class="admin-grid">
        <a href="edit-colors.php" class="admin-card">
            <h3>🎨 Branding & Colors</h3>
            <p>Update the primary orange shades, backgrounds, and global CSS variables.</p>
        </a>
        <a href="edit-features.php" class="admin-card">
            <h3>📦 Features Page</h3>
            <p>Edit the list of features, icons, and descriptions shown on the features page.</p>
        </a>
        <a href="edit-perks.php" class="admin-card">
            <h3>🌟 Careers & Perks</h3>
            <p>Manage the employee benefits and perks displayed on the careers page.</p>
        </a>
        <a href="edit-privacy.php" class="admin-card">
            <h3>⚖️ Legal Pages</h3>
            <p>Modify sections in Privacy Policy and Terms of Service.</p>
        </a>
    </div>
</body>
</html>