<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) { header('Location: login.php'); exit; }

$file_path = __DIR__ . '/../features.php';
$success = false;

// 1. Load the current features
include $file_path; // This gives us access to $features

// 2. Handle Save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_features'])) {
    $new_features = [];
    foreach ($_POST['f_icon'] as $index => $icon) {
        if (!empty($_POST['f_title'][$index])) {
            $new_features[] = [
                $icon,
                $_POST['f_title'][$index],
                $_POST['f_desc'][$index]
            ];
        }
    }

    // Generate the PHP file content
    $features_code = var_export($new_features, true);
    $content = "<?php\n"
             . "\$page_title = \"Features — Biltax Inventory Management\";\n"
             . "include 'php/header.php';\n"
             . "\$features = " . $features_code . ";\n"
             . "?>\n"
             . file_get_contents($file_path, false, null, strpos(file_get_contents($file_path), '<div class="page-hero">'));

    if (file_put_contents($file_path, $content)) {
        $success = true;
        $features = $new_features; // Update local variable for display
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Features — Biltax Admin</title>
    <link rel="stylesheet" href="../css/style.css">
    <style>
        body { cursor: default; background: var(--black); padding-bottom: 100px; }
        .feature-item { background: var(--black-3); border: 1px solid #333; padding: 20px; margin-bottom: 15px; border-radius: 4px; }
        .admin-header { background: var(--black-2); padding: 20px 60px; border-bottom: 1px solid rgba(255,107,0,0.1); margin-bottom: 40px; }
    </style>
</head>
<body>
    <div class="admin-header">
        <a href="index.php" style="color:var(--orange); text-decoration:none; font-weight:700;">← Back to Dashboard</a>
    </div>

    <div class="container">
        <h1 class="section-title">Edit <span>Features</span></h1>
        
        <?php if ($success): ?>
            <div class="form-msg success">Features updated successfully and saved to file!</div>
        <?php endif; ?>

        <form method="POST">
            <div id="features-list">
                <?php foreach ($features as $i => $f): ?>
                <div class="feature-item">
                    <div class="form-row">
                        <div class="form-group" style="flex:0 0 80px;">
                            <label>Icon</label>
                            <input type="text" name="f_icon[]" value="<?php echo htmlspecialchars($f[0]); ?>">
                        </div>
                        <div class="form-group">
                            <label>Title</label>
                            <input type="text" name="f_title[]" value="<?php echo htmlspecialchars($f[1]); ?>">
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Description</label>
                        <textarea name="f_desc[]" style="min-height:80px;"><?php echo htmlspecialchars($f[2]); ?></textarea>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>

            <div style="display:flex; gap:10px; margin-top:30px;">
                <button type="submit" name="save_features" class="btn btn-primary">Save Changes to File</button>
                <button type="button" class="btn btn-outline" onclick="addNew()">+ Add New Feature</button>
            </div>
        </form>
    </div>

    <script>
        function addNew() {
            const div = document.createElement('div');
            div.className = 'feature-item';
            div.innerHTML = `
                <div class="form-row">
                    <div class="form-group" style="flex:0 0 80px;"><label>Icon</label><input type="text" name="f_icon[]"></div>
                    <div class="form-group"><label>Title</label><input type="text" name="f_title[]"></div>
                </div>
                <div class="form-group"><label>Description</label><textarea name="f_desc[]" style="min-height:80px;"></textarea></div>
            `;
            document.getElementById('features-list').appendChild(div);
        }
    </script>
</body>
</html>