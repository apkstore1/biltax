<?php
$page_title = "Terms of Service — Biltax";
include 'php/header.php';
?>
<div class="page-hero" style="background:var(--black-2);">
  <span class="section-tag">Legal</span>
  <h1 class="section-title">Terms of <span>Service</span></h1>
  <p class="section-sub">Please read these terms carefully before using Biltax. By using our platform, you agree to be bound by these terms.</p>
  <div style="margin-top:20px;font-family:'JetBrains Mono',monospace;font-size:.78rem;color:var(--gray);">Last updated: April 1, 2026</div>
</div>

<section style="background:var(--black);padding:80px 60px;">
  <div style="display:grid;grid-template-columns:220px 1fr;gap:60px;align-items:start;max-width:1100px;margin:0 auto;" class="legal-page-grid">
    <div style="position:sticky;top:100px;" class="legal-toc-sticky legal-toc-col">
      <div style="font-size:.72rem;font-weight:700;letter-spacing:.18em;text-transform:uppercase;color:var(--gray);margin-bottom:16px;">Contents</div>
      <ul style="display:flex;flex-direction:column;gap:0;">
        <?php foreach(['acceptance'=>'1. Acceptance','account'=>'2. Account Registration','subscription'=>'3. Subscription & Payment','use'=>'4. Acceptable Use','data'=>'5. Data Ownership','ip'=>'6. Intellectual Property','disclaimer'=>'7. Disclaimers','limitation'=>'8. Limitation of Liability','termination'=>'9. Termination','law'=>'10. Governing Law','changes'=>'11. Changes to Terms','contact'=>'12. Contact'] as $a=>$l): ?>
        <li><a href="#<?= $a ?>" style="display:block;padding:8px 14px;font-size:.82rem;font-weight:500;color:var(--gray);border-left:2px solid rgba(255,255,255,.06);transition:.2s;text-decoration:none;" onmouseenter="this.style.color='var(--orange)';this.style.borderColor='var(--orange)'" onmouseleave="this.style.color='var(--gray)';this.style.borderColor='rgba(255,255,255,.06)'"><?= $l ?></a></li>
        <?php endforeach; ?>
      </ul>
      <a href="privacy-policy.php" style="display:block;margin-top:22px;font-size:.8rem;color:var(--orange);font-weight:600;text-decoration:none;">→ Privacy Policy</a>
    </div>
    <div class="legal-content legal-content-col">
      <div class="legal-intro">These Terms of Service ("Terms") constitute a legally binding agreement between you and <strong>Biltax Technologies (Pvt.) Ltd.</strong> ("Biltax"), governing your use of the Biltax inventory management platform, mobile applications, and related services.</div>

      <div class="legal-section" id="acceptance"><h2>1. Acceptance of Terms</h2><p>By creating an account, accessing, or using any part of the Biltax Service, you confirm that you are at least 18 years old, have the authority to bind yourself or the company you represent, and agree to be bound by these Terms.</p></div>

      <div class="legal-section" id="account"><h2>2. Account Registration</h2><p>To use Biltax, you must register for an account. You agree to provide accurate information, keep your credentials secure, notify us immediately of any unauthorised access, and accept responsibility for all activities under your account.</p></div>

      <div class="legal-section" id="subscription"><h2>3. Subscription & Payment</h2><h3>Plans and Billing</h3><ul><li>Biltax offers Starter (free), Business, and Enterprise plans as described on our <a href="pricing.php" style="color:var(--orange);">Pricing page</a>.</li><li>Paid plans are billed monthly or annually in advance in Pakistani Rupees (PKR).</li><li>Subscriptions automatically renew unless cancelled.</li></ul><h3>Cancellation & Refunds</h3><ul><li>You may cancel anytime from your account settings. Cancellation takes effect at the end of the current billing period.</li><li>No pro-rata refunds for partial months.</li></ul></div>

      <div class="legal-section" id="use"><h2>4. Acceptable Use</h2><p>You may only use the Service for lawful business purposes. You must not reverse-engineer the platform, use automated tools beyond your API quota, attempt to gain unauthorised access to other accounts, or resell the Service without written consent.</p></div>

      <div class="legal-section" id="data"><h2>5. Data Ownership</h2><p><strong>Your data belongs to you.</strong> All business data you enter into Biltax remains your property. We will never use your business data for any purpose other than providing the Service. You can export all your data at any time via Settings → Export Data.</p></div>

      <div class="legal-section" id="ip"><h2>6. Intellectual Property</h2><p>The Biltax platform, including all software, design, trademarks, logos, and documentation, is owned by Biltax Technologies (Pvt.) Ltd. and protected under applicable intellectual property laws.</p></div>

      <div class="legal-section" id="disclaimer"><h2>7. Disclaimers</h2><p>The Service is provided "as is" without warranties of any kind. We strongly recommend maintaining independent backups of your critical business data.</p></div>

      <div class="legal-section" id="limitation"><h2>8. Limitation of Liability</h2><p>Biltax's total liability shall not exceed the amount you paid to Biltax in the three months immediately preceding the claim. Biltax shall not be liable for any indirect, incidental, or consequential damages.</p></div>

      <div class="legal-section" id="termination"><h2>9. Termination</h2><p>You may terminate your account anytime from Settings. Biltax may suspend your account immediately if you materially breach these Terms, use the Service illegally, or if required by law.</p></div>

      <div class="legal-section" id="law"><h2>10. Governing Law</h2><p>These Terms are governed by the laws of Pakistan. Any disputes shall be subject to the exclusive jurisdiction of the courts of Karachi, Sindh, Pakistan.</p></div>

      <div class="legal-section" id="changes"><h2>11. Changes to Terms</h2><p>We may modify these Terms at any time. When we make material changes we will notify all registered users by email at least 14 days before changes take effect.</p></div>

      <div class="legal-section" id="contact"><h2>12. Contact</h2><p>For questions about these Terms, contact our legal team:</p>
        <div style="background:var(--black-3);border:1px solid rgba(255,107,0,.15);border-radius:6px;padding:22px 26px;margin-top:14px;">
          <div style="font-weight:700;color:var(--white);margin-bottom:6px;">Biltax Technologies (Pvt.) Ltd.</div>
          <div style="font-size:.88rem;color:var(--gray-light);line-height:1.8;font-weight:500;">Office 401, The Plaza, Block 9, Clifton, Karachi 75600, Pakistan<br>📧 <a href="mailto:legal@biltax.com" style="color:var(--orange);">legal@biltax.com</a></div>
        </div>
        <p style="margin-top:18px;">See also: <a href="privacy-policy.php" style="color:var(--orange);">Privacy Policy →</a></p>
      </div>
    </div>
  </div>
</section>
<?php include 'php/footer.php'; ?>
