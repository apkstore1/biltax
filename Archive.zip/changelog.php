<?php
$page_title = "Changelog — Biltax Product Updates";
include 'php/header.php';

$releases = [
  ['2.4.1','April 2, 2026','Latest','#4ADE80',[['fix','Fixed sync delay on multi-location stock transfers exceeding 500 items'],['fix','Resolved barcode scanner disconnection on Android 15 devices'],['improve','Purchase order PDF export now includes supplier tax registration number'],['improve','Dashboard load time reduced by 38% on low-bandwidth connections']]],
  ['2.4.0','March 18, 2026','Feature','var(--orange)',[['new','AI Demand Forecasting — predict stock needs up to 30 days ahead'],['new','Biltax Scanner App v1.0 — dedicated barcode scanning app for Android and iOS'],['new','Webhook support — real-time events for stock updates and PO status changes'],['new','Urdu language interface — full UI available in Urdu with RTL support'],['improve','New bulk import tool supports CSV files up to 50,000 rows'],['fix','Fixed incorrect VAT calculation on purchase orders with mixed tax rates']]],
  ['2.3.2','February 28, 2026','Patch','#60A5FA',[['fix','Resolved issue where deleted items still appeared in low-stock reports'],['fix','Fixed mobile app session expiry happening too early on Business plan'],['improve','Stock count audit export now includes timestamps per scanned item']]],
  ['2.3.0','January 30, 2026','Feature','var(--orange)',[['new','Multi-currency support — manage inventory costs in PKR, AED, USD, and GBP'],['new','Supplier performance dashboard — track on-time delivery rates and price history'],['new','Cycle count tools — run partial stock audits without freezing your inventory'],['new','WooCommerce integration — bi-directional sync with your WooCommerce store'],['improve','Reports module completely redesigned with 12 new report types']]],
  ['2.2.0','November 22, 2025','Feature','var(--orange)',[['new','REST API v1 — full programmatic access to all inventory, orders, and reporting'],['new','Shopify integration — live inventory sync with your Shopify storefront'],['new','Bundle & Kit management — auto-deduct component stock when sold'],['improve','Mobile app now supports offline mode with automatic background sync']]],
  ['2.1.0','September 10, 2025','Feature','var(--orange)',[['new','Biltax Mobile App v1.0 — iOS and Android app launched'],['new','Automated Purchase Orders — set reorder points and auto-generate POs'],['new','Batch & Expiry Tracking — full FIFO/FEFO support'],['improve','Complete UI redesign — faster, cleaner, and mobile-first']]],
];
$bl = ['new'=>'New','improve'=>'Improved','fix'=>'Fix'];
$bs = ['new'=>'background:rgba(74,222,128,.12);color:#4ADE80;border:1px solid rgba(74,222,128,.3);','improve'=>'background:rgba(255,107,0,.1);color:var(--orange);border:1px solid rgba(255,107,0,.25);','fix'=>'background:rgba(96,165,250,.1);color:#60A5FA;border:1px solid rgba(96,165,250,.25);'];
?>

<div class="page-hero" style="background:var(--black);">
  <span class="section-tag">Product Updates</span>
  <h1 class="section-title">What's <span>New</span> in Biltax</h1>
  <p class="section-sub">Every update, every fix, every new feature — documented here. We ship improvements every week.</p>
  <div style="margin-top:20px;display:flex;gap:22px;flex-wrap:wrap;">
    <?php foreach([['#4ADE80','New Features'],['var(--orange)','Improvements'],['#60A5FA','Bug Fixes']] as $b): ?>
    <div style="display:flex;align-items:center;gap:8px;font-size:.82rem;font-weight:600;color:var(--gray);">
      <span style="width:10px;height:10px;border-radius:50%;background:<?= $b[0] ?>;display:inline-block;flex-shrink:0;"></span> <?= $b[1] ?>
    </div>
    <?php endforeach; ?>
  </div>
</div>

<section style="background:var(--black);padding:80px 60px;">
  <div style="max-width:840px;margin:0 auto;">
    <?php foreach($releases as $rel):
      $dotShadow = $rel[3] === 'var(--orange)' ? 'rgba(255,107,0,.5)' : ($rel[3] === '#4ADE80' ? 'rgba(74,222,128,.5)' : 'rgba(96,165,250,.5)');
    ?>
    <div style="display:grid;grid-template-columns:160px 1fr;gap:40px;margin-bottom:56px;position:relative;" class="reveal changelog-row">
      <div style="text-align:right;padding-top:6px;" class="changelog-date-col">
        <div style="font-family:'JetBrains Mono',monospace;font-size:1.25rem;font-weight:500;color:var(--white);line-height:1;">v<?= $rel[0] ?></div>
        <div style="font-size:.76rem;color:var(--gray);font-weight:500;margin-top:5px;"><?= $rel[1] ?></div>
        <?php $bgC = $rel[3]==='var(--orange)'?'rgba(255,107,0,.12)':($rel[3]==='#4ADE80'?'rgba(74,222,128,.12)':'rgba(96,165,250,.12)');
               $bdC = $rel[3]==='var(--orange)'?'rgba(255,107,0,.3)':($rel[3]==='#4ADE80'?'rgba(74,222,128,.3)':'rgba(96,165,250,.3)');
        ?>
        <div style="display:inline-block;margin-top:10px;font-size:.68rem;font-weight:700;letter-spacing:.12em;text-transform:uppercase;padding:3px 10px;border-radius:100px;background:<?= $bgC ?>;color:<?= $rel[3] ?>;border:1px solid <?= $bdC ?>;"><?= $rel[2] ?></div>
      </div>
      <div style="border-left:2px solid rgba(255,107,0,.15);padding-left:34px;position:relative;" class="changelog-changes-col">
        <div class="changelog-dot" style="position:absolute;left:-7px;top:8px;width:12px;height:12px;border-radius:50%;background:<?= $rel[3] ?>;border:2px solid var(--black);box-shadow:0 0 10px <?= $dotShadow ?>;"></div>
        <div style="display:flex;flex-direction:column;gap:10px;">
          <?php foreach($rel[4] as $c): ?>
          <div style="display:flex;align-items:flex-start;gap:11px;">
            <span style="font-size:.67rem;font-weight:700;letter-spacing:.1em;text-transform:uppercase;padding:3px 9px;border-radius:3px;flex-shrink:0;margin-top:2px;<?= $bs[$c[0]] ?>"><?= $bl[$c[0]] ?></span>
            <span style="font-size:.88rem;color:var(--gray-light);line-height:1.6;font-weight:500;"><?= $c[1] ?></span>
          </div>
          <?php endforeach; ?>
        </div>
      </div>
    </div>
    <?php endforeach; ?>

    <div style="display:grid;grid-template-columns:160px 1fr;gap:40px;" class="reveal">
      <div style="text-align:right;padding-top:6px;">
        <div style="font-family:'JetBrains Mono',monospace;font-size:1.25rem;font-weight:500;color:var(--gray);line-height:1;">v1.0.0</div>
        <div style="font-size:.76rem;color:var(--gray);font-weight:500;margin-top:5px;">March 1, 2021</div>
      </div>
      <div style="border-left:2px solid rgba(255,255,255,.06);padding-left:34px;position:relative;">
        <div style="position:absolute;left:-7px;top:8px;width:12px;height:12px;border-radius:50%;background:var(--orange);border:2px solid var(--black);"></div>
        <div style="font-size:.88rem;color:var(--gray);line-height:1.6;font-weight:500;">🎉 Biltax 1.0 launched — Pakistan's first cloud-based inventory management platform for local businesses.</div>
      </div>
    </div>
  </div>
</section>

<section style="background:var(--black-2);padding:80px 60px;text-align:center;">
  <div class="reveal">
    <span class="section-tag">Stay Updated</span>
    <h2 class="section-title">Never Miss an <span>Update</span></h2>
    <p class="section-sub" style="margin:0 auto 36px;">Get notified by email whenever we ship new features or important fixes.</p>
    <div style="display:flex;gap:0;max-width:460px;margin:0 auto;" class="changelog-subscribe">
      <input type="email" placeholder="your@email.com" style="border-radius:4px 0 0 4px;border-right:0;">
      <button class="btn btn-primary" style="border-radius:0 4px 4px 0;white-space:nowrap;">Subscribe →</button>
    </div>
  </div>
</section>

<?php include 'php/footer.php'; ?>
