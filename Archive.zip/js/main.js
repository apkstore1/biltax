/* =============================================
   BILTAX — Main JavaScript v3.0
   ============================================= */

document.addEventListener('DOMContentLoaded', function () {

  const isTouchDevice = ('ontouchstart' in window) || (navigator.maxTouchPoints > 0);

  /* ---- CUSTOM CURSOR (desktop only) ---- */
  const cursor = document.getElementById('cursor');
  const ring   = document.getElementById('cursorRing');
  if (cursor && ring && !isTouchDevice) {
    let mx = 0, my = 0, rx = 0, ry = 0;
    document.addEventListener('mousemove', e => {
      mx = e.clientX; my = e.clientY;
      cursor.style.left = mx + 'px'; cursor.style.top = my + 'px';
    });
    (function animRing() {
      rx += (mx - rx) * 0.12; ry += (my - ry) * 0.12;
      ring.style.left = rx + 'px'; ring.style.top = ry + 'px';
      requestAnimationFrame(animRing);
    })();
    document.querySelectorAll('a,button,.faq-q,.industry-card,.feature-card,.price-card,.testi-card,.job-card,.frame-nav-item').forEach(el => {
      el.addEventListener('mouseenter', () => { cursor.style.width='20px';cursor.style.height='20px';ring.style.width='52px';ring.style.height='52px'; });
      el.addEventListener('mouseleave', () => { cursor.style.width='12px';cursor.style.height='12px';ring.style.width='36px';ring.style.height='36px'; });
    });
  } else if (cursor) {
    cursor.style.display = 'none';
    if (ring) ring.style.display = 'none';
  }

  /* ---- NAVBAR SCROLL ---- */
  const navbar = document.getElementById('navbar');
  if (navbar) {
    window.addEventListener('scroll', () => navbar.classList.toggle('scrolled', window.scrollY > 60), { passive: true });
  }

  /* ---- HAMBURGER / MOBILE MENU ---- */
  const hamburger  = document.getElementById('hamburger');
  const mobileMenu = document.getElementById('mobileMenu');
  if (hamburger && mobileMenu) {
    const openMenu  = () => { hamburger.classList.add('open'); mobileMenu.classList.add('open'); document.body.style.overflow = 'hidden'; hamburger.setAttribute('aria-expanded','true'); };
    const closeMenu = () => { hamburger.classList.remove('open'); mobileMenu.classList.remove('open'); document.body.style.overflow = ''; hamburger.setAttribute('aria-expanded','false'); };
    hamburger.addEventListener('click', () => mobileMenu.classList.contains('open') ? closeMenu() : openMenu());
    mobileMenu.querySelectorAll('a').forEach(a => a.addEventListener('click', closeMenu));
    document.addEventListener('keydown', e => { if (e.key === 'Escape') closeMenu(); });
    mobileMenu.addEventListener('click', e => { if (e.target === mobileMenu) closeMenu(); });
  }

  /* ---- FAQ ACCORDION ---- */
  document.querySelectorAll('.faq-q').forEach(q => {
    q.addEventListener('click', () => {
      const answer = q.nextElementSibling;
      const isOpen = answer.classList.contains('open');
      document.querySelectorAll('.faq-a').forEach(a  => a.classList.remove('open'));
      document.querySelectorAll('.faq-q').forEach(fq => fq.classList.remove('open'));
      if (!isOpen) { answer.classList.add('open'); q.classList.add('open'); }
    });
  });

  /* ---- DASHBOARD SIDEBAR HOVER (interactive demo) ---- */
  document.querySelectorAll('.frame-nav-item').forEach(item => {
    item.addEventListener('click', function () {
      document.querySelectorAll('.frame-nav-item').forEach(i => i.classList.remove('active'));
      this.classList.add('active');

      // Update page title to match selected menu item
      const label = this.querySelector('.nav-label');
      const title = document.querySelector('.frame-page-title');
      if (label && title) {
        title.textContent = label.textContent;
      }
    });
  });

  /* ---- SCROLL REVEAL ---- */
  const revealEls = document.querySelectorAll('.reveal');
  if (revealEls.length && 'IntersectionObserver' in window) {
    const observer = new IntersectionObserver(entries => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const delay = parseInt(entry.target.dataset.delay) || 0;
          setTimeout(() => entry.target.classList.add('visible'), delay);
          observer.unobserve(entry.target);
        }
      });
    }, { threshold: 0.08, rootMargin: '0px 0px -40px 0px' });
    revealEls.forEach((el, idx) => { el.dataset.delay = (idx % 4) * 80; observer.observe(el); });
  } else {
    revealEls.forEach(el => el.classList.add('visible'));
  }

  /* ---- STAT COUNTER ANIMATION ---- */
  function animateCounter(el, target, suffix) {
    let start = 0;
    const increment = target / (1800 / 16);
    const timer = setInterval(() => {
      start = Math.min(start + increment, target);
      el.textContent = Math.floor(start).toLocaleString() + suffix;
      if (start >= target) clearInterval(timer);
    }, 16);
  }
  const heroStats = document.querySelector('.hero-stats');
  if (heroStats && 'IntersectionObserver' in window) {
    let fired = false;
    new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !fired) {
        fired = true;
        document.querySelectorAll('.stat-num').forEach(el => {
          const txt = el.textContent.trim();
          if (txt.includes('K+'))     animateCounter(el, 12, 'K+');
          else if (txt.includes('%')) animateCounter(el, parseInt(txt), '%');
        });
      }
    }, { threshold: 0.5 }).observe(heroStats);
  }

  /* ---- TICKER DUPLICATE ---- */
  const tickerTrack = document.getElementById('tickerTrack');
  if (tickerTrack && !tickerTrack.dataset.duped) {
    tickerTrack.innerHTML += tickerTrack.innerHTML;
    tickerTrack.dataset.duped = '1';
  }

  /* ---- CHART BAR HOVER ---- */
  if (!isTouchDevice) {
    document.querySelectorAll('.bar').forEach(bar => {
      bar.addEventListener('mouseenter', () => bar.style.background = 'var(--orange)');
      bar.addEventListener('mouseleave', () => { if (!bar.classList.contains('hi')) bar.style.background = 'rgba(255,107,0,0.25)'; });
    });
  }

  /* ---- AJAX CONTACT FORM ---- */
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const btn = contactForm.querySelector('button[type="submit"]');
      const msgEl = document.getElementById('formMsg');
      const orig = btn.textContent;
      btn.disabled = true; btn.textContent = 'Sending...';
      try {
        const res  = await fetch('php/contact.php', { method:'POST', body:new FormData(contactForm) });
        const data = await res.json();
        msgEl.className = 'form-msg ' + (data.success ? 'success' : 'error');
        msgEl.textContent = data.message;
        msgEl.scrollIntoView({ behavior:'smooth', block:'nearest' });
        if (data.success) contactForm.reset();
      } catch { msgEl.className='form-msg error'; msgEl.textContent='Something went wrong. Please try again.'; }
      finally { btn.disabled=false; btn.textContent=orig; }
    });
  }

  /* ---- AJAX DEMO FORM ---- */
  const demoForm = document.getElementById('demoForm');
  if (demoForm) {
    demoForm.addEventListener('submit', async function (e) {
      e.preventDefault();
      const btn = demoForm.querySelector('button[type="submit"]');
      const msgEl = document.getElementById('demoMsg');
      const orig = btn.textContent;
      btn.disabled = true; btn.textContent = 'Submitting...';
      try {
        const res  = await fetch('php/demo.php', { method:'POST', body:new FormData(demoForm) });
        const data = await res.json();
        msgEl.className = 'form-msg ' + (data.success ? 'success' : 'error');
        msgEl.textContent = data.message;
        msgEl.scrollIntoView({ behavior:'smooth', block:'nearest' });
        if (data.success) demoForm.reset();
      } catch { msgEl.className='form-msg error'; msgEl.textContent='Something went wrong. Please try again.'; }
      finally { btn.disabled=false; btn.textContent=orig; }
    });
  }

  /* ---- ACTIVE NAV HIGHLIGHT ---- */
  const page = window.location.pathname.split('/').pop() || 'index.php';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === page) a.classList.add('active');
  });

  /* ---- JOB FILTER ---- */
  window.filterJobs = function (dept) {
    document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
    const btn = document.querySelector('[data-dept="'+dept+'"]');
    if (btn) btn.classList.add('active');
    let visible = 0;
    document.querySelectorAll('.job-card').forEach(c => {
      const show = dept==='All' || c.dataset.dept===dept;
      c.style.display = show ? 'block' : 'none';
      if (show) visible++;
    });
    const noJobs = document.getElementById('noJobs');
    if (noJobs) noJobs.style.display = visible===0 ? 'block' : 'none';
  };

  /* ---- COPY CODE BLOCK ---- */
  window.copyCode = function (btn) {
    const code = btn.closest('.code-block')?.querySelector('code');
    if (!code) return;
    navigator.clipboard.writeText(code.textContent)
      .then(() => { const o=btn.textContent; btn.textContent='Copied!'; setTimeout(()=>btn.textContent=o,2000); })
      .catch(() => {
        const range=document.createRange(); range.selectNodeContents(code);
        window.getSelection().removeAllRanges(); window.getSelection().addRange(range);
        document.execCommand('copy'); window.getSelection().removeAllRanges();
        const o=btn.textContent; btn.textContent='Copied!'; setTimeout(()=>btn.textContent=o,2000);
      });
  };

  /* ---- SMOOTH ANCHOR SCROLL (offsets for fixed navbar) ---- */
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
      const target = document.querySelector(this.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      const top = target.getBoundingClientRect().top + window.scrollY - (navbar ? navbar.offsetHeight : 76) - 16;
      window.scrollTo({ top, behavior: 'smooth' });
    });
  });

  /* ---- TOUCH: tap feedback on cards ---- */
  if (isTouchDevice) {
    document.querySelectorAll('.feature-card,.industry-card,.testi-card,.price-card,.job-card').forEach(card => {
      card.addEventListener('touchstart', () => card.style.opacity='.88', { passive:true });
      card.addEventListener('touchend',   () => card.style.opacity='1',   { passive:true });
    });
  }

  window.addEventListener('orientationchange', () => { setTimeout(()=>window.scrollBy(0,1),100); });
});
