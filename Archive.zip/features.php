<?php
$page_title = "Features — Biltax Inventory Management";
include 'php/header.php';
$features=[['📦','Real-Time Inventory Tracking','Monitor stock levels across all your locations in real time. Get instant alerts when items run low so you never face a stockout again. Every scan, sale, and transfer is logged with a full audit trail.'],['📊','Advanced Analytics & Reports','Deep-dive dashboards with sales velocity, dead stock analysis, shrinkage tracking, and profitability reports by category, location, and supplier — all exportable to PDF or Excel.'],['🤖','AI Demand Forecasting','Our AI engine predicts demand based on seasonality, historical trends, and market data. Stop over-ordering and under-ordering forever. Smart reorder suggestions save you time and money.'],['🏪','Multi-Location Management','Manage inventory across multiple branches, warehouses, and stores from a single unified control panel. Transfer stock between locations with one click and track in real time.'],['🔗','POS & ERP Integrations','Seamlessly connect with 50+ POS systems, accounting software, and e-commerce platforms. Shopify, WooCommerce, FoodicsOnline, QuickBooks, and more — synced automatically.'],['📱','Mobile Barcode Scanning','Use your smartphone as a full barcode scanner. Receive stock, conduct audits, fulfill orders, and verify shipments — all without any dedicated hardware.'],['🛒','Automated Purchase Orders','Set reorder points and let Biltax automatically generate and send purchase orders to your preferred suppliers when stock dips below your defined threshold.'],['👥','Supplier Management','Maintain a complete supplier database with pricing history, lead times, and performance ratings. Compare suppliers and negotiate better deals with real data.'],['🔒','Role-Based Access Control','Set granular permissions for every team member — from store managers to warehouse staff. Every action is logged with timestamps for a complete audit trail.'],['📋','Expiry & Batch Tracking','Track products by batch number, lot number, and expiry date. Enforce FIFO/FEFO rules automatically and get proactive alerts before items expire.'],['💰','Cost & Margin Tracking','Track landed cost, selling price, and gross margin per product. Know exactly which items are profitable and which are dragging down your bottom line.'],['📦','Bundle & Kit Management','Create product bundles and kits that automatically deduct component stock when sold. Perfect for gift sets, combos, and manufactured goods.']];
?>
<div class="page-hero">
  <span class="section-tag">Platform Features</span>
  <h1 class="section-title">Powerful Tools for <span>Modern Businesses</span></h1>
  <p class="section-sub">Every feature in Biltax is purpose-built to give you complete control over your inventory — from a single shop to a nationwide chain.</p>
  <div style="margin-top:32px;display:flex;gap:14px;flex-wrap:wrap;">
    <a href="demo.php" class="btn btn-primary">Start Free Trial →</a>
    <a href="contact.php" class="btn btn-outline">Talk to Sales</a>
  </div>
</div>
<section style="background:var(--black); padding:100px 60px;">
  <div class="features-grid">
    <?php foreach($features as $i=>$f):?>
    <div class="feature-card reveal">
      <div class="feature-icon"><?=$f[0]?></div><h3><?=$f[1]?></h3><p><?=$f[2]?></p>
      <div class="feature-num"><?=str_pad($i+1,2,'0',STR_PAD_LEFT)?></div>
    </div><?php endforeach;?>
  </div>
</section>
<section style="background:var(--black-2);padding:100px 60px;text-align:center;">
  <div class="reveal">
    <span class="section-tag">Integrations</span>
    <h2 class="section-title">Connects With <span>Your Existing Tools</span></h2>
    <p class="section-sub" style="margin:0 auto 56px;">Biltax plays well with the tools you already use. No ripping and replacing — just powerful integration.</p>
  </div>
  <div class="integrations-grid reveal" style="display:grid;grid-template-columns:repeat(6,1fr);gap:16px;max-width:900px;margin:0 auto;">
    <?php foreach(['Shopify','WooCommerce','QuickBooks','Xero','FoodicsOnline','Square','LS Retail','SAP','Oracle','Odoo','Zoho','Stripe'] as $intg):?>
    <div style="background:var(--black-3);border:1px solid rgba(255,255,255,0.06);border-radius:6px;padding:20px 14px;font-size:.82rem;font-weight:700;color:var(--gray-light);transition:border-color .3s,color .3s;cursor:none;" onmouseenter="this.style.borderColor='var(--orange)';this.style.color='var(--white)'" onmouseleave="this.style.borderColor='rgba(255,255,255,0.06)';this.style.color='var(--gray-light)'"><?=$intg?></div>
    <?php endforeach;?>
  </div>
</section>
<section id="cta-section">
  <div class="cta-tag">Start today — it's free</div>
  <div class="cta-title">READY TO<br>GET STARTED?</div>
  <p class="cta-sub">No credit card required. Set up in minutes. Cancel anytime.</p>
  <div class="cta-actions">
    <a href="demo.php" class="btn btn-dark">Try Biltax Free →</a>
    <a href="contact.php" class="btn" style="background:transparent;color:var(--black);border:2px solid rgba(0,0,0,0.3);">Contact Sales</a>
  </div>
</section>
<?php include 'php/footer.php'; ?>
