<?php
$page_title = "Pricing — Biltax Inventory Management";
include 'php/header.php';
$plans=[
  ['name'=>'Starter','price'=>'0','desc'=>'Perfect for small businesses just getting started with inventory management.','featured'=>false,'features'=>['Up to 500 SKUs','1 Location / Branch','Basic inventory tracking','Mobile barcode scanning','Standard reports (5 types)','Email support','1 user account'],'missing'=>['AI Forecasting','Auto Purchase Orders','POS Integration','Multi-Location','Priority Support'],'cta'=>'Get Started Free','href'=>'demo.php','style'=>'outline'],
  ['name'=>'Business','price'=>'4,999','desc'=>'Everything you need to run a growing multi-location operation efficiently.','featured'=>true,'features'=>['Unlimited SKUs','Up to 5 Locations','Real-time inventory tracking','AI Demand Forecasting','Automated Purchase Orders','POS & ERP Integration','All 25+ report types','Role-based access (10 users)','Priority support (chat + phone)','Batch & expiry tracking'],'missing'=>[],'cta'=>'Start 14-Day Trial','href'=>'demo.php','style'=>'filled'],
  ['name'=>'Enterprise','price'=>'Custom','desc'=>'Tailored for large-scale operations with complex workflows and compliance needs.','featured'=>false,'features'=>['Unlimited SKUs & Locations','Custom integrations & APIs','Dedicated account manager','SLA Uptime Guarantee','On-site training & onboarding','Custom report builder','Unlimited users','White-label options','Compliance & audit tools','24/7 phone support'],'missing'=>[],'cta'=>'Contact Sales','href'=>'contact.php','style'=>'outline'],
];
$faqs=[['Is there a free trial?','Yes! The Starter plan is completely free forever. Business and Enterprise plans come with a 14-day free trial — no credit card required.'],['Can I upgrade or downgrade anytime?','Absolutely. You can change your plan at any time from your account settings. Upgrades are instant; downgrades take effect at the next billing cycle.'],['Do you offer discounts for annual billing?','Yes — paying annually saves you 20% compared to monthly billing. Contact our sales team for custom annual pricing on Enterprise plans.'],['Are there setup or onboarding fees?','Zero. There are no setup fees, onboarding fees, or hidden charges. What you see is what you pay.'],['What payment methods do you accept?','We accept credit/debit cards (Visa, Mastercard), bank transfers, JazzCash, and EasyPaisa. Enterprise customers can also pay by cheque.'],['Is my data secure?','Your data is encrypted at rest and in transit using AES-256. We\'re hosted on ISO 27001-certified infrastructure with daily backups and 99.9% uptime SLA.']];
?>
<div class="page-hero">
  <span class="section-tag">Pricing</span>
  <h1 class="section-title">Simple, <span>Transparent</span> Pricing</h1>
  <p class="section-sub">No hidden fees. No long-term contracts. Start free and upgrade only when you need to. Every plan includes onboarding support.</p>
</div>
<section style="background:var(--black);padding:100px 60px;">
  <div class="pricing-grid" style="max-width:1100px;margin:0 auto;">
    <?php foreach($plans as $plan):?>
    <div class="price-card<?=$plan['featured']?' featured':''?> reveal">
      <?php if($plan['featured']):?><div class="feat-badge">Most Popular</div><?php endif;?>
      <div class="plan-name"><?=$plan['name']?></div>
      <?php if(is_numeric(str_replace(',','',$plan['price']))):?><div class="plan-price"><sup>₨</sup><?=$plan['price']?><sub>/mo</sub></div>
      <?php else:?><div class="plan-price" style="font-size:2.5rem;"><?=$plan['price']?></div><?php endif;?>
      <div class="plan-desc"><?=$plan['desc']?></div>
      <ul class="plan-features">
        <?php foreach($plan['features'] as $f):?><li><?=$f?></li><?php endforeach;?>
        <?php foreach($plan['missing'] as $m):?><li style="opacity:.35;text-decoration:line-through;"><?=$m?></li><?php endforeach;?>
      </ul>
      <a href="<?=$plan['href']?>" class="plan-btn <?=$plan['style']?>"><?=$plan['cta']?></a>
    </div><?php endforeach;?>
  </div>
  <div style="text-align:center;margin-top:56px;font-size:.86rem;color:var(--gray);font-weight:500;" class="reveal">
    All prices are in Pakistani Rupees (PKR) and exclusive of taxes. Annual billing saves 20%.
    <a href="contact.php" style="color:var(--orange);margin-left:6px;">Need a custom quote? →</a>
  </div>
</section>
<section style="background:var(--black-2);padding:100px 60px;">
  <div class="reveal" style="text-align:center;margin-bottom:56px;">
    <span class="section-tag">Full Comparison</span><h2 class="section-title">What's <span>Included</span></h2>
  </div>
  <div style="overflow-x:auto;" class="reveal compare-table-wrap">
    <table style="width:100%;border-collapse:collapse;font-size:.88rem;font-weight:500;">
      <thead><tr style="border-bottom:1px solid rgba(255,107,0,0.2);">
        <th style="text-align:left;padding:16px 20px;color:var(--gray);font-size:.78rem;letter-spacing:.12em;text-transform:uppercase;font-weight:700;width:40%;">Feature</th>
        <?php foreach($plans as $p):?><th style="text-align:center;padding:16px 20px;color:<?=$p['featured']?'var(--orange)':'var(--white)'?>;font-size:.88rem;font-weight:700;"><?=$p['name']?></th><?php endforeach;?>
      </tr></thead>
      <tbody>
        <?php $comparison=[['SKUs','500','Unlimited','Unlimited'],['Locations / Branches','1','5','Unlimited'],['User Accounts','1','10','Unlimited'],['Real-Time Tracking','✓','✓','✓'],['Mobile Barcode Scanning','✓','✓','✓'],['Standard Reports','5 types','All 25+','Custom Builder'],['AI Demand Forecasting','—','✓','✓'],['Automated Purchase Orders','—','✓','✓'],['POS / ERP Integration','—','50+ apps','Custom APIs'],['Batch & Expiry Tracking','—','✓','✓'],['Role-Based Access Control','—','✓','✓'],['Dedicated Account Manager','—','—','✓'],['SLA Uptime Guarantee','—','—','✓'],['On-site Training','—','—','✓'],['Support','Email','Chat + Phone','24/7 Phone']];
        foreach($comparison as $i=>$row): $bg=($i%2===0)?'rgba(255,255,255,0.02)':'transparent';?>
        <tr style="border-bottom:1px solid rgba(255,255,255,0.04);background:<?=$bg?>;">
          <td style="padding:14px 20px;color:var(--gray-light);"><?=$row[0]?></td>
          <?php for($j=1;$j<=3;$j++): $val=$row[$j]; $c=($val==='—')?'var(--gray)':($val==='✓'?'#4ADE80':'var(--white)');?>
          <td style="text-align:center;padding:14px 20px;color:<?=$c?>;font-weight:<?=($val==='✓'||$val==='—')?'700':'500'?>;"><?=$val?></td>
          <?php endfor;?>
        </tr><?php endforeach;?>
      </tbody>
    </table>
  </div>
</section>
<section style="background:var(--black);padding:100px 60px;">
  <div class="faq-layout">
    <div class="reveal">
      <span class="section-tag">FAQ</span>
      <h2 class="section-title">Pricing <span>Questions</span></h2>
      <p class="section-sub">Still have questions? Our team is happy to help you find the right plan for your business.</p>
      <div style="margin-top:32px;"><a href="contact.php" class="btn btn-primary">Talk to Sales →</a></div>
    </div>
    <div class="faq-list reveal">
      <?php foreach($faqs as $faq):?>
      <div class="faq-item"><div class="faq-q"><?=$faq[0]?> <span class="faq-icon">+</span></div><div class="faq-a"><?=$faq[1]?></div></div>
      <?php endforeach;?>
    </div>
  </div>
</section>
<section id="cta-section">
  <div class="cta-tag">No credit card required</div>
  <div class="cta-title">START FOR<br>FREE TODAY</div>
  <p class="cta-sub">Join 12,000+ businesses already running smarter with Biltax.</p>
  <div class="cta-actions">
    <a href="demo.php" class="btn btn-dark">Get Started Free →</a>
    <a href="contact.php" class="btn" style="background:transparent;color:var(--black);border:2px solid rgba(0,0,0,0.3);">Contact Sales</a>
  </div>
</section>
<?php include 'php/footer.php'; ?>
