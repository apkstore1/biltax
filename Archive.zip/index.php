<?php
$page_title = "Biltax — Inventory Management System for Every Business";
include 'php/header.php';
?>

<section class="hero" id="home">
  <div class="hero-grid"></div>
  <div class="hero-glow-1"></div>
  <div class="hero-glow-2"></div>
  <div class="hero-badge">🟠 Now with AI-powered demand forecasting</div>
  <h1 class="hero-title">
    Control<br>
    Your <span class="accent">Stock.</span><br>
    <span class="outline">Scale Fast.</span>
  </h1>
  <p class="hero-sub">Biltax is the all-in-one inventory management platform built for restaurants, retail, groceries, and every industry in between. Real-time. Accurate. Powerful.</p>
  <div class="hero-actions">
    <a href="demo.php" class="btn btn-primary">Start Free Trial →</a>
    <a href="features.php" class="btn btn-outline">Explore Features</a>
  </div>
  <div class="hero-stats">
    <div class="stat-item"><div class="stat-num">12K+</div><div class="stat-label">Active Businesses</div></div>
    <div class="stat-item"><div class="stat-num">98%</div><div class="stat-label">Accuracy Rate</div></div>
    <div class="stat-item"><div class="stat-num">₨0</div><div class="stat-label">Setup Cost</div></div>
    <div class="stat-item"><div class="stat-num">24/7</div><div class="stat-label">Live Support</div></div>
  </div>
</section>

<div class="ticker">
  <div class="ticker-track" id="tickerTrack">
    <span>Restaurants</span><span class="dot">◆</span><span>Retail Stores</span><span class="dot">◆</span>
    <span>Grocery Chains</span><span class="dot">◆</span><span>Pharmacies</span><span class="dot">◆</span>
    <span>Warehouses</span><span class="dot">◆</span><span>Cafes &amp; Bakeries</span><span class="dot">◆</span>
    <span>Supermarkets</span><span class="dot">◆</span><span>Electronics</span><span class="dot">◆</span>
    <span>Fashion Brands</span><span class="dot">◆</span><span>Food Chains</span><span class="dot">◆</span>
    <span>Auto Parts</span><span class="dot">◆</span><span>Hardware Stores</span><span class="dot">◆</span>
  </div>
</div>

<!-- FEATURES PREVIEW -->
<section style="background:var(--black-2); padding:110px 60px;">
  <div class="features-header reveal">
    <div>
      <span class="section-tag">Platform Features</span>
      <h2 class="section-title">Everything Your <span>Business Needs</span></h2>
    </div>
    <div>
      <p class="section-sub">From real-time tracking to AI forecasting — Biltax handles your entire inventory operation in one powerful platform.</p>
      <a href="features.php" class="btn btn-outline" style="margin-top:24px;">See All Features →</a>
    </div>
  </div>
  <div class="features-grid">
    <?php $features=[['📦','Real-Time Inventory Tracking','Monitor stock levels across all locations instantly. Get alerts before you run out.'],['📊','Advanced Analytics & Reports','Deep dashboards with sales velocity, shrinkage, and profitability by category.'],['🤖','AI Demand Forecasting','Predict demand with AI based on seasonality, trends, and historical data.'],['🏪','Multi-Location Management','Manage inventory across branches, warehouses, and stores from one panel.'],['🔗','POS & ERP Integrations','Connect with 50+ POS systems, accounting software, and e-commerce platforms.'],['📱','Mobile Barcode Scanning','Use your phone for stock receiving, audits, and order fulfillment on the go.']];
    foreach($features as $i=>$f):?>
    <div class="feature-card reveal">
      <div class="feature-icon"><?=$f[0]?></div>
      <h3><?=$f[1]?></h3><p><?=$f[2]?></p>
      <div class="feature-num">0<?=$i+1?></div>
    </div><?php endforeach;?>
  </div>
</section>

<!-- INDUSTRIES PREVIEW -->
<section style="background:var(--black); padding:110px 60px;">
  <div class="industries-header reveal">
    <span class="section-tag">Industry Solutions</span>
    <h2 class="section-title">Built For <span>Every Business</span></h2>
    <p class="section-sub">Biltax adapts to your industry with pre-built workflows, templates, and integrations.</p>
  </div>
  <div class="industries-grid" style="margin-top:60px;">
    <?php $industries=[['🍽️','Restaurants','Ingredient tracking, recipe costing, kitchen integration.'],['🛍️','Retail Stores','Multi-SKU management, promotions, e-commerce sync.'],['🥬','Grocery & Supermarkets','Perishables, FEFO, batch tracking, shrinkage control.'],['💊','Pharmacies','Regulatory compliance, batch numbers, controlled substances.'],['🏭','Warehouses','Bin management, receiving, shipping, pallet tracking.'],['☕','Cafes & Bakeries','Daily production, recipe usage, waste logs, auto-ordering.'],['👗','Fashion & Apparel','Variants by size and color, seasonal collections, returns.'],['🔧','Auto Parts & Hardware','Part numbers, compatibility, bulk supplier purchasing.']];
    foreach($industries as $ind):?>
    <div class="industry-card reveal"><span class="ind-icon"><?=$ind[0]?></span><h3><?=$ind[1]?></h3><p><?=$ind[2]?></p></div>
    <?php endforeach;?>
  </div>
  <div style="text-align:center;margin-top:56px;" class="reveal"><a href="industries.php" class="btn btn-primary">Explore All Industries →</a></div>
</section>

<!-- DASHBOARD MOCKUP -->
<section id="preview" style="background:var(--black-2); padding:110px 0;">
  <div class="preview-header reveal">
    <span class="section-tag">Live Dashboard</span>
    <h2 class="section-title">See Biltax <span>In Action</span></h2>
    <p class="section-sub">A clean, powerful interface that gives your team everything they need without the clutter.</p>
  </div>
  <div class="dashboard-frame reveal">
    <div class="frame-bar">
      <div class="frame-dot"></div><div class="frame-dot"></div><div class="frame-dot"></div>
      <div class="frame-url">app.biltax.com/dashboard</div>
    </div>
    <div class="frame-body">
      <div class="frame-sidebar">
        <div class="frame-logo"><img src="images/biltax-logo-horizontal.png" alt="Biltax" width="120" height="36"></div>
        <div class="frame-nav">
          <div class="frame-nav-item active"><span class="nav-icon">📊</span><span class="nav-label">Dashboard</span></div>
          <div class="frame-nav-item"><span class="nav-icon">📦</span><span class="nav-label">Inventory</span></div>
          <div class="frame-nav-item"><span class="nav-icon">🛒</span><span class="nav-label">Purchase Orders</span></div>
          <div class="frame-nav-item"><span class="nav-icon">🏪</span><span class="nav-label">Branches</span></div>
          <div class="frame-nav-item"><span class="nav-icon">👥</span><span class="nav-label">Suppliers</span></div>
          <div class="frame-nav-item"><span class="nav-icon">📋</span><span class="nav-label">Reports</span></div>
          <div class="frame-nav-item"><span class="nav-icon">⚙️</span><span class="nav-label">Settings</span></div>
        </div>
      </div>
      <div class="frame-main">
        <div class="frame-page-title">Inventory Overview</div>
        <div class="kpi-row">
          <div class="kpi"><div class="kpi-lbl">Total SKUs</div><div class="kpi-val">4,821</div><div class="kpi-chg up">↑ 3.2% this month</div></div>
          <div class="kpi"><div class="kpi-lbl">Low Stock Items</div><div class="kpi-val warn">47</div><div class="kpi-chg dn">⚠ Needs attention</div></div>
          <div class="kpi"><div class="kpi-lbl">Stock Value</div><div class="kpi-val">₨2.4M</div><div class="kpi-chg up">↑ 8.1% vs last month</div></div>
          <div class="kpi"><div class="kpi-lbl">Orders Today</div><div class="kpi-val">128</div><div class="kpi-chg up">↑ 12 vs yesterday</div></div>
        </div>
        <div class="charts-row">
          <div class="chart-box">
            <div class="chart-lbl">Stock Movement — Last 7 Days</div>
            <div class="bars">
              <div class="bar" style="height:55%"></div><div class="bar" style="height:72%"></div>
              <div class="bar" style="height:48%"></div><div class="bar" style="height:88%"></div>
              <div class="bar hi" style="height:95%"></div><div class="bar" style="height:63%"></div>
              <div class="bar" style="height:79%"></div>
            </div>
          </div>
          <div class="chart-box">
            <div class="chart-lbl">Category Split</div>
            <div class="donut-wrap">
              <svg viewBox="0 0 36 36"><circle cx="18" cy="18" r="15.9" fill="none" stroke="#222" stroke-width="3.8"/>
              <circle cx="18" cy="18" r="15.9" fill="none" stroke="#FF6B00" stroke-width="3.8" stroke-dasharray="62 38" stroke-linecap="round"/>
              <circle cx="18" cy="18" r="15.9" fill="none" stroke="#FF8C35" stroke-width="3.8" stroke-dasharray="22 78" stroke-dashoffset="-62" stroke-linecap="round"/>
              <circle cx="18" cy="18" r="15.9" fill="none" stroke="#CC5500" stroke-width="3.8" stroke-dasharray="16 84" stroke-dashoffset="-84" stroke-linecap="round"/></svg>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- HOW IT WORKS -->
<section style="background:var(--black); padding:110px 60px;">
  <div class="how-header reveal">
    <span class="section-tag">How It Works</span>
    <h2 class="section-title">Up & Running in <span>4 Simple Steps</span></h2>
    <p class="section-sub">Get your inventory under control within the same day. No complex setup required.</p>
  </div>
  <div class="steps">
    <div class="step reveal"><div class="step-ring">1</div><h3>Create Account</h3><p>Sign up in 60 seconds. Choose your industry and Biltax auto-configures your workflows.</p></div>
    <div class="step reveal"><div class="step-ring">2</div><h3>Import Products</h3><p>Upload a CSV or connect your existing POS/ERP. Our smart importer maps your data automatically.</p></div>
    <div class="step reveal"><div class="step-ring">3</div><h3>Set Reorder Rules</h3><p>Define minimum stock levels and Biltax auto-generates purchase orders to your suppliers.</p></div>
    <div class="step reveal"><div class="step-ring">4</div><h3>Manage & Grow</h3><p>Use live dashboards and AI insights to make faster, smarter business decisions every day.</p></div>
  </div>
</section>

<!-- TESTIMONIALS -->
<section style="background:var(--black-2); padding:110px 60px;">
  <div class="testimonials-header reveal">
    <span class="section-tag">Customer Stories</span>
    <h2 class="section-title">Loved by <span>Businesses</span> Across Pakistan</h2>
  </div>
  <div class="testimonials-grid">
    <?php $testi=[['AK','Ahmed Khan','Owner, Khana Khazana (5 Branches)','Biltax transformed how we manage our restaurant chain. We cut food waste by 34% and our chefs always have the right ingredients. The recipe-level tracking is a game changer.'],['SR','Sara Raza','Director, Style Hub Retail','We run 3 retail stores in Karachi. Before Biltax, stock reconciliation took 2 days a week. Now it\'s automated and takes minutes. ROI was visible within the first month.'],['MF','Muhammad Farooq','GM Operations, FreshMart Superstore','Managing perishables is incredibly complex. Biltax\'s FEFO tracking and expiry alerts have saved us hundreds of thousands in spoilage costs every single month.']];
    foreach($testi as $t):?>
    <div class="testi-card reveal">
      <div class="stars">★★★★★</div><div class="quote-mark">"</div>
      <p class="testi-text"><?=$t[3]?></p>
      <div class="testi-author"><div class="t-avatar"><?=$t[0]?></div><div><div class="t-name"><?=$t[1]?></div><div class="t-role"><?=$t[2]?></div></div></div>
    </div><?php endforeach;?>
  </div>
</section>

<!-- PRICING PREVIEW -->
<section style="background:var(--black); padding:110px 60px;">
  <?php
  $plans=[
    ['name'=>'Starter','price'=>'0','desc'=>'Perfect for small businesses just getting started with inventory management.','featured'=>false,
     'features'=>['Up to 500 SKUs','1 Location / Branch','Basic inventory tracking','Mobile barcode scanning','Standard reports (5 types)','Email support','1 user account'],
     'missing'=>['AI Forecasting','Auto Purchase Orders','POS Integration','Multi-Location','Priority Support'],
     'cta'=>'Get Started Free','href'=>'demo.php','style'=>'outline'],
    ['name'=>'Business','price'=>'4,999','desc'=>'Everything you need to run a growing multi-location operation efficiently.','featured'=>true,
     'features'=>['Unlimited SKUs','Up to 5 Locations','Real-time inventory tracking','AI Demand Forecasting','Automated Purchase Orders','POS & ERP Integration','All 25+ report types','Role-based access (10 users)','Priority support (chat + phone)','Batch & expiry tracking'],
     'missing'=>[],'cta'=>'Start 14-Day Trial','href'=>'demo.php','style'=>'filled'],
    ['name'=>'Enterprise','price'=>'Custom','desc'=>'Tailored for large-scale operations with complex workflows and compliance needs.','featured'=>false,
     'features'=>['Unlimited SKUs & Locations','Custom integrations & APIs','Dedicated account manager','SLA Uptime Guarantee','On-site training & onboarding','Custom report builder','Unlimited users','White-label options','Compliance & audit tools','24/7 phone support'],
     'missing'=>[],'cta'=>'Contact Sales','href'=>'contact.php','style'=>'outline'],
  ];
  ?>
  <div class="pricing-header reveal">
    <span class="section-tag">Simple Pricing</span>
    <h2 class="section-title">Transparent <span>Plans</span></h2>
    <p class="section-sub">No hidden fees. No contracts. Start free and scale as you grow.</p>
  </div>
  <div class="pricing-grid" style="max-width:1100px;margin:0 auto;">
    <?php foreach($plans as $plan): ?>
    <div class="price-card<?= $plan['featured'] ? ' featured' : '' ?> reveal">
      <?php if($plan['featured']): ?><div class="feat-badge">Most Popular</div><?php endif; ?>
      <div class="plan-name"><?= $plan['name'] ?></div>
      <?php if(is_numeric(str_replace(',','',$plan['price']))): ?>
        <div class="plan-price"><sup>₨</sup><?= $plan['price'] ?><sub>/mo</sub></div>
      <?php else: ?>
        <div class="plan-price" style="font-size:2.5rem;"><?= $plan['price'] ?></div>
      <?php endif; ?>
      <div class="plan-desc"><?= $plan['desc'] ?></div>
      <ul class="plan-features">
        <?php foreach($plan['features'] as $f): ?><li><?= $f ?></li><?php endforeach; ?>
        <?php foreach($plan['missing'] as $m): ?><li style="opacity:.35;text-decoration:line-through;"><?= $m ?></li><?php endforeach; ?>
      </ul>
      <a href="<?= $plan['href'] ?>" class="plan-btn <?= $plan['style'] ?>"><?= $plan['cta'] ?></a>
    </div>
    <?php endforeach; ?>
  </div>
  <div style="text-align:center;margin-top:44px;font-size:.86rem;color:var(--gray);font-weight:500;" class="reveal">
    All prices in PKR, exclusive of taxes. Annual billing saves 20%.
    <a href="pricing.php" style="color:var(--orange);margin-left:6px;">See full comparison →</a>
  </div>
</section>

<!-- CTA -->
<section id="cta-section">
  <div class="cta-tag">Ready to take control?</div>
  <div class="cta-title">START YOUR<br>FREE TRIAL<br>TODAY</div>
  <p class="cta-sub">Join 12,000+ businesses already running smarter with Biltax. No credit card required.</p>
  <div class="cta-actions">
    <a href="demo.php" class="btn btn-dark">Get Started Free →</a>
    <a href="contact.php" class="btn" style="background:transparent;color:var(--black);border:2px solid rgba(0,0,0,0.3);">Schedule a Demo</a>
  </div>
</section>

<?php include 'php/footer.php'; ?>
