-- Biltax careers table schema
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS careers (
    id              INT UNSIGNED    NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title           VARCHAR(200)    NOT NULL,
    department      VARCHAR(100)    NOT NULL,
    location        VARCHAR(150)    NOT NULL,
    employment_type VARCHAR(30)     NOT NULL DEFAULT 'Full-time',
    level           VARCHAR(50)     NOT NULL DEFAULT 'Mid-level',
    description     TEXT            NOT NULL,
    skills          JSON            NULL,
    apply_email     VARCHAR(255)    NULL,
    apply_url       VARCHAR(500)    NULL,
    status          ENUM('active','draft','closed') NOT NULL DEFAULT 'draft',
    sort_order      SMALLINT        NOT NULL DEFAULT 100,
    posted_at       DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    closed_at       DATETIME        NULL,
    INDEX idx_status     (status),
    INDEX idx_department (department),
    INDEX idx_sort       (sort_order, posted_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample data (remove before production if desired)
INSERT INTO careers (title,department,location,employment_type,level,description,skills,apply_email,status,sort_order) VALUES
('Senior Backend Engineer (PHP / Laravel)','Engineering','Karachi (Hybrid)','Full-time','Senior','Build and scale the core Biltax API, inventory engine, and integrations layer serving 12,000+ businesses.','["PHP 8+","Laravel","MySQL","Redis","REST APIs","AWS"]','careers@biltax.com','active',10),
('React / Next.js Frontend Engineer','Engineering','Remote (Pakistan)','Full-time','Mid-Senior','Own the Biltax web dashboard experience. Build fast, accessible, and beautiful inventory management UI.','["React","Next.js","TypeScript","Tailwind CSS","REST APIs"]','careers@biltax.com','active',20),
('Mobile Engineer (React Native)','Engineering','Karachi (Hybrid)','Full-time','Mid-Senior','Build and maintain the Biltax iOS and Android apps with barcode scanning and offline-first architecture.','["React Native","TypeScript","iOS","Android","REST APIs"]','careers@biltax.com','active',30),
('Product Manager','Product','Karachi (On-site)','Full-time','Senior','Define and own the Biltax product roadmap working with customers, engineering, and sales.','["Product Strategy","User Research","Data Analysis","Roadmapping","Agile"]','careers@biltax.com','active',40),
('Enterprise Sales Manager','Sales','Karachi or Lahore','Full-time','Mid-Senior','Drive enterprise and mid-market sales across Pakistan building relationships with chains and distributors.','["B2B Sales","SaaS","CRM","Negotiation","Pipeline Management"]','careers@biltax.com','active',50),
('Customer Success Manager','Customer Success','Remote (Pakistan)','Full-time','Mid-level','Own retention and expansion for Business and Enterprise customers through onboarding and proactive support.','["Account Management","Customer Onboarding","Churn Prevention","Data Analysis"]','careers@biltax.com','active',60),
('Content & SEO Specialist','Marketing','Remote (Pakistan)','Full-time','Mid-level','Build Biltax organic search presence through high-quality content and technical SEO.','["SEO","Content Writing","WordPress","Google Analytics","Keyword Research"]','careers@biltax.com','active',70),
('Implementation Specialist','Operations','Karachi (On-site)','Full-time','Junior-Mid','Help new customers migrate inventory data and go live with Biltax.','["Excel / CSV","Customer Training","Data Migration","Problem Solving","Urdu & English"]','careers@biltax.com','active',80);
