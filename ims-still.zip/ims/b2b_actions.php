<?php
require_once 'config/db_switch.php';
header('Content-Type: application/json');

// Error reporting setup
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable display to avoid corrupting JSON

if (!$tenant_conn) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized access.']);
    exit;
}
// Start output buffering to prevent accidental output corruption
ob_start();

$subscriber_tenant_id = $_SESSION['tenant_id'];
$subscriber_db_name = $_SESSION['db_name'];

try {
    $main_pdo = $m_pdo;

    $action = $_GET['action'] ?? $_POST['action'] ?? '';
    $raw_input = file_get_contents('php://input');
    $input = json_decode($raw_input, true) ?? $_POST;

    if ($action === 'import') {
        $provider_id = $input['provider_id'];
        $item_id = $input['item_id'];
        $product_name = $input['product_name'] ?? 'Imported Item';

        // 1. Get Provider info (DB and Business Name)
        $stmt = $main_pdo->prepare("SELECT db_name, business_name FROM tenants WHERE id = ?");
        $stmt->execute([$provider_id]);
        $provider_info = $stmt->fetch(PDO::FETCH_ASSOC);
        $provider_db = $provider_info['db_name'];
        $provider_biz_name = $provider_info['business_name'];

        if (!$provider_db) throw new Exception("Provider database not found.");

        // 2. Fetch Product from Provider's DB
        $p_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$provider_db", DB_USER, DB_PASS);
        $stmt = $p_pdo->prepare("SELECT p.*, u.name as unit_name, c.name as category_name FROM products p LEFT JOIN units u ON p.unit_id = u.id LEFT JOIN categories c ON p.category_id = c.id WHERE p.id = ?");
        $stmt->execute([$item_id]);
        $product = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$product) throw new Exception("Product not found in provider database.");

        // 3. Connect to Subscriber DB and Ensure Columns Exist
        $s_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$subscriber_db_name", DB_USER, DB_PASS);
        $s_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // 4. Handle Unit mapping
        $unit_id = null;
        if (!empty($product['unit_name'])) {
            $u_stmt = $s_pdo->prepare("SELECT id FROM units WHERE name = ?");
            $u_stmt->execute([$product['unit_name']]);
            $unit_id = $u_stmt->fetchColumn();
            if (!$unit_id) {
                $s_pdo->prepare("INSERT INTO units (name, is_allowed) VALUES (?, 1)")->execute([$product['unit_name']]);
                $unit_id = $s_pdo->lastInsertId();
            }
        }

        // Handle Category mapping/creation
        $category_id = null;
        if (!empty($product['category_name'])) {
            $c_stmt = $s_pdo->prepare("SELECT id FROM categories WHERE name = ?");
            $c_stmt->execute([$product['category_name']]);
            $category_id = $c_stmt->fetchColumn();
            if (!$category_id) {
                $s_pdo->prepare("INSERT INTO categories (name, is_allowed) VALUES (?, 1)")->execute([$product['category_name']]);
                $category_id = $s_pdo->lastInsertId();
            }
        }

        // Handle Supplier mapping/creation (using Provider's Business Name)
        $supplier_id = null;
        if (!empty($provider_biz_name)) {
            $sup_stmt = $s_pdo->prepare("SELECT id FROM suppliers WHERE name = ?");
            $sup_stmt->execute([$provider_biz_name]);
            $supplier_id = $sup_stmt->fetchColumn();
            if (!$supplier_id) {
                $s_pdo->prepare("INSERT INTO suppliers (name) VALUES (?)")->execute([$provider_biz_name]);
                $supplier_id = $s_pdo->lastInsertId();
            }
        }

        // 5. Insert into Subscriber Inventory with Category and Supplier
        $stmt = $s_pdo->prepare("INSERT INTO products (name, sku, sale_price, purchase_price, stock_level, unit_id, category_id, supplier_id, is_active, is_b2b_public) VALUES (?, ?, ?, ?, 0, ?, ?, ?, 1, 0)");
        $stmt->execute([
            $product['name'],
            $product['sku'] ?? null, 
            $product['sale_price'],
            $product['sale_price'], // Initial cost is provider's selling price
            $unit_id,
            $category_id,
            $supplier_id
        ]);
        $new_id = $s_pdo->lastInsertId();

        // 6. Save Mapping in Main DB
        $stmt = $main_pdo->prepare("INSERT INTO b2b_product_mappings (provider_tenant_id, subscriber_tenant_id, provider_item_id, subscriber_item_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$provider_id, $subscriber_tenant_id, $item_id, $new_id]);

        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'link') {
        $stmt = $main_pdo->prepare("INSERT INTO b2b_product_mappings (provider_tenant_id, subscriber_tenant_id, provider_item_id, subscriber_item_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$input['provider_id'], $subscriber_tenant_id, $input['provider_item_id'], $input['subscriber_item_id']]);
        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'search') {
        $q = $_GET['q'] ?? '';
        $s_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$subscriber_db_name", DB_USER, DB_PASS);
        $stmt = $s_pdo->prepare("SELECT id, name, sku FROM products WHERE name LIKE ? OR sku LIKE ? LIMIT 10");
        $stmt->execute(["%$q%", "%$q%"]);
        ob_clean();
        echo json_encode(['success' => true, 'results' => $stmt->fetchAll(PDO::FETCH_ASSOC)]);
        exit;

    } elseif ($action === 'place_order') {
        $provider_id = $input['provider_id'];
        $items = $input['items'];
        $active_branch = $_SESSION['active_branch_id'] ?? null;

        // Resolve Sender Branch: If 'All' is selected, default to Main Branch
        if ($active_branch === 'all') {
            $s_pdo_temp = new PDO("mysql:host=" . DB_HOST . ";dbname=$subscriber_db_name", DB_USER, DB_PASS);
            $sender_branch_id = $s_pdo_temp->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1")->fetchColumn();
        } else {
            $sender_branch_id = $active_branch;
        }

        // Manual branch selection from UI (Catalog Popup) takes priority
        $assigned_receiver_branch = $input['receiver_branch_id'] ?? null;

        if (!$assigned_receiver_branch) {
            // Fallback to SMART ROUTING if not picked from catalog
            $stmt_route = $main_pdo->prepare("SELECT receiver_branch_id FROM tenant_connections WHERE sender_id = ? AND receiver_id = ? AND status = 'accepted'");
            $stmt_route->execute([$subscriber_tenant_id, $provider_id]);
            $assigned_receiver_branch = $stmt_route->fetchColumn();
        }

        $main_pdo->beginTransaction();
        $stmt = $main_pdo->prepare("INSERT INTO b2b_orders (sender_tenant_id, receiver_tenant_id, sender_branch_id, receiver_branch_id, status) VALUES (?, ?, ?, ?, 'pending')");
        $stmt->execute([$subscriber_tenant_id, $provider_id, $sender_branch_id, $assigned_receiver_branch]);
        $order_id = $main_pdo->lastInsertId();

        $total = 0;
        foreach ($items as $item) {
            $m_stmt = $main_pdo->prepare("SELECT subscriber_item_id FROM b2b_product_mappings WHERE provider_tenant_id = ? AND subscriber_tenant_id = ? AND provider_item_id = ?");
            $m_stmt->execute([$provider_id, $subscriber_tenant_id, $item['id']]);
            $sub_item_id = $m_stmt->fetchColumn();

            $stmt = $main_pdo->prepare("INSERT INTO b2b_order_items (order_id, provider_item_id, subscriber_item_id, quantity, price) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$order_id, $item['id'], $sub_item_id, $item['qty'], $item['price']]);
            $total += ($item['qty'] * $item['price']);
        }

        $main_pdo->prepare("UPDATE b2b_orders SET total_amount = ? WHERE id = ?")->execute([$total, $order_id]);
        $main_pdo->commit();
        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'update_status') {
        $id = $_GET['id'];
        $status = $_GET['status'];
        
        $main_pdo->beginTransaction();

        // Fetch order details to check permissions and current status
        $stmt = $main_pdo->prepare("SELECT sender_tenant_id, receiver_tenant_id, sender_branch_id, receiver_branch_id, status, total_amount FROM b2b_orders WHERE id = ?");
        $stmt->execute([$id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$order) throw new Exception("Order not found.");

        // Only Provider (receiver_tenant_id) can mark the order as Shipped or Paid
        $is_provider = ($order['receiver_tenant_id'] == $_SESSION['tenant_id']);

        // Branch Assignment: Only update if it hasn't been pre-assigned by the sender
        if ($is_provider && in_array($status, ['processing', 'shipped'])) {
            if (empty($order['receiver_branch_id'])) {
                $active_branch = $_SESSION['active_branch_id'] ?? null;
                $assigned_branch = ($active_branch === 'all') ? get_active_stock_branch_id('all') : $active_branch;
                $main_pdo->prepare("UPDATE b2b_orders SET receiver_branch_id = ? WHERE id = ?")->execute([$assigned_branch, $id]);
                $order['receiver_branch_id'] = $assigned_branch;
            }
        }

        // 1. If status is becoming 'shipped', deduct stock from Provider's inventory
        if ($status === 'shipped' && $is_provider && $order['status'] !== 'shipped') {
            $p_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$subscriber_db_name", DB_USER, DB_PASS);
            $provider_stock_branch = get_active_stock_branch_id($order['receiver_branch_id']); // Provider's assigned branch
            
            $items_stmt = $main_pdo->prepare("SELECT provider_item_id, quantity, price FROM b2b_order_items WHERE order_id = ?");
            $items_stmt->execute([$id]);
            $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);

            // Fetch Partner Business Name to link as Customer in local Sales
            $stmt_pname = $main_pdo->prepare("SELECT business_name FROM tenants WHERE id = ?");
            $stmt_pname->execute([$order['sender_tenant_id']]);
            $partner_name = $stmt_pname->fetchColumn();

            $local_cust_id = null;
            if (!empty($partner_name)) { // Ensure partner_name is not empty
                $stmt_c = $p_pdo->prepare("SELECT id FROM customers WHERE name = ? LIMIT 1");
                $stmt_c->execute([$partner_name]);
                $local_cust_id = $stmt_c->fetchColumn();

                // If customer not found, create a new one
                if ($local_cust_id === false) {
                    // Ensure customers table has phone and email columns if they exist in the main tenants table
                    // For now, just insert name. Phone/email can be added later if needed.
                    $stmt_insert_cust = $p_pdo->prepare("INSERT INTO customers (name, phone, email) VALUES (?, NULL, NULL)");
                    $stmt_insert_cust->execute([$partner_name]);
                    $local_cust_id = $p_pdo->lastInsertId();
                }
            }

            // 1. Create Sale Record in Provider's DB (Recording B2B Order as a Sale)
            $stmt_sale = $p_pdo->prepare("INSERT INTO sales (branch_id, customer_id, total_amount, payment_method, status) VALUES (?, ?, ?, 'B2B Trade', 'completed')");
            $stmt_sale->execute([$order['receiver_branch_id'], $local_cust_id, $order['total_amount']]);
            $local_sale_id = $p_pdo->lastInsertId();
            
            foreach ($items as $item) {
                // Update Product Stock
                $p_pdo->prepare("UPDATE products SET stock_level = stock_level - ? WHERE id = ? AND branch_id = ?")
                      ->execute([$item['quantity'], $item['provider_item_id'], $provider_stock_branch]);

                // 2. Record Sale Item for the new sale
                $p_pdo->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price) VALUES (?, ?, ?, ?)")
                      ->execute([$local_sale_id, $item['provider_item_id'], $item['quantity'], $item['price']]);

                try { // Attempt to insert into stock table, but don't fail if it doesn't exist
                    $p_pdo->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")
                          ->execute([$item['provider_item_id'], -$item['quantity'], "B2B Order #$id Shipped (Sale #$local_sale_id)"]);
                } catch (Throwable $e) { /* Stock table might not exist */ }
            }
        }
        
        // If status is becoming 'received', update local stock
        if ($status === 'received') {
            if ($order['status'] === 'shipped') {
                // Notify Provider: "Maal mil gaya hai" (English: Delivery Received)
                $biz_name = $_SESSION['business_name'] ?? 'Partner';
                $msg = "Order #$id delivery has been confirmed by $biz_name.";
                $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (?, ?, 'Delivery Received', ?, 'system')")
                         ->execute([$subscriber_tenant_id, $order['receiver_tenant_id'], $msg]);
            }
        }

        if ($status === 'finalized' && $is_provider) {
            // 1. Mark as Paid in main DB
            $main_pdo->prepare("UPDATE b2b_orders SET status = ?, payment_status = 'Paid' WHERE id = ?")->execute([$status, $id]);

            // 2. Security Feature: Update Subscriber's Stock ONLY after Provider confirms payment
            // Fetch subscriber's (sender) database info
            $stmt_sub = $main_pdo->prepare("SELECT db_name FROM tenants WHERE id = ?");
            $stmt_sub->execute([$order['sender_tenant_id']]);
            $sub_db = $stmt_sub->fetchColumn();

            if ($sub_db) {
                $subscriber_stock_branch = get_active_stock_branch_id($order['sender_branch_id']); // Subscriber's branch from order
                $s_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$sub_db", DB_USER, DB_PASS);
                
                $items_stmt = $main_pdo->prepare("SELECT subscriber_item_id, quantity FROM b2b_order_items WHERE order_id = ?");
                $items_stmt->execute([$id]);
                $items = $items_stmt->fetchAll(PDO::FETCH_ASSOC);
                
                foreach ($items as $item) {
                    if ($item['subscriber_item_id']) {
                        $s_pdo->prepare("UPDATE products SET stock_level = stock_level + ? WHERE id = ? AND branch_id = ?")->execute([$item['quantity'], $item['subscriber_item_id'], $subscriber_stock_branch]);
                        try { // Attempt to insert into stock table, but don't fail if it doesn't exist
                            $s_pdo->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")->execute([$item['subscriber_item_id'], $item['quantity'], "B2B Order #$id Finalized & Paid"]);
                        } catch (Throwable $e) { /* Stock table might not exist */ }
                    }
                }

                // Notify Subscriber: "Payment Confirm hogayi hai"
                $msg = "Supplier has confirmed your payment for Order #$id. Stock is now live.";
                $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (?, ?, 'Payment Confirmed', ?, 'system')")
                         ->execute([$order['receiver_tenant_id'], $order['sender_tenant_id'], $msg]);
            }
        } else {
            $main_pdo->prepare("UPDATE b2b_orders SET status = ? WHERE id = ?")->execute([$status, $id]);
        }

        $main_pdo->commit();
        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'assign_rider') {
        $order_id = $input['order_id'];
        $rider_id = $input['rider_id'];

        $stmt = $main_pdo->prepare("UPDATE b2b_orders SET rider_id = ?, delivery_status = 'dispatched', status = 'shipped' WHERE id = ? AND receiver_tenant_id = ?");
        $stmt->execute([$rider_id, $order_id, $subscriber_tenant_id]);
        
        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'update_delivery_status') {
        $order_id = $input['order_id'];
        $status = $input['status']; // e.g., 'picked_up', 'delivered'
        $rider_id = $input['rider_id'];

        // Verify rider owns this order
        $stmt = $main_pdo->prepare("UPDATE b2b_orders SET delivery_status = ? WHERE id = ? AND rider_id = ?");
        $stmt->execute([$status, $order_id, $rider_id]);

        if ($status === 'delivered') {
            $main_pdo->prepare("UPDATE b2b_orders SET status = 'received' WHERE id = ?")->execute([$order_id]);
        }

        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'assign_rider') {
        $order_id = $input['order_id'];
        $rider_id = $input['rider_id'];

        $stmt = $main_pdo->prepare("UPDATE b2b_orders SET rider_id = ?, delivery_status = 'dispatched', status = 'shipped' WHERE id = ? AND receiver_tenant_id = ?");
        $stmt->execute([$rider_id, $order_id, $subscriber_tenant_id]);
        
        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'update_delivery_status') {
        $order_id = $input['order_id'];
        $status = $input['status']; // e.g., 'picked_up', 'delivered'
        $rider_id = $input['rider_id'];

        // Verify rider owns this order
        $stmt = $main_pdo->prepare("UPDATE b2b_orders SET delivery_status = ? WHERE id = ? AND rider_id = ?");
        $stmt->execute([$status, $order_id, $rider_id]);

        if ($status === 'delivered') {
            $main_pdo->prepare("UPDATE b2b_orders SET status = 'received' WHERE id = ?")->execute([$order_id]);
        }

        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'request_return') {
        $order_id = $input['order_id'];
        $items = $input['items']; // Array of {subscriber_item_id, qty, reason}
        $active_branch = $_SESSION['active_branch_id'] ?? null;

        // Resolve Subscriber Branch: If 'All' is selected, default to Main Branch
        if ($active_branch === 'all') {
            $s_pdo_temp = new PDO("mysql:host=" . DB_HOST . ";dbname=$subscriber_db_name", DB_USER, DB_PASS);
            $subscriber_branch_id = $s_pdo_temp->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1")->fetchColumn();
        } else {
            $subscriber_branch_id = $active_branch;
        }

        if (empty($items)) throw new Exception("No items selected for return.");

        $main_pdo->beginTransaction();
        // Fetch order info
        $stmt = $main_pdo->prepare("SELECT sender_tenant_id, receiver_tenant_id, receiver_branch_id FROM b2b_orders WHERE id = ?");
        $stmt->execute([$order_id]);
        $order = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$order) throw new Exception("Order not found.");

        // Fetch Subscriber's DB to "Lock" (deduct) stock immediately
        $stmt_s = $main_pdo->prepare("SELECT db_name FROM tenants WHERE id = ?");
        $stmt_s->execute([$order['sender_tenant_id']]);
        $s_db = $stmt_s->fetchColumn();
        if (!$s_db) throw new Exception("Subscriber database not found.");
        
        $s_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$s_db", DB_USER, DB_PASS);
        $s_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        foreach ($items as $item) {
            // Mandatory Handshake: Link subscriber_item_id to provider_item_id using mappings
            $stmt = $main_pdo->prepare("SELECT provider_item_id FROM b2b_product_mappings WHERE subscriber_item_id = ? AND subscriber_tenant_id = ?");
            $stmt->execute([$item['subscriber_item_id'], $order['sender_tenant_id']]);
            $provider_item_id = $stmt->fetchColumn();

            if (!$provider_item_id) throw new Exception("Product mapping missing for return.");

            // 1. LIMIT VALIDATION: Check original purchased quantity
            $stmt_purchased = $main_pdo->prepare("SELECT quantity FROM b2b_order_items WHERE order_id = ? AND subscriber_item_id = ?");
            $stmt_purchased->execute([$order_id, $item['subscriber_item_id']]);
            $original_qty = $stmt_purchased->fetchColumn();

            if (!$original_qty) throw new Exception("Item not found in this order.");

            // 2. Already Returned Check: Sum of existing returns (except rejected)
            $stmt_already = $main_pdo->prepare("SELECT SUM(qty) FROM b2b_return_requests WHERE order_id = ? AND subscriber_item_id = ? AND status != 'rejected'");
            $stmt_already->execute([$order_id, $item['subscriber_item_id']]);
            $already_returned = $stmt_already->fetchColumn() ?: 0;

            if (($already_returned + $item['qty']) > $original_qty) {
                throw new Exception("You cannot return more than the remaining purchased quantity. Original: $original_qty, Already Returned: $already_returned");
            }

            // LOCK STOCK: Deduct from subscriber inventory immediately
            $stmt_lock = $s_pdo->prepare("UPDATE products SET stock_level = stock_level - ? WHERE id = ? AND branch_id = ? AND stock_level >= ?");
            $stmt_lock->execute([$item['qty'], $item['subscriber_item_id'], $subscriber_branch_id, $item['qty']]);
            
            if ($stmt_lock->rowCount() === 0) throw new Exception("Insufficient stock to return this item.");
            
            try { $s_pdo->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")->execute([$item['subscriber_item_id'], -$item['qty'], "Return Requested (Locked)"]); } catch(Throwable $e) {}

            // Update Order Status to reflect return request
            $main_pdo->prepare("UPDATE b2b_orders SET status = 'return_requested' WHERE id = ?")->execute([$order_id]);
            // Record sender_branch_id in b2b_return_requests
            $stmt = $main_pdo->prepare("INSERT INTO b2b_return_requests (order_id, provider_id, subscriber_id, sender_branch_id, provider_item_id, subscriber_item_id, qty, reason, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([
                $order_id,
                $order['receiver_tenant_id'],
                $order['sender_tenant_id'],
                $subscriber_branch_id, // This is the sender_branch_id for the return request
                $item['subscriber_item_id'],
                $item['qty'],
                $item['reason']
            ]);
        }

        // Notify Provider about the return request
        $biz_name = $_SESSION['business_name'] ?? 'Partner';
        $msg = "New return request for Order #$order_id submitted by $biz_name.";
        $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (?, ?, 'Return Requested', ?, 'system')")
                 ->execute([$order['sender_tenant_id'], $order['receiver_tenant_id'], $msg]);

        $main_pdo->commit();
        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'cancel_return') {
        $return_id = $input['return_id'];
        
        $main_pdo->beginTransaction();
        
        $stmt = $main_pdo->prepare("SELECT * FROM b2b_return_requests WHERE id = ?");
        $stmt->execute([$return_id]);
        $ret = $stmt->fetch(PDO::FETCH_ASSOC);
        $subscriber_branch_id = $ret['sender_branch_id'] ?? null; // Get the branch from which the return was requested
        if (!$ret) throw new Exception("Request not found.");

        // UNLOCK STOCK: Add back to subscriber
        $stmt_s = $main_pdo->prepare("SELECT db_name FROM tenants WHERE id = ?");
        $stmt_s->execute([$ret['subscriber_id']]);
        $s_db = $stmt_s->fetchColumn();

        if ($s_db) {
            $s_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$s_db", DB_USER, DB_PASS);
            $s_pdo->prepare("UPDATE products SET stock_level = stock_level + ? WHERE id = ? AND branch_id = ?")
                  ->execute([$ret['qty'], $ret['subscriber_item_id'], $subscriber_branch_id]);
            
            try { $s_pdo->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")->execute([$ret['subscriber_item_id'], $ret['qty'], "Return Request Cancelled (Stock Released)"]); } catch(Throwable $e) {}
        }

        // Revert Order Status to finalized if no more ACTIVE return requests exist
        $stmt_check = $main_pdo->prepare("SELECT COUNT(*) FROM b2b_return_requests WHERE order_id = ? AND id != ? AND status NOT IN ('received', 'rejected')");
        $stmt_check->execute([$ret['order_id'], $return_id]);
        if ($stmt_check->fetchColumn() == 0) {
            $main_pdo->prepare("UPDATE b2b_orders SET status = 'finalized' WHERE id = ?")->execute([$ret['order_id']]);
        }

        // Delete the request
        $main_pdo->prepare("DELETE FROM b2b_return_requests WHERE id = ?")->execute([$return_id]);
        
        $main_pdo->commit();
        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'update_return_status') {
        $return_id = $input['return_id'];
        $status = $input['status'];
        $refund = $input['refund_amount'] ?? 0;
        $is_damaged = $input['is_damaged'] ?? 0;

        $main_pdo->beginTransaction();

        // Fetch full return details
        $stmt = $main_pdo->prepare("SELECT * FROM b2b_return_requests WHERE id = ?");
        $stmt->execute([$return_id]);
        $ret = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$ret) throw new Exception("Return request not found.");

        // The Final Sync Logic (When status becomes 'received')
        if ($status === 'accepted') {
            // Notify Subscriber: "Return Accept hogayi hai"
            $msg = "Supplier has accepted your return request for Order #{$ret['order_id']}. Please arrange shipment.";
            $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (?, ?, 'Return Accepted', ?, 'system')")
                     ->execute([$ret['provider_id'], $ret['subscriber_id'], $msg]);
        }

        if ($status === 'received') {
            // 1. Update Provider DB: Add qty back to inventory ONLY if NOT damaged
            if (!$is_damaged) {
                $stmt_p = $main_pdo->prepare("SELECT db_name FROM tenants WHERE id = ?");
                $stmt_p->execute([$ret['provider_id']]);
                $p_db = $stmt_p->fetchColumn();
                
                $p_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$p_db", DB_USER, DB_PASS); // This is the provider's DB
                // Use branch stored in return request
                $provider_stock_branch = get_active_stock_branch_id($ret['receiver_branch_id']);
                $p_pdo->prepare("UPDATE products SET stock_level = stock_level + ? WHERE id = ? AND branch_id = ?")
                      ->execute([$ret['qty'], $ret['provider_item_id'], $provider_stock_branch]);
                
                try {
                    $p_pdo->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")
                          ->execute([$ret['provider_item_id'], $ret['qty'], "B2B Return #$return_id Received (Resalable)"]);
                } catch(Throwable $e) {}
            }

            // 2. Update Subscriber DB: Deduct qty from their inventory
            $stmt_s = $main_pdo->prepare("SELECT db_name FROM tenants WHERE id = ?");
            $stmt_s->execute([$ret['subscriber_id']]);
            $s_db = $stmt_s->fetchColumn();

            $s_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$s_db", DB_USER, DB_PASS); // This is the subscriber's DB
            $subscriber_branch_id_for_return = $ret['sender_branch_id'] ?? null; // Use the branch from which it was sent
            $s_pdo->prepare("UPDATE products SET stock_level = stock_level - ? WHERE id = ? AND branch_id = ?")
                  ->execute([$ret['qty'], $ret['subscriber_item_id'], $subscriber_branch_id_for_return]);

            try {
                $s_pdo->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")
                      ->execute([$ret['subscriber_item_id'], -$ret['qty'], "B2B Return #$return_id Handshake Complete"]);
            } catch(Exception $e) {}

            // Finalize order status if this was the last pending return
            $stmt_check = $main_pdo->prepare("SELECT COUNT(*) FROM b2b_return_requests WHERE order_id = ? AND id != ? AND status NOT IN ('received', 'rejected')");
            $stmt_check->execute([$ret['order_id'], $return_id]);
            if ($stmt_check->fetchColumn() == 0) {
                $main_pdo->prepare("UPDATE b2b_orders SET status = 'finalized' WHERE id = ?")->execute([$ret['order_id']]);
            }

            // 3. Financial Adjustment: Reduce order total by refund amount (Adjustment to outstanding balance)
            $main_pdo->prepare("UPDATE b2b_orders SET total_amount = total_amount - ? WHERE id = ?")
                     ->execute([$refund, $ret['order_id']]);
        }

        // Update status in main DB
        $stmt = $main_pdo->prepare("UPDATE b2b_return_requests SET status = ?, refund_amount = ?, is_damaged = ? WHERE id = ?");
        $stmt->execute([$status, $refund, $is_damaged, $return_id]);

        $main_pdo->commit();
        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'dispute_order') {
        $id = $input['id'] ?? null;
        $reason = $input['reason'] ?? '';
        $image_path = null;

        if (isset($_FILES['proof']) && $_FILES['proof']['error'] === 0) {
            $dir = 'uploads/disputes/';
            if (!is_dir($dir)) mkdir($dir, 0777, true);
            $ext = pathinfo($_FILES['proof']['name'], PATHINFO_EXTENSION);
            $filename = 'dispute_' . $id . '_' . time() . '.' . $ext;
            if (move_uploaded_file($_FILES['proof']['tmp_name'], $dir . $filename)) {
                $image_path = $dir . $filename;
            }
        }

        // Update Main DB
        $stmt = $main_pdo->prepare("UPDATE b2b_orders SET status = 'disputed', dispute_reason = ?, dispute_image = ? WHERE id = ?");
        $stmt->execute([$reason, $image_path, $id]);

        // Notify Provider
        $stmt = $main_pdo->prepare("SELECT receiver_tenant_id FROM b2b_orders WHERE id = ?");
        $stmt->execute([$id]);
        $prov_id = $stmt->fetchColumn();
        
        $biz_name = $_SESSION['business_name'] ?? 'Partner';
        $msg = "Order #$id has been DISPUTED by $biz_name. Please check details.";
        $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (?, ?, 'Order Disputed', ?, 'alert')")
                 ->execute([$subscriber_tenant_id, $prov_id, $msg]);

        ob_clean();
        echo json_encode(['success' => true]);
        exit;

    } elseif ($action === 'get_partner_products') {
        $partner_id = $_GET['partner_id'];
        $branch_id = $_GET['branch_id'] ?? null;
        $stmt = $main_pdo->prepare("SELECT db_name FROM tenants WHERE id = ?");
        $stmt->execute([$partner_id]);
        $pdb = $stmt->fetchColumn();

        if (!$pdb) throw new Exception("Partner database not found.");

        $p_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$pdb", DB_USER, DB_PASS);

        // Check if partner has branches enabled
        $stmt_mod = $main_pdo->prepare("SELECT COUNT(*) FROM enabled_modules WHERE tenant_id = ? AND module_key = 'manage_branches'");
        $stmt_mod->execute([$partner_id]);
        $has_branches_mod = $stmt_mod->fetchColumn() > 0;

        $branches = [];
        if ($has_branches_mod) {
            try {
                $branches = $p_pdo->query("SELECT id, branch_name, address, is_main FROM branches ORDER BY is_main DESC, branch_name ASC")->fetchAll(PDO::FETCH_ASSOC);
            } catch(Exception $e) { $has_branches_mod = false; }
        }

        // Default to Main Branch if not specified but branches exist
        if (!$branch_id && $has_branches_mod && !empty($branches)) {
            foreach($branches as $br) { if($br['is_main']) { $branch_id = $br['id']; break; } }
        }

        $sql = "SELECT p.id, p.name, p.sale_price as cost, p.sku, u.name as unit, c.name as category_name FROM products p LEFT JOIN units u ON p.unit_id = u.id LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_b2b_public = 1";
        $params = [];
        if ($branch_id) {
            $is_main = false;
            foreach($branches as $br) { if($br['id'] == $branch_id && $br['is_main']) { $is_main = true; break; } }
            $sql .= $is_main ? " AND (p.branch_id = ? OR p.branch_id IS NULL)" : " AND p.branch_id = ?";
            $params[] = $branch_id;
        }

        $stmt = $p_pdo->prepare($sql . " ORDER BY p.name ASC");
        $stmt->execute($params);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Fetch mappings for this subscriber
        $m_stmt = $main_pdo->prepare("SELECT provider_item_id, subscriber_item_id FROM b2b_product_mappings WHERE provider_tenant_id = ? AND subscriber_tenant_id = ?");
        $m_stmt->execute([$partner_id, $subscriber_tenant_id]);
        $mappings = $m_stmt->fetchAll(PDO::FETCH_KEY_PAIR); // Returns [provider_id => subscriber_id]

        foreach($products as &$p) {
            $p['subscriber_item_id'] = $mappings[$p['id']] ?? null;
        }

        ob_clean();
        echo json_encode([
            'success' => true, 
            'products' => $products, 
            'branches' => $branches, 
            'has_branches_mod' => $has_branches_mod
        ]);
        exit;
    }

} catch (Throwable $e) {
    if (isset($main_pdo) && $main_pdo->inTransaction()) $main_pdo->rollBack();
    ob_clean();
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    exit;
}