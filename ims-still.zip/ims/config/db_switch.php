<?php
/**
 * Tenant Database Switcher
 *
 * This script starts a session, reads the tenant's database name ('db_name'),
 * and establishes a PDO connection to that specific database.
 * The resulting connection object is stored in $tenant_conn.
 *
 * This file should be included at the top of any page that needs to
 * interact with a logged-in tenant's data.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- Include Central Database Connection ---
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/../mailer/email_helper.php';

$tenant_conn = null; // Initialize connection variable
$active_modules = []; // Global modules array
$m_pdo = null; // Share main DB connection
$role_allowed_modules = null; // Global role permissions cache
$logo_url = null; // Global logo variable
$currency_symbol = '$'; // Global fallback
$global_tax_rate = 0;
$max_discount_limit = 100;
$discount_limit_type = 'percentage';
$staff_limit = 5; // Global fallback
$is_super_admin_impersonating = false; // Flag to indicate if Super Admin is viewing tenant panel
$is_system_inactive = false; // Status 'inactive': visible but blurred/locked
$is_system_locked = false;   // Status 'locked' or Expired: Hidden except whitelist

// Clear any previous lock reason
unset($_SESSION['lock_reason']);

if (isset($_SESSION['super_admin_backup'])) {
    $is_super_admin_impersonating = true;
}
$branch_limit = 1; // Global fallback
$has_critical_verification = false; // Flag for Red Alert Bar

// Check if a tenant is logged in (i.e., db_name is in the session)
if (isset($_SESSION['db_name']) && !empty($_SESSION['db_name'])) {
    $tenant_db_name = $_SESSION['db_name'];
    $industry_type = strtolower(trim($_SESSION['industry_type'] ?? 'retail'));

    try {
        // Establish connection to the specific tenant's database
        $tenant_conn = new PDO("mysql:host=" . DB_HOST . ";dbname=$tenant_db_name", DB_USER, DB_PASS);
        $tenant_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Connect to Main DB to fetch Tenant Config & Modules
        $m_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
        $m_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // --- Subscription & Expiry Logic ---
    $sub_status = 'inactive';
    $sub_expiry = 'N/A';

    // 1. Fetch Global Settings & Tenant Status
    $stmt_conf = $m_pdo->prepare("SELECT id, status, email, logo_url, package_id, business_category_id, currency_code, currency_symbol, tax_rate, max_discount_limit, discount_limit_type, staff_limit, branch_limit, allow_receipt_reprint, current_storage_usage, storage_limit 
                                     FROM tenants 
                                     WHERE db_name = ?");
        $stmt_conf->execute([$tenant_db_name]);
        $t_conf = $stmt_conf->fetch(PDO::FETCH_ASSOC);

    if ($t_conf) {
        $tenant_status = $t_conf['status'] ?? 'active';
        $_SESSION['tenant_status'] = $tenant_status;

        // --- Storage Limit Check ---
        $current_storage_usage = (float)($t_conf['current_storage_usage'] ?? 0);
        $storage_limit = (int)($t_conf['storage_limit'] ?? 1);

        // If storage is full and tenant is not already locked or suspended
        if ($current_storage_usage >= $storage_limit && $tenant_status !== 'locked' && $tenant_status !== 'suspended') {
            // Update tenant status to 'locked' in the main database
            $m_pdo->prepare("UPDATE tenants SET status = 'locked' WHERE id = ?")->execute([$t_conf['id']]);
            $tenant_status = 'locked'; // Update current status for this request
            $_SESSION['tenant_status'] = 'locked';
            $_SESSION['lock_reason'] = 'storage_full'; // Set lock reason

            // Add a notification for storage full
            $title = "Storage Limit Reached";
            $msg = "Your account has reached its storage limit of {$storage_limit} MB. Please upgrade your plan to continue using all features.";
            $check = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND DATE(created_at) = CURDATE()");
            $check->execute([$t_conf['id'], $title]);
            if ($check->fetchColumn() == 0) {
                $m_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'alert')")->execute([$t_conf['id'], $title, $msg]);
            }
        }

        // --- ACTION 1: SUSPENDED CHECK ---
        if ($tenant_status === 'suspended' && !$is_super_admin_impersonating) {
            http_response_code(403);
            echo "<style>
                body { background: #0a0a0a; color: white; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
                .box { text-align: center; border: 1px solid #333; padding: 40px; border-radius: 24px; background: #111; max-width: 400px; }
                h1 { color: #e11d48; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 2px; }
                p { color: #888; line-height: 1.6; }
            </style>
            <div class='box'>
                <h1>Account Suspended</h1>
                <p>Your business access has been suspended by the administrator. Please contact Biltax Support for further details.</p>
                <a href='login.php' style='color: white; text-decoration: underline; font-size: 12px; margin-top: 20px; display: block;'>Back to Login</a>
            </div>";
            exit;
        }

        try {
            $stmt_sub = $m_pdo->prepare("SELECT status, expiry_date FROM subscriptions WHERE tenant_id = ? ORDER BY id DESC LIMIT 1");
            $stmt_sub->execute([$t_conf['id']]);
            $sub_info = $stmt_sub->fetch(PDO::FETCH_ASSOC);

            if ($sub_info) {
                $sub_status = $sub_info['status'];
                $sub_expiry = $sub_info['expiry_date'];

                // Fetch Actual Plan Name
                $stmt_pn = $m_pdo->prepare("SELECT package_name FROM packages WHERE id = ?");
                $stmt_pn->execute([$t_conf['package_id']]);
                $_SESSION['subscription_plan_name'] = $stmt_pn->fetchColumn() ?: 'Starter';

                // Auto-Expiry (Safe Check)
                if ($m_pdo && ($sub_status === 'active' || $sub_status === 'trial') && $sub_expiry && $sub_expiry < date('Y-m-d')) {
                    $m_pdo->prepare("UPDATE subscriptions SET status = 'expired' WHERE tenant_id = ?")->execute([$t_conf['id']]);
                    $sub_status = 'expired';

                    // Real-time notification for expiry
                    $title = "Subscription Expired";
                    $msg = "Your subscription has expired. Please renew now to avoid service interruption.";
                    $check = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND DATE(created_at) = CURDATE()");
                    $check->execute([$t_conf['id'], $title]);
                    if ($check->fetchColumn() == 0) {
                        // Only add notification if not already added today
                        $m_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'alert')")
                            ->execute([$t_conf['id'], $title, $msg]);
                        
                        // Send Expiry Email
                        sendBiltaxEmail($t_conf['email'] ?? '', 'Subscription Expired', [
                            'days_left' => '0', 
                            'plan_name' => $_SESSION['subscription_plan_name'] ?? 'Plan'
                        ], 'expiry');
                    }
                }
            }
        } catch (Exception $e) {
            // Billing tables not ready, fail silently to keep dashboard alive
        }
        $_SESSION['subscription_status'] = $sub_status;
        $_SESSION['subscription_expiry'] = $sub_expiry;

        // --- ACTION 2: STATE DETECTION ---
        $valid_subs = ['active', 'trial'];
        
        // State 1: Inactive (Blurred/Locked)
        if ($tenant_status === 'inactive') {
            $is_system_inactive = true;
        }
        // State 2: Locked (Hidden except whitelist) - also triggered by expiry
        if ($tenant_status === 'locked' || !in_array($sub_status, $valid_subs)) {
            $is_system_locked = true;
            // If lock_reason is not already set by storage full, set it to subscription_expired
            if (!isset($_SESSION['lock_reason']) && $tenant_status !== 'suspended') { // Don't overwrite if already suspended
                $_SESSION['lock_reason'] = 'subscription_expired';
            }
        }
    }

        if ($t_conf) { // Ensure $t_conf is not false
            $currency_symbol = $t_conf['currency_symbol'] ?: '$';
            $logo_url = $t_conf['logo_url'];
            $global_tax_rate = (float)($t_conf['tax_rate'] ?? 0);
            $max_discount_limit = (float)($t_conf['max_discount_limit'] ?? 100);
            $discount_limit_type = $t_conf['discount_limit_type'] ?? 'percentage';
            $allow_receipt_reprint = (bool)($t_conf['allow_receipt_reprint'] ?? 0);
            $staff_limit = (int)($t_conf['staff_limit'] ?? 5);
            $branch_limit = (int)($t_conf['branch_limit'] ?? 1);
            $current_storage_usage = (float)($t_conf['current_storage_usage'] ?? 0);
            $storage_limit = (int)($t_conf['storage_limit'] ?? 1);
            
            // 2. Fetch Modules (Only if $t_conf['id'] is valid)
            // Combined Logic: Manual Enabled + Industry Defaults + Package Features
            $stmt_mod = $m_pdo->prepare("
                SELECT module_key FROM enabled_modules WHERE tenant_id = ? AND is_active = 1
                UNION
                SELECT module_key FROM category_modules WHERE category_id = ?
                UNION
                SELECT m.module_key FROM package_features pf JOIN modules m ON pf.module_id = m.id WHERE pf.package_id = ?
            ");
            $stmt_mod->execute([$t_conf['id'], $t_conf['business_category_id'], $t_conf['package_id']]);
            $active_modules = $stmt_mod->fetchAll(PDO::FETCH_COLUMN);
        }


        // 3. Check for High Priority Verification Tasks
        if (isset($t_conf['id']) && in_array('verification_center', $active_modules)) {
            $stmt_v = $m_pdo->prepare("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id = ? AND priority = 'high' AND status IN ('not_started', 'rejected')");
            $stmt_v->execute([$t_conf['id']]);
            $has_critical_verification = ($stmt_v->fetchColumn() > 0);
        }

        // --- Initialize Active Branch Session ---
        $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
        $main_branch_id = $stmt_main->fetchColumn();

        // Force Main Branch if module is disabled or session not set
        if (!isset($_SESSION['active_branch_id']) || !in_array('manage_branches', $active_modules)) {
            if ($main_branch_id) $_SESSION['active_branch_id'] = $main_branch_id;
        }

        // --- Branch Switching Handler ---
        if (isset($_GET['switch_branch_id'])) {
            $sid_raw = $_GET['switch_branch_id'];

            // Lock Down: Staff with assignment cannot switch
            $can_switch = true;
            if (isset($_SESSION['staff_id']) && isset($_SESSION['staff_restricted']) && $_SESSION['staff_restricted'] === true) {
                $can_switch = false;
            }

            if ($can_switch && $sid_raw === 'all') {
                $_SESSION['active_branch_id'] = 'all';
                header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
                exit;
            } elseif ($can_switch) {
                $sid = (int)$_GET['switch_branch_id'];
                // Verify branch belongs to tenant
                $stmt_v = $tenant_conn->prepare("SELECT COUNT(*) FROM branches WHERE id = ?");
                $stmt_v->execute([$sid]);
                if ($stmt_v->fetchColumn() > 0) {
                    $_SESSION['active_branch_id'] = $sid;
                    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?')); // Redirect back to same page without param
                    exit;
                }
            }
        }

        // Fallback defaults if no modules are explicitly enabled in DB
        if (empty($active_modules)) {
            $active_modules = ['dashboard', 'reports', 'settings', 'manage_branches', 'inventory', 'support_tickets', 'documentation', 'knowledge_base', 'biltax_hub', 'marketplace_main']; 
            switch ($industry_type) {
                case 'restaurant':
                    $active_modules = array_merge($active_modules, ['food_pos', 'tables', 'kot', 'recipes', 'staff', 'receipt_reprint']);
                    break;
                case 'wholesale':
                    $active_modules = array_merge($active_modules, ['bulk_sales', 'inventory', 'ledgers', 'purchases', 'staff', 'partner_network', 'b2b_returns', 'b2b_orders', 'receipt_reprint']);
                    break;
                case 'service':
                    $active_modules = array_merge($active_modules, ['jobs', 'customers', 'reminders', 'receipt_reprint']);
                    break;
                default: // Retail
                    $active_modules = array_merge($active_modules, ['retail_pos', 'inventory', 'suppliers', 'barcodes', 'sales_reports', 'staff', 'purchases', 'whatsapp_email_sharing', 'receipt_reprint']);
                    break;
            }
        }

        // Background sync and schema maintenance removed for production performance.
        // All tables are now created complete in register_tenant.php or via manual system update.

    } catch (PDOException $e) {
        // If connection fails, stop everything and show an error.
        http_response_code(503); // Service Unavailable
        die("FATAL ERROR: Could not connect to database. Error: " . $e->getMessage());
    }
}

// --- ACTION 3: ACCESS REDIRECTION LOGIC ---
$current_script = basename($_SERVER['PHP_SELF']);
$current_slug = basename($_SERVER['PHP_SELF'], '.php');

// Whitelisted pages in Locked state
$whitelisted_pages = [
    'billing_plans_view.php', 'billing_history.php', 'setting.php', 
    'support_tickets.php', 'documentation.php', 'knowledge_base.php', 
    'pay_now.php', 'logout.php', 'locked_feature.php', 'login.php',
    'api.php', 'api_notifications.php', 'api_mark_read.php'
];

// Both Inactive and Locked states redirect non-whitelisted pages
if (($is_system_locked || $is_system_inactive) && !in_array($current_script, $whitelisted_pages) && !$is_super_admin_page) {
    $redirect_url = "billing_plans_view.php?lock=true";
    if (isset($_SESSION['lock_reason'])) { $redirect_url .= "&reason=" . $_SESSION['lock_reason']; }
    header("Location: " . $redirect_url);
    exit;
}

/**
 * World-class Module Access Helper
 */
if (!function_exists('has_module')) {
    function has_module($key) {
        global $active_modules, $role_allowed_modules, $m_pdo;
        
        // 1. Tenant-Level Check
        // Core support and hub modules bypass the tenant-enabled check so Role Permissions can control them globally.
        $global_bypass_keys = ['documentation', 'knowledge_base', 'support_tickets', 'biltax_hub', 'marketplace_main', 'live_chat', 'notifications'];
        
        if (!in_array($key, $active_modules) && !in_array($key, $global_bypass_keys)) return false;

        // 2. Role Check: Admin always has full access
        $user_role = strtolower(trim($_SESSION['role'] ?? 'admin'));
        if ($user_role === 'admin') return true;

        // 3. Check Role-based permissions from main DB
        if ($role_allowed_modules === null) {
            try {
                if (!$m_pdo) {
                    $m_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
                    $m_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                }
                $stmt_perm = $m_pdo->prepare("SELECT module_key FROM role_permissions WHERE role_key = ? AND is_allowed = 1");
                $stmt_perm->execute([$user_role]);
                $role_allowed_modules = $stmt_perm->fetchAll(PDO::FETCH_COLUMN);
            } catch (Exception $e) {
                $role_allowed_modules = []; // Fallback empty if table missing
            }
        }

        return in_array($key, $role_allowed_modules);
    }
}

/**
 * Background helper to detect low stock and notify the main dashboard
 */
function syncLowStockAlerts($host, $user, $pass, $tenant_pdo, $db_name) {
    try {
        // Connect to Main DB for notifications
        $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
        
        // 1. Get Tenant ID and Email from main database
        $stmt = $main_pdo->prepare("SELECT id, email FROM tenants WHERE db_name = ?");
        $stmt->execute([$db_name]);
        $t_data = $stmt->fetch(PDO::FETCH_ASSOC);
        $tenant_id = $t_data['id'] ?? null;
        $tenant_email = $t_data['email'] ?? '';
        
        if (!$tenant_id) return;

        // 2. Safe check for columns before query to prevent 500 error
        $stmt_cols = $tenant_pdo->query("SHOW COLUMNS FROM products");
        $cols = $stmt_cols->fetchAll(PDO::FETCH_COLUMN);
        
        if (!in_array('stock_level', $cols) || !in_array('alert_level', $cols)) return;

        $stmt_low = $tenant_pdo->query("SELECT name, sku, stock_level, alert_level FROM products WHERE stock_level <= alert_level");
        $low_stock_items = $stmt_low ? $stmt_low->fetchAll(PDO::FETCH_ASSOC) : [];

        foreach ($low_stock_items as $item) {
            $title = "Low Stock Alert";
            $msg = "Warning: Product '" . $item['name'] . "' (" . $item['sku'] . ") has reached critical level. Current: " . $item['stock_level'];

            // 3. Prevent Duplicate Spam (Check if a similar alert was sent in the last 24 hours)
            $check = $main_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND message = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
            $check->execute([$tenant_id, $title, $msg]);

            if ($check->fetchColumn() == 0) {
                // 4. Insert System Notification
                $ins = $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'system')");
                $ins->execute([$tenant_id, $title, $msg]);

                // 5. Send Stock Alert Email
                sendBiltaxEmail($tenant_email, 'Low Stock Alert', ['items' => [['name' => $item['name'], 'stock' => $item['stock_level']]]], 'stock_alert');
            }
        }
    } catch (Exception $e) {
        // Silently fail to ensure the main application logic remains uninterrupted
    }
}

/**
 * Background helper to detect subscription expiry and notify
 */
if (!function_exists('syncSubscriptionExpiryNotifications')) {
    function syncSubscriptionExpiryNotifications($m_pdo, $tenant_id) {
        try {
            // Get Email for the tenant
            $stmt_e = $m_pdo->prepare("SELECT email FROM tenants WHERE id = ?");
            $stmt_e->execute([$tenant_id]);
            $t_email = $stmt_e->fetchColumn() ?: '';

            // 1. Check for Expiry Tomorrow (1 Day Before)
            $tomorrow = date('Y-m-d', strtotime('+1 day'));
            $stmt = $m_pdo->prepare("SELECT s.expiry_date, p.package_name FROM subscriptions s JOIN packages p ON s.plan_id = p.id WHERE s.tenant_id = ? AND s.status IN ('active', 'trial') AND s.expiry_date = ?");
            $stmt->execute([$tenant_id, $tomorrow]);
            $sub = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($sub) {
                $title = "Subscription Expiring Tomorrow";
                $msg = "Your subscription for " . $sub['package_name'] . " will expire tomorrow. Please renew to avoid interruption.";
                
                $check = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND DATE(created_at) = CURDATE()");
                $check->execute([$tenant_id, $title]);

                if ($check->fetchColumn() == 0) {
                    $m_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'alert')")
                        ->execute([$tenant_id, $title, $msg]);

                    // Send 1-Day Warning Email
                    sendBiltaxEmail($t_email, 'Plan Expiring Tomorrow', [
                        'days_left' => '1', 
                        'plan_name' => $sub['package_name']
                    ], 'expiry');
                }
            }

            // Note: "Expired" notification is handled in the main db_switch loop above 
            // when status transition happens.

        } catch (Exception $e) {
            error_log("Subscription Sync Error: " . $e->getMessage());
        }
    }
}

/**
 * Background helper to detect expiring stock and notify the main dashboard
 */
if (!function_exists('syncExpiringStockAlerts')) {
    function syncExpiringStockAlerts($host, $user, $pass, $tenant_pdo, $db_name) {
        try {
            $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
            $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
            $stmt->execute([$db_name]);
            $tenant_id = $stmt->fetchColumn();
            if (!$tenant_id) return;

            // Fetch products expiring within the next 30 days
            $expiring_items = $tenant_pdo->query("SELECT name, sku, (SELECT expiry_date FROM stock WHERE product_id = products.id AND expiry_date IS NOT NULL ORDER BY expiry_date ASC LIMIT 1) as expiry_date FROM products WHERE is_expirable = 1 HAVING expiry_date IS NOT NULL AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($expiring_items as $item) {
                $title = "Stock Expiry Alert";
                $msg = "Warning: Product '" . $item['name'] . "' (" . $item['sku'] . ") is expiring soon on " . $item['expiry_date'] . ".";

                $check = $main_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND message = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
                $check->execute([$tenant_id, $title, $msg]);

                if ($check->fetchColumn() == 0) {
                    $ins = $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'expiry_alert')");
                    $ins->execute([$tenant_id, $title, $msg]);
                }
            }
        } catch (Exception $e) {
            error_log("Expiring Stock Sync Error: " . $e->getMessage());
        }
    }
}

/**
 * Background helper to detect due service reminders and notify the main dashboard
 */
if (!function_exists('syncServiceRemindersAlerts')) {
    function syncServiceRemindersAlerts($host, $user, $pass, $tenant_pdo, $db_name) {
        try {
            $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
            $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
            $stmt->execute([$db_name]);
            $tenant_id = $stmt->fetchColumn();
            if (!$tenant_id) return;

            // Fetch reminders due today or in the past that are still pending
            $due_reminders = $tenant_pdo->query("SELECT r.id, r.message, c.name as customer_name FROM reminders r JOIN customers c ON r.customer_id = c.id WHERE r.status = 'pending' AND r.due_date <= CURDATE()")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($due_reminders as $reminder) {
                $title = "Service Reminder Due";
                $msg = "Reminder for " . $reminder['customer_name'] . ": " . $reminder['message'];

                $check = $main_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND message = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
                $check->execute([$tenant_id, $title, $msg]);

                if ($check->fetchColumn() == 0) {
                    $ins = $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'service_reminder')");
                    $ins->execute([$tenant_id, $title, $msg]);
                }
            }
        } catch (Exception $e) {
            error_log("Service Reminders Sync Error: " . $e->getMessage());
        }
    }
}

/**
 * Background helper to detect new B2B orders and notify the main dashboard
 */
if (!function_exists('syncB2BAlerts')) {
    function syncB2BAlerts($host, $user, $pass, $tenant_pdo, $db_name) {
        try {
            $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
            $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
            $stmt->execute([$db_name]);
            $tenant_id = $stmt->fetchColumn();
            if (!$tenant_id) return;

            // Fetch new B2B orders for this tenant that are still pending
            $new_b2b_orders = $main_pdo->prepare("SELECT id, sender_tenant_id FROM b2b_orders WHERE receiver_tenant_id = ? AND status = 'pending' AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)"); // Check for orders in last hour to avoid old ones
            $new_b2b_orders->execute([$tenant_id]);
            $orders = $new_b2b_orders->fetchAll(PDO::FETCH_ASSOC);

            foreach ($orders as $order) {
                $title = "New B2B Order Received";
                $msg = "You have received a new B2B order (ID: " . $order['id'] . ") from Sender ID: " . $order['sender_tenant_id'];

                $check = $main_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND message = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
                $check->execute([$tenant_id, $title, $msg]);

                if ($check->fetchColumn() == 0) {
                    $ins = $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'b2b_order')");
                    $ins->execute([$tenant_id, $title, $msg]);
                }
            }
        } catch (Exception $e) {
            error_log("B2B Alerts Sync Error: " . $e->getMessage());
        }
    }
}

/**
 * Resolves the branch ID from which stock should be pulled.
 * 
 * @param int $session_branch_id The branch ID currently active in user's session.
 * @return int|null The branch ID to use for stock queries.
 */
if (!function_exists('get_active_stock_branch_id')) {
    function get_active_stock_branch_id($session_branch_id) {
        global $tenant_conn;
        
        if (!$tenant_conn || empty($session_branch_id) || $session_branch_id === 'all') {
            // Fallback to Main Branch if 'all' or empty
            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $main_id = $stmt_main->fetchColumn();
            return $main_id ? (int)$main_id : null;
        }

        try {
            // 1. Check if the current branch has its own stock
            $stmt = $tenant_conn->prepare("SELECT has_own_stock FROM branches WHERE id = ?");
            $stmt->execute([$session_branch_id]);
            $branch = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($branch && (int)$branch['has_own_stock'] === 1) {
                return (int)$session_branch_id;
            }

            // 2. If not, fallback to the Main branch ID
            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $main_id = $stmt_main->fetchColumn();
            
            return $main_id ? (int)$main_id : null;
        } catch (Exception $e) {
            error_log("Gatekeeper Error (Branch Resolution): " . $e->getMessage());
            return null;
        }
    }
}

/**
 * Helper function to check page access based on page_access_controls.
 * Redirects if access is denied.
 *
 * @param string $current_page_slug The slug of the current page (e.g., 'dashboard', 'b2b_connect').
 */
if (!function_exists('gatekeeper_check')) {
    function gatekeeper_check($current_page_slug) {
        global $m_pdo, $t_conf; // Access global main PDO and tenant config

        // If tenant is not logged in, let the regular authentication handle redirection
        if (!isset($t_conf['id'])) {
            return; 
        }

        $tenant_id = $t_conf['id'];
        $tenant_package_id = $t_conf['package_id'];

        try {
            // 1. Fetch Rules for the current page slug
            // Using trim and lowercase for foolproof slug matching
            $stmt = $m_pdo->prepare("SELECT * FROM page_access_controls WHERE LOWER(TRIM(page_slug)) = LOWER(TRIM(?))");
            $stmt->execute([$current_page_slug]);
            $rule = $stmt->fetch(PDO::FETCH_ASSOC);

            // If no rule exists at all in the gatekeeper table, allow access
            if (!$rule) { 
                error_log("GATEKEEPER_DEBUG: No active rule found for page slug: '$current_page_slug'. Allowing access."); //
                return;
            }

            // NEW: If status is 'inactive', it means the page is MANUALLY DISABLED by Super Admin
            if (trim($rule['status']) === 'inactive') {
                error_log("GATEKEEPER_DEBUG: Page '$current_page_slug' is INACTIVE. Denying access.");
                header("Location: locked_feature.php?msg=" . urlencode("This feature is currently disabled by the system administrator."));
                exit();
            }

            error_log("GATEKEEPER_DEBUG: Rule found for '$current_page_slug'. Details: " . json_encode($rule)); //

            switch ($rule['restriction_type']) {
                case 'none':
                    // No restriction, allow access
                    break;

                case 'request_based':
                    error_log("GATEKEEPER_DEBUG: Checking Request Status for '$current_page_slug'."); 
                    if (!empty($rule['required_verification_task_id'])) {
                        $stmt_template_task = $m_pdo->prepare("SELECT task_title FROM verification_tasks WHERE id = ? AND tenant_id IS NULL");
                        $stmt_template_task->execute([$rule['required_verification_task_id']]);
                        $template_task_title = $stmt_template_task->fetchColumn();

                        if ($template_task_title) {
                            $stmt_tenant_task = $m_pdo->prepare("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id = ? AND task_title = ? AND status = 'approved'");
                            $stmt_tenant_task->execute([$tenant_id, $template_task_title]);
                            $is_approved = $stmt_tenant_task->fetchColumn() > 0;

                            if (!$is_approved) {
                                // Check if user has already submitted a request
                                $stmt_pending = $m_pdo->prepare("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id = ? AND task_title = ? AND status = 'pending_review'");
                                $stmt_pending->execute([$tenant_id, $template_task_title]);
                                $is_pending = $stmt_pending->fetchColumn() > 0;

                                if ($is_pending) {
                                    header("Location: locked_feature.php?type=request_based&msg=" . urlencode("Your request for this feature is currently under review. Please wait for admin approval."));
                                } else {
                                    header("Location: locked_feature.php?type=request_based&msg=" . urlencode("This feature requires a special access request."));
                                }
                                exit();
                            }
                        } else {
                            error_log("GATEKEEPER_ERROR: Restriction set to 'request_based' but template task ID " . $rule['required_verification_task_id'] . " not found for '$current_page_slug'.");
                            header("Location: locked_feature.php?msg=" . urlencode("Feature configuration error: No request task linked. Please contact support."));
                            exit();
                        }
                    } else {
                        error_log("GATEKEEPER_ERROR: Restriction set to 'request_based' but no task linked for '$current_page_slug'.");
                        header("Location: locked_feature.php?msg=" . urlencode("Feature configuration error: No request task linked. Please contact support."));
                        exit();
                    }
                    break;

                case 'verification_required':
                    error_log("GATEKEEPER_DEBUG: Checking Verification for '$current_page_slug'. Required Task ID: " . $rule['required_verification_task_id']); //
                    // Check if a specific verification task is required and approved
                    if (!empty($rule['required_verification_task_id'])) {
                        // Get the task_title of the template task (assuming tenant_id IS NULL for templates)
                        $stmt_template_task = $m_pdo->prepare("SELECT task_title FROM verification_tasks WHERE id = ? AND tenant_id IS NULL");
                        $stmt_template_task->execute([$rule['required_verification_task_id']]);
                        $template_task_title = $stmt_template_task->fetchColumn();

                        if ($template_task_title) {
                            error_log("GATEKEEPER_DEBUG: Template task title found: '$template_task_title'. Checking tenant tasks."); //
                            // Check if the current tenant has an APPROVED task with this title
                            $stmt_tenant_task = $m_pdo->prepare("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id = ? AND task_title = ? AND status = 'approved'");
                            $stmt_tenant_task->execute([$tenant_id, $template_task_title]);
                            $is_approved = $stmt_tenant_task->fetchColumn() > 0;

                            error_log("GATEKEEPER_DEBUG: Tenant $tenant_id has approved task '$template_task_title': " . ($is_approved ? 'YES' : 'NO')); //
                            if (!$is_approved) {
                                // Access denied: Redirect to Verification Center
                                error_log("GATEKEEPER_DEBUG: Access DENIED for '$current_page_slug' (Verification/Request). Redirecting."); //
                                header("Location: verification_center.php?feature_locked=" . urlencode($current_page_slug)); //
                                exit();
                            }
                        } else {
                            // Configuration error: Template task not found, deny access for safety
                            error_log("GATEKEEPER_ERROR: Template task ID {$rule['required_verification_task_id']} not found in main DB for '$current_page_slug'."); //
                            header("Location: locked_feature.php?msg=" . urlencode("Configuration Error: Verification task template not found for this feature. Please contact support.")); //
                            exit();
                        }
                    } else {
                        // Configuration error: Restriction type set but no task linked, deny access for safety
                        error_log("GATEKEEPER_ERROR: Restriction type '{$rule['restriction_type']}' set but no task linked for '$current_page_slug'."); //
                        header("Location: locked_feature.php?msg=" . urlencode("Configuration Error: No verification task linked for this feature. Please contact support.")); //
                        exit();
                    }
                    break;

                case 'upgrade_required':
                    // Check if tenant's package meets the requirement
                    if (!empty($rule['required_package_id'])) {
                        $req_pkg = (int)$rule['required_package_id'];
                        $cur_pkg = (int)$tenant_package_id;
                        
                        // Assuming higher package_id means a better package
                        if ($cur_pkg < $req_pkg) {
                            error_log("GATEKEEPER_DEBUG: Access DENIED for '$current_page_slug'. Tenant Pkg: $cur_pkg < Required: $req_pkg"); 
                            header("Location: locked_feature.php?type=upgrade_required&msg=" . urlencode("This feature requires a higher subscription plan.")); 
                            exit();
                        }
                    } else {
                        // Configuration error: Restriction type set but no package linked, deny access for safety
                        error_log("GATEKEEPER_ERROR: Restriction type 'upgrade_required' set but no package linked for '$current_page_slug'."); //
                        header("Location: locked_feature.php?msg=" . urlencode("Configuration Error: No package linked for this feature. Please contact support.")); //
                        exit();
                    }
                    break;
            }
        } catch (Exception $e) {
            error_log("GATEKEEPER_RUNTIME_ERROR for '$current_page_slug' (Tenant ID: $tenant_id): " . $e->getMessage()); //
            header("Location: locked_feature.php?msg=" . urlencode("An unexpected error occurred while checking access to this feature. Please try again or contact support.")); //
            exit();
        }
    }
}

// Automatically call gatekeeper_check for tenant-facing pages
// Exclude login.php, register_tenant.php, locked_feature.php, and super_admin pages
$current_script_name = basename($_SERVER['PHP_SELF']);
$current_page_slug = basename($_SERVER['PHP_SELF'], '.php');

$excluded_pages = ['login.php', 'register_tenant.php', 'locked_feature.php', 'auth/register_tenant.php', 'api.php', 'api_notifications.php', 'api_mark_read.php']; // Exclude APIs from gatekeeper
$is_super_admin_page = strpos($_SERVER['PHP_SELF'], '/super_admin/') !== false;

if (isset($_SESSION['db_name']) && !empty($_SESSION['db_name']) && !in_array($current_script_name, $excluded_pages) && !$is_super_admin_page) {
    // Enforce Module-level security for Branch related pages
    if (($current_page_slug === 'manage_branches' || $current_page_slug === 'stock_transfer') && !has_module('manage_branches')) {
        header("Location: dashboard.php");
        exit();
    }
    gatekeeper_check($current_page_slug);
}