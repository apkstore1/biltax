<?php
// --- Connect to Main DB to fetch dynamic settings ---
require_once 'config/db_connect.php';

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // --- Fetch Dynamic Data ---
    $categories = $pdo->query("SELECT * FROM business_categories WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC);
    $packages = $pdo->query("SELECT * FROM packages ORDER BY monthly_price ASC")->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("System Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biltax - Environment Setup</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        
        /* Custom Animations */
        .fade-in { animation: fadeIn 0.4s ease-out forwards; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        .selected-card { border-color: #f97316 !important; background-color: #262626 !important; box-shadow: 0 0 15px rgba(249, 115, 22, 0.15) !important; }
        
        /* Custom Scrollbar */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #171717; }
        ::-webkit-scrollbar-thumb { background: #404040; border-radius: 10px; }
    </style>
</head>
<body class="bg-neutral-950 text-white min-h-screen flex flex-col justify-between selection:bg-orange-500 selection:text-white">

    <!-- Top Bar & Progress -->
    <header class="w-full max-w-4xl mx-auto pt-10 px-6">
        <div class="flex items-center justify-between mb-6">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-orange-900/20 overflow-hidden p-1.5">
                    <img src="assets/Biltax-icon.png" class="w-full h-full object-contain brightness-0 invert" alt="Biltax">
                </div>
                <div>
                    <h1 class="text-xl font-bold tracking-tight text-white">Biltax</h1>
                    <p class="text-[10px] font-bold text-orange-500 uppercase tracking-widest">Environment Setup</p>
                </div>
            </div>
            <div class="text-right hidden sm:block">
                <p class="text-sm text-neutral-400">Step <span id="step-count">1</span> of 4</p>
                <p class="text-xs text-neutral-600" id="step-label">Account Details</p>
            </div>
        </div>

        <!-- Progress Bar -->
        <div class="h-1 w-full bg-neutral-800 rounded-full overflow-hidden">
            <div id="progress-bar" class="h-full bg-orange-600 transition-all duration-500 ease-out w-1/4"></div>
        </div>
    </header>

    <!-- Main Content Wizard -->
    <main class="flex-1 flex items-center justify-center p-6 w-full max-w-2xl mx-auto">
        
        <!-- Step 1: Account Details -->
        <div id="step-1" class="step-section w-full fade-in">
            <h2 class="text-3xl font-bold mb-2">Create your account</h2>
            <p class="text-neutral-400 mb-8">Let's start with your administrative credentials.</p>
            
            <div class="space-y-5">
                <div>
                    <label class="block text-xs font-bold text-neutral-500 uppercase mb-2">Full Name</label>
                    <input type="text" id="owner_name" class="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all" placeholder="e.g. Ali Khan">
                </div>
                <div>
                    <label class="block text-xs font-bold text-neutral-500 uppercase mb-2">Email Address</label>
                    <input type="email" id="email" class="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all" placeholder="name@company.com">
                </div>
                <div>
                    <label class="block text-xs font-bold text-neutral-500 uppercase mb-2">Password</label>
                    <input type="password" id="password" class="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all" placeholder="••••••••">
                </div>
            </div>

            <div class="mt-10 flex justify-between items-center">
                <p class="text-sm text-neutral-500">Already have an account? <a href="login.php" class="text-white hover:text-orange-500 font-bold transition-colors">Login</a></p>
                <button onclick="nextStep(2)" class="bg-white text-black hover:bg-neutral-200 px-8 py-3 rounded-xl font-bold flex items-center gap-2 transition-all">
                    Next Step <i data-lucide="arrow-right" size="18"></i>
                </button>
            </div>
        </div>

        <!-- Step 2: Business Details -->
        <div id="step-2" class="step-section w-full hidden">
            <h2 class="text-3xl font-bold mb-2">Tell us about your business</h2>
            <p class="text-neutral-400 mb-8">This information will appear on your invoices and reports.</p>
            
            <div class="space-y-5">
                <div>
                    <label class="block text-xs font-bold text-neutral-500 uppercase mb-2">Business Name</label>
                    <input type="text" id="business_name" class="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all" placeholder="e.g. Khan Electronics">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <div>
                        <label class="block text-xs font-bold text-neutral-500 uppercase mb-2">Country</label>
                        <select id="country" class="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-5 py-4 text-white focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all">
                            <option value="Pakistan">Pakistan</option>
                            <option value="India">India</option>
                            <option value="United Arab Emirates">United Arab Emirates</option>
                            <option value="Saudi Arabia">Saudi Arabia</option>
                            <option value="United Kingdom">United Kingdom</option>
                            <option value="United States">United States</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-neutral-500 uppercase mb-2">City / Location</label>
                        <input type="text" id="address" class="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all" placeholder="Karachi, Pakistan">
                    </div>
                </div>
                <div>
                    <label class="block text-xs font-bold text-neutral-500 uppercase mb-2">Phone Number</label>
                    <div class="flex gap-2">
                        <select id="phone_code" class="w-32 bg-neutral-900 border border-neutral-800 rounded-xl px-4 py-4 text-white focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all">
                            <option value="+92">+92 (PK)</option>
                            <option value="+91">+91 (IN)</option>
                            <option value="+971">+971 (AE)</option>
                            <option value="+966">+966 (SA)</option>
                            <option value="+44">+44 (UK)</option>
                            <option value="+1">+1 (US)</option>
                        </select>
                        <input type="text" id="phone" class="flex-1 bg-neutral-900 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all" placeholder="300 1234567">
                    </div>
                </div>
                <div class="p-4 bg-orange-500/10 border border-orange-500/20 rounded-xl flex items-start gap-3">
                    <i data-lucide="info" class="text-orange-500 mt-0.5 shrink-0" size="18"></i>
                    <p class="text-sm text-orange-200">A dedicated database will be automatically created for your business environment upon completion.</p>
                </div>
            </div>

            <div class="mt-10 flex justify-between items-center">
                <button onclick="nextStep(1)" class="text-neutral-500 hover:text-white font-medium transition-colors">Back</button>
                <button onclick="nextStep(3)" class="bg-white text-black hover:bg-neutral-200 px-8 py-3 rounded-xl font-bold flex items-center gap-2 transition-all">
                    Next Step <i data-lucide="arrow-right" size="18"></i>
                </button>
            </div>
        </div>

        <!-- Step 3: Industry Selection -->
        <div id="step-3" class="step-section w-full hidden">
            <h2 class="text-3xl font-bold mb-2">Select your Industry</h2>
            <p class="text-neutral-400 mb-8">We will tailor the interface based on your business type.</p>
            
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                <?php foreach ($categories as $cat): ?>
                <div onclick="selectIndustry('<?php echo htmlspecialchars($cat['slug']); ?>', this)" class="industry-card group cursor-pointer relative bg-neutral-900 hover:bg-neutral-800 border border-neutral-800 hover:border-orange-500/50 p-6 rounded-2xl transition-all duration-300">
                    <div class="w-12 h-12 bg-neutral-800 group-hover:bg-orange-500 rounded-full flex items-center justify-center text-white mb-4 transition-colors">
                        <i data-lucide="<?php echo htmlspecialchars($cat['icon_class']); ?>" size="20"></i>
                    </div>
                    <h3 class="text-xl font-bold text-white mb-2"><?php echo htmlspecialchars($cat['category_name']); ?></h3>
                    <p class="text-sm text-neutral-400 group-hover:text-neutral-300"><?php echo htmlspecialchars($cat['description']); ?></p>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-10 flex justify-between items-center">
                <button onclick="nextStep(2)" class="text-neutral-500 hover:text-white font-medium transition-colors">Back</button>
                <button onclick="nextStep(4)" class="bg-white text-black hover:bg-neutral-200 px-8 py-3 rounded-xl font-bold flex items-center gap-2 transition-all">
                    Next Step <i data-lucide="arrow-right" size="18"></i>
                </button>
            </div>
        </div>

        <!-- Step 4: Plan Selection -->
        <div id="step-4" class="step-section w-full hidden">
            <h2 class="text-3xl font-bold mb-2">Choose your Plan</h2>
            <p class="text-neutral-400 mb-8">Scale as your business grows.</p>
            
            <div class="space-y-4">
                <?php foreach ($packages as $pkg): 
                    $slug = strtolower($pkg['package_name']);
                    $isStarter = ($slug === 'starter');
                    $icon = match($slug) { 'starter' => 'sprout', 'pro' => 'zap', 'unlimited' => 'infinity', default => 'box' };
                    $iconColor = match($slug) { 'starter' => 'bg-neutral-800 text-white', 'pro' => 'bg-orange-600/20 text-orange-500', 'unlimited' => 'bg-white text-black', default => 'bg-neutral-800 text-white' };
                    $price = ($pkg['monthly_price'] == 0) ? 'Free' : '$' . number_format($pkg['monthly_price'], 2) . '<span class="text-neutral-500 font-normal text-xs">/mo</span>';
                ?>
                <div onclick="selectPlan('<?php echo $slug; ?>', this)" class="plan-card <?php echo $isStarter ? 'selected-card' : ''; ?> cursor-pointer flex items-center justify-between p-5 rounded-2xl bg-neutral-900 border border-neutral-800 hover:bg-neutral-800 transition-all">
                    <div class="flex items-center gap-4">
                        <div class="w-10 h-10 rounded-full <?php echo $iconColor; ?> flex items-center justify-center"><i data-lucide="<?php echo $icon; ?>" size="18"></i></div>
                        <div>
                            <h3 class="font-bold text-white"><?php echo htmlspecialchars($pkg['package_name']); ?></h3>
                            <p class="text-xs text-neutral-400"><?php echo $pkg['staff_limit']; ?> Staff Members</p>
                        </div>
                    </div>
                    <span class="font-bold text-white"><?php echo $price; ?></span>
                </div>
                <?php endforeach; ?>
            </div>

            <div class="mt-10 flex justify-between items-center">
                <button onclick="nextStep(3)" class="text-neutral-500 hover:text-white font-medium transition-colors">Back</button>
                <button onclick="finishSetup()" class="bg-orange-600 text-white hover:bg-orange-700 px-8 py-3 rounded-xl font-bold flex items-center gap-2 transition-all shadow-lg shadow-orange-900/20">
                    Finish Setup <i data-lucide="check" size="18"></i>
                </button>
            </div>
        </div>

        <!-- Loading State -->
        <div id="loading-state" class="hidden text-center fade-in">
            <div class="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-orange-500 mb-6"></div>
            <h2 class="text-2xl font-bold mb-2">Setting up your environment...</h2>
            <p class="text-neutral-400">Creating database, configuring tables, and securing account.</p>
        </div>

    </main>

    <!-- Footer -->
    <footer class="w-full text-center py-6 border-t border-neutral-900">
        <div class="flex items-center justify-center gap-2 opacity-50 hover:opacity-100 transition-opacity">
            <span class="text-xs text-neutral-500">Powered by</span>
            <span class="text-sm font-black text-white tracking-tighter">HYPERTEX</span>
        </div>
    </footer>

    <script>
        lucide.createIcons();

        let currentStep = 1;
        const formData = {};

        // Pre-select defaults
        formData.industry_type = '';
        formData.package_type = 'starter';

        // Helper to select industry
        function selectIndustry(type, el) {
            formData.industry_type = type;
            document.querySelectorAll('.industry-card').forEach(c => c.classList.remove('selected-card'));
            el.classList.add('selected-card');
        }

        // Helper to select plan
        function selectPlan(type, el) {
            formData.package_type = type;
            document.querySelectorAll('.plan-card').forEach(c => c.classList.remove('selected-card'));
            el.classList.add('selected-card');
        }

        function nextStep(step) {
            // Validation for Step 1
            if (currentStep === 1 && step === 2) {
                const owner = document.getElementById('owner_name').value;
                const email = document.getElementById('email').value;
                const pass = document.getElementById('password').value;

                if (!owner || !email || !pass) {
                    alert("Please fill in all account details.");
                    return;
                }
                formData.owner_name = owner;
                formData.email = email;
                formData.password = pass;
            }

            // Validation for Step 2
            if (currentStep === 2 && step === 3) {
                const business = document.getElementById('business_name').value;
                if (!business) {
                    alert("Please enter your business name.");
                    return;
                }
                const country = document.getElementById('country').value;
                const phoneCode = document.getElementById('phone_code').value;
                const phone = document.getElementById('phone').value;
                const address = document.getElementById('address').value;
                
                formData.business_name = business;
                formData.country = country;
                formData.phone = phoneCode + ' ' + phone;
                formData.address = address;
            }

            // Validation for Step 3
            if (currentStep === 3 && step === 4) {
                if (!formData.industry_type) {
                    alert("Please select an industry.");
                    return;
                }
            }

            showStep(step);
        }

        function showStep(step) {
            // Hide all steps
            document.querySelectorAll('.step-section').forEach(el => el.classList.add('hidden'));
            document.querySelectorAll('.step-section').forEach(el => el.classList.remove('fade-in'));
            
            // Show current step with animation
            const target = document.getElementById(`step-${step}`);
            target.classList.remove('hidden');
            void target.offsetWidth; // Trigger reflow for animation
            target.classList.add('fade-in');

            // Update Progress Bar
            const progress = document.getElementById('progress-bar');
            const stepCount = document.getElementById('step-count');
            const stepLabel = document.getElementById('step-label');

            currentStep = step;
            stepCount.innerText = step;
            
            if (step === 1) {
                progress.style.width = '25%';
                stepLabel.innerText = "Account Details";
            } else if (step === 2) {
                progress.style.width = '50%';
                stepLabel.innerText = "Business Details";
            } else if (step === 3) {
                progress.style.width = '75%';
                stepLabel.innerText = "Industry Selection";
            } else if (step === 4) {
                progress.style.width = '100%';
                stepLabel.innerText = "Plan Selection";
            }
        }

        async function finishSetup() {
            // Show Loading
            document.querySelectorAll('.step-section').forEach(el => el.classList.add('hidden'));
            document.getElementById('loading-state').classList.remove('hidden');

            try {
                const response = await fetch('auth/register_tenant.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(formData)
                });

                const text = await response.text();
                let result;
                try {
                    result = JSON.parse(text);
                } catch (e) {
                    console.error("Server Error Response:", text);
                    throw new Error("Server Error. Check Console for details.");
                }

                if (response.ok) {
                    // Success Animation/Redirect
                    document.getElementById('loading-state').innerHTML = `
                        <div class="inline-flex items-center justify-center w-16 h-16 bg-green-500/10 rounded-full mb-6">
                            <i data-lucide="check" class="text-green-500" size="32"></i>
                        </div>
                        <h2 class="text-2xl font-bold mb-2">Setup Complete!</h2>
                        <p class="text-neutral-400">Redirecting to login...</p>
                    `;
                    lucide.createIcons();
                    setTimeout(() => {
                        window.location.href = 'login.php';
                    }, 2000);
                } else {
                    throw new Error(result.message || "Registration failed");
                }
            } catch (error) {
                // Show Error
                document.getElementById('loading-state').innerHTML = `
                    <div class="inline-flex items-center justify-center w-16 h-16 bg-red-500/10 rounded-full mb-6">
                        <i data-lucide="alert-circle" class="text-red-500" size="32"></i>
                    </div>
                    <h2 class="text-2xl font-bold mb-2">Setup Failed</h2>
                    <p class="text-red-400 mb-6">${error.message}</p>
                    <button onclick="location.reload()" class="bg-neutral-800 text-white px-6 py-2 rounded-lg font-bold">Try Again</button>
                `;
                lucide.createIcons();
            }
        }
    </script>
</body>
</html>