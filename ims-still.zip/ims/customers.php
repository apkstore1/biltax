<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Handle Save Customer
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_customer') {
    try {
        if (!empty($_POST['id'])) {
            $stmt = $tenant_conn->prepare("UPDATE customers SET name=?, phone=?, email=?, address=?, recurring_type=? WHERE id=?");
            $stmt->execute([$_POST['name'], $_POST['phone'], $_POST['email'], $_POST['address'], $_POST['recurring_type'], $_POST['id']]);
        } else {
            $stmt = $tenant_conn->prepare("INSERT INTO customers (name, phone, email, address, recurring_type) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['name'], $_POST['phone'], $_POST['email'], $_POST['address'], $_POST['recurring_type']]);
        }
        header("Location: customers.php?msg=success"); exit;
    } catch(Exception $e) { $error = $e->getMessage(); }
}

$customers = $tenant_conn->query("SELECT * FROM customers ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Customer CRM | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Customer CRM</h1>
                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Manage your service clients and contracts</p>
            </div>
            <button onclick="openModal()" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-orange-600/20 transition-all active:scale-95">Add New Customer</button>
        </header>

        <div class="bg-white dark:bg-neutral-900 rounded-[32px] border border-slate-200 dark:border-neutral-800 overflow-hidden shadow-sm">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-100 dark:border-neutral-800 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                    <tr>
                        <th class="px-6 py-4">Customer Details</th>
                        <th class="px-6 py-4">Contact Info</th>
                        <th class="px-6 py-4">Recurring Service</th>
                        <th class="px-6 py-4">Last Service</th>
                        <th class="px-6 py-4 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach($customers as $c): ?>
                    <tr class="group hover:bg-slate-50 dark:hover:bg-neutral-800 transition-colors">
                        <td class="px-6 py-4">
                            <p class="font-bold dark:text-white"><?= htmlspecialchars($c['name']) ?></p>
                            <p class="text-[10px] text-slate-400 font-bold uppercase truncate max-w-[200px]"><?= htmlspecialchars($c['address'] ?: 'No Address') ?></p>
                        </td>
                        <td class="px-6 py-4">
                            <p class="text-xs font-bold dark:text-slate-300"><?= htmlspecialchars($c['phone']) ?></p>
                            <p class="text-[10px] text-slate-400"><?= htmlspecialchars($c['email'] ?: 'No Email') ?></p>
                        </td>
                        <td class="px-6 py-4">
                            <?php if($c['recurring_type'] !== 'none'): ?>
                                <span class="px-3 py-1 bg-orange-500/10 text-orange-500 rounded-lg text-[9px] font-black uppercase"><?= $c['recurring_type'] ?></span>
                            <?php else: ?>
                                <span class="text-[9px] text-slate-400 font-bold uppercase italic">One-time</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-xs font-bold text-slate-500"><?= $c['last_service_date'] ? date('d M, Y', strtotime($c['last_service_date'])) : 'Never' ?></td>
                        <td class="px-6 py-4 text-right">
                            <button onclick='openModal(<?= json_encode($c) ?>)' class="p-2 text-slate-400 hover:text-orange-600 transition-colors"><i data-lucide="edit" size="16"></i></button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Modal -->
    <div id="customerModal" class="fixed inset-0 bg-black/80 hidden flex items-center justify-center p-4 z-50 backdrop-blur-sm">
        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] w-full max-w-md border border-slate-200 dark:border-neutral-800">
            <h2 id="modalTitle" class="text-2xl font-black dark:text-white uppercase mb-6 text-center">Customer Details</h2>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="save_customer">
                <input type="hidden" name="id" id="custId">
                
                <input type="text" name="name" id="custName" placeholder="Customer Name" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                <input type="text" name="phone" id="custPhone" placeholder="Phone Number" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                <input type="email" name="email" id="custEmail" placeholder="Email (Optional)" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                <textarea name="address" id="custAddress" placeholder="Physical Address" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm"></textarea>
                
                <div>
                    <label class="text-[9px] font-black uppercase text-slate-400 ml-2 mb-1 block">Recurring Contract</label>
                    <select name="recurring_type" id="custRecurring" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                        <option value="none">No Contract (One-time)</option>
                        <option value="monthly">Monthly Service</option>
                        <option value="quarterly">Quarterly (3 Months)</option>
                        <option value="yearly">Yearly Service</option>
                    </select>
                </div>

                <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 active:scale-95 transition-all mt-4">Save Customer</button>
                <button type="button" onclick="closeModal()" class="w-full text-slate-400 text-[10px] font-black uppercase">Cancel</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function openModal(data = null) {
            document.getElementById('custId').value = data ? data.id : '';
            document.getElementById('custName').value = data ? data.name : '';
            document.getElementById('custPhone').value = data ? data.phone : '';
            document.getElementById('custEmail').value = data ? data.email : '';
            document.getElementById('custAddress').value = data ? data.address : '';
            document.getElementById('custRecurring').value = data ? data.recurring_type : 'none';
            document.getElementById('modalTitle').innerText = data ? 'Edit Customer' : 'New Customer';
            document.getElementById('customerModal').classList.remove('hidden');
        }
        function closeModal() {
            document.getElementById('customerModal').classList.add('hidden');
        }
    </script>
</body>
</html>