<?php
require_once 'auth_check.php'; // Authenticate Super Admin
// Temporary error reporting (can be removed in production)
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../config/currency_helper.php';
require_once '../config/db_connect.php';
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_MAIN, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Seed Modules if empty (using data from setup_modules.sql)
    $modCount = $pdo->query("SELECT COUNT(*) FROM modules")->fetchColumn();
    if ($modCount == 0) {
        $pdo->exec("INSERT INTO modules (module_name, module_key, status) VALUES ('Dashboard', 'dashboard', 'active'), ('Food POS Terminal', 'food_pos', 'active'), ('Retail POS Terminal', 'retail_pos', 'active'), ('Wholesale POS Terminal', 'wholesale_pos', 'active'), ('Service POS Terminal', 'service_pos', 'active'), ('Custom POS Terminal', 'custom_pos', 'active'), ('Inventory Management', 'inventory', 'active'), ('Staff Management', 'staff', 'active'), ('Suppliers', 'suppliers', 'active'), ('Purchase Entry', 'purchase_orders', 'active'), ('Sales Reports', 'sales_reports', 'active'), ('Barcode Engine', 'barcodes', 'active'), ('Table Management', 'tables', 'active'), ('Kitchen Orders (KOT)', 'kot', 'active'), ('Menu & Recipes', 'recipes', 'active'), ('Bulk Sales', 'bulk_sales', 'active'), ('Party Ledgers (Udhaar)', 'ledgers', 'active'), ('Service Jobs', 'jobs', 'active'), ('Partner Network (B2B)', 'partner_network', 'active'), ('Customers (CRM)', 'customers', 'active'), ('Reminders', 'reminders', 'active'), ('Advanced Reports', 'reports', 'active'), ('System Settings', 'settings', 'active')");
    }



    // Seed default packages if table is empty
    $pkg_count = $pdo->query("SELECT COUNT(*) FROM packages")->fetchColumn();
    if ($pkg_count == 0) {
        $pdo->exec("INSERT INTO packages (package_name, price, staff_limit, branch_limit, storage_limit, max_products) VALUES 
            ('Starter', 0.00, 3, 1, 1, 50),
            ('Pro', 29.99, 10, 5, 5, 500),
            ('Unlimited', 99.99, 9999, 999, 20, 9999)
        ");
    }

    // Seed Business Categories if empty
    $catCount = $pdo->query("SELECT COUNT(*) FROM business_categories")->fetchColumn();
    if ($catCount == 0) {
        $pdo->exec("INSERT INTO business_categories (category_name, slug, icon_class, description) VALUES 
            ('Retail Shop', 'retail', 'shopping-bag', 'Clothing, Electronics, Grocery'),
            ('Restaurant & Cafe', 'restaurant', 'utensils', 'Restaurants, Cafes, Food Trucks'),
            ('Wholesale Distribution', 'wholesale', 'container', 'Distribution, Bulk Selling'),
            ('Service Business', 'service', 'wrench', 'Repair Shop, Salon, Consultancy')
        ");
        // After seeding categories, get their IDs to seed category_modules
        $retail_id = $pdo->query("SELECT id FROM business_categories WHERE slug = 'retail'")->fetchColumn();
        $restaurant_id = $pdo->query("SELECT id FROM business_categories WHERE slug = 'restaurant'")->fetchColumn();
        $wholesale_id = $pdo->query("SELECT id FROM business_categories WHERE slug = 'wholesale'")->fetchColumn();
        $service_id = $pdo->query("SELECT id FROM business_categories WHERE slug = 'service'")->fetchColumn();

        // Seed default category_modules
        $pdo->exec("INSERT INTO category_modules (category_id, module_key) VALUES
            ($retail_id, 'dashboard'), ($retail_id, 'reports'), ($retail_id, 'settings'), ($retail_id, 'retail_pos'), ($retail_id, 'inventory'), ($retail_id, 'suppliers'), ($retail_id, 'barcodes'), ($retail_id, 'sales_reports'), ($retail_id, 'staff'), ($retail_id, 'partner_network'),
            ($restaurant_id, 'dashboard'), ($restaurant_id, 'reports'), ($restaurant_id, 'settings'), ($restaurant_id, 'food_pos'), ($restaurant_id, 'tables'), ($restaurant_id, 'kot'), ($restaurant_id, 'recipes'), ($restaurant_id, 'inventory'), ($restaurant_id, 'staff'),
            ($wholesale_id, 'dashboard'), ($wholesale_id, 'reports'), ($wholesale_id, 'settings'), ($wholesale_id, 'wholesale_pos'), ($wholesale_id, 'bulk_sales'), ($wholesale_id, 'inventory'), ($wholesale_id, 'ledgers'), ($wholesale_id, 'purchase_orders'), ($wholesale_id, 'staff'), ($wholesale_id, 'partner_network'),
            ($service_id, 'dashboard'), ($service_id, 'reports'), ($service_id, 'settings'), ($service_id, 'service_pos'), ($service_id, 'jobs'), ($service_id, 'customers'), ($service_id, 'reminders')
        ");
    }

    // Self-healing: Create category_modules table
    $pdo->exec("CREATE TABLE IF NOT EXISTS category_modules (
        category_id INT NOT NULL,
        module_key VARCHAR(50) NOT NULL,
        PRIMARY KEY (category_id, module_key)
    )");

    // 1. Create Table with PRIMARY KEY from the start
    $pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value TEXT
    )");

    // 2. CRITICAL: Cleanup and Enforce Primary Key (Ensure no duplicates)
    $has_pk = $pdo->query("SHOW KEYS FROM system_settings WHERE Key_name = 'PRIMARY'")->fetch();
    if (!$has_pk) {
        $pdo->exec("DROP TABLE IF EXISTS system_settings_tmp");
        $pdo->exec("CREATE TABLE system_settings_tmp SELECT setting_key, MAX(setting_value) as setting_value FROM system_settings WHERE setting_key IS NOT NULL AND setting_key != '' GROUP BY setting_key");
        $pdo->exec("DROP TABLE IF EXISTS system_settings");
        $pdo->exec("CREATE TABLE system_settings (setting_key VARCHAR(100) PRIMARY KEY, setting_value TEXT)");
        $pdo->exec("INSERT INTO system_settings SELECT * FROM system_settings_tmp");
        $pdo->exec("DROP TABLE system_settings_tmp");
    }

    // 3. Atomic Seeding: Use INSERT IGNORE to prevent 'Duplicate entry' 1062 errors
    $pdo->exec("INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES ('global_currency', 'USD')");
    $pdo->exec("INSERT IGNORE INTO system_settings (setting_key, setting_value) VALUES ('global_currency_symbol', '$')");

    // Remove stray 'id' column from system_settings if it exists
    try { $pdo->exec("ALTER TABLE system_settings DROP COLUMN IF EXISTS id"); } catch(Exception $e) {}

} catch (Exception $e) { die("System Error: " . $e->getMessage()); }

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_package') {
            $has_secondary = isset($_POST['has_secondary']) ? 1 : 0;
            $stmt = $pdo->prepare("INSERT INTO packages (package_name, price, yearly_price, primary_cycle, secondary_cycle, has_secondary, staff_limit, branch_limit, storage_limit, max_products) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['package_name'], $_POST['price'], $_POST['yearly_price'] ?? 0, $_POST['primary_cycle'], $_POST['secondary_cycle'], $has_secondary, $_POST['staff_limit'], $_POST['branch_limit'], $_POST['storage_limit'], $_POST['max_products']]);
            
            // Sync monthly_price for backward compatibility
            $lastId = $pdo->lastInsertId();
            $pdo->prepare("UPDATE packages SET monthly_price = ? WHERE id = ?")->execute([$_POST['price'], $lastId]);

            if (!empty($_POST['modules'])) {
                $mod_stmt = $pdo->prepare("INSERT INTO package_features (package_id, module_id) VALUES (?, ?)");
                foreach ($_POST['modules'] as $mod_id) { $mod_stmt->execute([$lastId, $mod_id]); }
            }

        } elseif ($_POST['action'] === 'edit_package') {
            $has_secondary = isset($_POST['has_secondary']) ? 1 : 0;
            $stmt = $pdo->prepare("UPDATE packages SET package_name = ?, price = ?, yearly_price = ?, primary_cycle = ?, secondary_cycle = ?, has_secondary = ?, staff_limit = ?, branch_limit = ?, storage_limit = ?, max_products = ? WHERE id = ?");
            $stmt->execute([$_POST['package_name'], $_POST['price'], $_POST['yearly_price'] ?? 0, $_POST['primary_cycle'], $_POST['secondary_cycle'], $has_secondary, $_POST['staff_limit'], $_POST['branch_limit'], $_POST['storage_limit'], $_POST['max_products'], $_POST['package_id']]);
            
            // Sync monthly_price for backward compatibility
            $pdo->prepare("UPDATE packages SET monthly_price = ? WHERE id = ?")->execute([$_POST['price'], $_POST['package_id']]);

            // Sync Package Modules
            $pdo->prepare("DELETE FROM package_features WHERE package_id = ?")->execute([$_POST['package_id']]);
            if (!empty($_POST['modules'])) {
                $mod_stmt = $pdo->prepare("INSERT INTO package_features (package_id, module_id) VALUES (?, ?)");
                foreach ($_POST['modules'] as $mod_id) { $mod_stmt->execute([$_POST['package_id'], $mod_id]); }
            }

        } elseif ($_POST['action'] === 'add_category') {
            $name = $_POST['category_name'];
            $icon = $_POST['category_icon'] ?? 'layers';
            $icon_class = $_POST['category_icon_class'] ?? '';
            $desc = $_POST['category_description'] ?? '';
            $slug = !empty($_POST['category_slug']) ? $_POST['category_slug'] : strtolower(preg_replace('/[^a-z0-9_]/', '', str_replace(' ', '_', $name)));
            
            $stmt = $pdo->prepare("INSERT INTO business_categories (category_name, slug, icon, icon_class, description, is_active) VALUES (?, ?, ?, ?, ?, 1)");
            $stmt->execute([$name, $slug, $icon, $icon_class, $desc]);
            $cat_id = $pdo->lastInsertId();

            if (!empty($_POST['modules'])) {
                $mod_stmt = $pdo->prepare("INSERT INTO category_modules (category_id, module_key) VALUES (?, ?)");
                foreach ($_POST['modules'] as $mod) { $mod_stmt->execute([$cat_id, $mod]); }
            }

        } elseif ($_POST['action'] === 'edit_category') {
            $id = $_POST['category_id'];
            $pdo->prepare("UPDATE business_categories SET category_name = ?, slug = ?, icon = ?, icon_class = ?, description = ? WHERE id = ?")
                ->execute([$_POST['category_name'], $_POST['category_slug'], $_POST['category_icon'], $_POST['category_icon_class'], $_POST['category_description'], $id]);
            
            // Sync Modules
            $pdo->prepare("DELETE FROM category_modules WHERE category_id = ?")->execute([$id]);
            if (!empty($_POST['modules'])) {
                $mod_stmt = $pdo->prepare("INSERT INTO category_modules (category_id, module_key) VALUES (?, ?)");
                foreach ($_POST['modules'] as $mod) { $mod_stmt->execute([$id, $mod]); }
            }
        } elseif ($_POST['action'] === 'delete_package') {
            $pdo->prepare("DELETE FROM package_features WHERE package_id = ?")->execute([$_POST['package_id']]);
            $stmt = $pdo->prepare("DELETE FROM packages WHERE id = ?");
            $stmt->execute([$_POST['package_id']]);
        } elseif ($_POST['action'] === 'delete_category') {
            $id = $_POST['category_id'];
            $pdo->prepare("DELETE FROM category_modules WHERE category_id = ?")->execute([$id]);
            $pdo->prepare("DELETE FROM business_categories WHERE id = ?")->execute([$id]);
        } elseif ($_POST['action'] === 'update_payment_settings') {
            $currency = $_POST['global_currency'];
            $symbol = $_POST['global_currency_symbol'];
            
            // Use REPLACE INTO to force overwrite the specific key
            $stmt_update = $pdo->prepare("REPLACE INTO system_settings (setting_key, setting_value) VALUES (?, ?)");
            $stmt_update->execute(['global_currency', $currency]);
            $stmt_update->execute(['global_currency_symbol', $symbol]);
        }

        // Tab Persistence: Redirect back to the active tab
        $active_tab = $_POST['active_tab'] ?? 'general';
        header("Location: settings.php?msg=success&tab=" . $active_tab); exit;
    }
    } catch (Exception $e) {
        die("Operation Failed: " . $e->getMessage());
    }
}

// Fetch Data
function fetchSafe($pdo, $query) {
    try { return $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC); } 
    catch (Exception $e) { return []; }
}

$categories = fetchSafe($pdo, "SELECT * FROM business_categories ORDER BY id DESC");
$available_modules = fetchSafe($pdo, "SELECT * FROM modules WHERE status = 'active'");
$packages = fetchSafe($pdo, "SELECT * FROM packages ORDER BY price ASC");

// Fetch Global Settings
$settings_raw = fetchSafe($pdo, "SELECT * FROM system_settings");
$sys_settings = [];
foreach($settings_raw as $s) { $sys_settings[$s['setting_key']] = $s['setting_value']; }
$global_currency = $sys_settings['global_currency'] ?? 'USD';
$global_symbol = $sys_settings['global_currency_symbol'] ?? '$';
$rates = getExchangeRates();
$global_rate = $rates[$global_currency] ?? 1.0;

// Get mapping for JS
$mappings = [];
$raw_mapping = fetchSafe($pdo, "SELECT * FROM category_modules");
foreach($raw_mapping as $m) { $mappings[$m['category_id']][] = $m['module_key']; }

$pkg_mappings = [];
$raw_pkg_mapping = fetchSafe($pdo, "SELECT pf.package_id, pf.module_id FROM package_features pf");
foreach($raw_pkg_mapping as $m) { $pkg_mappings[$m['package_id']][] = $m['module_id']; }

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Industry Categories | Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <main class="flex-1 ml-64 p-8">
        <header class="mb-10">
            <h1 class="text-3xl font-black uppercase tracking-tight">System Settings</h1>
            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Configure global parameters, packages, and industries</p>
        </header>

        <!-- Tabs Header -->
        <div class="flex gap-2 p-1 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl mb-8 overflow-x-auto">
            <button onclick="switchTab('general')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all bg-orange-600 text-white" data-tab="general">General Settings</button>
            <button onclick="switchTab('packages')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="packages">Packages</button>
            <button onclick="switchTab('categories')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="categories">Category / Industry</button>
            <button onclick="switchTab('dummy1')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="dummy1">Advanced</button>
            <button onclick="switchTab('dummy2')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="dummy2">Logs</button>
        </div>

        <!-- Tab 1: General Settings -->
        <div id="general" class="tab-content animate-in fade-in duration-300">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Payment Settings Card -->
                <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <div class="flex items-center gap-3 mb-8">
                        <div class="w-12 h-12 bg-orange-600/10 text-orange-600 rounded-2xl flex items-center justify-center">
                            <i data-lucide="credit-card" size="24"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-black uppercase tracking-tight">Payment Settings</h3>
                            <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Global Currency Configuration</p>
                        </div>
                    </div>
                    
                    <form method="POST" class="space-y-6">
                        <input type="hidden" name="action" value="update_payment_settings">
                        <input type="hidden" name="active_tab" value="general">
                        
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest ml-1">Admin Panel Currency</label>
                                <select name="global_currency" id="global_currency_select" onchange="updateSymbolDisplay(this)" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all text-sm text-orange-600">
                                    <option value="USD" data-symbol="$" <?= ($global_currency == 'USD') ? 'selected' : '' ?>>USD - US Dollar</option>
                                    <option value="PKR" data-symbol="Rs" <?= ($global_currency == 'PKR') ? 'selected' : '' ?>>PKR - Pakistani Rupee</option>
                                    <option value="AED" data-symbol="د.إ" <?= ($global_currency == 'AED') ? 'selected' : '' ?>>AED - UAE Dirham</option>
                                    <option value="SAR" data-symbol="ر.س" <?= ($global_currency == 'SAR') ? 'selected' : '' ?>>SAR - Saudi Riyal</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest ml-1">Currency Symbol</label>
                                <input type="text" name="global_currency_symbol" id="global_currency_symbol_input" value="<?= htmlspecialchars($global_symbol) ?>" readonly class="w-full px-5 py-4 bg-slate-100 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-2xl outline-none dark:text-slate-400 font-bold text-sm cursor-not-allowed">
                            </div>
                        </div>
                        
                        <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:scale-[1.01] active:scale-95 transition-all text-xs">
                            Save Global Payment Config
                        </button>
                    </form>
                </div>

                <!-- Placeholder -->
                <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl flex flex-col items-center justify-center text-center opacity-50 border-dashed">
                    <i data-lucide="settings-2" size="48" class="text-slate-300 mb-4"></i>
                    <h3 class="text-sm font-black uppercase tracking-widest">Other Settings</h3>
                    <p class="text-slate-500 text-[10px] font-bold">Coming Soon</p>
                </div>
            </div>
        </div>

        <!-- Tab 2: Packages -->
        <div id="packages" class="tab-content hidden animate-in fade-in duration-300">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-xl font-black uppercase">Subscription Packages</h3>
                <button onclick="openPackageModal()" class="bg-orange-600 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-widest flex items-center gap-2">
                    <i data-lucide="plus" size="14"></i> Add Package
                </button>
            </div>
            <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[32px] overflow-hidden">
                <table class="w-full text-left">
                    <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-100 dark:border-neutral-800">
                        <tr>
                            <th class="px-8 py-5 text-[10px] font-black uppercase text-slate-400">Package Name</th>
                            <th class="px-8 py-5 text-[10px] font-black uppercase text-slate-400">Price</th>
                            <th class="px-8 py-5 text-[10px] font-black uppercase text-slate-400">Limits</th>
                            <th class="px-8 py-5 text-[10px] font-black uppercase text-slate-400 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                        <?php foreach($packages as $p): ?>
                        <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors">
                            <td class="px-8 py-5 font-bold"><?= htmlspecialchars($p['package_name']) ?></td>
                            <td class="px-8 py-5">
                                <div class="text-sm font-black text-orange-600"><?= $global_symbol ?><?= number_format($p['price'] * $global_rate, 2) ?> / <?= str_replace('_', ' ', $p['primary_cycle']) ?></div>
                                <?php if($p['has_secondary']): ?>
                                    <div class="text-[9px] font-black text-slate-400 uppercase tracking-tighter">Option: <?= $global_symbol ?><?= number_format($p['yearly_price'] * $global_rate, 2) ?> / <?= str_replace('_', ' ', $p['secondary_cycle']) ?></div>
                                <?php endif; ?>
                            </td>
                            <td class="px-8 py-5 text-xs text-slate-500"><?= $p['staff_limit'] ?> Staff • <?= $p['branch_limit'] ?> Branches • <?= $p['storage_limit'] ?> MB Storage • <?= $p['max_products'] ?> Products</td>
                            <td class="px-8 py-5 text-right flex justify-end gap-2">
                                <button type="button" onclick='openEditPackageModal(<?= json_encode($p) ?>)' class="p-2 text-slate-400 hover:text-blue-500 transition-colors"><i data-lucide="edit-3" size="16"></i></button>
                                <form method="POST" onsubmit="return confirm('Delete package?')" class="inline">
                                    <input type="hidden" name="active_tab" value="packages">
                                    <input type="hidden" name="action" value="delete_package">
                                    <input type="hidden" name="package_id" value="<?= $p['id'] ?>">
                                    <button type="submit" class="p-2 text-slate-300 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="16"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($packages)): ?>
                            <tr><td colspan="4" class="px-8 py-10 text-center text-slate-400 text-xs font-bold uppercase tracking-widest">No packages found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Tab 3: Categories -->
        <div id="categories" class="tab-content hidden animate-in fade-in duration-300">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-xl font-black uppercase">Industry Categories</h3>
                <button onclick="openAddModal()" class="bg-orange-600 text-white px-5 py-2.5 rounded-xl font-bold text-xs uppercase tracking-widest flex items-center gap-2">
                    <i data-lucide="plus" size="14"></i> Add Industry
                </button>
            </div>
            <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[32px] overflow-hidden">
                <table class="w-full text-left">
                    <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-100 dark:border-neutral-800">
                        <tr>
                            <th class="px-8 py-5 text-[10px] font-black uppercase text-slate-400">Industry Name</th>
                            <th class="px-8 py-5 text-[10px] font-black uppercase text-slate-400">Modules</th>
                            <th class="px-8 py-5 text-[10px] font-black uppercase text-slate-400 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                        <?php foreach($categories as $c): ?>
                        <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors">
                            <td class="px-8 py-5">
                                <div class="flex items-center gap-3">
                                    <i data-lucide="<?= $c['icon'] ?>" size="18" class="text-orange-500"></i>
                                    <span class="font-bold"><?= htmlspecialchars($c['category_name']) ?></span>
                                </div>
                            </td>
                            <td class="px-8 py-5">
                                <div class="flex flex-wrap gap-1">
                                    <?php 
                                    $mods = $mappings[$c['id']] ?? [];
                                    if(empty($mods)) echo '<span class="text-[9px] text-slate-400 italic font-bold">No Modules</span>';
                                    foreach($mods as $m): 
                                    ?>
                                        <span class="px-2 py-0.5 bg-orange-500/10 text-orange-600 rounded text-[9px] font-black uppercase"><?= $m ?></span>
                                    <?php endforeach; ?>
                                </div>
                            </td>
                            <td class="px-8 py-5 text-right flex justify-end gap-2">
                                <button type="button" onclick='openEditModal(<?= htmlspecialchars(json_encode($c), ENT_QUOTES) ?>, <?= htmlspecialchars(json_encode(array_values($mods)), ENT_QUOTES) ?>)' class="p-2 text-slate-400 hover:text-orange-500 transition-colors"><i data-lucide="edit-3" size="16"></i></button>
                                <form method="POST" onsubmit="return confirm('Delete category?')" class="inline">
                                    <input type="hidden" name="active_tab" value="categories">
                                    <input type="hidden" name="action" value="delete_category">
                                    <input type="hidden" name="category_id" value="<?= $c['id'] ?>">
                                    <button type="submit" class="p-2 text-slate-300 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="16"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($categories)): ?>
                            <tr><td colspan="3" class="px-8 py-10 text-center text-slate-400 text-xs font-bold uppercase tracking-widest">No industry categories found.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Tab 4 & 5: Dummy -->
        <div id="dummy1" class="tab-content hidden animate-in fade-in duration-300">
            <div class="p-20 text-center text-slate-400 font-bold uppercase tracking-widest">Advanced Module Mapping Coming Soon</div>
        </div>
        <div id="dummy2" class="tab-content hidden animate-in fade-in duration-300">
            <div class="p-20 text-center text-slate-400 font-bold uppercase tracking-widest">System Error & Activity Logs Placeholder</div>
        </div>
    </main>

    <!-- Category Modal -->
    <div id="catModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button onclick="closeModal()" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            
            <h3 id="modalTitle" class="text-2xl font-black mb-1 uppercase tracking-tight">Add Industry</h3>
            <p class="text-xs text-slate-500 mb-8 uppercase tracking-widest">Define name and default features</p>
            
            <form method="POST" id="catForm" class="space-y-6">
                <input type="hidden" name="active_tab" value="categories">
                <input type="hidden" name="action" id="formAction" value="add_category">
                <input type="hidden" name="category_id" id="formCatId">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Industry Name</label>
                        <input type="text" name="category_name" id="formCatName" required placeholder="e.g. Pharmacy" 
                            class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">URL Slug (Auto-generated if empty)</label>
                        <input type="text" name="category_slug" id="formCatSlug" placeholder="e.g. pharmacy_shop" 
                            class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Icon (Lucide Name)</label>
                        <input type="text" name="category_icon" id="formCatIcon" placeholder="e.g. shopping-bag" 
                            class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Icon Class (CSS/Font)</label>
                        <input type="text" name="category_icon_class" id="formCatIconClass" placeholder="e.g. fa fa-shop" 
                            class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Description</label>
                    <textarea name="category_description" id="formCatDesc" rows="2" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all"></textarea>
                </div>

                <div class="pt-4 border-t border-slate-100 dark:border-neutral-800">
                    <label class="block text-[10px] font-black uppercase text-orange-500 mb-4 tracking-widest">Assign Default Modules</label>
                    <div class="grid grid-cols-2 md:grid-cols-3 gap-3">
                        <?php foreach($available_modules as $mod): ?>
                        <label class="flex items-center gap-3 p-3 bg-slate-50 dark:bg-neutral-950 border border-slate-100 dark:border-neutral-800 rounded-xl cursor-pointer group hover:border-orange-500/30 transition-all">
                            <input type="checkbox" name="modules[]" value="<?= $mod['module_key'] ?>" class="mod-checkbox w-4 h-4 accent-orange-600">
                            <div class="flex flex-col">
                                <span class="text-xs font-bold text-slate-700 dark:text-slate-300 group-hover:text-orange-500 transition-colors"><?= $mod['module_name'] ?></span>
                                <span class="text-[8px] text-slate-400 uppercase tracking-tighter"><?= $mod['module_key'] ?></span>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="flex gap-4 pt-6">
                    <button type="button" onclick="closeModal()" class="flex-1 py-4 text-xs font-black uppercase text-slate-400 hover:text-slate-600 transition-colors">Cancel</button>
                    <button type="submit" class="flex-[2] bg-slate-900 dark:bg-white text-white dark:text-black font-black py-4 rounded-2xl shadow-xl active:scale-95 transition-all text-xs uppercase tracking-widest">Save Industry Config</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Package Modal -->
    <div id="pkgModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="closePkgModal()" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h3 id="pkgModalTitle" class="text-2xl font-black mb-1 uppercase tracking-tight">Add Package</h3>
            <p class="text-xs text-slate-500 mb-8 uppercase tracking-widest">Set pricing and system limits</p>
            <form method="POST" id="pkgForm" class="space-y-4">
                <input type="hidden" name="active_tab" value="packages">
                <input type="hidden" name="action" id="pkgFormAction" value="add_package">
                <input type="hidden" name="package_id" id="pkgId">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Package Name</label>
                    <input type="text" name="package_name" id="pkgName" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                </div>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Primary Cycle</label>
                        <select name="primary_cycle" id="pkgPrimaryCycle" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                            <option value="15_days">15 Days</option>
                            <option value="1_month" selected>1 Month</option>
                            <option value="3_months">3 Months</option>
                            <option value="6_months">6 Months</option>
                            <option value="1_year">1 Year</option>
                            <option value="5_years">5 Years</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Primary Price (<?= $global_symbol ?>)</label>
                        <input type="number" step="0.01" name="price" id="pkgPrice" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-neutral-900/50 border border-slate-200 dark:border-neutral-800 rounded-3xl space-y-4">
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-sm font-black dark:text-white uppercase tracking-tight">Enable Secondary Cycle?</p>
                            <p class="text-[10px] text-slate-500 uppercase font-bold">Offer an additional cycle (e.g. Yearly Discount)</p>
                        </div>
                        <label class="relative inline-flex items-center cursor-pointer">
                            <input type="checkbox" name="has_secondary" id="pkgHasSecondary" onchange="toggleSecondaryFields()" class="sr-only peer">
                            <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
                        </label>
                    </div>
                    
                    <div id="secondaryFields" class="hidden grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Secondary Cycle</label>
                            <select name="secondary_cycle" id="pkgSecondaryCycle" class="w-full px-4 py-3 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white font-bold">
                                <option value="15_days">15 Days</option>
                                <option value="1_month">1 Month</option>
                                <option value="3_months">3 Months</option>
                                <option value="6_months">6 Months</option>
                                <option value="1_year" selected>1 Year</option>
                                <option value="5_years">5 Years</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Secondary Price (<?= $global_symbol ?>)</label>
                            <input type="number" step="0.01" name="yearly_price" id="pkgYearlyPrice" class="w-full px-4 py-3 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white font-bold">
                        </div>
                    </div>
                </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Staff Limit</label>
                        <input type="number" name="staff_limit" id="pkgStaff" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Storage (MB)</label>
                        <input type="number" name="storage_limit" id="pkgStorage" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Branch Limit</label>
                        <input type="number" name="branch_limit" id="pkgBranch" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                    </div>
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Max Products</label>
                    <input type="number" name="max_products" id="pkgProducts" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                </div>

                <div class="pt-4 border-t border-slate-100 dark:border-neutral-800">
                    <label class="block text-[10px] font-black uppercase text-orange-500 mb-4 tracking-widest">Plan-Specific Modules</label>
                    <div class="grid grid-cols-2 gap-3 max-h-48 overflow-y-auto pr-2">
                        <?php foreach($available_modules as $mod): ?>
                        <label class="flex items-center gap-3 p-3 bg-slate-50 dark:bg-neutral-950 border border-slate-100 dark:border-neutral-800 rounded-xl cursor-pointer group hover:border-orange-500/30 transition-all">
                            <input type="checkbox" name="modules[]" value="<?= $mod['id'] ?>" class="pkg-mod-checkbox w-4 h-4 accent-orange-600">
                            <div class="flex flex-col">
                                <span class="text-xs font-bold text-slate-700 dark:text-slate-300 group-hover:text-orange-500 transition-colors"><?= $mod['module_name'] ?></span>
                            </div>
                        </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="flex gap-4 pt-6">
                    <button type="button" onclick="closePkgModal()" class="flex-1 py-4 text-xs font-black uppercase text-slate-400">Cancel</button>
                    <button type="submit" class="flex-[2] bg-orange-600 text-white font-black py-4 rounded-2xl shadow-xl">Save Package</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();

        function updateSymbolDisplay(select) {
            const symbol = select.options[select.selectedIndex].getAttribute('data-symbol');
            document.getElementById('global_currency_symbol_input').value = symbol;
        }

        function openAddModal() {
            document.getElementById('catModal').classList.remove('hidden');
            document.getElementById('catModal').classList.add('flex');
            document.getElementById('modalTitle').innerText = 'Add Industry';
            document.getElementById('formAction').value = 'add_category';
            document.getElementById('catForm').reset();
            document.querySelectorAll('.mod-checkbox').forEach(c => c.checked = false);
            document.getElementById('formCatSlug').value = '';
            document.getElementById('formCatIcon').value = 'layers';
            document.getElementById('formCatIconClass').value = '';
            document.getElementById('formCatDesc').value = '';
        }

        function openEditModal(category, assignedModules) {
            document.getElementById('catModal').classList.remove('hidden');
            document.getElementById('catModal').classList.add('flex');
            document.getElementById('modalTitle').innerText = 'Edit Industry';
            document.getElementById('formAction').value = 'edit_category';
            
            document.getElementById('formCatId').value = category.id;
            document.getElementById('formCatName').value = category.category_name;
            document.getElementById('formCatSlug').value = category.slug;
            document.getElementById('formCatIcon').value = category.icon || 'layers';
            document.getElementById('formCatIconClass').value = category.icon_class || '';
            document.getElementById('formCatDesc').value = category.description || '';

            console.log("Category Data:", category);
            console.log("Assigned Modules (Raw):", assignedModules);

            // Pehle saare checkboxes ko uncheck karo
            const checkboxes = document.querySelectorAll('#catModal .mod-checkbox');
            checkboxes.forEach(cb => cb.checked = false);

            // Phir sirf assigned modules ko check karo
            if (Array.isArray(assignedModules)) {
                console.log("Assigned Modules (Cleaned for comparison):", assignedModules.map(m => String(m).trim()));
                const cleanModules = assignedModules.map(m => String(m).trim());
                checkboxes.forEach(cb => {
                    if (cleanModules.includes(cb.value.trim())) {
                        cb.checked = true;
                    }
                });
            }
        }

        function closeModal() {
            document.getElementById('catModal').classList.add('hidden');
            document.getElementById('catModal').classList.remove('flex');
        }

        function openPackageModal() {
            document.getElementById('pkgModal').classList.remove('hidden');
            document.getElementById('pkgModal').classList.add('flex');
            document.getElementById('pkgModalTitle').innerText = 'Add Package';
            document.getElementById('pkgFormAction').value = 'add_package';
            document.getElementById('pkgForm').reset();
        }

        function openEditPackageModal(pkg) {
            document.getElementById('pkgModal').classList.remove('hidden');
            document.getElementById('pkgModal').classList.add('flex');
            document.getElementById('pkgModalTitle').innerText = 'Edit Package';
            document.getElementById('pkgFormAction').value = 'edit_package';
            
            document.getElementById('pkgId').value = pkg.id;
            document.getElementById('pkgName').value = pkg.package_name;
            document.getElementById('pkgPrice').value = pkg.price;
            document.getElementById('pkgYearlyPrice').value = pkg.yearly_price;
            document.getElementById('pkgPrimaryCycle').value = pkg.primary_cycle || '1_month';
            document.getElementById('pkgSecondaryCycle').value = pkg.secondary_cycle || '1_year';
            document.getElementById('pkgHasSecondary').checked = (pkg.has_secondary == 1);
            toggleSecondaryFields();
            document.getElementById('pkgSecondaryCycle').value = pkg.secondary_cycle || '1_year';
            document.getElementById('pkgHasSecondary').checked = (pkg.has_secondary == 1);
            toggleSecondaryFields();
            document.getElementById('pkgStaff').value = pkg.staff_limit;
            document.getElementById('pkgStorage').value = pkg.storage_limit;
            document.getElementById('pkgBranch').value = pkg.branch_limit || 1;
            document.getElementById('pkgProducts').value = pkg.max_products;
            
            // Set Module Checkboxes for Package
            const pkgMappings = <?= json_encode($pkg_mappings) ?>;
            const assigned = pkgMappings[pkg.id] || [];
            document.querySelectorAll('.pkg-mod-checkbox').forEach(cb => {
                cb.checked = assigned.includes(parseInt(cb.value));
            });
        }

        function toggleSecondaryFields() {
            const isChecked = document.getElementById('pkgHasSecondary').checked;
            const container = document.getElementById('secondaryFields');
            if (isChecked) container.classList.remove('hidden');
            else container.classList.add('hidden');
        }

        function switchTab(tabId) {
            document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
            document.getElementById(tabId).classList.remove('hidden');

            document.querySelectorAll('.tab-btn').forEach(b => {
                b.classList.remove('bg-orange-600', 'text-white');
                b.classList.add('text-slate-400');
            });
            
            const activeBtn = document.querySelector(`[data-tab="${tabId}"]`);
            if(activeBtn) {
                activeBtn.classList.add('bg-orange-600', 'text-white');
                activeBtn.classList.remove('text-slate-400');
            }
        }

        // Restore active tab from URL on page load
        window.addEventListener('load', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab') || 'general';
            switchTab(tab);
        });

        function closePkgModal() {
            document.getElementById('pkgModal').classList.add('hidden');
            document.getElementById('pkgModal').classList.remove('flex');
        }
    </script>
</body>
</html>