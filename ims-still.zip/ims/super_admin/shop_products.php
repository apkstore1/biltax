<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard
if (!has_admin_permission('biltax_shop')) {
    die("Access Denied: You do not have permission to manage shop products.");
}

require_once 'config.php';

// Handle Add/Edit Product
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];
    $desc = $_POST['description'];
    $image_url = $_POST['image_url'] ?? '';
    $req_custom = isset($_POST['requires_custom_image']) ? 1 : 0;

    if ($_POST['action'] === 'add') {
        $stmt = $pdo->prepare("INSERT INTO shop_products (name, price, stock, description, image_url, requires_custom_image) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$name, $price, $stock, $desc, $image_url, $req_custom]);
    } elseif ($_POST['action'] === 'edit') {
        $id = $_POST['id'];
        $stmt = $pdo->prepare("UPDATE shop_products SET name = ?, price = ?, stock = ?, description = ?, image_url = ?, requires_custom_image = ? WHERE id = ?");
        $stmt->execute([$name, $price, $stock, $desc, $image_url, $req_custom, $id]);
    }
    header("Location: shop_products.php?msg=success"); exit;
}

$products = $pdo->query("SELECT * FROM shop_products ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Manage Biltax Shop - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white flex min-h-screen">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 ml-64 p-8">
        <header class="flex justify-between items-center mb-8">
            <h1 class="text-2xl font-black uppercase tracking-tight">Biltax Shop Inventory</h1>
            <button onclick="openModal()" class="bg-orange-600 px-6 py-2.5 rounded-xl text-white font-bold text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-orange-600/20">
                <i data-lucide="plus" size="16"></i> Add Product
            </button>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php foreach($products as $p): ?>
            <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-6 rounded-3xl shadow-sm">
                <div class="aspect-square bg-slate-50 dark:bg-neutral-800 rounded-2xl flex items-center justify-center mb-4 overflow-hidden border border-slate-100 dark:border-neutral-800">
                    <?php 
                    $images = explode("\n", $p['image_url']);
                    if(!empty(trim($images[0]))): ?>
                        <img src="<?= htmlspecialchars(trim($images[0])) ?>" class="w-full h-full object-cover">
                    <?php else: ?>
                        <i data-lucide="package" class="text-slate-300"></i>
                    <?php endif; ?>
                </div>
                <h3 class="font-black uppercase text-sm mb-1"><?= htmlspecialchars($p['name']) ?></h3>
                <p class="text-xs text-slate-500 mb-4 line-clamp-2"><?= htmlspecialchars($p['description']) ?></p>
                <div class="flex justify-between items-center">
                    <span class="text-lg font-black text-orange-600">$<?= number_format($p['price'], 2) ?></span>
                    <span class="text-[10px] font-bold text-slate-400 uppercase">Stock: <?= $p['stock'] ?></span>
                </div>
                <button onclick='editProduct(<?= json_encode($p) ?>)' class="w-full mt-4 py-2 border border-slate-200 dark:border-neutral-800 rounded-lg text-xs font-bold hover:bg-slate-50 dark:hover:bg-neutral-800 transition-all">Edit Details</button>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <!-- Product Modal -->
    <div id="prodModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 p-8 rounded-3xl w-full max-w-md border border-slate-200 dark:border-neutral-800 shadow-2xl">
            <h3 id="modalTitle" class="text-xl font-black uppercase mb-6">Add Shop Item</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" id="formAction" value="add">
                <input type="hidden" name="id" id="prodId">
                <input type="text" name="name" id="prodName" placeholder="Product Name" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none">
                <div class="grid grid-cols-2 gap-4">
                    <input type="number" step="0.01" name="price" id="prodPrice" placeholder="Price" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none">
                    <input type="number" name="stock" id="prodStock" placeholder="Stock" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none">
                </div>
                <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-800/50 rounded-2xl border border-slate-100 dark:border-neutral-800">
                    <div>
                        <p class="text-sm font-bold dark:text-white uppercase tracking-tight">Requires Custom Image?</p>
                        <p class="text-[10px] text-slate-500 font-medium">Allow tenants to upload their own design</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="requires_custom_image" id="prodCustomImage" class="sr-only peer">
                        <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-orange-600"></div>
                    </label>
                </div>
                <label class="text-[10px] font-black uppercase text-slate-400">Image URLs (One per line)</label>
                <textarea name="image_url" id="prodImage" placeholder="https://example.com/img1.jpg&#10;https://example.com/img2.jpg" rows="3" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-xs font-mono"></textarea>
                <textarea name="description" id="prodDesc" placeholder="Description..." rows="3" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none"></textarea>
                <div class="flex gap-3">
                    <button type="button" onclick="closeModal()" class="flex-1 py-3 text-xs font-bold uppercase text-slate-400">Cancel</button>
                    <button type="submit" class="flex-[2] bg-orange-600 text-white font-black py-3 rounded-xl shadow-lg shadow-orange-600/20 uppercase tracking-widest text-xs">Save Product</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function openModal() {
            document.getElementById('prodModal').classList.remove('hidden');
            document.getElementById('prodModal').classList.add('flex');
            document.getElementById('formAction').value = 'add';
            document.getElementById('prodCustomImage').checked = false;
        }
        function editProduct(p) {
            openModal();
            document.getElementById('modalTitle').innerText = 'Edit Shop Item';
            document.getElementById('formAction').value = 'edit';
            document.getElementById('prodId').value = p.id;
            document.getElementById('prodName').value = p.name;
            document.getElementById('prodPrice').value = p.price;
            document.getElementById('prodStock').value = p.stock;
            document.getElementById('prodDesc').value = p.description;
            document.getElementById('prodImage').value = p.image_url || '';
            document.getElementById('prodCustomImage').checked = (p.requires_custom_image == 1);
        }
        function closeModal() { document.getElementById('prodModal').classList.add('hidden'); }
    </script>
</body>
</html>