<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard
if (!has_admin_permission('manage_tenants')) {
    die("Access Denied: You do not have permission to manage staff roles.");
}

require_once 'config.php';
require_once '../config/db_connect.php';

// --- Advanced Self-Healing: Ensure Modules table data is correct ---
        ['name' => 'Financials', 'key' => 'finance_management'],
        ['name' => 'Payroll System', 'key' => 'payroll_system'],
        ['name' => 'Expense Tracker', 'key' => 'expense_tracker'],
        ['name' => 'Accounts Payable', 'key' => 'accounts_payable'],
        ['name' => 'Finance Reports', 'key' => 'finance_reports'],
        ['name' => 'Biltax Hub', 'key' => 'marketplace_main'],
        ['name' => 'Marketplace', 'key' => 'biltax_hub'],
        ['name' => 'Shop', 'key' => 'shop_module'],
        ['name' => 'Marketplace Listing Visibility', 'key' => 'marketplace_listing_visibility'],
        ['name' => 'Marketplace Listing', 'key' => 'marketplace'],
        ['name' => 'Payment QR Generator', 'key' => 'payment_qr'],
        ['name' => 'Custom Invoice Builder', 'key' => 'invoice_builder'],
        ['name' => 'Live Chat Support', 'key' => 'live_chat'],
        ['name' => 'Documentation', 'key' => 'documentation'],
        ['name' => 'Knowledge Base', 'key' => 'knowledge_base'],
        ['name' => 'WhatsApp & Email Sharing', 'key' => 'whatsapp_email_sharing'],
        ['name' => 'Advanced Reports', 'key' => 'reports'],
        ['name' => 'Notifications', 'key' => 'notifications']
    ];

    $upsert = $pdo->prepare("INSERT INTO modules (module_name, module_key, status) VALUES (?, ?, 'active') ON DUPLICATE KEY UPDATE module_key = VALUES(module_key), status = 'active'");
    foreach ($essential_modules as $mod) {
        $upsert->execute([$mod['name'], $mod['key']]);
    }
} catch (Exception $e) { /* Silent fail to avoid interrupting UI */ }

// Define all possible staff roles
$roles = ['manager', 'cashier', 'waiter', 'chef', 'technician', 'salesman'];

// Fetch all active modules from the main database
$modules = $pdo->query("SELECT module_name, module_key FROM modules WHERE status = 'active' ORDER BY module_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Grouping Logic for Menus (Sidebar Sync)
$menu_groups = [
    'POS & Terminals' => ['food_pos', 'retail_pos', 'wholesale_pos', 'service_pos', 'custom_pos', 'pos_returns', 'receipt_reprint'],
    'Inventory & Products' => ['inventory', 'recipes', 'raw_material_system', 'barcodes'],
    'Supply Chain' => ['suppliers', 'purchases', 'b2b_orders', 'b2b_returns', 'vendors', 'vendor_orders', 'partner_network'],
    'Financials & Payroll' => ['finance_management', 'payroll_system', 'expense_tracker', 'finance_reports', 'accounts_payable'],
    'Industry Specialized' => ['tables', 'kot', 'bulk_sales', 'ledgers', 'jobs', 'rider_tracking', 'customers', 'reminders'],
    'Biltax Hub' => ['marketplace_main', 'biltax_hub', 'shop_module', 'marketplace', 'marketplace_listing_visibility', 'payment_qr', 'invoice_builder', 'whatsapp_email_sharing'],
    'System & Operations' => ['dashboard', 'staff', 'manage_branches', 'verification_center', 'settings', 'notifications', 'reports', 'business_logo', 'shop_image_upload'],
    'Support' => ['support_tickets', 'live_chat', 'documentation', 'knowledge_base', 'b2b_chat', 'chat_images']
];

// Handle Save Permissions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_permissions') {
    $pdo->beginTransaction();
    try {
        // Clear existing permissions to rebuild them
        $pdo->exec("DELETE FROM role_permissions");
        
        // Prepare statement for inserting new permissions
        $stmt = $pdo->prepare("INSERT INTO role_permissions (role_key, module_key, is_allowed) VALUES (?, ?, 1)");
        
        // Insert permissions for selected modules for each role
        if (isset($_POST['perms']) && is_array($_POST['perms'])) {
            foreach ($_POST['perms'] as $role_key => $mod_keys) {
                foreach ($mod_keys as $m_key) {
                    $stmt->execute([$role_key, $m_key]);
                }
            }
        }
        $pdo->commit();
        $msg = "Permissions updated successfully!";
    } catch (Exception $e) { 
        $pdo->rollBack(); 
        $error = $e->getMessage(); 
    }
}

// Fetch current permissions to pre-check checkboxes
$raw_perms = $pdo->query("SELECT role_key, module_key FROM role_permissions")->fetchAll(PDO::FETCH_ASSOC);
$perms_map = [];
foreach ($raw_perms as $rp) {
    $perms_map[$rp['role_key']][] = $rp['module_key'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Role Access | Biltax Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>
        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-7xl mx-auto">
                <header class="flex justify-between items-center mb-10">
                    <div>
                        <h1 class="text-3xl font-black tracking-tight uppercase">Staff Role Access</h1>
                        <p class="text-sm text-slate-500">Global permission control for staff roles across all tenants.</p>
                    </div>
                    <?php if(isset($msg)): ?>
                        <div class="px-4 py-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-xl text-xs font-bold"><?= $msg ?></div>
                    <?php endif; ?>
                    <?php if(isset($error)): ?>
                        <div class="px-4 py-2 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-xl text-xs font-bold">Error: <?= $error ?></div>
                    <?php endif; ?>
                </header>

                <form method="POST" class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[40px] shadow-2xl overflow-hidden">
                    <input type="hidden" name="action" value="save_permissions">
                    <div class="overflow-x-auto">
                        <table class="w-full text-left border-collapse">
                            <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-100 dark:border-neutral-800">
                                <tr>
                                    <th class="px-8 py-6 text-[10px] font-black uppercase text-slate-400 tracking-widest sticky left-0 bg-slate-50 dark:bg-neutral-950 z-10">Sidebar Menu / Module</th>
                                    <?php foreach($roles as $r): ?>
                                        <th class="px-4 py-6 text-center min-w-[120px]">
                                            <p class="text-[10px] font-black uppercase text-slate-500 tracking-widest mb-2"><?= $r ?></p>
                                            <button type="button" onclick="toggleColumn('<?= $r ?>', true)" class="text-[8px] font-bold text-orange-500 hover:underline uppercase">All</button>
                                            <span class="text-slate-300 mx-1">|</span>
                                            <button type="button" onclick="toggleColumn('<?= $r ?>', false)" class="text-[8px] font-bold text-slate-400 hover:underline uppercase">None</button>
                                        </th>
                                    <?php endforeach; ?>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                                <?php foreach($menu_groups as $group_name => $group_keys): ?>
                                    <tr class="bg-slate-50/50 dark:bg-neutral-950/30">
                                        <td colspan="<?= count($roles) + 1 ?>" class="px-8 py-2 text-[9px] font-black uppercase text-orange-500 tracking-[0.2em] border-y border-slate-100 dark:border-neutral-800">
                                            <?= $group_name ?> Group
                                        </td>
                                    </tr>
                                    <?php foreach($modules as $m): 
                                        if(!in_array($m['module_key'], $group_keys)) continue;
                                    ?>
                                    <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors">
                                        <td class="px-8 py-4 sticky left-0 bg-white dark:bg-neutral-900 z-10 border-r dark:border-neutral-800">
                                            <div class="flex items-center gap-2">
                                                <p class="text-sm font-bold dark:text-white"><?= htmlspecialchars($m['module_name']) ?></p>
                                            </div>
                                            <p class="text-[9px] text-slate-400 font-mono"><?= $m['module_key'] ?></p>
                                        </td>
                                        <?php foreach($roles as $r): 
                                            $checked = in_array($m['module_key'], $perms_map[$r] ?? []);
                                        ?>
                                        <td class="px-4 py-4 text-center">
                                            <label class="relative inline-flex items-center cursor-pointer">
                                                <input type="checkbox" name="perms[<?= $r ?>][]" value="<?= $m['module_key'] ?>" <?= $checked ? 'checked' : '' ?> class="sr-only peer role-check-<?= $r ?>">
                                                <div class="w-9 h-5 bg-slate-200 dark:bg-neutral-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-orange-600"></div>
                                            </label>
                                        </td>
                                        <?php endforeach; ?>
                                    </tr>
                                    <?php endforeach; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="p-8 bg-slate-50 dark:bg-neutral-950 border-t border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                        <p class="text-xs text-slate-400 font-medium">Unchecked modules will be completely hidden from that role.</p>
                        <button type="submit" class="px-10 py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl hover:scale-105 transition-all active:scale-95">
                            Save Global Config
                        </button>
                    </div>
                </form>
            </div>
        </main>
    </div>
    <script>
        lucide.createIcons();
        
        function toggleColumn(role, status) {
            const boxes = document.querySelectorAll('.role-check-' + role);
            boxes.forEach(box => { if(!box.disabled) box.checked = status; });
        }
    </script>
</body>
</html>