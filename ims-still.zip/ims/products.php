<?php
require_once 'config/db_switch.php';

// Check login
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

// Page Restriction Logic (Allows access if either inventory or restaurant recipes are enabled)
if (!has_module('inventory') && !has_module('recipes') && !has_module('raw_material_system')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$industry = strtolower(trim($_SESSION['industry_type'] ?? 'retail'));
$success_msg = $error_msg = '';

// --- Handle Success Messages from Redirects ---
if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'added') $success_msg = "Product added successfully!";
    if ($_GET['msg'] === 'updated') $success_msg = "Product updated successfully!";
    if ($_GET['msg'] === 'deleted') $success_msg = "Product deleted.";
}

// --- Fetch Marketplace Status from Main DB ---
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $stmt = $main_pdo->prepare("SELECT marketplace_listing_status FROM tenants WHERE db_name = ?");
    $stmt->execute([$_SESSION['db_name']]);
    $marketplace_enabled = (bool)$stmt->fetchColumn();
} catch (Exception $e) { $marketplace_enabled = false; }

// --- Fetch Dropdowns for Modal (Only for Retail/Wholesale) ---
$categories_list = [];
$units_list = [];
$suppliers_list = [];

try {
    $categories_list = $tenant_conn->query("SELECT id, name FROM categories WHERE is_allowed = 1 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    $units_list = $tenant_conn->query("SELECT id, name FROM units WHERE is_allowed = 1 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    $suppliers_list = $tenant_conn->query("SELECT id, name FROM suppliers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Tables might not exist yet for very old tenants
}

// --- Multi-Branch Context ---
$active_branch = $_SESSION['active_branch_id'] ?? null;
$target_branch = get_active_stock_branch_id($active_branch);

// --- Handle Form Submission (Add Product) ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_product') {
    try {
        if ($industry === 'restaurant' || $industry === 'service') {
            // Restaurant/Service Logic
            $type = $_POST['type'] ?? 'product';
            $name = $_POST['name'];
            $category = $_POST['category'] ?? 'General';
            $desc = $_POST['description'] ?? '';

            if ($type === 'raw_material') {
                $purchase_rate = (float)($_POST['purchase_price'] ?? 0);
                $stock = $_POST['stock_level'] ?? 0;
                $alert = $_POST['alert_level'] ?? 5;
                $unit_id = $_POST['unit_id'] ?: null;
                $is_expirable = isset($_POST['is_expirable']) ? 1 : 0;
                $expiry_date = (!empty($_POST['initial_expiry_date']) && $is_expirable) ? $_POST['initial_expiry_date'] : null;
                $raw_cat = 'Raw item';

                $stmt = $tenant_conn->prepare("INSERT INTO products (branch_id, name, price, stock_level, alert_level, category, description, unit_id, is_raw, is_expirable) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1, ?)");
                $stmt->execute([$target_branch, $name, $purchase_rate, $stock, $alert, $raw_cat, $desc, $unit_id, $is_expirable]);
                
                // Add to stock history table for expiry tracking
                $product_id = $tenant_conn->lastInsertId();
                try {
                    $stmt_stock = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason, expiry_date) VALUES (?, ?, 'Initial Opening Stock', ?)");
                    $stmt_stock->execute([$product_id, $stock, $expiry_date]);
                } catch (Exception $e) { }

            } else {
                $price = (float)($_POST['price'] ?? $_POST['sale_price'] ?? 0);
                $has_stock = isset($_POST['has_stock']) ? 1 : 0;
                $stock = $has_stock ? ($_POST['dish_stock'] ?? 0) : 0;
                $alert = $has_stock ? ($_POST['dish_alert'] ?? 5) : 5;
                $is_expirable = $has_stock ? (isset($_POST['dish_expirable']) ? 1 : 0) : 0;
                $expiry_date = ($has_stock && !empty($_POST['dish_expiry_date']) && $is_expirable) ? $_POST['dish_expiry_date'] : null;

                $stmt = $tenant_conn->prepare("INSERT INTO products (branch_id, name, price, category, description, is_raw, has_stock, stock_level, alert_level, is_expirable) VALUES (?, ?, ?, ?, ?, 0, ?, ?, ?, ?)");
                $stmt->execute([$target_branch, $name, $price, $category, $desc, $has_stock, $stock, $alert, $is_expirable]);

                // Add to stock history if item has stock
                if ($has_stock) {
                    $product_id = $tenant_conn->lastInsertId();
                    try {
                        $stmt_stock = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason, expiry_date) VALUES (?, ?, 'Initial Opening Stock', ?)");
                        $stmt_stock->execute([$product_id, $stock, $expiry_date]);
                    } catch (Exception $e) { }
                }
            }

        } elseif ($industry === 'retail') {
            // Retail Logic
            $name = $_POST['name'];
            $sku = $_POST['sku'] ?: null;
            
            // Duplicate SKU Check
            if (!empty($sku)) {
                $check_stmt = $tenant_conn->prepare("SELECT COUNT(*) FROM products WHERE sku = ?");
                $check_stmt->execute([$sku]);
                if ($check_stmt->fetchColumn() > 0) throw new Exception("Duplicate SKU: A product with barcode '$sku' already exists.");
            }

            $sale_price = $_POST['sale_price'] ?? 0;
            $purchase_price = $_POST['purchase_price'] ?? 0;
            $stock = $_POST['stock_level'] ?? 0;
            $cat_id = $_POST['category_id'] ?: null;
            $unit_id = $_POST['unit_id'] ?: null;
            $supp_id = $_POST['supplier_id'] ?: null;
            $alert = $_POST['alert_level'] ?? 10;
            $is_expirable = isset($_POST['is_expirable']) ? 1 : 0;
            $initial_expiry_date = (!empty($_POST['initial_expiry_date']) && $is_expirable) ? $_POST['initial_expiry_date'] : null;
            
            $is_b2b = (isset($_POST['visibility']) && $_POST['visibility'] === 'public') ? 1 : 0;
            $is_raw = (isset($_POST['visibility']) && $_POST['visibility'] === 'raw') ? 1 : 0;

            $is_raw_comp = isset($_POST['is_raw_component']) ? 1 : 0;
            $is_sellable = isset($_POST['is_sellable']) ? 1 : 0;

            $stmt = $tenant_conn->prepare("INSERT INTO products (branch_id, name, sku, sale_price, purchase_price, stock_level, category_id, unit_id, supplier_id, alert_level, is_expirable, is_b2b_public, allow_partner_view, is_raw_component, is_sellable) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$target_branch, $name, $sku, $sale_price, $purchase_price, $stock, $cat_id, $unit_id, $supp_id, $alert, $is_expirable, $is_b2b, $is_b2b, $is_raw_comp, $is_sellable]);
            
            // Add to stock table
            $product_id = $tenant_conn->lastInsertId();
            try {
                $stmt_stock = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason, expiry_date) VALUES (?, ?, 'Initial Opening Stock', ?)");
                $stmt_stock->execute([$product_id, $stock, $initial_expiry_date]);
            } catch (Exception $e) { /* Stock table might not exist */ }

        } elseif ($industry === 'wholesale') {
            // Wholesale Logic
            $name = $_POST['name'];
            $sku = $_POST['sku'];

            // Duplicate SKU Check
            if (!empty($sku)) {
                $check_stmt = $tenant_conn->prepare("SELECT COUNT(*) FROM products WHERE sku = ?");
                $check_stmt->execute([$sku]);
                if ($check_stmt->fetchColumn() > 0) throw new Exception("Duplicate SKU: A product with barcode '$sku' already exists.");
            }

            $sale_price = $_POST['sale_price'] ?? 0;
            $purchase_price = $_POST['purchase_price'] ?? 0;
            $stock = $_POST['stock_level'] ?? 0;
            $cat_id = $_POST['category_id'] ?: null;
            $unit_id = $_POST['unit_id'] ?: null;
            $supp_id = $_POST['supplier_id'] ?: null;
            $alert = $_POST['alert_level'] ?? 10;
            $is_expirable = isset($_POST['is_expirable']) ? 1 : 0;
            $initial_expiry_date = (!empty($_POST['initial_expiry_date']) && $is_expirable) ? $_POST['initial_expiry_date'] : null;
            
            $is_b2b = (isset($_POST['visibility']) && $_POST['visibility'] === 'public') ? 1 : 0;
            $is_raw = (isset($_POST['visibility']) && $_POST['visibility'] === 'raw') ? 1 : 0;

            $is_raw_comp = isset($_POST['is_raw_component']) ? 1 : 0;
            $is_sellable = isset($_POST['is_sellable']) ? 1 : 0;

            // Wholesale schema in register_tenant.php matches Retail columns for these fields.
            // We map UI inputs to match the actual DB columns.
            $stmt = $tenant_conn->prepare("INSERT INTO products (branch_id, name, sku, sale_price, purchase_price, stock_level, category_id, unit_id, supplier_id, alert_level, is_expirable, is_b2b_public, allow_partner_view, is_raw_component, is_sellable) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$target_branch, $name, $sku, $sale_price, $purchase_price, $stock, $cat_id, $unit_id, $supp_id, $alert, $is_expirable, $is_b2b, $is_b2b, $is_raw_comp, $is_sellable]);

            // Add to stock table for expiry tracking and history
            $product_id = $tenant_conn->lastInsertId();
            try {
                $stmt_stock = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason, expiry_date) VALUES (?, ?, 'Initial Opening Stock', ?)");
                $stmt_stock->execute([$product_id, $stock, $initial_expiry_date]);
            } catch (Exception $e) { /* Stock table might not exist or other issue */ }
        }
        
        // Persist the source parameter in redirect
        $source_param = isset($_GET['source']) ? '&source=' . htmlspecialchars($_GET['source']) : '';
        header("Location: products.php?msg=added" . $source_param);
        exit;
    } catch (Exception $e) {
        $error_msg = "Error: " . $e->getMessage();
    }
}

// --- Handle Edit Product ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_product') {
    try {
        $id = $_POST['id'];
        $is_b2b = (isset($_POST['visibility']) && $_POST['visibility'] === 'public') ? 1 : 0;
        $is_raw = (isset($_POST['visibility']) && $_POST['visibility'] === 'raw') ? 1 : 0;
        $is_expirable = isset($_POST['is_expirable']) ? 1 : 0;
        $new_expiry = $_POST['initial_expiry_date'] ?? null;

        if ($industry === 'restaurant' || $industry === 'service') {
            $price = (float)($_POST['price'] ?? $_POST['sale_price'] ?? 0);
            // Restaurant/Service products use 'price' column instead of 'sale_price'
            $stmt = $tenant_conn->prepare("UPDATE products SET name=?, price=?, category=?, description=?, is_b2b_public=?, allow_partner_view=?, is_raw=?, is_expirable=? WHERE id=?");
            $stmt->execute([$_POST['name'], $price, $_POST['category'] ?? 'General', $_POST['description'] ?? '', $is_b2b, $is_b2b, $is_raw, $is_expirable, $id]);
        } else {
            $sale_price = $_POST['sale_price'] ?? 0;
            $alert = $_POST['alert_level'] ?? 10;
            $is_raw_comp = isset($_POST['is_raw_component']) ? 1 : 0;
            $is_sellable = isset($_POST['is_sellable']) ? 1 : 0;

            $stmt = $tenant_conn->prepare("UPDATE products SET sale_price=?, alert_level=?, is_expirable=?, is_b2b_public=?, allow_partner_view=?, is_raw=?, is_raw_component=?, is_sellable=? WHERE id=?");
            $stmt->execute([$sale_price, $alert, $is_expirable, $is_b2b, $is_b2b, $is_raw, $is_raw_comp, $is_sellable, $id]);
        }

        // Handle Expiry Date Update in Stock Table
        if ($is_expirable && !empty($new_expiry)) {
            // Check if there is already a stock entry with an expiry date for this product
            $st_check = $tenant_conn->prepare("SELECT id FROM stock WHERE product_id = ? AND expiry_date IS NOT NULL ORDER BY id DESC LIMIT 1");
            $st_check->execute([$id]);
            $last_stock_id = $st_check->fetchColumn();

            if ($last_stock_id) {
                // Update the most recent expiry record
                $tenant_conn->prepare("UPDATE stock SET expiry_date = ? WHERE id = ?")->execute([$new_expiry, $last_stock_id]);
            } else {
                // Create a new entry if none exists to store the expiry date
                $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason, expiry_date) VALUES (?, 0, 'Expiry updated via edit', ?)")->execute([$id, $new_expiry]);
            }
        } elseif (!$is_expirable) {
            // If user unchecked expirable, clear the expiry date from the most recent stock record 
            // so it doesn't haunt us later.
            $tenant_conn->prepare("UPDATE stock SET expiry_date = NULL WHERE product_id = ?")->execute([$id]);
        }

        // PRG Pattern to prevent duplicate entry on refresh
        $source_param = isset($_GET['source']) ? '&source=' . htmlspecialchars($_GET['source']) : '';
        header("Location: products.php?msg=updated" . $source_param);
        exit;
    } catch (Exception $e) {
        $error_msg = "Update Error: " . $e->getMessage();
    }
}


// --- Handle Delete ---
if (isset($_POST['action']) && $_POST['action'] === 'delete_product') {
    try {
        $stmt = $tenant_conn->prepare("DELETE FROM products WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $source_param = isset($_GET['source']) ? '&source=' . htmlspecialchars($_GET['source']) : '';
        header("Location: products.php?msg=deleted" . $source_param);
        exit;
    } catch (PDOException $e) {
        $error_msg = "Error: " . $e->getMessage();
    }
}

// --- Fetch Products ---
$search = $_GET['search'] ?? '';
$type_filter = $_GET['type'] ?? 'all';

$active_branch = $_SESSION['active_branch_id'] ?? null;
$is_all = ($active_branch === 'all');
$stock_branch = $is_all ? null : get_active_stock_branch_id($active_branch);

$stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
$main_id = $stmt_main->fetchColumn();

if ($industry !== 'restaurant' && $industry !== 'service') {
    // Advanced JOIN for Retail/Wholesale
    $sql = "SELECT p.*, c.name as cat_name, u.name as unit_name, s.name as supp_name,
            (SELECT expiry_date FROM stock WHERE product_id = p.id AND expiry_date IS NOT NULL ORDER BY id DESC LIMIT 1) as latest_expiry
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            LEFT JOIN units u ON p.unit_id = u.id 
            LEFT JOIN suppliers s ON p.supplier_id = s.id";

    $where_clauses = [];
    if (!$is_all) {
        $where_clauses[] = ($stock_branch == $main_id) ? "(p.branch_id = :branch_id OR p.branch_id IS NULL)" : "p.branch_id = :branch_id";
    }

    if ($type_filter === 'expiry') {
        $where_clauses[] = "p.is_expirable = 1";
    }

    if (!empty($search)) {
        $where_clauses[] = "(p.name LIKE :search OR p.sku LIKE :search)";
    }
    if (!empty($where_clauses)) $sql .= " WHERE " . implode(" AND ", $where_clauses);
    $sql .= " ORDER BY p.id DESC";
} else {
    $sql = "SELECT *, (SELECT expiry_date FROM stock WHERE product_id = products.id AND expiry_date IS NOT NULL ORDER BY id DESC LIMIT 1) as latest_expiry FROM products";
    
    $where_clauses = [];
    if (!$is_all) {
        $where_clauses[] = ($stock_branch == $main_id) ? "(branch_id = :branch_id OR branch_id IS NULL)" : "branch_id = :branch_id";
    }

    if ($type_filter === 'product') {
        $where_clauses[] = "is_raw = 0";
    } elseif ($type_filter === 'raw') {
        $where_clauses[] = "is_raw = 1";
    }

    if ($search) $where_clauses[] = "name LIKE :search";
    if (!empty($where_clauses)) $sql .= " WHERE " . implode(" AND ", $where_clauses);
    $sql .= " ORDER BY id DESC";
}

try {
    $stmt = $tenant_conn->prepare($sql);
    if (!$is_all) $stmt->bindValue(':branch_id', $stock_branch);
    if ($search) $stmt->bindValue(':search', "%$search%");
    $stmt->execute();
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $products = [];
    $error_msg = "Database Sync in progress... Please refresh the page. (Details: " . $e->getMessage() . ")";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Product Management</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Theme Logic -->
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 font-sans text-slate-900 dark:text-neutral-200 transition-colors duration-300">
    
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8 overflow-y-auto">
        <!-- Header & Toolbar -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-8">
            <div>
                <h1 class="text-2xl font-black text-slate-900 dark:text-white tracking-tight">
                    <?php echo ($industry === 'restaurant') ? 'Menu Management' : 'Product Inventory'; ?>
                </h1>
                <p class="text-sm text-slate-500 dark:text-neutral-400">Manage your <?php echo ($industry === 'restaurant') ? 'dishes and recipes' : 'items, stock, and pricing'; ?>.</p>
            </div>
            
            <div class="flex items-center gap-3 w-full md:w-auto">
                <?php include 'topbar.php'; ?>
                <button onclick="document.getElementById('addProductModal').classList.remove('hidden'); document.getElementById('addProductModal').classList.add('flex')" class="bg-orange-600 hover:bg-orange-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-lg shadow-orange-900/20 transition-all whitespace-nowrap">
                    <i data-lucide="plus" size="18"></i> Add Item
                </button>
            </div>
        </div>

        <!-- Dedicated Search & Filters Bar -->
        <div class="bg-white dark:bg-neutral-950 p-4 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm mb-6">
            <form class="flex flex-col md:flex-row items-center gap-4" method="GET">
                <?php if (isset($_GET['source'])): ?>
                    <input type="hidden" name="source" value="<?php echo htmlspecialchars($_GET['source']); ?>">
                <?php endif; ?>
                
                <?php if ($industry === 'restaurant'): ?>
                <select name="type" onchange="this.form.submit()" class="w-full md:w-48 px-4 py-2.5 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl text-sm outline-none focus:border-orange-500 transition-colors text-slate-700 dark:text-neutral-300 font-bold">
                    <option value="all" <?php echo $type_filter === 'all' ? 'selected' : ''; ?>>All Items</option>
                    <option value="product" <?php echo $type_filter === 'product' ? 'selected' : ''; ?>>Menu / Dishes</option>
                    <option value="raw" <?php echo $type_filter === 'raw' ? 'selected' : ''; ?>>Raw Items</option>
                </select>
                <?php endif; ?>

                <div class="relative flex-1 w-full">
                    <i data-lucide="search" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                    <input type="text" name="search" value="<?php echo htmlspecialchars($search); ?>" placeholder="Search items by name..." class="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl text-sm focus:border-orange-500 outline-none transition-colors">
                </div>
                <button type="submit" class="w-full md:w-auto px-8 py-2.5 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-sm font-bold hover:opacity-90 transition-all">Search</button>
            </form>
        </div>

        <!-- Global Verification Alert Bar -->
        <?php include 'alert_bar.php'; ?>

        <?php if ($error_msg): ?>
            <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-xl text-sm font-bold flex items-center gap-2">
                <i data-lucide="alert-circle" size="18"></i> <?php echo $error_msg; ?>
            </div>
        <?php endif; ?>

        <?php if ($success_msg): ?>
            <div class="mb-6 p-4 bg-green-50 dark:bg-green-900/10 border border-green-200 dark:border-green-900/20 text-green-700 dark:text-green-400 rounded-xl text-sm font-medium flex items-center gap-2">
                <i data-lucide="check-circle" size="18"></i> <?php echo $success_msg; ?>
            </div>
        <?php endif; ?>

        <!-- Product Table -->
        <div class="bg-white dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-200 dark:border-neutral-800">
                    <tr>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Name</th>
                        
                        <?php if ($industry === 'restaurant'): ?>
                            <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Category</th>
                            <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Price</th>
                            <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Recipe</th>
                        <?php else: ?>
                            <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Category / Unit</th>
                            <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">SKU / Barcode</th>
                            <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Price</th>
                            <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-center">Stock</th>
                            <?php if (has_module('raw_material_system')): ?>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Build</th>
                            <?php endif; ?>
                        <?php endif; ?>

                        <?php if ($marketplace_enabled): ?>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-center">Visibility</th>
                        <?php endif; ?>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach ($products as $p): ?>
                    <tr class="group hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                        
                        <!-- Name Column -->
                        <td class="px-6 py-4">
                            <div class="font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($p['name']); ?></div>
                            <div class="text-[10px] text-slate-400 font-black uppercase mt-0.5 tracking-tighter flex items-center gap-2">
                                Unit: <?= htmlspecialchars($p['unit_name'] ?? 'Piece') ?>
                                <?php if($p['latest_expiry']): ?>
                                    <span class="text-rose-500">• Exp: <?= $p['latest_expiry'] ?></span>
                                <?php endif; ?>
                            </div>
                            <?php if ($industry === 'restaurant' && !empty($p['description'])): ?>
                                <div class="text-xs text-slate-500 truncate max-w-xs"><?php echo htmlspecialchars($p['description']); ?></div>
                            <?php endif; ?>
                        </td>

                        <?php if ($industry === 'restaurant'): ?>
                            <td class="px-6 py-4">
                                <span class="px-2.5 py-1 rounded-full text-xs font-bold bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-neutral-400 border border-slate-200 dark:border-neutral-700">
                                    <?php echo htmlspecialchars($p['category']); ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 font-mono text-slate-700 dark:text-slate-300"><?php echo $currency_symbol; ?><?php echo number_format($p['price'], 2); ?></td>
                            <td class="px-6 py-4">
                                <?php if (($p['is_raw'] ?? 0) == 0): ?>
                                <button onclick='openRecipeModal(<?= $p['id'] ?>, <?= htmlspecialchars(json_encode($p['name']), ENT_QUOTES) ?>)' class="text-xs font-bold text-orange-600 dark:text-orange-500 hover:underline flex items-center gap-1">
                                    <i data-lucide="chef-hat" size="14"></i> Manage Ingredients
                                </button>
                                <?php else: ?>
                                <span class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Ingredient</span>
                                <?php endif; ?>
                            </td>
                        <?php else: ?>
                            <td class="px-6 py-4">
                                <div class="text-xs font-bold text-slate-700 dark:text-white"><?php echo htmlspecialchars($p['cat_name'] ?? 'Uncategorized'); ?></div>
                                <div class="text-[10px] text-slate-400"><?php echo htmlspecialchars($p['unit_name'] ?? 'pcs'); ?></div>
                            </td>
                            <td class="px-6 py-4 font-mono text-xs text-slate-500 dark:text-neutral-400"><?php echo htmlspecialchars($p['sku']); ?></td>
                            <td class="px-6 py-4 font-mono text-slate-700 dark:text-slate-300 text-right">
                                <div class="text-orange-600 font-bold"><?php echo $currency_symbol; ?><?php echo number_format($p['sale_price'] ?? $p['price'], 2); ?></div>
                                <div class="text-[10px] text-slate-400 italic">Cost: <?php echo $currency_symbol; ?><?php echo number_format($p['purchase_price'] ?? 0, 2); ?></div>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <?php 
                                    $stock = $p['stock_level'] ?? 0;
                                    $alert_level = $p['alert_level'] ?? 10;
                                    
                                    if ($stock <= $alert_level) {
                                        $stockClass = 'bg-rose-500 text-white shadow-lg shadow-rose-500/20';
                                    } else {
                                        $stockClass = 'bg-emerald-500/10 text-emerald-600 border border-emerald-500/20';
                                    }
                                ?>
                                <span class="px-2.5 py-1 rounded-full text-xs font-bold <?php echo $stockClass; ?>">
                                    <?php echo $stock; ?>
                                </span>
                            </td>
                            <?php if (has_module('raw_material_system')): ?>
                            <td class="px-6 py-4 text-right">
                                <div class="flex flex-col items-end gap-1">
                                    <button onclick='openRecipeModal(<?= $p['id'] ?>, <?= htmlspecialchars(json_encode($p['name']), ENT_QUOTES) ?>)' class="text-[10px] font-black uppercase text-orange-600 dark:text-orange-500 hover:underline flex items-center gap-1">
                                        <i data-lucide="settings-2" size="12"></i> Set Formula
                                    </button>
                                    <button onclick='openProductionModal(<?= $p['id'] ?>, <?= htmlspecialchars(json_encode($p['name']), ENT_QUOTES) ?>)' class="text-[10px] font-black uppercase text-emerald-600 dark:text-emerald-500 hover:underline flex items-center gap-1">
                                        <i data-lucide="factory" size="12"></i> Produce Stock
                                    </button>
                                </div>
                            </td>
                            <?php endif; ?>
                        <?php endif; ?>

                        <!-- Visibility Column -->
                        <?php if ($marketplace_enabled): ?>
                        <td class="px-6 py-4 text-center">
                            <?php if (($p['is_b2b_public'] ?? 0) == 1): ?>
                                <span class="px-2 py-1 rounded-md text-[9px] font-black uppercase bg-orange-100 text-orange-600 dark:bg-orange-500/10 dark:text-orange-500 border border-orange-200 dark:border-orange-500/20 flex items-center justify-center gap-1">
                                    <i data-lucide="globe" size="10"></i> Public
                                </span>
                            <?php elseif (($p['is_raw'] ?? 0) == 1): ?>
                                <span class="px-2 py-1 rounded-md text-[9px] font-black uppercase bg-blue-100 text-blue-600 dark:bg-blue-500/10 dark:text-blue-500 border border-blue-200 dark:border-blue-500/20 flex items-center justify-center gap-1">
                                    <i data-lucide="box" size="10"></i> Raw
                                </span>
                            <?php else: ?>
                                <span class="px-2 py-1 rounded-md text-[9px] font-black uppercase bg-slate-100 text-slate-500 dark:bg-neutral-800 dark:text-neutral-500 border border-slate-200 dark:border-neutral-700 flex items-center justify-center gap-1">
                                    <i data-lucide="lock" size="10"></i> Private
                                </span>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>

                        <td class="px-6 py-4 text-right">
                            <button onclick='openEditModal(<?= htmlspecialchars(json_encode($p), ENT_QUOTES) ?>)' class="p-2 text-slate-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-900/20 rounded-lg transition-colors inline-block">
                                <i data-lucide="edit-3" size="16"></i>
                            </button>
                            <form method="POST" onsubmit="return confirm('Delete this product?');" class="inline">
                                <input type="hidden" name="action" value="delete_product">
                                <input type="hidden" name="id" value="<?php echo $p['id']; ?>">
                                <button class="p-2 text-slate-400 hover:text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors">
                                    <i data-lucide="trash-2" size="16"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Add Product Modal -->
    <div id="addProductModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl w-full max-w-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button onclick="document.getElementById('addProductModal').classList.add('hidden'); document.getElementById('addProductModal').classList.remove('flex')" class="absolute top-4 right-4 text-slate-400 hover:text-slate-900 dark:hover:text-white"><i data-lucide="x" size="20"></i></button>
            
            <h3 class="text-2xl font-black mb-1 text-slate-900 dark:text-white uppercase tracking-tight">Add New Product</h3>
            <p class="text-xs text-slate-500 mb-8">Update your inventory with new stock items.</p>
            
            <?php if ($industry === 'restaurant'): ?>
            <div class="flex gap-4 mb-6 border-b border-slate-100 dark:border-neutral-800">
                <button type="button" onclick="switchAddTab('product')" id="btn-tab-product" class="pb-2 text-xs font-black uppercase tracking-widest border-b-2 border-orange-600 text-orange-600">Menu / Dishes</button>
                <button type="button" onclick="switchAddTab('raw_material')" id="btn-tab-raw" class="pb-2 text-xs font-black uppercase tracking-widest border-b-2 border-transparent text-slate-400">Raw Item / Ingredient</button>
            </div>
            <?php endif; ?>

            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add_product">
                <input type="hidden" name="type" id="add_type_field" value="product">

                <!-- Universal Field -->
                <div>
                    <label id="label-name" class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500"><?php echo ($industry === 'restaurant') ? 'Dish Name' : 'Product Name'; ?></label>
                    <input type="text" name="name" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                </div>

                <!-- Restaurant Specific -->
                <?php if ($industry === 'restaurant'): ?>
                <div class="grid grid-cols-2 gap-4">
                    <div id="cat-container">
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Category</label> <!-- Changed from 'Category' to 'Dish Category' for clarity -->
                        <select name="category" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                            <option value="Appetizer">Appetizer</option>
                            <option value="Main Course">Main Course</option>
                            <option value="Dessert">Dessert</option>
                            <option value="Beverage">Beverage</option>
                        </select>
                    </div>
                    <div id="price-container">
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Price</label>
                        <input type="number" step="0.01" name="price" id="add_price_input" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                    </div>
                    <div id="cost-container" class="hidden">
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Purchase Cost</label>
                        <input type="number" step="0.01" name="purchase_price" id="add_cost_input" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                    </div>
                </div>

                <div id="dish-stock-option" class="py-2 border-t border-slate-100 dark:border-neutral-800 mt-4">
                    <label class="flex items-center gap-2 cursor-pointer group">
                        <input type="checkbox" name="has_stock" id="has_stock_checkbox" onchange="toggleDishStockFields()" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 rounded">
                        <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Track stock for this item? (e.g. Drinks, Packed Foods)</span>
                    </label>
                </div>

                <div id="dish-stock-fields" class="hidden space-y-4 pt-2">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Initial Stock</label>
                            <input type="number" step="0.01" name="dish_stock" value="0" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Alert Level</label>
                            <input type="number" step="0.01" name="dish_alert" value="5" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                        </div>
                    </div>
                    <label class="flex items-center gap-2 cursor-pointer group">
                        <input type="checkbox" name="dish_expirable" id="dish_is_expirable" onchange="toggleExpiryDateInput('dish')" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 rounded">
                        <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Is this item expirable?</span>
                    </label>
                    <div id="dish_expiry_date_container" class="mt-2 hidden">
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500 dark:text-neutral-500">Expiry Date</label>
                        <input type="date" name="dish_expiry_date" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-sm dark:text-white">
                    </div>
                </div>

                <div id="raw-fields" class="hidden space-y-4">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Initial Stock</label>
                            <input type="number" step="0.01" name="stock_level" value="0" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                        </div>
                        <div>
                            <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Alert Level</label>
                            <input type="number" step="0.01" name="alert_level" value="5" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                        </div>
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Measurement Unit</label>
                        <select name="unit_id" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                            <option value="">Select Unit</option>
                            <?php foreach($units_list as $ul): ?>
                                <option value="<?= $ul['id'] ?>"><?= htmlspecialchars($ul['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-span-2 py-2">
                        <label class="flex items-center gap-2 cursor-pointer group">
                            <input type="checkbox" name="is_expirable" id="raw_is_expirable" onchange="toggleExpiryDateInput('raw')" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 rounded">
                            <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Expirable Product?</span>
                        </label>
                        <div id="raw_expiry_date_container" class="mt-2 hidden">
                            <label class="block text-[10px] font-black uppercase mb-1 text-slate-500 dark:text-neutral-500">Expiry Date</label>
                            <input type="date" name="initial_expiry_date" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-sm dark:text-white">
                        </div>
                    </div>
                </div>

                <div>
                    <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Description</label>
                    <textarea name="description" rows="2" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white"></textarea>
                </div>
                
                <!-- Retail / Wholesale Specific -->
                <?php else: ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Barcode / SKU</label>
                        <div class="flex gap-1">
                            <input type="text" name="sku" id="sku_input" class="flex-1 px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm font-mono">
                            <button type="button" onclick="const r=Math.floor(100000+Math.random()*900000);document.getElementById('sku_input').value='BX-'+r;" class="px-3 bg-slate-100 dark:bg-neutral-800 rounded-xl hover:text-orange-500"><i data-lucide="refresh-cw" size="16"></i></button>
                        </div>
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Category</label>
                        <select name="category_id" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                            <option value="">Select Category</option>
                            <?php foreach($categories_list as $cl): ?>
                                <option value="<?= $cl['id'] ?>"><?= htmlspecialchars($cl['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Unit</label>
                        <select name="unit_id" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                            <?php foreach($units_list as $ul): ?>
                                <option value="<?= $ul['id'] ?>"><?= htmlspecialchars($ul['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Supplier</label>
                        <select name="supplier_id" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                            <option value="">Default Supplier</option>
                            <?php foreach($suppliers_list as $sl): ?>
                                <option value="<?= $sl['id'] ?>"><?= htmlspecialchars($sl['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Purchase Cost</label>
                        <input type="number" step="0.01" name="purchase_price" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Selling Price</label>
                        <input type="number" step="0.01" name="sale_price" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Initial Stock</label>
                        <input type="number" name="stock_level" value="0" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Alert Level</label>
                        <input type="number" name="alert_level" value="10" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                    <div class="space-y-1 md:col-span-2">
                        <label class="flex items-center gap-2 cursor-pointer group">
                            <input type="checkbox" name="is_expirable" id="add_is_expirable" onchange="toggleExpiryDateInput('add')" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900">
                            <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Is this product expirable?</span>
                        </label>
                        <div id="add_expiry_date_container" class="mt-2 hidden">
                            <label class="block text-[10px] font-black uppercase mb-1 text-slate-500 dark:text-neutral-500">Initial Stock Expiry Date</label>
                            <input type="date" name="initial_expiry_date" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                            <p class="text-[9px] text-slate-400 mt-1 italic">This expiry date will be applied to the initial stock quantity.</p>
                        </div>
                    </div>
                    <?php if (has_module('raw_material_system')): ?>
                    <div id="add_raw_config_container" class="space-y-4 md:col-span-2 p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-dashed border-slate-200 dark:border-neutral-800">
                        <p class="text-[10px] font-black uppercase text-orange-500 tracking-widest mb-2">Raw Material Configuration</p>
                        <div class="flex flex-wrap gap-6">
                            <label class="flex items-center gap-2 cursor-pointer group">
                                <input type="checkbox" name="is_raw_component" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 rounded">
                                <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Can be used as Raw Material?</span>
                            </label>
                            <label class="flex items-center gap-2 cursor-pointer group">
                                <input type="checkbox" name="is_sellable" checked class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900 rounded">
                                <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Directly Sellable on POS?</span>
                            </label>
                        </div>
                    </div>
                    <?php else: ?>
                        <input type="hidden" name="is_sellable" value="1">
                    <?php endif; ?>
                    <?php if ($marketplace_enabled || has_module('raw_material_system')): ?>
                    <div class="space-y-1 md:col-span-2">
                        <label class="text-[10px] font-black uppercase text-slate-400">Visibility & Type</label>
                        <div class="flex flex-wrap gap-4 mt-2">
                            <?php if ($marketplace_enabled): ?>
                            <label class="flex items-center gap-2 cursor-pointer group">
                                <input type="radio" name="visibility" value="public" onchange="updateVisibilityToggles('add')" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900">
                                <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Public (Visible to Partners)</span>
                            </label>
                            <?php endif; ?>
                            <label class="flex items-center gap-2 cursor-pointer group">
                                <input type="radio" name="visibility" value="private" checked onchange="updateVisibilityToggles('add')" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900">
                                <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Private (Internal Only)</span>
                            </label>
                            <label class="flex items-center gap-2 cursor-pointer group">
                                <input type="radio" name="visibility" value="raw" onchange="updateVisibilityToggles('add')" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900">
                                <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Raw Material</span>
                            </label>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

                <button type="submit" class="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-4 rounded-2xl transition-all shadow-lg shadow-orange-600/20 uppercase tracking-widest text-sm mt-6">Add to Inventory</button>
            </form>
        </div>
    </div>
    
    <!-- Edit Product Modal -->
    <div id="editProductModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl w-full max-w-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button onclick="document.getElementById('editProductModal').classList.add('hidden'); document.getElementById('editProductModal').classList.remove('flex')" class="absolute top-4 right-4 text-slate-400 hover:text-slate-900 dark:hover:text-white"><i data-lucide="x" size="20"></i></button>
            
            <h3 class="text-2xl font-black mb-1 text-slate-900 dark:text-white uppercase tracking-tight">Edit Product</h3>
            <p class="text-xs text-slate-500 mb-8">Update your product visibility and details.</p>
            
            <form method="POST" class="space-y-4" id="editForm">
                <input type="hidden" name="action" value="edit_product">
                <input type="hidden" name="id" id="edit_id">

                <div class="p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl">
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Editing Product</p>
                    <p id="edit_display_name" class="text-lg font-black text-slate-900 dark:text-white"></p>
                    <p id="edit_display_sku" class="text-xs font-mono text-slate-500"></p>
                </div>

                <?php if ($industry === 'restaurant'): ?>
                <div>
                    <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Dish Name</label>
                    <input type="text" name="name" id="edit_name" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Category</label>
                        <select name="category" id="edit_category" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                            <option value="Appetizer">Appetizer</option>
                            <option value="Main Course">Main Course</option>
                            <option value="Dessert">Dessert</option>
                            <option value="Beverage">Beverage</option>
                        </select>
                    </div>
                <div>
                    <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Price</label>
                    <input type="number" step="0.01" name="price" id="edit_price" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                </div>
                </div>
                <div>
                    <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Description</label>
                    <textarea name="description" id="edit_description" rows="2" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white"></textarea>
                </div>
                <?php else: ?>
                <div class="grid grid-cols-2 gap-4">
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Selling Price</label>
                        <input type="number" step="0.01" name="sale_price" id="edit_sale_price" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                    <div class="space-y-1">
                        <label class="text-[10px] font-black uppercase text-slate-400">Alert Level</label>
                        <input type="number" name="alert_level" id="edit_alert" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                </div>
                <div class="space-y-1">
                    <label class="flex items-center gap-2 cursor-pointer group">
                        <input type="checkbox" name="is_expirable" id="edit_is_expirable" onchange="toggleExpiryDateInput('edit')" class="w-4 h-4 text-orange-600 focus:ring-orange-500 border-slate-300 dark:border-neutral-700 bg-white dark:bg-neutral-900">
                        <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Is this product expirable?</span>
                    </label>
                    <div id="edit_expiry_date_container" class="mt-2 hidden">
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500 dark:text-neutral-500">Initial Stock Expiry Date</label>
                        <input type="date" name="initial_expiry_date" id="edit_initial_expiry_date" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                        <p class="text-[9px] text-slate-400 mt-1 italic">This expiry date will be applied to the initial stock quantity if stock is added.</p>
                    </div>
                </div>
                <?php if (has_module('raw_material_system')): ?>
                <div id="edit_raw_config_container" class="space-y-4 p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-dashed border-slate-200 dark:border-neutral-800">
                    <p class="text-[10px] font-black uppercase text-orange-500 tracking-widest mb-2">Raw Material Configuration</p>
                    <div class="flex flex-wrap gap-6">
                        <label class="flex items-center gap-2 cursor-pointer group">
                            <input type="checkbox" name="is_raw_component" id="edit_is_raw_component" class="w-4 h-4 text-orange-600 rounded">
                            <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Can be used as Raw Material?</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer group">
                            <input type="checkbox" name="is_sellable" id="edit_is_sellable" class="w-4 h-4 text-orange-600 rounded">
                            <span class="text-xs font-bold text-slate-700 dark:text-white group-hover:text-orange-500">Directly Sellable on POS?</span>
                        </label>
                    </div>
                </div>
                <?php endif; ?>
                <?php endif; ?>

                <?php if ($marketplace_enabled || has_module('raw_material_system')): ?>
                <div class="space-y-1">
                    <label class="text-[10px] font-black uppercase text-slate-400">Visibility & Type</label>
                    <div class="flex flex-wrap gap-4 mt-2">
                        <?php if ($marketplace_enabled): ?>
                        <label class="flex items-center gap-2 cursor-pointer group">
                            <input type="radio" name="visibility" value="public" id="vis_public" onchange="updateVisibilityToggles('edit')" class="w-4 h-4 text-orange-600">
                            <span class="text-xs font-bold text-slate-700 dark:text-white">Public</span>
                        </label>
                        <?php endif; ?>
                        <label class="flex items-center gap-2 cursor-pointer group">
                            <input type="radio" name="visibility" value="private" id="vis_private" onchange="updateVisibilityToggles('edit')" class="w-4 h-4 text-orange-600">
                            <span class="text-xs font-bold text-slate-700 dark:text-white">Private</span>
                        </label>
                        <label class="flex items-center gap-2 cursor-pointer group">
                            <input type="radio" name="visibility" value="raw" id="vis_raw" onchange="updateVisibilityToggles('edit')" class="w-4 h-4 text-orange-600">
                            <span class="text-xs font-bold text-slate-700 dark:text-white">Raw Material</span>
                        </label>
                    </div>
                </div>
                <?php endif; ?>

                <button type="submit" class="w-full bg-emerald-600 hover:bg-emerald-700 text-white font-black py-4 rounded-2xl transition-all shadow-lg shadow-emerald-600/20 uppercase tracking-widest text-sm mt-6">Save Changes</button>
            </form>
        </div>
    </div>

    <!-- Production Modal -->
    <div id="productionModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[70] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('productionModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-rose-500"><i data-lucide="x" size="24"></i></button>
            
            <div class="text-center mb-6">
                <div class="w-16 h-16 bg-emerald-500/10 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="factory" size="32"></i>
                </div>
                <h2 class="text-2xl font-black dark:text-white uppercase tracking-tight">Produce Finished Stock</h2>
                <p id="prod_product_name" class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1"></p>
            </div>

            <div class="space-y-4">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 text-center">How many units did you produce?</label>
                    <input type="number" id="produce_qty_input" step="0.01" value="1" class="w-full px-4 py-5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-3xl outline-none focus:border-emerald-500 dark:text-white font-black text-2xl text-center">
                    <p class="text-[9px] text-slate-400 mt-2 italic text-center">Note: Raw materials will be deducted automatically based on formula.</p>
                </div>
                <button onclick="submitProduction()" id="btnSubmitProd" class="w-full py-5 bg-emerald-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all mt-4">Confirm Production</button>
            </div>
        </div>
    </div>

    <!-- Recipe Management Modal -->
    <div id="recipeModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[60] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-xl shadow-2xl relative">
            <button onclick="closeRecipeModal()" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Recipe Builder</h2>
            <p id="recipeDishName" class="text-xs text-orange-500 font-bold uppercase tracking-widest mb-6"></p>

            <div class="space-y-4">
                <div class="relative">
                    <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="16"></i>
                    <input type="text" id="ingSearch" onkeyup="filterAvailableIngredients(this.value)" placeholder="Search from all available raw materials..." class="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm focus:border-orange-500 transition-all">
                </div>

                <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Available Raw Materials (Click to add)</p>
                <div id="availableIngredientsList" class="flex flex-wrap gap-2 max-h-40 overflow-y-auto p-1 custom-scrollbar"></div>

                <div class="max-h-60 overflow-y-auto custom-scrollbar">
                    <table class="w-full text-left">
                        <thead class="text-[10px] font-black uppercase text-slate-400 border-b border-slate-100 dark:border-neutral-800">
                            <tr>
                                <th class="py-2">Ingredient</th>
                                <th class="py-2 text-center">Qty</th>
                                <th class="py-2 text-right"></th>
                            </tr>
                        </thead>
                        <tbody id="recipeListBody" class="divide-y divide-slate-50 dark:divide-neutral-800"></tbody>
                    </table>
                </div>
            </div>

            <button onclick="saveRecipe()" class="w-full py-4 bg-orange-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 mt-8">Save Recipe</button>
        </div>
    </div>

    <script>
        lucide.createIcons();
        let currentRecipeDishId = null;
        let selectedIngredients = [];
        let allRawItems = []; // Global store for all ingredients
        let isCreatingNewItem = false;
        let currentProdId = null;

        function openProductionModal(id, name) {
            currentProdId = id;
            document.getElementById('prod_product_name').innerText = name;
            document.getElementById('produce_qty_input').value = 1;
            document.getElementById('productionModal').classList.replace('hidden', 'flex');
        }

        async function submitProduction() {
            const qty = document.getElementById('produce_qty_input').value;
            const btn = document.getElementById('btnSubmitProd');
            
            btn.disabled = true;
            btn.innerText = "Processing Production...";

            try {
                const res = await fetch('api.php?route=production/build', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ product_id: currentProdId, quantity: qty })
                });
                const result = await res.json();
                if (result.success) {
                    alert(result.message);
                    location.reload();
                } else {
                    alert("Production Error: " + result.message);
                }
            } catch (e) { alert("System Error."); }
            btn.disabled = false; btn.innerText = "Confirm Production";
        }

        async function fetchAllRawItems() {
            try {
                const res = await fetch(`api.php?route=products&raw_only=1`);
                allRawItems = await res.json();
                renderAvailableIngredients();
            } catch (err) { console.error("Error loading ingredients:", err); }
        }

        async function openRecipeModal(dishId, dishName) {
            isCreatingNewItem = false;
            currentRecipeDishId = dishId;
            document.getElementById('recipeDishName').innerText = dishName;
            document.getElementById('ingSearch').value = '';
            
            const modal = document.getElementById('recipeModal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
            
            // Load all raw items if not already loaded
            if (allRawItems.length === 0) await fetchAllRawItems();
            else renderAvailableIngredients();

            const res = await fetch(`api.php?route=recipe/get&product_id=${dishId}`);
            const data = await res.json();
            selectedIngredients = data.map(i => ({ id: i.ingredient_id, name: i.name, qty: i.quantity, unit: i.unit }));
            renderRecipeList();
        }

        function openRecipeSearch(context) {
            if (context === 'add-item') {
                isCreatingNewItem = true;
                document.getElementById('ingSearch').value = '';
                document.getElementById('recipeDishName').innerText = "New Product Recipe";
                const modal = document.getElementById('recipeModal');
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                
                if (allRawItems.length === 0) fetchAllRawItems();
                else renderAvailableIngredients();

                // Clear previous if any
                if (!selectedIngredients.length) renderRecipeList();
            }
        }

        function renderAvailableIngredients(filter = '') {
            const container = document.getElementById('availableIngredientsList');
            const query = filter.toLowerCase();
            
            const filtered = allRawItems.filter(p => p.name.toLowerCase().includes(query));
            
            container.innerHTML = filtered.map(p => {
                const isAdded = selectedIngredients.find(i => i.id == p.id);
                return `
                <button onclick="addIngredientToRecipe(${p.id})" 
                    class="px-3 py-2 rounded-xl border transition-all text-[10px] font-black uppercase tracking-tight
                    ${isAdded ? 'bg-orange-600 text-white border-orange-600' : 'bg-white dark:bg-neutral-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-neutral-700 hover:border-orange-500'}">
                    ${p.name}
                </button>
                `;
            }).join('');
        }

        function filterAvailableIngredients(q) {
            renderAvailableIngredients(q);
        }

        function addIngredientToRecipe(id) {
            const item = allRawItems.find(i => i.id == id);
            if (!item || selectedIngredients.find(i => i.id == id)) return;
            selectedIngredients.push({ id: item.id, name: item.name, qty: 1, unit: item.unit_name });
            renderAvailableIngredients(document.getElementById('ingSearch').value);
            renderRecipeList();
        }

        function renderRecipeList() {
            const body = document.getElementById('recipeListBody');
            body.innerHTML = selectedIngredients.map((ing, idx) => `
                <tr>
                    <td class="py-3">
                        <p class="text-sm font-bold dark:text-white">${ing.name}</p>
                        <p class="text-[9px] text-slate-400 uppercase font-black">${ing.unit || 'unit'}</p>
                    </td>
                    <td class="py-3 text-center">
                        <input type="number" step="0.001" onchange="selectedIngredients[${idx}].qty = this.value" value="${ing.qty}" class="w-20 px-2 py-1 bg-slate-50 dark:bg-neutral-800 border rounded-lg text-center font-bold dark:text-white outline-none focus:border-orange-500">
                    </td>
                    <td class="py-3 text-right">
                        <button onclick="selectedIngredients.splice(${idx}, 1); renderRecipeList();" class="text-rose-500 p-1"><i data-lucide="trash-2" size="14"></i></button>
                    </td>
                </tr>
            `).join('');
            lucide.createIcons();
        }

        async function saveRecipe() {
            if (isCreatingNewItem) {
                // Save to hidden field for the "Add Item" form
                document.getElementById('add_item_recipe_json').value = JSON.stringify(selectedIngredients);
                
                // Update UI hint in the Add Modal
                const hint = document.getElementById('add-item-recipe-list');
                hint.innerHTML = `<div class="p-2 bg-orange-50 dark:bg-orange-500/10 text-orange-600 text-[10px] font-bold rounded-lg border border-orange-200">✓ ${selectedIngredients.length} Ingredients linked to this new dish</div>`;
                
                closeRecipeModal();
                return;
            }

            const res = await fetch('api.php?route=recipe/save', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ product_id: currentRecipeDishId, ingredients: selectedIngredients })
            });
            const result = await res.json();
            if (result.success) {
                alert("Recipe saved successfully!");
                closeRecipeModal();
            }
        }

        function closeRecipeModal() {
            document.getElementById('recipeModal').classList.replace('flex', 'hidden');
            selectedIngredients = [];
        }

        function toggleDishStockFields() {
            const checkbox = document.getElementById('has_stock_checkbox');
            const fields = document.getElementById('dish-stock-fields');
            if (checkbox && fields) {
                if (checkbox.checked) fields.classList.remove('hidden');
                else fields.classList.add('hidden');
            }
        }

        function switchAddTab(type) {
            const typeField = document.getElementById('add_type_field');
            const rawFields = document.getElementById('raw-fields');
            const catContainer = document.getElementById('cat-container');
            const priceContainer = document.getElementById('price-container');
            const costContainer = document.getElementById('cost-container');
            const nameLabel = document.getElementById('label-name');
            const dishStockOpt = document.getElementById('dish-stock-option');
            const dishStockFields = document.getElementById('dish-stock-fields');
            const btnProduct = document.getElementById('btn-tab-product');
            const btnRaw = document.getElementById('btn-tab-raw');

            const priceInput = document.getElementById('add_price_input');
            const costInput = document.getElementById('add_cost_input');

            typeField.value = type;

            if (type === 'raw_material') {
                rawFields.classList.remove('hidden');
                costContainer.classList.remove('hidden');
                catContainer.classList.add('hidden');
                priceContainer.classList.add('hidden');
                if(dishStockOpt) dishStockOpt.classList.add('hidden');
                if(dishStockFields) dishStockFields.classList.add('hidden');

                // Fix validation error: Toggle required attributes
                if(priceInput) priceInput.required = false;
                if(costInput) costInput.required = true;

                nameLabel.innerText = 'Ingredient Name';
                btnRaw.classList.add('border-orange-600', 'text-orange-600');
                btnRaw.classList.remove('border-transparent', 'text-slate-400');
                btnProduct.classList.remove('border-orange-600', 'text-orange-600');
                btnProduct.classList.add('border-transparent', 'text-slate-400');
            } else {
                rawFields.classList.add('hidden');
                costContainer.classList.add('hidden');
                catContainer.classList.remove('hidden');
                priceContainer.classList.remove('hidden');
                if(dishStockOpt) dishStockOpt.classList.remove('hidden');
                toggleDishStockFields();

                // Fix validation error: Toggle required attributes
                if(priceInput) priceInput.required = true;
                if(costInput) costInput.required = false;

                nameLabel.innerText = 'Dish Name';
                btnProduct.classList.add('border-orange-600', 'text-orange-600');
                btnProduct.classList.remove('border-transparent', 'text-slate-400');
                btnRaw.classList.remove('border-orange-600', 'text-orange-600');
                btnRaw.classList.add('border-transparent', 'text-slate-400');
            }
        }

        function openEditModal(p) {
            document.getElementById('edit_id').value = p.id;
            document.getElementById('edit_display_name').innerText = p.name;
            
            if ("<?php echo $industry; ?>" === 'restaurant') {
                document.getElementById('edit_name').value = p.name;
                document.getElementById('edit_price').value = p.price;
                document.getElementById('edit_category').value = p.category;
                document.getElementById('edit_description').value = p.description || '';
            } else {
                document.getElementById('edit_display_sku').innerText = p.sku ? 'SKU: ' + p.sku : 'No SKU';
                document.getElementById('edit_sale_price').value = p.sale_price || p.price;
                document.getElementById('edit_alert').value = p.alert_level;
                
                if (document.getElementById('edit_is_raw_component')) {
                    document.getElementById('edit_is_raw_component').checked = p.is_raw_component == 1;
                    document.getElementById('edit_is_sellable').checked = p.is_sellable == 1;
                }
            }
            
            const editIsExpirable = document.getElementById('edit_is_expirable');
            if (editIsExpirable) {
                editIsExpirable.checked = p.is_expirable == 1;
                const dateField = document.getElementById('edit_initial_expiry_date');
                if (dateField) dateField.value = p.expiry_date || '';
                toggleExpiryDateInput('edit');
            }

            // Set Visibility (Only if elements exist)
            const visPublic = document.getElementById('vis_public');
            if (visPublic) {
                // Reset all visibility radios first
                document.getElementById('vis_public').checked = false;
                document.getElementById('vis_private').checked = false;
                document.getElementById('vis_raw').checked = false;

                if (p.is_b2b_public == 1) document.getElementById('vis_public').checked = true;
                else if (p.is_raw == 1) document.getElementById('vis_raw').checked = true;
                else document.getElementById('vis_private').checked = true;
            }

            updateVisibilityToggles('edit');

            document.getElementById('editProductModal').classList.remove('hidden');
            document.getElementById('editProductModal').classList.add('flex');
        }

        function updateVisibilityToggles(prefix) {
            const container = document.getElementById(`${prefix}_raw_config_container`);
            if (!container) return;

            let selectedValue = '';
            if (prefix === 'add') {
                selectedValue = document.querySelector('input[name="visibility"]:checked')?.value;
            } else {
                selectedValue = document.querySelector('#editForm input[name="visibility"]:checked')?.value;
            }

            if (selectedValue === 'private') {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        }

        document.addEventListener('DOMContentLoaded', () => {
            updateVisibilityToggles('add');
        });

        function toggleExpiryDateInput(prefix) {
            const checkbox = document.getElementById(`${prefix}_is_expirable`);
            const container = document.getElementById(`${prefix}_expiry_date_container`);
            if (checkbox.checked) {
                container.classList.remove('hidden');
            } else {
                container.classList.add('hidden');
            }
        }
    </script>
</body>
</html>
