<?php
require_once 'config/db_switch.php';

// Redirect if not logged in
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

// Gatekeeper check
gatekeeper_check('stock_transfer');

$message = '';
$error = '';

// Handle Stock Transfer Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'transfer_stock') {
    $from_branch = (int)$_POST['from_branch'];
    $to_branch = (int)$_POST['to_branch'];
    $product_id = (int)$_POST['product_id'];
    $qty = (float)$_POST['quantity'];

    if ($from_branch === $to_branch) {
        $error = "Source and Destination branches cannot be the same.";
    } elseif ($qty <= 0) {
        $error = "Quantity must be greater than zero.";
    } else {
        try {
            $tenant_conn->beginTransaction();

            // 1. Fetch Source Product Details and check stock
            // Detect stock column name
            $stockCol = 'stock_level';
            $checkCol = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'stock_quantity'")->fetch();
            if ($checkCol) $stockCol = 'stock_quantity';

            // Detect if barcode column exists (Wholesale/Restaurant schemas might not have it)
            $checkBarcode = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'barcode'")->fetch();
            $hasBarcode = (bool)$checkBarcode;

            $stmt_src = $tenant_conn->prepare("SELECT * FROM products WHERE id = ? AND branch_id = ?");
            $stmt_src->execute([$product_id, $from_branch]);
            $src_product = $stmt_src->fetch(PDO::FETCH_ASSOC);

            if (!$src_product) throw new Exception("Product not found in source branch.");
            if ($src_product[$stockCol] < $qty) throw new Exception("Insufficient stock in source branch. Available: " . $src_product[$stockCol]);

            // 2. Deduct from Source
            $stmt_deduct = $tenant_conn->prepare("UPDATE products SET $stockCol = $stockCol - ? WHERE id = ?");
            $stmt_deduct->execute([$qty, $product_id]);

            // 3. Find or Create in Destination
            // We match by SKU to identify the same product across branches
            $stmt_dest = $tenant_conn->prepare("SELECT id FROM products WHERE branch_id = ? AND sku = ?");
            $stmt_dest->execute([$to_branch, $src_product['sku']]);
            $dest_product_id = $stmt_dest->fetchColumn();

            if ($dest_product_id) {
                // Update existing
                $stmt_add = $tenant_conn->prepare("UPDATE products SET $stockCol = $stockCol + ? WHERE id = ?");
                $stmt_add->execute([$qty, $dest_product_id]);
            } else {
                // Create new row copying details
                $cols = ["branch_id", "name", "sku", "sale_price", "purchase_price", "category_id", "unit_id", "supplier_id", $stockCol, "alert_level"];
                $vals = [
                    $to_branch, 
                    $src_product['name'], 
                    $src_product['sku'], 
                    $src_product['sale_price'], 
                    $src_product['purchase_price'], 
                    $src_product['category_id'],
                    $src_product['unit_id'], 
                    $src_product['supplier_id'], 
                    $qty, 
                    $src_product['alert_level']
                ];

                if ($hasBarcode) {
                    $cols[] = "barcode";
                    $vals[] = $src_product['barcode'] ?? null;
                }

                $colStr = implode(", ", $cols);
                $placeholderStr = implode(", ", array_fill(0, count($cols), "?"));

                $stmt_create = $tenant_conn->prepare("INSERT INTO products ($colStr) VALUES ($placeholderStr)");
                $stmt_create->execute($vals);
            }

            // 4. Log Stock Movement (Optional but recommended)
            try {
                $stmt_log = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)");
                $stmt_log->execute([$product_id, -$qty, "Transfer to Branch #$to_branch"]);
            } catch(Exception $e) {}

            $tenant_conn->commit();
            $message = "Successfully transferred $qty units!";
        } catch (Exception $e) {
            $tenant_conn->rollBack();
            $error = $e->getMessage();
        }
    }
}

// Fetch active branches with own stock
$stmt_br = $tenant_conn->query("SELECT id, branch_name, is_main FROM branches WHERE has_own_stock = 1 ORDER BY is_main DESC, branch_name ASC");
$branches = $stmt_br->fetchAll(PDO::FETCH_ASSOC);

// Initial products for the first branch in list
$initial_branch_id = $branches[0]['id'] ?? 0;
$products = [];

if ($initial_branch_id) {
    $industry = strtolower($_SESSION['industry_type'] ?? 'retail');
    $p_sql = "SELECT id, name, sku FROM products WHERE branch_id = ?";
    if ($industry === 'restaurant') $p_sql .= " AND (is_raw = 1 OR has_stock = 1)";
    $p_sql .= " ORDER BY name ASC";

    $stmt_p = $tenant_conn->prepare($p_sql);
    $stmt_p->execute([$initial_branch_id]);
    $products = $stmt_p->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Stock Transfer | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors duration-300">
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h2 class="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Stock Transfer</h2>
                <p class="text-xs text-orange-500 font-bold uppercase tracking-widest">Move inventory between warehouses</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <div class="max-w-2xl mx-auto">
            <?php if ($message): ?>
                <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-2xl text-sm font-bold animate-in fade-in"><?= $message ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-2xl text-sm font-bold animate-in fade-in"><?= $error ?></div>
            <?php endif; ?>

            <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-2xl">
                <form method="POST" class="space-y-6">
                    <input type="hidden" name="action" value="transfer_stock">
                    
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Source Branch (From)</label>
                            <select name="from_branch" id="from_branch" required onchange="loadProducts(this.value)" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                                <?php foreach ($branches as $br): ?>
                                    <option value="<?= $br['id'] ?>"><?= htmlspecialchars($br['branch_name']) ?> <?= $br['is_main'] ? '(Main)' : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Destination Branch (To)</label>
                            <select name="to_branch" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                                <option value="">Select Destination</option>
                                <?php foreach ($branches as $br): ?>
                                    <option value="<?= $br['id'] ?>"><?= htmlspecialchars($br['branch_name']) ?> <?= $br['is_main'] ? '(Main)' : '' ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Select Product</label>
                        <select name="product_id" id="product_select" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                            <?php foreach ($products as $p): ?>
                                <option value="<?= $p['id'] ?>"><?= htmlspecialchars($p['name']) ?> (<?= $p['sku'] ?>)</option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Quantity to Transfer</label>
                        <div class="relative">
                            <input type="number" name="quantity" step="0.01" required placeholder="0.00" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-black text-2xl transition-all">
                            <div class="absolute right-5 top-1/2 -translate-y-1/2 text-slate-400 font-bold uppercase text-[10px]">Units</div>
                        </div>
                    </div>

                    <div class="pt-4">
                        <button type="submit" class="w-full py-5 bg-orange-600 hover:bg-orange-700 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 active:scale-95 transition-all flex items-center justify-center gap-3">
                            <i data-lucide="repeat" size="20"></i> Execute Transfer
                        </button>
                    </div>
                </form>
            </div>

            <!-- Warning Info -->
            <div class="mt-8 p-6 bg-amber-500/5 border border-dashed border-amber-500/20 rounded-3xl flex items-start gap-4">
                <i data-lucide="alert-triangle" class="text-amber-500 shrink-0" size="20"></i>
                <p class="text-[11px] text-slate-500 leading-relaxed font-medium">
                    <span class="text-amber-600 font-bold uppercase">Note:</span> If the product does not exist in the destination branch, a new record will be automatically created with the same SKU and pricing details. Stock will be deducted immediately from the source.
                </p>
            </div>
        </div>
    </main>

    <script>
        lucide.createIcons();

        const industry = "<?php echo strtolower($_SESSION['industry_type'] ?? 'retail'); ?>";

        async function loadProducts(branchId) {
            const select = document.getElementById('product_select');
            select.innerHTML = '<option>Loading products...</option>';
            select.disabled = true;

            try {
                // Only apply raw_only filter for Restaurant context
                const url = (industry === 'restaurant') ? `api.php?route=products&branch_id=${branchId}&raw_only=1` : `api.php?route=products&branch_id=${branchId}`;
                const response = await fetch(url);
                const data = await response.json();
                
                select.innerHTML = '';
                if (data.length === 0) {
                    select.innerHTML = '<option value="">No products in this branch</option>';
                } else {
                    data.forEach(p => {
                        const opt = document.createElement('option');
                        opt.value = p.id;
                        opt.textContent = `${p.name} (${p.sku || 'No SKU'}) - Stock: ${p.stock_level}`;
                        select.appendChild(opt);
                    });
                }
            } catch (err) {
                console.error(err);
                select.innerHTML = '<option value="">Error loading products</option>';
            } finally {
                select.disabled = false;
            }
        }

        // Note: For api.php to handle the branch_id param properly, 
        // ensure the case 'products' uses $_GET['branch_id'] if provided.
    </script>
</body>
</html>