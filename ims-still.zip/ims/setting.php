<?php
require_once 'config/db_switch.php';
require_once 'config/currency_helper.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Initialize Main PDO once at the top
$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
$main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

$can_upload_logo = has_module('business_logo');
$can_upload_shop_image = has_module('shop_image_upload');

$is_staff = (isset($_SESSION['role']) && $_SESSION['role'] !== 'admin');
$is_cashier = (isset($_SESSION['role']) && $_SESSION['role'] === 'cashier');

// Handle Profile Update
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_profile') {
    try {
        $new_name = $_POST['owner_name'];
        $new_email = $_POST['email'];
        $new_phone = $_POST['phone'];
        $new_address = $_POST['address'];
        $db_name = $_SESSION['db_name'];

        $stmt = $main_pdo->prepare("UPDATE tenants SET owner_name = ?, email = ?, phone = ?, address = ? WHERE db_name = ?");
        $stmt->execute([$new_name, $new_email, $new_phone, $new_address, $db_name]);

        // Update Session to reflect changes immediately
        $_SESSION['owner_name'] = $new_name;
        $_SESSION['email'] = $new_email;
        $_SESSION['phone'] = $new_phone;
        $_SESSION['address'] = $new_address;

        $message = "Profile updated successfully!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Handle Business Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_business') {
    try {
        require_once 'config/CloudinaryStorage.php';

        $new_biz_name = $_POST['business_name'];
        $db_name = $_SESSION['db_name'];

        $logo_url = null;
        $shop_url = null;

        // Handle Cloudinary Uploads (Only if module is enabled)
        if ($can_upload_logo && isset($_FILES['logo']) && $_FILES['logo']['error'] === 0) {
            // Use tenant_id for public_id to ensure uniqueness and easy tracking
            $logo_url = uploadToCloud($_FILES['logo']['tmp_name'], "biltax_tenants/logos/$tenant_data[id]", "logo_$tenant_data[id]");
        }
        if ($can_upload_shop_image && isset($_FILES['shop_image']) && $_FILES['shop_image']['error'] === 0) {
            // Use tenant_id for public_id
            $shop_url = uploadToCloud($_FILES['shop_image']['tmp_name'], "biltax_tenants/shop_images/$tenant_data[id]", "shop_image_$tenant_data[id]");
        }

        $sql = "UPDATE tenants SET business_name = ?";
        $params = [$new_biz_name];
        if ($logo_url) { $sql .= ", logo_url = ?"; $params[] = $logo_url; }
        if ($shop_url) { $sql .= ", shop_image_url = ?"; $params[] = $shop_url; }
        $sql .= " WHERE db_name = ?";
        $params[] = $db_name;

        $stmt = $main_pdo->prepare($sql);
        $stmt->execute($params);

        $_SESSION['business_name'] = $new_biz_name;
        $business_name = $new_biz_name;
        $message = "Business information updated successfully!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Handle Password Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_password') {
    try {
        $current_pass = $_POST['current_password'];
        $new_pass = $_POST['new_password'];
        $confirm_pass = $_POST['confirm_password'];

        if ($new_pass !== $confirm_pass) {
            throw new Exception("New passwords do not match.");
        }

        if (isset($_SESSION['staff_id'])) {
            // Update Staff Password (In Tenant specific database)
            $stmt = $tenant_conn->prepare("SELECT password FROM users WHERE id = ?");
            $stmt->execute([$_SESSION['staff_id']]);
            $hash = $stmt->fetchColumn();

            if (!$hash || !password_verify($current_pass, $hash)) {
                throw new Exception("Current password is incorrect.");
            }

            $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $stmt = $tenant_conn->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->execute([$new_hash, $_SESSION['staff_id']]);
        } else {
            // Update Business Owner Password (In Main database)
            $db_name = $_SESSION['db_name'];
            $stmt = $main_pdo->prepare("SELECT password FROM tenants WHERE db_name = ?");
            $stmt->execute([$db_name]);
            $hash = $stmt->fetchColumn();

            // Verify current password (support hashed and fallback plain for legacy)
            if (!password_verify($current_pass, $hash) && $current_pass !== $hash) {
                throw new Exception("Current password is incorrect.");
            }

            $new_hash = password_hash($new_pass, PASSWORD_DEFAULT);
            $stmt = $main_pdo->prepare("UPDATE tenants SET password = ? WHERE db_name = ?");
            $stmt->execute([$new_hash, $db_name]);
        }

        $message = "Password updated successfully!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Handle POS & Billing Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_pos_settings') {
    try {
        $currency_code = $_POST['currency'];
        $tax_rate = $_POST['tax_rate'];
        $max_discount = $_POST['max_discount'];
        $limit_type = $_POST['discount_limit_type'];
        $db_name = $_SESSION['db_name'];

        // Simple mapping for symbols
        $symbols = ['USD' => '$', 'PKR' => 'Rs', 'AED' => 'د.إ', 'SAR' => 'ر.س'];
        $currency_symbol = $symbols[$currency_code] ?? '$';

        $stmt = $main_pdo->prepare("UPDATE tenants SET currency_code = ?, currency_symbol = ?, tax_rate = ?, max_discount_limit = ?, discount_limit_type = ? WHERE db_name = ?");
        $stmt->execute([$currency_code, $currency_symbol, $tax_rate, $max_discount, $limit_type, $db_name]);

        $message = "POS & Billing settings updated successfully!";
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Handle Marketplace Listing Update - Moved ABOVE data fetch to fix UI sync
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_marketplace_status') {
    try {
        $status = $_POST['status'] === 'true' ? 1 : 0;
        $db_name = $_SESSION['db_name'];

        $stmt = $main_pdo->prepare("UPDATE tenants SET marketplace_listing_status = ? WHERE db_name = ?");
        $stmt->execute([$status, $db_name]);

        $message = "Marketplace listing status updated successfully!";
        // Update current variable immediately so fetch is not even needed for this
        $marketplace_listing_status = $status;
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Handle Marketplace Listing Visibility Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_marketplace_listing_visibility') {
    try {
        $status = $_POST['status'] === 'true' ? 1 : 0;
        $db_name = $_SESSION['db_name'];

        $stmt = $main_pdo->prepare("UPDATE tenants SET marketplace_listing_visibility = ? WHERE db_name = ?");
        $stmt->execute([$status, $db_name]);

        $message = "Marketplace listing visibility updated successfully!";
        $marketplace_listing_visibility = $status;
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage(); // Changed message
    }
}

// Handle Receipt Reprint Setting Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_receipt_reprint_setting') {
    try {
        $status = $_POST['status'] === 'true' ? 1 : 0;
        $db_name = $_SESSION['db_name'];

        $stmt = $main_pdo->prepare("UPDATE tenants SET allow_receipt_reprint = ? WHERE db_name = ?");
        $stmt->execute([$status, $db_name]);

        $message = "Receipt reprint setting updated successfully!";
        // Update current variable immediately
        $allow_receipt_reprint = $status;
    } catch (Exception $e) {
        $message = "Error: " . $e->getMessage();
    }
}

// Fetch latest data from main DB if session is old
try {
    $stmt = $main_pdo->prepare("SELECT * FROM tenants WHERE db_name = ?");
    $stmt->execute([$_SESSION['db_name']]);
    $tenant_data = $stmt->fetch(PDO::FETCH_ASSOC) ?: []; // Ensure $tenant_data is always an array
} catch (Exception $e) {
    $tenant_data = [];
}

$business_name = $tenant_data['business_name'] ?? $_SESSION['business_name'] ?? 'Biltax';
$owner_name = $tenant_data['owner_name'] ?? $_SESSION['owner_name'] ?? 'Admin';
$email = $tenant_data['email'] ?? $_SESSION['email'] ?? 'admin@biltax.com';
$phone = $tenant_data['phone'] ?? $_SESSION['phone'] ?? '';
$address = $tenant_data['address'] ?? $_SESSION['address'] ?? '';
$industry_type = $tenant_data['industry_type'] ?? $_SESSION['industry_type'] ?? 'Retail';
// Ensure we use the updated status if it was just changed in the POST block above
$marketplace_listing_status = isset($marketplace_listing_status) ? $marketplace_listing_status : ($tenant_data['marketplace_listing_status'] ?? 0);
$marketplace_listing_visibility = isset($marketplace_listing_visibility) ? $marketplace_listing_visibility : ($tenant_data['marketplace_listing_visibility'] ?? 0); // Renamed variable
$currency_code = $tenant_data['currency_code'] ?? 'USD';
$symbols = ['USD' => '$', 'PKR' => 'Rs', 'AED' => 'د.إ', 'SAR' => 'ر.س'];
$currency_symbol = $symbols[$currency_code] ?? '$';
$tax_rate = $tenant_data['tax_rate'] ?? 0.00; // Default tax rate
$max_discount_limit = $tenant_data['max_discount_limit'] ?? 999.00; // Default max discount limit to 0
$discount_limit_type = $tenant_data['discount_limit_type'] ?? 'disabled'; // Default to disabled
$allow_receipt_reprint = $tenant_data['allow_receipt_reprint'] ?? 0;
$current_storage_usage = $tenant_data['current_storage_usage'] ?? 0;
$storage_limit = $tenant_data['storage_limit'] ?? 1;

// Calculate converted price for display
$rates = getExchangeRates();
$current_rate = $rates[$currency_code] ?? 1;
 
// Fetch Package Details & Usage Stats for Subscription Tab
$stmt_pkg = $main_pdo->prepare("SELECT * FROM packages WHERE id = ?");
$stmt_pkg->execute([$tenant_data['package_id'] ?? 1]);
$package = $stmt_pkg->fetch(PDO::FETCH_ASSOC);

$current_active_plan_id = $tenant_data['package_id'] ?? null;

// Fetch detailed current subscription info for the info bar (similar to billing_plans_view.php)
$sub_details = null;
$days_left = 0; // Initialize days_left
if (isset($tenant_data['id']) && !empty($tenant_data['id'])) { // Check if tenant_data['id'] is set and not empty
    $stmt_sub = $main_pdo->prepare("SELECT s.*, p.package_name, p.price, p.yearly_price, p.primary_cycle, p.secondary_cycle
                                FROM subscriptions s
                                JOIN packages p ON s.plan_id = p.id
                                WHERE s.tenant_id = ?
                                ORDER BY s.id DESC LIMIT 1");
    $stmt_sub->execute([$tenant_data['id']]);
    $sub_details = $stmt_sub->fetch(PDO::FETCH_ASSOC);

    if ($sub_details && $sub_details['expiry_date']) {
        $today = new DateTime(date('Y-m-d'));
        $expiry = new DateTime($sub_details['expiry_date']);
        $interval = $today->diff($expiry);
        $days_left = (int)$interval->format('%r%a'); // format %r ensures we get negative if already expired
    }
}

// Fetch Billing Adjustments (Discounts or Extra Charges) from Main DB
$stmt_adj = $main_pdo->prepare("SELECT * FROM billing_adjustments WHERE tenant_id = ?");
$stmt_adj->execute([$tenant_data['id'] ?? 0]);
$adjustments = $stmt_adj->fetchAll(PDO::FETCH_ASSOC);

$adj_sum = 0;
foreach ($adjustments as $adj) {
    $adj_sum += ($adj['type'] === 'discount') ? -(float)$adj['amount'] : (float)$adj['amount'];
}

$u_total = 0;
try { $u_total = (int)$tenant_conn->query("SELECT COUNT(*) FROM users")->fetchColumn(); } catch(Exception $e) {}

$r_total = 0;
if (has_module('rider_tracking')) {
    try { $r_total = (int)$tenant_conn->query("SELECT COUNT(*) FROM riders")->fetchColumn(); } catch(Exception $e) {}
}
$current_staff_count = $u_total + $r_total;

$current_branch_count = 0;
try { $current_branch_count = (int)$tenant_conn->query("SELECT COUNT(*) FROM branches")->fetchColumn(); } catch(Exception $e) {}

$current_product_count = 0;
try { $current_product_count = (int)$tenant_conn->query("SELECT COUNT(*) FROM products")->fetchColumn(); } catch(Exception $e) {}

$expiry_date = $tenant_data['expiry_date'] ?? 'N/A';

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors duration-300">
    
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h2 class="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">System Settings</h2>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Manage your profile and business configurations</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <!-- Global Verification Alert Bar -->
        <?php include 'alert_bar.php'; ?>

        <?php if ($message): ?>
            <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl text-sm font-bold animate-in fade-in duration-300">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="max-w-4xl">
            <!-- Tabs Header -->
            <div class="flex gap-2 p-1 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl mb-8 overflow-x-auto">
                <?php if (!$is_staff): ?>
                <button onclick="switchTab('profile')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all bg-orange-600 text-white" data-tab="profile">Profile</button>
                <button onclick="switchTab('business')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="business">Business Info</button>
                <button onclick="switchTab('subscription')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="subscription">Subscription & Plan</button>
                <?php endif; ?>
                
                <button onclick="switchTab('security')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="security">Security</button>
                
                <?php if (!$is_staff): ?>
                <button onclick="switchTab('pos_config')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="pos_config">POS & Billing</button>
                <button onclick="switchTab('config')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="config">Settings</button>
                <button onclick="switchTab('modules')" class="tab-btn px-6 py-3 rounded-xl text-xs font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="modules">Modules & Features</button>
                <?php endif; ?>
            </div>

            <!-- Tab Contents -->
            <?php if (!$is_staff): ?>
            <div id="profile" class="tab-content animate-in fade-in duration-300">
                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <div class="flex items-center gap-4 mb-8">
                        <div class="w-20 h-20 bg-orange-600 rounded-3xl flex items-center justify-center text-white text-3xl font-black shadow-lg shadow-orange-600/20">
                            <?= strtoupper(substr($owner_name, 0, 1)) ?>
                        </div>
                        <div>
                            <h3 class="text-xl font-black dark:text-white uppercase tracking-tight">Personal Profile</h3>
                            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Update your contact details</p>
                        </div>
                    </div>
                    <form method="POST" class="space-y-4">
                        <input type="hidden" name="action" value="update_profile">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Owner Name</label>
                                <input type="text" name="owner_name" value="<?= htmlspecialchars($owner_name) ?>" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Email Address</label>
                                <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" readonly class="w-full px-5 py-4 bg-slate-100 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-800 rounded-2xl text-slate-400 font-bold cursor-not-allowed outline-none transition-all">
                            </div>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Phone Number</label>
                            <input type="text" name="phone" value="<?= htmlspecialchars($phone) ?>" placeholder="e.g. +92 300 1234567" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Home / Office Address</label>
                            <textarea name="address" rows="3" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all"><?= htmlspecialchars($address) ?></textarea>
                        </div>
                        <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all mt-4">Save Changes</button>
                    </form>
                </div>
            </div>

            <div id="business" class="tab-content hidden animate-in fade-in duration-300">
                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <h3 class="text-xl font-black mb-6 dark:text-white uppercase tracking-tight">Business Information</h3>
                    <form method="POST" class="space-y-4" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="update_business">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Business Name</label>
                                <input type="text" name="business_name" value="<?= htmlspecialchars($business_name) ?>" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Business ID (Unique)</label>
                                <input type="text" value="<?= htmlspecialchars($tenant_data['unique_id'] ?? 'N/A') ?>" readonly class="w-full px-5 py-4 bg-slate-100 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-800 rounded-2xl text-orange-500 font-mono font-bold cursor-not-allowed outline-none">
                            </div>
                        </div>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6 pt-6 border-t border-slate-100 dark:border-neutral-800">
                            <div>
                                <?php if ($can_upload_logo): ?>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Business Logo</label>
                                <?php if(!empty($tenant_data['logo_url'])): ?>
                                    <img src="<?= $tenant_data['logo_url'] ?>" class="w-20 h-20 object-contain mb-3 rounded-xl border border-slate-200 dark:border-neutral-800 p-2 bg-white">
                                <?php endif; ?>
                                <input type="file" name="logo" accept="image/*" class="text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-black file:bg-orange-600 file:text-white hover:file:bg-orange-700 cursor-pointer">
                                <?php else: ?>
                                <div class="p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800">
                                    <p class="text-[10px] font-black uppercase text-slate-400 italic"><i data-lucide="lock" class="inline-block mr-1" size="12"></i> Logo upload locked.</p>
                                </div>
                                <?php endif; ?>
                            </div>
                            <div>
                                <?php if ($can_upload_shop_image): ?>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Shop / Front Image</label>
                                <?php if(!empty($tenant_data['shop_image_url'])): ?>
                                    <img src="<?= $tenant_data['shop_image_url'] ?>" class="w-32 h-20 object-cover mb-3 rounded-xl border border-slate-200 dark:border-neutral-800">
                                <?php endif; ?>
                                <input type="file" name="shop_image" accept="image/*" class="text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-black file:bg-orange-600 file:text-white hover:file:bg-orange-700 cursor-pointer">
                                <?php else: ?>
                                <div class="p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800">
                                    <p class="text-[10px] font-black uppercase text-slate-400 italic"><i data-lucide="lock" class="inline-block mr-1" size="12"></i> Shop image upload locked.</p>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Industry Type</label>
                            <input type="text" value="<?= htmlspecialchars(ucfirst($industry_type)) ?>" readonly class="w-full px-5 py-4 bg-slate-100 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-800 rounded-2xl text-slate-400 font-bold cursor-not-allowed">
                        </div>
                        <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all mt-4">Save Business Info</button>
                    </form>
                </div>
            </div>

            <div id="subscription" class="tab-content hidden animate-in fade-in duration-300">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8 items-stretch">
                    <!-- Plan Info Card -->
                    <div class="bg-white dark:bg-neutral-950 p-10 rounded-[48px] border border-slate-200 dark:border-neutral-800 shadow-xl flex flex-col transition-colors">
                        <h3 class="text-xl font-black mb-6 dark:text-white uppercase tracking-tight">Current Plan</h3>
                        <?php
                        $is_expired = ($sub_details && $sub_details['status'] === 'expired');
                        $is_locked_by_storage = ($tenant_data['status'] === 'locked' && ($tenant_data['current_storage_usage'] ?? 0) >= ($tenant_data['storage_limit'] ?? 1));
                        $is_locked_overall = ($tenant_data['status'] === 'locked'); // General locked status
                        $card_bg_class = 'bg-orange-600 shadow-orange-600/20';
                        $badge_text = 'Active';
                        $badge_class = 'bg-white/20';
                        $expiry_text_class = 'dark:text-white';

                        if ($is_expired) {
                            $card_bg_class = 'bg-rose-600 shadow-rose-600/20';
                            $badge_text = 'Expired';
                            $badge_class = 'bg-white text-rose-600';
                            $expiry_text_class = 'text-rose-600';
                        } elseif ($is_locked_by_storage) {
                            $card_bg_class = 'bg-red-700 shadow-red-700/20'; // A distinct red for storage lock
                            $badge_text = 'Locked (Storage)';
                            $badge_class = 'bg-white text-red-700';
                            $expiry_text_class = 'text-red-700';
                        }
                        ?>
                        <div class="p-8 <?= $card_bg_class ?> rounded-[32px] text-white mb-8 shadow-lg flex-shrink-0 transition-colors">
                            <p class="text-[10px] font-black uppercase opacity-70 mb-1"><?= $is_expired ? 'Membership Expired' : ($is_locked_by_storage ? 'Account Locked' : 'Active Membership') ?></p>
                            <h4 class="text-2xl font-black"><?= htmlspecialchars($package['package_name'] ?? 'Standard Plan') ?></h4>
                            <div class="mt-4 flex justify-between items-end">
                                <p class="text-sm font-bold"><?= $currency_symbol ?><?= number_format(($package['price'] ?? 0) * $current_rate, 2) ?> / Mo</p>
                                <span class="px-3 py-1 <?= $badge_class ?> rounded-lg text-[9px] font-black uppercase"><?= $badge_text ?></span>
                            </div>
                        </div>
                        
                        <div class="space-y-5 mb-8">
                            <div class="flex justify-between items-center text-xs">
                                <span class="font-bold text-slate-400 uppercase tracking-widest">Expiry Date</span>
                                <span class="font-black <?= $expiry_text_class ?>"><?= ($sub_details && isset($sub_details['expiry_date'])) ? date('M d, Y', strtotime($sub_details['expiry_date'])) : 'N/A' ?></span>
                            </div>
                            <div class="flex justify-between items-center text-xs">
                                <span class="font-bold text-slate-400 uppercase tracking-widest">Billing Cycle</span>
                                <span class="font-black <?= $is_expired ? 'text-rose-600' : 'dark:text-white' ?>">
                                    <?php 
                                        $c_key = ($sub_details && isset($sub_details['billing_cycle']) && $sub_details['billing_cycle'] === 'secondary') ? ($sub_details['secondary_cycle'] ?? '1_year') : ($sub_details['primary_cycle'] ?? '1_month');
                                        echo ucwords(str_replace('_', ' ', $c_key));
                                    ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="space-y-4 mb-8 pt-4 border-t border-slate-100 dark:border-neutral-800">
                            <?php if (!empty($adjustments)): ?>
                                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Adjustments & Extra</p>
                                <?php foreach($adjustments as $adj): 
                                    $is_disc = ($adj['type'] === 'discount');
                                    $adj_disp = (float)$adj['amount'] * $current_rate;
                                ?>
                                <div class="flex justify-between items-start text-[11px]">
                                    <div class="flex flex-col">
                                        <span class="font-bold <?= $is_disc ? 'text-emerald-500' : 'text-rose-500' ?>"><?= $is_disc ? 'Discount' : 'Extra Charge' ?> (<?= $adj['is_recurring'] ? 'Recurring' : 'One-time' ?>)</span>
                                        <span class="text-[9px] text-slate-500 italic"><?= htmlspecialchars($adj['reason']) ?></span>
                                    </div>
                                    <span class="font-black <?= $is_disc ? 'text-emerald-500' : 'text-rose-500' ?>"><?= $is_disc ? '-' : '+' ?><?= $currency_symbol ?><?= number_format($adj_disp, 2) ?></span>
                                </div>
                                <?php endforeach; ?>
                                <div class="flex justify-between items-center pt-2 border-t border-slate-100 dark:border-neutral-800">
                                    <span class="text-xs font-black dark:text-white uppercase tracking-tighter">Total Payable</span>
                                    <span class="text-sm font-black text-orange-600"><?= $currency_symbol ?><?= number_format((($package['price'] ?? 0) * $current_rate) + ($adj_sum * $current_rate), 2) ?></span>
                                </div>
                            <?php else: ?>
                                <div class="flex justify-between items-center">
                                    <span class="text-xs font-black dark:text-white uppercase tracking-tighter">Plan Total</span>
                                    <span class="text-sm font-black text-orange-600"><?= $currency_symbol ?><?= number_format((($package['price'] ?? 0) + $adj_sum) * $current_rate, 2) ?></span>
                                </div>
                            <?php endif; ?>
                        </div>

                        <a href="billing_plans_view.php" class="w-full mt-auto py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black text-xs uppercase tracking-widest active:scale-95 transition-all text-center block">Upgrade Plan</a>
                        <?php
                            // Calculate total amount for renewal including adjustments
                            $renewal_base_price = ($sub_details && isset($sub_details['billing_cycle']) && $sub_details['billing_cycle'] === 'secondary') ? ((float)($sub_details['yearly_price'] ?? 0) ?? (float)($sub_details['price'] ?? 0)) : ((float)($sub_details['price'] ?? 0) ?? 0);
                            $renewal_amount_converted = ($renewal_base_price * $current_rate) + $adj_sum; // $adj_sum is already in local currency
                        ?>
                        <?php if ($sub_details && $days_left <= 1 && ($sub_details['status'] === 'active' || $sub_details['status'] === 'expired') && $renewal_amount_converted > 0): ?>
                            <button onclick="renewSubscription('<?= (int)$sub_details['plan_id'] ?>', '<?= (float)$renewal_amount_converted ?>', '<?= htmlspecialchars($sub_details['billing_cycle'] ?? '1_month') ?>', '<?= (int)$sub_details['plan_id'] ?>', '<?= htmlspecialchars($sub_details['expiry_date'] ?? 'null') ?>')" class="w-full mt-4 py-4 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all">Renew Now</button>
                        <?php endif; ?>
                    </div>

                    <!-- NEW Personnel & Branch Quota Card -->
                    <div class="bg-white dark:bg-neutral-950 p-10 rounded-[48px] border border-slate-200 dark:border-neutral-800 shadow-xl flex flex-col transition-colors">
                        <div class="flex justify-between items-start mb-8">
                            <div>
                                <h3 class="text-xl font-black dark:text-white uppercase tracking-tight">Personnel Quota</h3>
                                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Staff & Branch Limits</p>
                            </div>
                            <i data-lucide="users" class="text-orange-500"></i>
                        </div>
                        
                        <div class="space-y-8">
                            <!-- Staff Usage -->
                            <div class="<?= !has_module('staff') ? 'opacity-40 grayscale pointer-events-none' : '' ?>">
                                <div class="flex justify-between text-[11px] font-black uppercase text-slate-400 mb-3">
                                    <span>Staff Slots</span>
                                    <span class="text-orange-600"><?= $current_staff_count ?> / <?= $staff_limit ?></span>
                                </div>
                                <div class="w-full h-4 bg-slate-100 dark:bg-neutral-900 rounded-full overflow-hidden">
                                    <?php $staff_pct = ($staff_limit > 0) ? ($current_staff_count / $staff_limit) * 100 : 0; ?>
                                    <div class="h-full bg-orange-600 transition-all duration-1000" style="width: <?= min(100, $staff_pct) ?>%"></div>
                                </div>
                                <p class="text-[10px] text-slate-500 mt-3 font-bold uppercase tracking-tighter"><?= !has_module('staff') ? 'Module Disabled' : 'Dashboard Users & Riders' ?></p>
                            </div>

                            <!-- Branch Usage -->
                            <div class="<?= !has_module('manage_branches') ? 'opacity-40 grayscale pointer-events-none' : '' ?>">
                                <div class="flex justify-between text-[11px] font-black uppercase text-slate-400 mb-3">
                                    <span>Active Branches</span>
                                    <span class="text-blue-500"><?= $current_branch_count ?> / <?= $branch_limit ?></span>
                                </div>
                                <div class="w-full h-4 bg-slate-100 dark:bg-neutral-900 rounded-full overflow-hidden">
                                    <?php $branch_pct = ($branch_limit > 0) ? ($current_branch_count / $branch_limit) * 100 : 0; ?>
                                    <div class="h-full bg-blue-500 transition-all duration-1000" style="width: <?= min(100, $branch_pct) ?>%"></div>
                                </div>
                                <p class="text-[10px] text-slate-500 mt-3 font-bold uppercase tracking-tighter"><?= !has_module('manage_branches') ? 'Module Disabled' : 'Physical locations' ?></p>
                            </div>
                        </div>
                        <p class="mt-auto text-[9px] text-slate-400 italic border-t border-slate-100 dark:border-neutral-900 pt-6">Limits are defined by your central subscription tier.</p>
                    </div>

                    <!-- Storage & Catalog Card (Spans 2 columns for better layout) -->
                    <div class="md:col-span-2 bg-white dark:bg-neutral-950 p-10 rounded-[48px] border border-slate-200 dark:border-neutral-800 shadow-xl transition-colors">
                        <div class="flex justify-between items-start mb-8">
                            <div>
                                <h3 class="text-xl font-black dark:text-white uppercase tracking-tight">Storage & Catalog</h3>
                                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Inventory and System utilization</p>
                            </div>
                            <i data-lucide="database" class="text-emerald-500"></i>
                        </div>

                        <div class="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
                            <!-- Product Limits -->
                            <div>
                                <div class="flex justify-between text-[11px] font-black uppercase text-slate-400 mb-3">
                                    <span>Catalog Capacity</span>
                                    <span class="text-emerald-500"><?= $current_product_count ?> / <?= $package['max_products'] ?? 100 ?></span>
                                </div>
                                <div class="w-full h-4 bg-slate-100 dark:bg-neutral-900 rounded-full overflow-hidden">
                                    <?php $prod_limit = $package['max_products'] ?? 100; $prod_pct = ($prod_limit > 0) ? ($current_product_count / $prod_limit) * 100 : 0; ?>
                                    <div class="h-full bg-emerald-500 transition-all duration-1000" style="width: <?= min(100, $prod_pct) ?>%"></div>
                                </div>
                                <p class="text-[10px] text-slate-500 mt-3 font-bold uppercase tracking-tighter">Products & Services</p>
                            </div>

                            <!-- Storage Info -->
                            <div>
                                <div class="space-y-6">
                                    <!-- Total Storage Usage Bar -->
                                    <div class="pt-2">
                                        <div class="flex justify-between text-[11px] font-black uppercase text-slate-600 dark:text-slate-400 mb-3">
                                            <span>Total Storage Usage</span>
                                            <span class="text-purple-600 font-black"><?= number_format($current_storage_usage, 2) ?> MB / <?= $storage_limit ?> MB</span>
                                        </div>
                                        <?php $storage_pct = ($storage_limit > 0) ? ($current_storage_usage / $storage_limit) * 100 : 0; ?>
                                        <div class="w-full h-4 bg-slate-100 dark:bg-neutral-900 rounded-full overflow-hidden">
                                            <div class="h-full bg-purple-600 transition-all duration-1000 shadow-[0_0_15px_rgba(147,51,234,0.3)]" style="width: <?= min(100, $storage_pct) ?>%"></div>
                                        </div>
                                        <p class="text-[10px] text-slate-500 mt-3 font-bold uppercase tracking-tighter">System Health & Assets Monitor</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <div id="security" class="tab-content hidden animate-in fade-in duration-300">
                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <div class="flex items-center gap-4 mb-8">
                        <div class="w-20 h-20 bg-slate-100 dark:bg-neutral-900 rounded-3xl flex items-center justify-center text-slate-400">
                            <i data-lucide="shield-check" size="32"></i>
                        </div>
                        <div>
                            <h3 class="text-xl font-black dark:text-white uppercase tracking-tight">Security Settings</h3>
                            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Update your login credentials</p>
                        </div>
                    </div>
                    <form method="POST" class="space-y-4">
                        <input type="hidden" name="action" value="update_password">
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Current Password</label>
                            <input type="password" name="current_password" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">New Password</label>
                            <input type="password" name="new_password" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Confirm New Password</label>
                            <input type="password" name="confirm_password" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                        </div>
                        <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all mt-4">Update Password</button>
                    </form>
                </div>
            </div>

            <?php if (!$is_cashier): ?>
            <div id="pos_config" class="tab-content hidden animate-in fade-in duration-300">
                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <h3 class="text-xl font-black mb-6 dark:text-white uppercase tracking-tight">POS & Billing Configuration</h3>
                    <form method="POST" class="space-y-4">
                        <input type="hidden" name="action" value="update_pos_settings">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Default Currency</label>
                                <select name="currency" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                                    <option value="USD" <?= $currency_code === 'USD' ? 'selected' : '' ?>>USD ($)</option>
                                    <option value="PKR" <?= $currency_code === 'PKR' ? 'selected' : '' ?>>PKR (Rs)</option>
                                    <option value="AED" <?= $currency_code === 'AED' ? 'selected' : '' ?>>AED (د.إ)</option>
                                    <option value="SAR" <?= $currency_code === 'SAR' ? 'selected' : '' ?>>SAR (ر.س)</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Default Tax Rate (%)</label>
                                <input type="number" step="0.01" name="tax_rate" value="<?= htmlspecialchars($tax_rate) ?>" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Max Discount Limit Value</label>
                                <input type="number" step="0.01" name="max_discount" value="<?= htmlspecialchars($max_discount_limit) ?>" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Limit Basis</label>
                                <select name="discount_limit_type" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                                    <option value="disabled" <?= $discount_limit_type === 'disabled' ? 'selected' : '' ?>>Disabled (No Limit)</option>
                                    <option value="percentage" <?= $discount_limit_type === 'percentage' ? 'selected' : '' ?>>Percentage (%)</option>
                                    <option value="fixed" <?= $discount_limit_type === 'fixed' ? 'selected' : '' ?>>Fixed Amount (<?= $currency_symbol ?>)</option>
                                </select>
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Rounding Method</label>
                                <select name="rounding" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                                    <option value="none">No Rounding</option>
                                    <option value="nearest">Nearest Integer</option>
                                    <option value="up">Always Round Up</option>
                                    <option value="down">Always Round Down</option>
                                </select>
                            </div>
                            <?php if (has_module('receipt_reprint')): ?>
                            <div class="md:col-span-2 flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800">
                                <div>
                                    <p class="text-sm font-black dark:text-white">Allow Reprint Old Receipts</p>
                                    <p class="text-[10px] text-slate-500 uppercase font-bold">Enable option to reprint past sales receipts.</p>
                                </div>
                                <button type="button" id="receipt_reprint_toggle" onclick="toggleReceiptReprint()" class="w-12 h-6 bg-slate-200 rounded-full relative transition-all">
                                    <div class="absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-all"></div>
                                </button>
                            </div>
                            <?php else: ?>
                                <div class="md:col-span-2 p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800 opacity-60">
                                    <p class="text-[10px] font-black uppercase text-slate-400 italic"><i data-lucide="lock" class="inline-block mr-1" size="12"></i> Receipt Reprint module disabled.</p>
                                </div>
                            <?php endif; ?>
                        </div>
                        <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all mt-4">Save POS Settings</button>
                    </form>
                </div>
            </div>

            <div id="config" class="tab-content hidden animate-in fade-in duration-300">
                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <h3 class="text-xl font-black mb-6 dark:text-white uppercase tracking-tight">System Preferences</h3>
                    <div class="space-y-6">
                        <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl">
                            <div>
                                <p class="text-sm font-black dark:text-white">Dark Mode</p>
                                <p class="text-[10px] text-slate-500 uppercase font-bold">Toggle system appearance</p>
                            </div>
                            <button onclick="toggleTheme()" class="w-12 h-6 bg-slate-200 dark:bg-orange-600 rounded-full relative transition-all">
                                <div class="absolute top-1 left-1 dark:left-7 w-4 h-4 bg-white rounded-full transition-all"></div>
                            </button>
                        </div>
                        <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl opacity-60">
                            <div>
                                <p class="text-sm font-black dark:text-white">Email Notifications</p>
                                <p class="text-[10px] text-orange-500 uppercase font-black tracking-widest">Coming Soon</p>
                            </div>
                            <button disabled class="w-12 h-6 bg-slate-300 dark:bg-neutral-800 rounded-full relative cursor-not-allowed">
                                <div class="absolute top-1 left-1 w-4 h-4 bg-white rounded-full"></div>
                            </button>
                        </div>
                    </div>
                </div>

                <?php if (has_module('marketplace')): ?>
                <!-- Marketplace Card -->
                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <h3 class="text-xl font-black mb-6 dark:text-white uppercase tracking-tight">Marketplace / Partner Setting</h3>
                    <div class="space-y-6">
                        <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl">
                            <div>
                                <p class="text-sm font-black dark:text-white">Allow me to partner connect selling</p>
                                <p class="text-[10px] text-slate-500 uppercase font-bold">Enable B2B visibility for your inventory</p>
                            </div>
                            <button id="marketplace_listing_toggle" onclick="toggleMarketplaceListing()" class="w-12 h-6 bg-slate-200 rounded-full relative transition-all">
                                <div class="absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-all"></div>
                            </button>
                        </div>

                        <?php if (has_module('marketplace_listing_visibility')): // New module check ?>
                        <!-- Dependent Marketplace Listing Visibility -->
                        <div id="marketplace_listing_visibility_container" class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl transition-all">
                            <div>
                                <p class="text-sm font-black dark:text-white">List me on Marketplace</p>
                                <p class="text-[10px] text-slate-500 uppercase font-bold">Only available when partner connect is ON</p>
                            </div>
                            <button id="marketplace_listing_visibility_toggle" onclick="toggleMarketplaceListingVisibility()" class="w-12 h-6 bg-slate-200 rounded-full relative transition-all">
                                <div class="absolute top-1 left-1 w-4 h-4 bg-white rounded-full transition-all"></div>
                            </button>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
            <?php endif; ?>

            <!-- Modules & Features Tab -->
            <?php if (!$is_staff): ?>
            <div id="modules" class="tab-content hidden animate-in fade-in duration-300">
                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <h3 class="text-xl font-black mb-6 dark:text-white uppercase tracking-tight">Your Active Features</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php
                        // Fetch all modules from main DB
                        $all_modules_stmt = $main_pdo->query("SELECT id, module_name, module_key FROM modules WHERE status = 'active' ORDER BY module_name ASC");
                        $all_modules = $all_modules_stmt->fetchAll(PDO::FETCH_ASSOC);

                        // Fetch modules linked to packages
                        $package_modules_stmt = $main_pdo->query("SELECT pf.module_id, p.package_name, p.id as package_id FROM package_features pf JOIN packages p ON pf.package_id = p.id");
                        $package_modules = [];
                        foreach ($package_modules_stmt->fetchAll(PDO::FETCH_ASSOC) as $pm) {
                            $package_modules[$pm['module_id']] = ['name' => $pm['package_name'], 'id' => $pm['package_id']];
                        }

                        // Fetch all feature requests from dedicated table
                        $feature_requests_stmt = $main_pdo->prepare("SELECT module_key, status, admin_reason FROM feature_requests WHERE tenant_id = ?");
                        $feature_requests_stmt->execute([$t_conf['id']]);
                        $feature_requests = $feature_requests_stmt->fetchAll(PDO::FETCH_ASSOC);
                        
                        $feature_status_map = [];
                        foreach ($feature_requests as $fr) {
                            $feature_status_map[$fr['module_key']] = [
                                'status' => $fr['status'],
                                'reason' => $fr['admin_reason']
                            ];
                        }

                        $active_module_keys = $active_modules; // From db_switch.php
                        $tenant_package_id = $t_conf['package_id']; // From db_switch.php

                        $found_active_modules = false;
                        foreach ($all_modules as $module) {
                            $req_status = $feature_status_map[$module['module_key']]['status'] ?? '';
                            // Show if actually active OR if request is approved (waiting for manual admin setup)
                            if (in_array($module['module_key'], $active_module_keys) || $req_status === 'approved') {
                                $found_active_modules = true;
                                $is_active_in_system = in_array($module['module_key'], $active_module_keys);
                                ?>
                                <div class="p-4 <?= $is_active_in_system ? 'bg-emerald-500/10 border-emerald-500/20' : 'bg-blue-500/10 border-blue-500/20' ?> border rounded-2xl flex items-center gap-3">
                                    <i data-lucide="<?= $is_active_in_system ? 'check-circle' : 'check' ?>" class="<?= $is_active_in_system ? 'text-emerald-500' : 'text-blue-500' ?>" size="20"></i>
                                    <div>
                                        <p class="text-sm font-black dark:text-white"><?= htmlspecialchars($module['module_name']) ?></p>
                                        <p class="text-[10px] <?= $is_active_in_system ? 'text-emerald-600' : 'text-blue-600' ?> uppercase font-bold">
                                            <?= $is_active_in_system ? 'Active' : 'Approved / Ready' ?>
                                        </p>
                                    </div>
                                </div>
                                <?php
                            }
                        }
                        if (!$found_active_modules): ?>
                            <div class="col-span-full p-4 text-center text-slate-500 italic">No active modules found.</div>
                        <?php endif; ?>
                    </div>

                    <h3 class="text-xl font-black mt-10 mb-6 dark:text-white uppercase tracking-tight">Explore More Features</h3>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                        <?php
                        $found_explore_modules = false;
                        foreach ($all_modules as $module) {
                            $req_status = $feature_status_map[$module['module_key']]['status'] ?? '';
                            
                            // Don't show in "Explore" if it's already active or already approved
                            if (!in_array($module['module_key'], $active_module_keys) && $req_status !== 'approved') {
                                $found_explore_modules = true;
                                $module_status = 'available';
                                $button_text = 'Request Access';
                                $button_class = 'bg-indigo-600 hover:bg-indigo-700 shadow-indigo-600/20';
                                $action_type = 'request';
                                $action_disabled = false;

                                // Check if module is part of a package
                                $module_package = null;
                                foreach ($package_modules as $mod_id => $pkg_info) {
                                    if ($mod_id == $module['id']) {
                                        $module_package = $pkg_info;
                                        break;
                                    }
                                }

                                if ($module_package && $tenant_package_id < $module_package['id']) {
                                    $module_status = 'upgrade_required';
                                    $button_text = 'Upgrade to ' . htmlspecialchars($module_package['name']);
                                    $button_class = 'bg-orange-600 hover:bg-orange-700 shadow-orange-600/20';
                                    $action_type = 'upgrade';
                                } elseif (isset($feature_status_map[$module['module_key']])) {
                                    $req = $feature_status_map[$module['module_key']];
                                    if ($req['status'] === 'pending') {
                                        $module_status = 'pending_request';
                                        $button_text = 'Request Pending';
                                        $button_class = 'bg-slate-500 cursor-not-allowed';
                                        $action_disabled = true;
                                    } elseif ($req['status'] === 'rejected') {
                                        $module_status = 'rejected';
                                        $button_text = 'Re-request Access';
                                        $button_class = 'bg-rose-600 hover:bg-rose-700 shadow-rose-600/20';
                                        $rejection_reason = $req['reason'];
                                    }
                                }
                                ?>
                                <div class="p-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl flex flex-col gap-2">
                                    <div class="flex items-center justify-between gap-3">
                                    <div>
                                        <p class="text-sm font-black dark:text-white"><?= htmlspecialchars($module['module_name']) ?></p>
                                        <p class="text-[10px] text-slate-500 uppercase font-bold"><?= str_replace('_', ' ', $module_status) ?></p>
                                    </div>
                                    <button <?= $action_disabled ? 'disabled' : '' ?> onclick="handleFeatureAction('<?= $action_type ?>', '<?= htmlspecialchars($module['module_key']) ?>', '<?= htmlspecialchars($module['module_name']) ?>')" class="px-4 py-2 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg <?= $button_class ?> transition-all active:scale-95">
                                        <?= $button_text ?>
                                    </button>
                                    </div>
                                    <?php if (isset($rejection_reason) && !empty($rejection_reason) && $module_status === 'rejected'): ?>
                                        <p class="text-[9px] text-rose-500 italic font-bold">Reason: "<?= htmlspecialchars($rejection_reason) ?>"</p>
                                    <?php endif; ?>
                                </div>
                                <?php
                                unset($rejection_reason); // Reset for next loop
                            }
                        }
                        if (!$found_explore_modules): ?>
                            <div class="col-span-full p-4 text-center text-slate-500 italic">All available modules are active!</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </main>
    <script>
        lucide.createIcons();

        function switchTab(tabId) {
            // Save current tab in URL hash for persistence across reloads
            window.location.hash = tabId;

            // Hide all contents
            document.querySelectorAll('.tab-content').forEach(c => c.classList.add('hidden'));
            // Show selected content
            document.getElementById(tabId).classList.remove('hidden');

            // Update buttons
            document.querySelectorAll('.tab-btn').forEach(b => {
                b.classList.remove('bg-orange-600', 'text-white');
                b.classList.add('text-slate-400');
            });
            const activeBtn = document.querySelector(`[data-tab="${tabId}"]`);
            if (activeBtn) {
                activeBtn.classList.add('bg-orange-600', 'text-white');
                activeBtn.classList.remove('text-slate-400');
            }
        }

        async function handleFeatureAction(type, key, name) {
            if (type === 'upgrade') {
                switchTab('subscription');
                return;
            }

            if (type === 'request') {
                if (!confirm(`Do you want to request access to the "${name}" module? Our team will review your request.`)) return;
                
                try {
                    const formData = new FormData();
                    formData.append('module_key', key);
                    formData.append('module_name', name);

                    const res = await fetch('api.php?route=feature_request', {
                        method: 'POST',
                        body: formData
                    });
                    const result = await res.json();
                    if (result.success) {
                        alert("Request submitted! We will notify you once it is approved.");
                        location.reload();
                    } else {
                        alert(result.message || "Request failed.");
                    }
                } catch (e) {
                    alert("System error occurred.");
                }
            }
        }

        let isMarketplaceListed = <?= json_encode((bool)$marketplace_listing_status) ?>;
        let isMarketplaceListingVisibilityEnabled = <?= json_encode((bool)$marketplace_listing_visibility) ?>; // Renamed variable

        function updateMarketplaceToggleUI() {
            const toggleBtn = document.getElementById('marketplace_listing_toggle');
            if (!toggleBtn) return; // Ensure the button exists
            const toggleCircle = toggleBtn.querySelector('div');

            if (isMarketplaceListed) {
                toggleBtn.classList.add('bg-orange-600');
                toggleBtn.classList.remove('bg-slate-200');
                toggleCircle.classList.add('left-7');
                toggleCircle.classList.remove('left-1');
            } else {
                toggleBtn.classList.remove('bg-orange-600');
                toggleBtn.classList.add('bg-slate-200');
                toggleCircle.classList.remove('left-7');
                toggleCircle.classList.add('left-1');
            }

            // Handle Dependent Marketplace Listing Visibility Toggle
            const visibilityContainer = document.getElementById('marketplace_listing_visibility_container'); // Renamed ID
            const visibilityBtn = document.getElementById('marketplace_listing_visibility_toggle'); // Renamed ID
            if (!visibilityBtn) return; // Check if the element exists (module might be disabled)
            const visibilityCircle = visibilityBtn.querySelector('div');

            if (isMarketplaceListed) {
                visibilityContainer.classList.remove('opacity-40', 'pointer-events-none');
                if (isMarketplaceListingVisibilityEnabled) { // Renamed variable
                    visibilityBtn.classList.add('bg-blue-600');
                    visibilityBtn.classList.remove('bg-slate-200');
                    visibilityCircle.classList.add('left-7');
                    visibilityCircle.classList.remove('left-1');
                } else {
                    visibilityBtn.classList.remove('bg-blue-600');
                    visibilityBtn.classList.add('bg-slate-200');
                    visibilityCircle.classList.remove('left-7');
                    visibilityCircle.classList.add('left-1');
                }
            } else {
                visibilityContainer.classList.add('opacity-40', 'pointer-events-none');
            }
        }

        function toggleMarketplaceListing() {
            const form = document.createElement('form');
            form.method = 'POST';
            // Preserve current tab hash during form submission
            form.action = 'setting.php' + window.location.hash;

            const actionInput = document.createElement('input'); actionInput.type = 'hidden'; actionInput.name = 'action'; actionInput.value = 'update_marketplace_status'; form.appendChild(actionInput);
            const statusInput = document.createElement('input'); statusInput.type = 'hidden'; statusInput.name = 'status'; statusInput.value = !isMarketplaceListed; form.appendChild(statusInput);

            document.body.appendChild(form);
            form.submit();
        }

        function toggleMarketplaceListingVisibility() { // Renamed function
            if (!isMarketplaceListed) return;
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'setting.php' + window.location.hash;

            const actionInput = document.createElement('input'); actionInput.type = 'hidden'; actionInput.name = 'action'; actionInput.value = 'update_marketplace_listing_visibility'; form.appendChild(actionInput); // Renamed action
            const statusInput = document.createElement('input'); statusInput.type = 'hidden'; statusInput.name = 'status'; statusInput.value = !isMarketplaceListingVisibilityEnabled; form.appendChild(statusInput); // Renamed variable
            
            document.body.appendChild(form);
            form.submit();
        }

        let allowReceiptReprint = <?= json_encode((bool)$allow_receipt_reprint) ?>;

        function updateReceiptReprintToggleUI() {
            const toggleBtn = document.getElementById('receipt_reprint_toggle');
            if (!toggleBtn) return;
            const toggleCircle = toggleBtn.querySelector('div');

            if (allowReceiptReprint) {
                toggleBtn.classList.add('bg-orange-600');
                toggleBtn.classList.remove('bg-slate-200');
                toggleCircle.classList.add('left-7');
                toggleCircle.classList.remove('left-1');
            } else {
                toggleBtn.classList.remove('bg-orange-600');
                toggleBtn.classList.add('bg-slate-200');
                toggleCircle.classList.remove('left-7');
                toggleCircle.classList.add('left-1');
            }
        }

        function toggleReceiptReprint() {
            const form = document.createElement('form');
            form.method = 'POST';
            form.action = 'setting.php' + window.location.hash;
            form.innerHTML = `<input type="hidden" name="action" value="update_receipt_reprint_setting"><input type="hidden" name="status" value="${!allowReceiptReprint}">`;
            document.body.appendChild(form);
            form.submit();
        }

        document.addEventListener('DOMContentLoaded', () => {
            updateMarketplaceToggleUI();
            
            const isStaff = <?= json_encode($is_staff) ?>;
            if (isStaff) {
                switchTab('security');
            } else {
                const hash = window.location.hash.replace('#', '');
                if (hash && document.getElementById(hash)) {
                    switchTab(hash);
                }
            }
            updateReceiptReprintToggleUI();
        });

        function renewSubscription(planId, amount, cycle, currentPlanId, currentExpiryDate) {
            window.location.href = `pay_now.php?plan_id=${planId}&amount=${amount}&cycle=${cycle}&current_plan_id=${currentPlanId}&current_expiry_date=${currentExpiryDate}`;
        }
    </script>
</body>
</html>