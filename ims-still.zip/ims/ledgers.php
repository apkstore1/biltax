<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

// --- Self-Healing: Ensure ledgers table exists ---
try {
    $tenant_conn->exec("CREATE TABLE IF NOT EXISTS ledgers (
        id INT PRIMARY KEY AUTO_INCREMENT,
        branch_id INT,
        party_name VARCHAR(255) NOT NULL,
        party_type ENUM('customer', 'supplier') NOT NULL,
        description TEXT,
        debit DECIMAL(15,2) DEFAULT 0,
        credit DECIMAL(15,2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (party_name),
        INDEX (branch_id)
    )");
} catch (Exception $e) { /* Silent fail if table exists */ }

// --- Branch Resolution ---
$active_branch = $_SESSION['active_branch_id'] ?? 'all';
$is_all = ($active_branch === 'all');

// --- Handle Manual Entry Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_entry') {
    try {
        $party_name = $_POST['party_name'];
        $party_type = $_POST['party_type']; // customer or supplier
        $description = $_POST['description'];
        $amount = (float)$_POST['amount'];
        $entry_type = $_POST['entry_type']; // debit or credit

        $debit = ($entry_type === 'debit') ? $amount : 0;
        $credit = ($entry_type === 'credit') ? $amount : 0;

        // Resolve Target Branch: If 'All' is selected, default to Main Account
        if ($is_all) {
            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $target_branch = $stmt_main->fetchColumn();
        } else {
            $target_branch = $active_branch;
        }

        $stmt = $tenant_conn->prepare("INSERT INTO ledgers (branch_id, party_name, party_type, description, debit, credit) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$target_branch, $party_name, $party_type, $description, $debit, $credit]);
        
        header("Location: ledgers.php?success=Entry added");
        exit;
    } catch (Exception $e) { $error = $e->getMessage(); }
}

// Helper for branch filtering
$branch_cond = $is_all ? "" : " WHERE branch_id = ?";
$branch_params = $is_all ? [] : [$active_branch];

// --- Fetch Summary Stats ---
$stats_stmt = $tenant_conn->prepare("
    SELECT 
        SUM(CASE WHEN party_type = 'supplier' THEN (credit - debit) ELSE 0 END) as total_payable,
        SUM(CASE WHEN party_type = 'customer' THEN (debit - credit) ELSE 0 END) as total_receivable
    FROM ledgers
    $branch_cond
");
$stats_stmt->execute($branch_params);
$stats = $stats_stmt->fetch(PDO::FETCH_ASSOC) ?: ['total_payable' => 0, 'total_receivable' => 0];

// --- Fetch Party List ---
$query = "SELECT party_name, party_type, SUM(debit) as total_debit, SUM(credit) as total_credit FROM ledgers $branch_cond GROUP BY party_name, party_type ORDER BY party_name ASC";
$parties_stmt = $tenant_conn->prepare($query);
$parties_stmt->execute($branch_params);
$parties = $parties_stmt->fetchAll(PDO::FETCH_ASSOC);

// --- Fetch Unpaid B2B Orders if Module Enabled ---
$unpaid_b2b = ['incoming' => [], 'outgoing' => []];
$current_tab = $_GET['tab'] ?? 'manual';

if (has_module('partner_network')) {
    $my_id = $_SESSION['tenant_id'];
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    
    // Incoming Unpaid (Receivables - Maal becha hai paisay lenay hain)
    $in_sql = "SELECT o.*, t.business_name as party FROM b2b_orders o JOIN tenants t ON o.sender_tenant_id = t.id WHERE o.receiver_tenant_id = ? AND o.payment_status = 'Unpaid'";
    $in_params = [$my_id];
    if (!$is_all) { $in_sql .= " AND (o.receiver_branch_id = ? OR (o.receiver_branch_id IS NULL AND o.status = 'pending'))"; $in_params[] = $active_branch; }
    $stmt_in = $main_pdo->prepare($in_sql);
    $stmt_in->execute($in_params);
    $unpaid_b2b['incoming'] = $stmt_in->fetchAll(PDO::FETCH_ASSOC);

    // Outgoing Unpaid (Payables - Maal khareeda hai paisay denay hain)
    $out_sql = "SELECT o.*, t.business_name as party FROM b2b_orders o JOIN tenants t ON o.receiver_tenant_id = t.id WHERE o.sender_tenant_id = ? AND o.payment_status = 'Unpaid'";
    $out_params = [$my_id];
    if (!$is_all) { $out_sql .= " AND o.sender_branch_id = ?"; $out_params[] = $active_branch; }
    $stmt_out = $main_pdo->prepare($out_sql);
    $stmt_out->execute($out_params);
    $unpaid_b2b['outgoing'] = $stmt_out->fetchAll(PDO::FETCH_ASSOC);
}

// --- Fetch Details if Party Selected ---
$selected_party = $_GET['view'] ?? null;
$history = [];
if ($selected_party) {
    $hist_sql = "SELECT * FROM ledgers WHERE party_name = ?";
    $hist_params = [$selected_party];
    if (!$is_all) { $hist_sql .= " AND branch_id = ?"; $hist_params[] = $active_branch; }
    
    $stmt = $tenant_conn->prepare($hist_sql . " ORDER BY created_at ASC");
    $stmt->execute($hist_params);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Party Ledger | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen">
    <div class="flex">
        <?php include 'sidebar.php'; ?>
        
        <main class="flex-1 p-8">
            <header class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Party Ledger</h1>
                    <p class="text-xs text-slate-500 uppercase tracking-widest font-bold mt-1">Manage Receivables & Payables</p>
                </div>
                <div class="flex items-center gap-3">
                    <?php include 'topbar.php'; ?>
                    <button onclick="document.getElementById('entryModal').classList.remove('hidden')" class="px-6 py-3 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 hover:scale-105 transition-all">
                        <i data-lucide="plus-circle" class="inline mr-2" size="16"></i> New Entry
                    </button>
                </div>
            </header>

            <!-- Tabs Navigation -->
            <div class="flex gap-4 mb-6 border-b border-slate-200 dark:border-neutral-800">
                <a href="?tab=manual" class="px-6 py-3 text-[10px] font-black uppercase tracking-widest transition-all <?= $current_tab === 'manual' ? 'text-orange-600 border-b-2 border-orange-600' : 'text-slate-400 hover:text-slate-600' ?>">
                    Manual Ledger
                </a>
                <?php if (has_module('partner_network')): ?>
                <a href="?tab=b2b" class="px-6 py-3 text-[10px] font-black uppercase tracking-widest transition-all <?= $current_tab === 'b2b' ? 'text-orange-600 border-b-2 border-orange-600' : 'text-slate-400 hover:text-slate-600' ?>">
                    B2B Unpaid Orders
                </a>
                <?php endif; ?>
            </div>

            <!-- Stats Row -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
                <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-1 tracking-widest">Total Receivable (Customers)</p>
                    <h3 class="text-3xl font-black text-emerald-500"><?= $currency_symbol . number_format($stats['total_receivable'] ?? 0, 2) ?></h3>
                </div>
                <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-1 tracking-widest">Total Payable (Suppliers)</p>
                    <h3 class="text-3xl font-black text-rose-500"><?= $currency_symbol . number_format($stats['total_payable'] ?? 0, 2) ?></h3>
                </div>
            </div>

            <?php if ($current_tab === 'manual'): ?>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Party List -->
                <div class="lg:col-span-1 bg-white dark:bg-neutral-900 rounded-3xl border border-slate-200 dark:border-neutral-800 overflow-hidden shadow-xl">
                    <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                        <h2 class="font-black dark:text-white uppercase text-sm">Parties</h2>
                    </div>
                    <div class="divide-y divide-slate-100 dark:divide-neutral-800 max-h-[600px] overflow-y-auto">
                        <?php foreach($parties as $p): 
                            $bal = ($p['party_type'] === 'supplier') ? ($p['total_credit'] - $p['total_debit']) : ($p['total_debit'] - $p['total_credit']);
                            $is_active = ($selected_party === $p['party_name']);
                        ?>
                        <a href="?view=<?= urlencode($p['party_name']) ?>" class="block p-4 hover:bg-slate-50 dark:hover:bg-neutral-800 transition-all <?= $is_active ? 'bg-orange-500/5 border-l-4 border-orange-500' : '' ?>">
                            <div class="flex justify-between items-start">
                                <div>
                                    <p class="font-bold text-sm dark:text-white"><?= htmlspecialchars($p['party_name']) ?></p>
                                    <p class="text-[10px] uppercase font-black <?= $p['party_type'] === 'supplier' ? 'text-rose-500' : 'text-emerald-500' ?>"><?= $p['party_type'] ?></p>
                                </div>
                                <div class="text-right">
                                    <p class="font-black text-sm <?= $bal > 0 ? 'text-orange-500' : 'text-slate-400' ?>"><?= $currency_symbol . number_format(abs($bal), 2) ?></p>
                                    <p class="text-[9px] text-slate-400 uppercase font-bold"><?= $bal >= 0 ? ($p['party_type'] === 'supplier' ? 'Payable' : 'Receivable') : 'Clear' ?></p>
                                </div>
                            </div>
                        </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Details View -->
                <div class="lg:col-span-2">
                    <?php if ($selected_party): ?>
                        <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
                            <div class="p-6 border-b border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                                <h2 class="font-black dark:text-white uppercase tracking-tight"><?= htmlspecialchars($selected_party) ?> - History</h2>
                                <button onclick="window.print()" class="p-2 text-slate-400 hover:text-orange-500"><i data-lucide="printer" size="18"></i></button>
                            </div>
                            <table class="w-full text-left">
                                <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                    <tr>
                                        <th class="px-6 py-4">Date</th>
                                        <th class="px-6 py-4">Description</th>
                                        <th class="px-6 py-4 text-right">Debit</th>
                                        <th class="px-6 py-4 text-right">Credit</th>
                                        <th class="px-6 py-4 text-right">Balance</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                                    <?php 
                                    $running_bal = 0;
                                    foreach($history as $h): 
                                        $running_bal += ($h['debit'] - $h['credit']);
                                    ?>
                                    <tr class="text-sm dark:text-white">
                                        <td class="px-6 py-4 text-slate-500 text-xs"><?= date('d M, Y', strtotime($h['created_at'])) ?></td>
                                        <td class="px-6 py-4 font-medium"><?= htmlspecialchars($h['description']) ?></td>
                                        <td class="px-6 py-4 text-right font-mono text-emerald-500"><?= $h['debit'] > 0 ? number_format($h['debit'], 2) : '-' ?></td>
                                        <td class="px-6 py-4 text-right font-mono text-rose-500"><?= $h['credit'] > 0 ? number_format($h['credit'], 2) : '-' ?></td>
                                        <td class="px-6 py-4 text-right font-black"><?= number_format(abs($running_bal), 2) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="h-full flex flex-col items-center justify-center text-slate-400 bg-white dark:bg-neutral-900 rounded-3xl border border-dashed border-slate-200 dark:border-neutral-800 p-20">
                            <i data-lucide="book-open" size="48" class="mb-4 opacity-20"></i>
                            <p class="font-bold uppercase tracking-widest text-xs">Select a party to view ledger details</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php else: ?>
            <!-- B2B Unpaid Orders View -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                <!-- Receivables Section -->
                <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-slate-200 dark:border-neutral-800 overflow-hidden shadow-xl">
                    <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                        <h2 class="font-black text-emerald-500 uppercase text-xs tracking-widest">B2B Receivables (Incoming)</h2>
                    </div>
                    <div class="p-4 space-y-3">
                        <?php if(empty($unpaid_b2b['incoming'])): ?>
                            <p class="text-center p-8 text-slate-400 text-xs italic">No unpaid incoming orders.</p>
                        <?php endif; foreach($unpaid_b2b['incoming'] as $o): ?>
                        <div class="p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 flex justify-between items-center">
                            <div>
                                <p class="font-bold text-sm dark:text-white"><?= htmlspecialchars($o['party']) ?></p>
                                <p class="text-[10px] text-slate-400 font-mono">Order #B2B-<?= $o['id'] ?></p>
                            </div>
                            <div class="text-right">
                                <p class="font-black text-emerald-500"><?= $currency_symbol . number_format($o['total_amount'], 2) ?></p>
                                <a href="view_order_details.php?id=<?= $o['id'] ?>&type=b2b" class="text-[9px] font-black uppercase text-orange-600 hover:underline">View Details</a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Payables Section -->
                <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-slate-200 dark:border-neutral-800 overflow-hidden shadow-xl">
                    <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                        <h2 class="font-black text-rose-500 uppercase text-xs tracking-widest">B2B Payables (Outgoing)</h2>
                    </div>
                    <div class="p-4 space-y-3">
                        <?php if(empty($unpaid_b2b['outgoing'])): ?>
                            <p class="text-center p-8 text-slate-400 text-xs italic">No unpaid outgoing orders.</p>
                        <?php endif; foreach($unpaid_b2b['outgoing'] as $o): ?>
                        <div class="p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 flex justify-between items-center">
                            <div>
                                <p class="font-bold text-sm dark:text-white"><?= htmlspecialchars($o['party']) ?></p>
                                <p class="text-[10px] text-slate-400 font-mono">Order #B2B-<?= $o['id'] ?></p>
                            </div>
                            <div class="text-right">
                                <p class="font-black text-rose-500"><?= $currency_symbol . number_format($o['total_amount'], 2) ?></p>
                                <div class="flex gap-2 justify-end">
                                    <?php if($o['status'] === 'received'): ?>
                                        <a href="b2b_price_review.php?order_id=<?= $o['id'] ?>" class="text-[9px] font-black uppercase text-emerald-600 hover:underline">Finalize</a>
                                    <?php endif; ?>
                                    <a href="view_order_details.php?id=<?= $o['id'] ?>&type=b2b" class="text-[9px] font-black uppercase text-orange-600 hover:underline">Details</a>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>

    <!-- Add Entry Modal -->
    <div id="entryModal" class="fixed inset-0 bg-black/80 hidden flex items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('entryModal').classList.add('hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-6">New Ledger Entry</h2>
            
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add_entry">
                
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Party Name</label>
                    <input type="text" name="party_name" required list="partySuggestions" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                    <datalist id="partySuggestions">
                        <?php foreach($parties as $p): ?><option value="<?= htmlspecialchars($p['party_name']) ?>"><?php endforeach; ?>
                    </datalist>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Party Type</label>
                        <select name="party_type" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                            <option value="customer">Customer (Receivable)</option>
                            <option value="supplier">Supplier (Payable)</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Entry Type</label>
                        <select name="entry_type" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                            <option value="debit">Debit (Sale / Payment to Supplier)</option>
                            <option value="credit">Credit (Purchase / Receipt from Customer)</option>
                        </select>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Amount (<?= $currency_symbol ?>)</label>
                        <input type="number" step="0.01" name="amount" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Description</label>
                        <input type="text" name="description" placeholder="e.g. Cash Payment" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                    </div>
                </div>

                <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:bg-orange-700 transition-all mt-4">Save Entry</button>
            </form>
        </div>
    </div>

    <script>lucide.createIcons();</script>
</body>
</html>