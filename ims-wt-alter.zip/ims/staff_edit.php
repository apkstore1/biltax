<?php
require_once 'config/db_switch.php';

// Check if user is logged in
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

$id = $_GET['id'] ?? null;
$staff = null;
$error_msg = $success_msg = '';

// Dynamic Roles based on Industry Type
$industry_type = $_SESSION['industry_type'] ?? 'retail';
$roles_config = [
    'service' => [
        'technician' => 'Technician / Service Man',
        'manager' => 'Service Manager',
        'cashier' => 'Cashier',
        'admin' => 'Administrator'
    ],
    'restaurant' => ['chef' => 'Chef', 'waiter' => 'Waiter', 'cashier' => 'Cashier', 'manager' => 'Manager', 'admin' => 'Admin'],
    'wholesale' => ['sales_agent' => 'Sales Agent', 'warehouse' => 'Warehouse Manager', 'cashier' => 'Cashier', 'admin' => 'Admin'],
    'retail' => ['salesman' => 'Salesman', 'cashier' => 'Cashier', 'manager' => 'Manager', 'admin' => 'Admin']
];
$available_roles = $roles_config[$industry_type] ?? $roles_config['retail'];

if ($id) {
    $stmt = $tenant_conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$id]);
    $staff = $stmt->fetch(PDO::FETCH_ASSOC);
}

if (!$staff) {
    header("Location: staff_list.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_staff') {
    $name = $_POST['name'];
    $role = $_POST['role'];
    $password = $_POST['password'];

    try {
        if (!empty($password)) {
            $stmt = $tenant_conn->prepare("UPDATE users SET name = ?, role = ?, password = ? WHERE id = ?");
            $stmt->execute([$name, $role, $password, $id]);
        } else {
            $stmt = $tenant_conn->prepare("UPDATE users SET name = ?, role = ? WHERE id = ?");
            $stmt->execute([$name, $role, $id]);
        }
        $success_msg = "Staff member updated successfully.";
        // Update local object for display
        $staff['name'] = $name;
        $staff['role'] = $role;
    } catch (PDOException $e) {
        $error_msg = "Error updating staff: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Staff Member</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 font-sans text-slate-900 dark:text-neutral-200 transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 overflow-y-auto">
        <div class="max-w-2xl mx-auto">
            <header class="flex justify-between items-center mb-10">
                <div>
                    <h2 class="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Edit Staff</h2>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Update information for <?= htmlspecialchars($staff['name']) ?></p>
                </div>
                <div class="flex items-center gap-4">
                    <?php include 'topbar.php'; ?>
                    <a href="staff_list.php" class="text-xs font-black uppercase text-slate-400 hover:text-orange-500 flex items-center gap-1 transition-colors">
                        <i data-lucide="arrow-left" size="14"></i> Back to List
                    </a>
                </div>
            </header>

            <?php if ($error_msg): ?>
                <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-2xl text-sm font-bold flex items-center gap-2">
                    <i data-lucide="alert-circle" size="18"></i> <?php echo $error_msg; ?>
                </div>
            <?php endif; ?>

            <?php if ($success_msg): ?>
                <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-2xl text-sm font-bold flex items-center gap-2">
                    <i data-lucide="check-circle" size="18"></i> <?php echo $success_msg; ?>
                </div>
            <?php endif; ?>

            <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                <form method="POST" class="space-y-6">
                    <input type="hidden" name="action" value="update_staff">
                    
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Full Name</label>
                        <input type="text" name="name" value="<?= htmlspecialchars($staff['name']) ?>" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>

                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Access Role</label>
                        <select name="role" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                            <?php foreach ($available_roles as $value => $label): ?>
                                <option value="<?= $value ?>" <?= strtolower($staff['role']) === strtolower($value) ? 'selected' : '' ?>><?= $label ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Login Password</label>
                        <input type="password" name="password" placeholder="Leave empty to keep current password" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                        <p class="text-[9px] text-slate-400 mt-2 italic">Only fill this if you want to change the staff member's password.</p>
                    </div>

                    <button type="submit" class="w-full py-5 bg-orange-600 text-white rounded-3xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-[0.98] transition-all mt-4">
                        Update Member Details
                    </button>
                </form>
            </div>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>