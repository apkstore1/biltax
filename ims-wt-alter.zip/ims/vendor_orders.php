<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
$my_id = $_SESSION['tenant_id'];

$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';

$active_branch = $_SESSION['active_branch_id'] ?? null;
$is_all = ($active_branch === 'all');
$stock_branch = $is_all ? null : get_active_stock_branch_id($active_branch);

// 1. Fetch Incoming B2B Orders (Orders placed by Partners to ME)
$orders = [];
$b2b_sql = "SELECT o.id, o.total_amount, o.created_at, o.status, o.payment_status, t.business_name as customer_name, 'b2b' as type 
            FROM b2b_orders o 
            JOIN tenants t ON o.sender_tenant_id = t.id 
            WHERE o.receiver_tenant_id = ?";

$b2b_params = [$my_id];

if (!$is_all) {
    $b2b_sql .= " AND o.receiver_branch_id = ?";
    $b2b_params[] = $stock_branch;
}

if ($filter === 'pending') $b2b_sql .= " AND o.status IN ('pending', 'processing', 'shipped')";
elseif ($filter === 'completed') $b2b_sql .= " AND o.status IN ('received', 'finalized')";
elseif ($filter === 'disputed') $b2b_sql .= " AND o.status = 'disputed'";

if ($search) {
    $b2b_sql .= " AND (t.business_name LIKE ? OR o.id LIKE ?)";
    $b2b_params[] = "%$search%";
    $b2b_params[] = "%$search%";
}

$b2b_sql .= " ORDER BY o.created_at DESC";
$stmt = $main_pdo->prepare($b2b_sql);
$stmt->execute($b2b_params);
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch active riders for assignment
$riders = [];
if (has_module('rider_tracking')) {
    try { $riders = $tenant_conn->query("SELECT id, name FROM riders WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC); } catch(Exception $e) {}
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Vendor Order History | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 min-h-screen transition-colors duration-300 flex">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Partner Orders Received</h1>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Detailed log of all vendor transactions</p>
            </div>
        </header>

        <!-- Filter & Search Section -->
        <form method="GET" class="flex flex-col lg:flex-row items-start lg:items-center gap-4 mb-8">
            <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
            <div class="flex gap-2 bg-white dark:bg-neutral-900 p-1.5 rounded-2xl border border-slate-200 dark:border-neutral-800 w-fit">
                <?php 
                $tabs = ['all' => 'All Orders', 'pending' => 'Outgoing (Pending)', 'completed' => 'Completed', 'disputed' => 'Disputed'];
                foreach($tabs as $key => $label): 
                    $active = ($filter === $key) ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/20' : 'text-slate-500 hover:text-orange-600';
                ?>
                    <a href="?filter=<?= $key ?>&search=<?= urlencode($search) ?>" class="px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-tight transition-all <?= $active ?>"><?= $label ?></a>
                <?php endforeach; ?>
            </div>
            
            <div class="relative flex-1">
                <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search Customer or Order ID..." class="w-full pl-12 pr-4 py-3 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl text-sm focus:border-orange-500 outline-none transition-colors dark:text-white">
            </div>
        </form>

        <!-- Orders Table -->
        <div class="bg-white dark:bg-neutral-900 rounded-[32px] shadow-2xl border border-slate-200 dark:border-neutral-800 overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                    <tr class="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <th class="px-8 py-5">Order ID</th>
                        <th class="px-8 py-5">Ordered By (Customer)</th>
                        <th class="px-8 py-5 text-center">Type</th>
                        <th class="px-8 py-5 text-right">Total Amount</th>
                        <th class="px-8 py-5">Date</th>
                        <th class="px-8 py-5 text-center">Status</th>
                        <th class="px-8 py-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php if(empty($orders)): ?>
                        <tr><td colspan="7" class="px-8 py-20 text-center text-slate-400 italic">No incoming partner orders found.</td></tr>
                    <?php endif; ?>
                    <?php foreach($orders as $o): 
                        $statusColors = [
                            'pending' => 'bg-amber-500/10 text-amber-500 border-amber-500/20',
                            'processing' => 'bg-indigo-500/10 text-indigo-500 border-indigo-500/20',
                            'shipped' => 'bg-blue-500/10 text-blue-500 border-blue-500/20',
                            'received' => 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
                            'finalized' => 'bg-slate-500/10 text-slate-500 border-slate-500/20',
                            'disputed' => 'bg-rose-500/10 text-rose-500 border-rose-500/20',
                            'return_requested' => 'bg-orange-500/10 text-orange-500 border-orange-500/20',
                            'cancelled' => 'bg-red-500/10 text-red-500 border-red-500/20'
                        ];
                        $badge = $statusColors[$o['status']] ?? 'bg-slate-100 text-slate-500';
                    ?>
                    <tr class="group hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors">
                        <td class="px-8 py-5 font-mono text-xs font-bold text-slate-400 group-hover:text-orange-600 transition-colors">#<?= strtoupper($o['type']) ?>-<?= $o['id'] ?></td>
                        <td class="px-8 py-5">
                            <div class="font-black dark:text-white text-sm"><?= htmlspecialchars($o['customer_name']) ?></div>
                            <div class="flex items-center gap-1.5 mt-1">
                                <span class="text-[8px] font-black uppercase px-1.5 py-0.5 rounded-md <?= ($o['payment_status'] ?? 'Unpaid') === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500' ?>">
                                    <?= $o['payment_status'] ?? 'Unpaid' ?>
                                </span>
                            </div>
                        </td>
                        <td class="px-8 py-5 text-center">
                            <span class="text-[9px] font-black uppercase px-2 py-1 rounded-lg bg-slate-100 dark:bg-neutral-800 text-slate-500 tracking-tighter"><?= $o['type'] === 'b2b' ? 'Incoming' : 'Manual' ?></span>
                        </td>
                        <td class="px-8 py-5 text-right font-black text-slate-900 dark:text-white">$<?= number_format($o['total_amount'], 2) ?></td>
                        <td class="px-8 py-5 text-xs text-slate-500"><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                        <td class="px-8 py-5">
                            <div class="flex flex-col items-center gap-1">
                                <?php if(($o['payment_status'] ?? 'Unpaid') === 'Unpaid'): ?>
                                    <span class="text-[8px] font-black uppercase px-2 py-0.5 bg-rose-600 text-white rounded shadow-sm">Unpaid</span>
                                <?php endif; ?>
                                <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase border <?= $badge ?>">
                                    <?= $o['status'] ?>
                                </span>
                            </div>
                        </td>
                        <td class="px-8 py-5 text-right">
                            <a href="view_order_details.php?id=<?= $o['id'] ?>&type=<?= strtolower($o['type']) ?>" class="p-2 text-slate-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-950 rounded-xl transition-all inline-block">
                                <i data-lucide="eye" size="18"></i>
                            </a>
                            <a href="invoice_builder.php?type=b2b&order_id=<?= $o['id'] ?>" class="p-2 text-slate-400 hover:text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950 rounded-xl transition-all inline-block" title="Generate Invoice">
                                <i data-lucide="file-text" size="18"></i>
                            </a>
                            <?php if (has_module('rider_tracking') && in_array($o['status'], ['pending', 'processing'])): ?>
                            <button onclick="openDispatchModal(<?= $o['id'] ?>, '<?= htmlspecialchars($o['customer_name']) ?>')" class="p-2 text-slate-400 hover:text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950 rounded-xl transition-all inline-block" title="Dispatch Order">
                                <i data-lucide="truck" size="18"></i>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Dispatch Modal -->
    <div id="dispatchModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('dispatchModal').classList.add('hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Dispatch Order</h2>
            <p id="dispatchTargetName" class="text-xs text-orange-500 font-bold uppercase tracking-widest mb-8"></p>

            <form id="dispatchForm" class="space-y-4">
                <input type="hidden" id="dispatch_order_id">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Select Rider</label>
                    <select id="rider_id" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                        <option value="">-- Choose Rider --</option>
                        <?php foreach($riders as $r): ?>
                            <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                    <?php if(empty($riders)): ?>
                        <p class="text-[9px] text-rose-500 mt-2 font-bold">No active riders found. Please add riders in Staff Management first.</p>
                    <?php endif; ?>
                </div>
                <button type="button" onclick="confirmDispatch()" class="w-full py-4 bg-emerald-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 mt-4 active:scale-95 transition-all">Assign & Dispatch</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();

        function openDispatchModal(orderId, customerName) {
            document.getElementById('dispatch_order_id').value = orderId;
            document.getElementById('dispatchTargetName').innerText = 'To: ' + customerName;
            document.getElementById('dispatchModal').classList.remove('hidden');
            document.getElementById('dispatchModal').classList.add('flex');
        }

        async function confirmDispatch() {
            const orderId = document.getElementById('dispatch_order_id').value;
            const riderId = document.getElementById('rider_id').value;
            if(!riderId) return alert("Select a rider first!");
            
            try {
                const res = await fetch('b2b_actions.php?action=assign_rider', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ order_id: orderId, rider_id: riderId })
                });
                const data = await res.json();
                if (data.success) {
                    alert("Order dispatched to rider!");
                    location.reload();
                } else {
                    alert(data.message);
                }
            } catch (e) { alert("Network Error"); }
        }
    </script>
</body>
</html>