<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }
if (!has_module('sales_reports')) { header("Location: dashboard.php?error=access_denied"); exit; }

$currency = $currency_symbol ?? '$';
$today = date('Y-m-d');
$last_30_days = date('Y-m-d', strtotime('-30 days'));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sales Reports | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap');
        body { font-family: 'Inter', sans-serif; }

        /* Hide default calendar icon for date inputs */
        input[type="date"]::-webkit-calendar-picker-indicator {
            opacity: 0;
            width: 100%; /* Make it cover the entire input for easier clicking */
            height: 100%;
            position: absolute;
            top: 0;
            left: 0;
            cursor: pointer;
        }
        input[type="date"]::-webkit-inner-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }
        /* For Firefox */
        input[type="date"]::-moz-calendar-picker-indicator {
            opacity: 0;
        }
    </style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Sales Reports</h1>
                <p class="text-xs text-slate-500 uppercase tracking-widest font-bold mt-1">Detailed overview of your sales performance</p>
            </div>
            <div class="flex items-center gap-3">
                <?php include 'topbar.php'; ?>
            </div>
        </header>

        <!-- Filters and Search -->
        <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm mb-8 flex flex-wrap items-end gap-4">
            <div class="relative">
                <label class="block text-[10px] font-black uppercase text-slate-400 mb-1">Start Date</label>
                <i data-lucide="calendar" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size="18"></i>
                <input type="date" id="startDate" value="<?= $last_30_days ?>" class="pl-10 pr-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm dark:text-white cursor-pointer">
            </div>
            <div class="relative">
                <label class="block text-[10px] font-black uppercase text-slate-400 mb-1">End Date</label>
                <i data-lucide="calendar" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 pointer-events-none" size="18"></i>
                <input type="date" id="endDate" value="<?= $today ?>" class="pl-10 pr-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm dark:text-white cursor-pointer">
            </div>
            <div class="relative flex-1 min-w-[200px]">
                <label class="block text-[10px] font-black uppercase text-slate-400 mb-1">Search Invoice/Product/Customer</label>
                <i data-lucide="search" class="absolute left-3 top-1/2 translate-y-1 text-slate-400" size="18"></i>
                <input type="text" id="searchQuery" placeholder="Search..." class="w-full pl-10 pr-4 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm">
            </div>
            <button onclick="fetchSalesData()" class="px-5 py-2.5 bg-orange-600 text-white rounded-xl font-bold text-sm shadow-lg shadow-orange-600/20 hover:bg-orange-700 transition-all flex items-center gap-2">
                <i data-lucide="filter" class="inline mr-2" size="18"></i> Apply Filters
            </button>
            <button onclick="resetFilters()" class="px-5 py-2.5 bg-slate-200 dark:bg-neutral-800 text-slate-600 dark:text-neutral-400 rounded-xl font-bold text-sm shadow-sm hover:bg-slate-300 dark:hover:bg-neutral-700 transition-all flex items-center gap-2">
                <i data-lucide="rotate-ccw" class="inline mr-2" size="18"></i> Reset Filters
            </button>
        </div>

        <!-- Summary Statistics -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8" id="summaryStats">
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black uppercase text-slate-400">Total Revenue</p>
                    <h3 class="text-2xl font-black dark:text-white mt-1" id="totalRevenue"><?= $currency ?>0.00</h3>
                </div>
                <i data-lucide="dollar-sign" class="text-orange-500" size="32"></i>
            </div>
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black uppercase text-slate-400">Gross Profit</p>
                    <h3 class="text-2xl font-black dark:text-white mt-1" id="grossProfit"><?= $currency ?>0.00</h3>
                </div>
                <i data-lucide="trending-up" class="text-emerald-500" size="32"></i>
            </div>
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black uppercase text-slate-400">Items Sold</p>
                    <h3 class="text-2xl font-black dark:text-white mt-1" id="itemsSold">0</h3>
                </div>
                <i data-lucide="package" class="text-blue-500" size="32"></i>
            </div>
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black uppercase text-slate-400">Total Invoices</p>
                    <h3 class="text-2xl font-black dark:text-white mt-1" id="totalInvoices">0</h3>
                </div>
                <i data-lucide="receipt" class="text-purple-500" size="32"></i>
            </div>
        </div>

        <!-- Sales Table -->
        <div class="bg-white dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-200 dark:border-neutral-800">
                    <tr>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Date</th>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Invoice ID</th>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Customer</th>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Product</th>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-center">Qty</th>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Unit Price</th>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Total Sale</th>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Profit</th>
                    </tr>
                </thead>
                <tbody id="salesTableBody" class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <tr><td colspan="8" class="p-10 text-center text-slate-400 italic">No sales data available. Apply filters to view.</td></tr>
                </tbody>
            </table>
            <div class="p-4 flex justify-end items-center border-t border-slate-100 dark:border-neutral-800">
                <button id="prevPage" onclick="changePage(-1)" class="px-4 py-2 text-sm font-bold text-orange-600 hover:bg-orange-50 dark:hover:bg-neutral-800 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed">Previous</button>
                <span id="currentPage" class="mx-4 text-sm dark:text-white">Page 1</span>
                <button id="nextPage" onclick="changePage(1)" class="px-4 py-2 text-sm font-bold text-orange-600 hover:bg-orange-50 dark:hover:bg-neutral-800 rounded-xl disabled:opacity-50 disabled:cursor-not-allowed">Next</button>
            </div>
        </div>
    </main>

    <script>
        lucide.createIcons();
        const currency = '<?= $currency ?>';
        let currentPage = 1;
        let totalPages = 1;

        async function fetchSalesData() {
            const startDate = document.getElementById('startDate').value;
            const endDate = document.getElementById('endDate').value;
            const searchQuery = document.getElementById('searchQuery').value;
            const activeBranchId = '<?= $_SESSION['active_branch_id'] ?? 'all' ?>'; // Get current active branch

            let url = `api.php?route=sales/detailed&start=${startDate}&end=${endDate}&page=${currentPage}`;
            if (searchQuery) url += `&search=${encodeURIComponent(searchQuery)}`;
            if (activeBranchId) url += `&branch_id=${activeBranchId}`;

            try {
                const response = await fetch(url);
                const data = await response.json();

                if (data.success === false) {
                    alert("Error fetching sales data: " + data.message);
                    return;
                }

                updateSummaryStats(data.stats);
                renderSalesTable(data.sales);
                totalPages = Math.ceil(data.stats.total_records / 15); // Assuming 15 items per page
                updatePaginationControls();

            } catch (error) {
                console.error('Error:', error);
                alert('Failed to fetch sales data.');
            }
        }

        function updateSummaryStats(stats) {
            document.getElementById('totalRevenue').innerText = `${currency}${parseFloat(stats.revenue).toFixed(2)}`;
            document.getElementById('grossProfit').innerText = `${currency}${parseFloat(stats.profit).toFixed(2)}`;
            document.getElementById('itemsSold').innerText = stats.items;
            document.getElementById('totalInvoices').innerText = stats.invoices;
        }

        function renderSalesTable(sales) {
            const tableBody = document.getElementById('salesTableBody');
            if (sales.length === 0) {
                tableBody.innerHTML = '<tr><td colspan="8" class="p-10 text-center text-slate-400 italic">No sales data available for the selected filters.</td></tr>';
                return;
            }

            tableBody.innerHTML = sales.map(sale => `
                <tr class="dark:text-white text-sm hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                    <td class="px-6 py-4">${new Date(sale.date).toLocaleDateString()}</td>
                    <td class="px-6 py-4 font-bold">${sale.invoice_id}</td>
                    <td class="px-6 py-4">${sale.customer_name || 'Walk-in'}</td>
                    <td class="px-6 py-4">${sale.product_name}</td>
                    <td class="px-6 py-4 text-center">${parseFloat(sale.qty).toFixed(0)}</td>
                    <td class="px-6 py-4 text-right">${currency}${parseFloat(sale.unit_sale_price).toFixed(2)}</td>
                    <td class="px-6 py-4 text-right font-bold">${currency}${parseFloat(sale.total_sale).toFixed(2)}</td>
                    <td class="px-6 py-4 text-right text-emerald-600 font-bold">${currency}${parseFloat(sale.net_profit).toFixed(2)}</td>
                </tr>
            `).join('');
        }

        function changePage(delta) {
            const newPage = currentPage + delta;
            if (newPage > 0 && newPage <= totalPages) {
                currentPage = newPage;
                fetchSalesData();
            }
        }

        function updatePaginationControls() {
            document.getElementById('currentPage').innerText = `Page ${currentPage} of ${totalPages}`;
            document.getElementById('prevPage').disabled = (currentPage === 1);
            document.getElementById('nextPage').disabled = (currentPage === totalPages);
        }

        // Initial data fetch on page load
        document.addEventListener('DOMContentLoaded', () => {
            fetchSalesData();
            document.getElementById('startDate').addEventListener('change', () => { currentPage = 1; fetchSalesData(); });
            document.getElementById('endDate').addEventListener('change', () => { currentPage = 1; fetchSalesData(); });
            document.getElementById('searchQuery').addEventListener('keyup', (event) => {
                if (event.key === 'Enter') {
                    currentPage = 1;
                    fetchSalesData();
                }
            });
        });
    </script>
</body>
</html>