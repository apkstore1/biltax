<?php
require_once 'config/db_switch.php';

// Check if user is logged in
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

// Handle Delete Request
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id']) && isset($_POST['source_table'])) {
    try {
        $table = ($_POST['source_table'] === 'riders') ? 'riders' : 'users';
        $stmt = $tenant_conn->prepare("DELETE FROM $table WHERE id = :id");
        $stmt->execute([':id' => $_POST['delete_id']]);
        $success_msg = "Personnel removed successfully.";
    } catch (PDOException $e) {
        $error_msg = "Error deleting record: " . $e->getMessage();
    }
}

$industry = strtolower(trim($_SESSION['industry_type'] ?? 'retail'));

// Fetch Staff Members
$staff_members = [];
try {
    // Create table if it doesn't exist (Self-healing)
    $tenant_conn->exec("CREATE TABLE IF NOT EXISTS users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL,
        password VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Check if riders table exists to prevent crash for tenants without rider_tracking module
    $has_riders_table = false;
    if (has_module('rider_tracking')) {
        $check = $tenant_conn->query("SHOW TABLES LIKE 'riders'")->fetch();
        if ($check) $has_riders_table = true;
    }

    $sql = "SELECT u.id, u.name, u.role, u.assigned_branch_id, u.created_at, b.branch_name, 'users' as source_table
            FROM users u 
            LEFT JOIN branches b ON u.assigned_branch_id = b.id";

    if ($has_riders_table) {
        $sql .= " UNION ALL
                  SELECT r.id, r.name, 'rider' as role, NULL as assigned_branch_id, r.created_at, NULL as branch_name, 'riders' as source_table
                  FROM riders r";
    }

    $sql .= " ORDER BY created_at DESC";

    $staff_members = $tenant_conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);

    // Count and check limit for UI
    $current_count = count($staff_members);
    $limit_reached = ($current_count >= $staff_limit);
} catch (PDOException $e) {
    $error_msg = "Database Error: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff List</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Theme Logic -->
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 font-sans text-slate-900 dark:text-neutral-200 transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 overflow-y-auto">
        <div class="flex justify-between items-center mb-6">
            <div>
                <h2 class="text-2xl font-black text-slate-900 dark:text-white">Staff Team</h2>
                <p class="text-[10px] font-black uppercase text-orange-500 tracking-widest mt-1">
                    Staff Added: <span class="text-slate-900 dark:text-white"><?= $current_count ?></span> / <?= $staff_limit ?> Personnel Registered
                </p>
            </div>
            <div class="flex items-center gap-4">
                <?php include 'topbar.php'; ?>
                <?php if (!$limit_reached): ?>
                <a href="staff_add.php" class="bg-orange-500 hover:bg-orange-600 text-white px-4 py-2 rounded-xl font-bold flex items-center gap-2 text-sm shadow-lg shadow-orange-200 dark:shadow-none transition-all">
                    <i data-lucide="plus" size="16"></i> Add New
                </a>
                <?php else: ?>
                <span class="bg-slate-200 dark:bg-neutral-800 text-slate-500 px-4 py-2 rounded-xl font-bold flex items-center gap-2 text-sm cursor-not-allowed opacity-60" title="Staff Limit Reached">
                    <i data-lucide="lock" size="16"></i> Limit Reached (<?= $current_count ?>/<?= $staff_limit ?>)
                </span>
                <?php endif; ?>
            </div>
        </div>

        <!-- Global Verification Alert Bar -->
        <?php include 'alert_bar.php'; ?>

        <?php if (isset($success_msg)): ?>
            <div class="mb-4 p-4 bg-green-100 border border-green-200 text-green-700 rounded-xl text-sm"><?php echo $success_msg; ?></div>
        <?php endif; ?>

        <div class="bg-white dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 shadow-sm overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-100 dark:border-neutral-800">
                    <tr>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Name</th>
                        <?php if (has_module('manage_branches')): ?>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Branch Assignment</th>
                        <?php endif; ?>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Role</th>
                        <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Action</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach ($staff_members as $staff): 
                        // Industry-aware labels
                        $display_role = $staff['role'];
                        if ($staff['role'] === 'rider') {
                            $display_role = ($industry === 'service') ? 'Service Man' : 'Rider';
                        }
                    ?>
                    <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800 transition-colors">
                        <td class="px-6 py-4 font-bold"><?php echo htmlspecialchars($staff['name']); ?></td>
                        <?php if (has_module('manage_branches')): ?>
                        <td class="px-6 py-4 text-xs">
                            <?php if ($staff['branch_name']): ?>
                                <span class="text-indigo-600 dark:text-indigo-400 font-bold italic"><i data-lucide="map-pin" size="12" class="inline"></i> <?= htmlspecialchars($staff['branch_name']) ?></span>
                            <?php else: ?>
                                <span class="text-slate-400 italic">All Branches (Global)</span>
                            <?php endif; ?>
                        </td>
                        <?php endif; ?>
                        <td class="px-6 py-4 text-sm"><span class="px-2 py-1 rounded-md text-xs font-bold bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-neutral-400"><?php echo htmlspecialchars(ucfirst($display_role)); ?></span></td>
                        <td class="px-6 py-4 flex items-center gap-1">
                            <?php if ($staff['source_table'] === 'users'): ?>
                                <a href="staff_edit.php?id=<?php echo $staff['id']; ?>" class="p-2 text-slate-400 hover:text-blue-500 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors" title="Edit Staff Member">
                                    <i data-lucide="pencil" size="16"></i>
                                </a>
                            <?php endif; ?>
                            <form method="POST" onsubmit="return confirm('Are you sure?');" class="inline">
                                <input type="hidden" name="delete_id" value="<?php echo $staff['id']; ?>">
                                <input type="hidden" name="source_table" value="<?php echo $staff['source_table']; ?>">
                                <button type="submit" class="text-rose-500 hover:text-rose-600 p-2 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors"><i data-lucide="trash-2" size="16"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($staff_members)): ?>
                        <tr><td colspan="3" class="px-6 py-8 text-center text-slate-400">No staff members found. Add one to get started.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>