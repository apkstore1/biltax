<?php
session_start();
require_once 'config.php';

// Handle Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $task_id = $_POST['task_id'];
    
    if ($_POST['action'] === 'approve_task') {
        // Fetch task details to check if it's a feature request
        $stmt_task = $pdo->prepare("SELECT tenant_id, task_title FROM verification_tasks WHERE id = ?");
        $stmt_task->execute([$task_id]);
        $task_info = $stmt_task->fetch(PDO::FETCH_ASSOC);

        $stmt = $pdo->prepare("UPDATE verification_tasks SET status = 'approved', admin_reason = NULL WHERE id = ?");
        $stmt->execute([$task_id]);

        // If it's a feature request, enable the module for the tenant
        if ($task_info && strpos($task_info['task_title'], 'Feature Request:') === 0) {
            $module_key = str_replace('Feature Request: ', '', $task_info['task_title']);
            $tenant_id = $task_info['tenant_id'];
            
            // Insert into enabled_modules table
            $stmt_enable_module = $pdo->prepare("INSERT INTO enabled_modules (tenant_id, module_key, is_active) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE is_active = 1");
            $stmt_enable_module->execute([$tenant_id, $module_key]);
            
            // Optionally, add a notification for the tenant that their feature request was approved
        }
        header("Location: verification_requests.php?msg=approved");
    } elseif ($_POST['action'] === 'reject_task') {
        $reason = $_POST['reason'] ?? 'Documents are unclear or invalid.';
        $stmt = $pdo->prepare("UPDATE verification_tasks SET status = 'rejected', admin_reason = ? WHERE id = ?");
        $stmt->execute([$reason, $task_id]);
        header("Location: verification_requests.php?msg=rejected");
    } elseif ($_POST['action'] === 'delete_task') {
        $stmt = $pdo->prepare("DELETE FROM verification_tasks WHERE id = ?");
        $stmt->execute([$task_id]);
        header("Location: verification_requests.php?msg=deleted");
    } elseif ($_POST['action'] === 'push_verification_task') {
        $target = $_POST['target_tenant']; // 'all' or tenant_id
        $title = $_POST['task_title'];
        $desc = $_POST['task_description'];
        $priority = $_POST['priority'];

        $docs_arr = $_POST['required_docs'] ?? [];
        if (!empty($_POST['other_doc_name'])) {
            $docs_arr[] = trim($_POST['other_doc_name']);
        }
        $docs = implode(', ', array_unique(array_filter($docs_arr)));

        try {
            if ($target === 'all') {
                $stmt_t = $pdo->query("SELECT id FROM tenants WHERE status = 'active'");
                $all_tids = $stmt_t->fetchAll(PDO::FETCH_COLUMN);
                $ins = $pdo->prepare("INSERT INTO verification_tasks (tenant_id, task_title, task_description, required_docs, priority) VALUES (?, ?, ?, ?, ?)");
                $notif_ins = $pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'verification_task')");
                foreach ($all_tids as $tid) {
                    $ins->execute([$tid, $title, $desc, $docs, $priority]);
                    $notif_ins->execute([$tid, "New Verification Task: " . $title, $desc]);
                }
            } else {
                $ins = $pdo->prepare("INSERT INTO verification_tasks (tenant_id, task_title, task_description, required_docs, priority) VALUES (?, ?, ?, ?, ?)");
                $ins->execute([$target, $title, $desc, $docs, $priority]);
                $pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'verification_task')")
                    ->execute([$target, "New Verification Task: " . $title, $desc]);
            }
            header("Location: verification_requests.php?msg=task_pushed");
        } catch (Exception $e) {
            header("Location: verification_requests.php?msg=error&error=" . urlencode($e->getMessage()));
        }
    }
    exit;
}

// Fetch Active Tenants for Push Modal
$active_tenants = $pdo->query("SELECT id, business_name, unique_id FROM tenants WHERE status = 'active' ORDER BY business_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Filtering & Search Logic
$status_filter = $_GET['status'] ?? 'all';
$search_query = $_GET['search'] ?? '';

$sql = "SELECT vt.*, t.business_name, t.unique_id, t.owner_name, t.email 
        FROM verification_tasks vt
        JOIN tenants t ON vt.tenant_id = t.id";

$where_clauses = [];
$params = [];

if ($status_filter !== 'all') {
    $where_clauses[] = "vt.status = ?";
    $params[] = $status_filter;
}
if (!empty($search_query)) {
    $where_clauses[] = "(t.business_name LIKE ? OR t.unique_id LIKE ? OR vt.task_title LIKE ?)";
    $p_val = "%$search_query%";
    array_push($params, $p_val, $p_val, $p_val);
}
if (!empty($where_clauses)) { $sql .= " WHERE " . implode(" AND ", $where_clauses); }

$sql .= " ORDER BY vt.status = 'pending_review' DESC, vt.created_at DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verification Requests - Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Theme Logic -->
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64">
        <?php include 'topbar.php'; ?>
        <main class="p-8">
            <header class="mb-10 flex justify-between items-start">
                <div>
                    <h1 class="text-2xl font-black uppercase tracking-tight">Compliance & Verifications</h1>
                    <p class="text-sm text-slate-500">Review submitted documents and verify tenant businesses.</p>
                </div>
                <button onclick="document.getElementById('pushTaskModal').classList.replace('hidden', 'flex')" class="bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center gap-2 shadow-lg shadow-indigo-900/20 transition-all">
                    <i data-lucide="send" size="18"></i> Push Request
                </button>
            </header>

            <!-- Search and Filter Bar -->
            <div class="flex flex-col md:flex-row gap-4 mb-8">
                <div class="flex-1 flex gap-2">
                    <div class="relative flex-1">
                        <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                        <input type="text" id="search-input" value="<?= htmlspecialchars($search_query) ?>" placeholder="Search business, ID or task..." class="w-full pl-12 pr-4 py-3 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-indigo-500 transition-all text-sm">
                    </div>
                    <button onclick="applySearch()" class="px-6 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase text-[10px] tracking-widest hover:bg-indigo-600 hover:text-white transition-all">Search</button>
                </div>
                <div class="flex gap-2 p-1 bg-white dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800 overflow-x-auto">
                    <?php foreach(['all', 'pending_review', 'approved', 'rejected', 'not_started'] as $st): ?>
                        <a href="?status=<?= $st ?>&search=<?= urlencode($search_query) ?>" class="px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap <?= $status_filter === $st ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-indigo-500' ?>">
                            <?= str_replace('_', ' ', $st) ?>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <?php if (isset($_GET['msg'])): ?>
                <div class="mb-8 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center gap-3 animate-pulse-once">
                    <i data-lucide="check-circle" size="18"></i>
                    <p class="text-sm font-bold">
                        <?php 
                            if($_GET['msg'] == 'approved') echo "Verification approved successfully!";
                            elseif($_GET['msg'] == 'rejected') echo "Submission has been rejected with feedback.";
                            elseif($_GET['msg'] == 'deleted') echo "Verification request has been permanently deleted.";
                            elseif($_GET['msg'] == 'task_pushed') echo "New verification task has been broadcasted.";
                            elseif($_GET['msg'] == 'error') echo "Operation failed: " . htmlspecialchars($_GET['error'] ?? 'Unknown error');
                        ?>
                    </p>
                </div>
            <?php endif; ?>

            <div class="grid grid-cols-1 gap-6">
                <?php if (empty($tasks)): ?>
                    <div class="p-20 text-center bg-white dark:bg-neutral-900 rounded-[40px] border border-dashed border-slate-200 dark:border-neutral-800">
                        <p class="text-slate-400 font-bold uppercase tracking-widest text-xs">No verification tasks found.</p>
                    </div>
                <?php endif; ?>

                <?php foreach($tasks as $t): 
                    $docs = json_decode($t['submitted_docs'] ?? '[]', true);
                    $statusColors = [
                        'pending_review' => 'bg-amber-500 text-white animate-pulse',
                        'approved' => 'bg-emerald-500 text-white',
                        'rejected' => 'bg-rose-600 text-white',
                        'not_started' => 'bg-slate-200 text-slate-500'
                    ];
                    $priorityColors = [
                        'high' => 'text-rose-500 bg-rose-500/10',
                        'medium' => 'text-amber-500 bg-amber-500/10',
                        'low' => 'text-emerald-500 bg-emerald-500/10',
                    ];
                ?>
                <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm flex flex-col md:flex-row justify-between gap-8">
                    <div class="flex-1">
                        <div class="flex flex-wrap items-center gap-3 mb-4 cursor-pointer" onclick="toggleTask(<?= $t['id'] ?>)">
                            <div class="flex items-center gap-2">
                                <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase <?= $statusColors[$t['status']] ?>">
                                    <?= str_replace('_', ' ', $t['status']) ?>
                                </span>
                                <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase <?= $priorityColors[$t['priority']] ?>">
                                    <?= $t['priority'] ?> Priority
                                </span>
                            </div>
                            <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-auto">
                                Created: <?= date('M d, Y', strtotime($t['created_at'])) ?>
                            </span>
                            <i data-lucide="chevron-down" size="18" id="toggle-icon-<?= $t['id'] ?>" class="transition-transform <?= $t['status'] === 'pending_review' ? '' : 'rotate-180' ?>"></i>
                        </div>

                        <div id="task-content-<?= $t['id'] ?>" class="<?= $t['status'] === 'pending_review' ? '' : 'hidden' ?>">
                            <div class="mb-6">
                                <p class="text-[10px] font-black text-indigo-500 uppercase mb-1">Recipient Business</p>
                                <h3 class="text-xl font-black mb-1"><?= htmlspecialchars($t['business_name']) ?> <span class="text-slate-400 font-mono text-sm font-normal">#<?= $t['unique_id'] ?></span></h3>
                                <p class="text-xs font-bold text-slate-500"><?= htmlspecialchars($t['owner_name']) ?> (<?= htmlspecialchars($t['email']) ?>)</p>
                            </div>
                            
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                                <div>
                                    <p class="text-[10px] font-black text-slate-400 uppercase mb-1">Task Title & Details</p>
                                    <p class="text-sm font-black text-slate-800 dark:text-slate-200"><?= htmlspecialchars($t['task_title']) ?></p>
                                    <p class="text-xs text-slate-500 mt-1"><?= htmlspecialchars($t['task_description']) ?></p>
                                </div>
                                <div>
                                    <p class="text-[10px] font-black text-slate-400 uppercase mb-1">Required Documents</p>
                                    <p class="text-xs font-bold text-orange-600"><?= htmlspecialchars($t['required_docs']) ?></p>
                                </div>
                            </div>

                            <?php if (!empty($docs)): ?>
                            <div class="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-6">
                                <?php foreach($docs as $doc): ?>
                                <a href="<?= $doc['url'] ?>" target="_blank" class="group relative aspect-square bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 overflow-hidden flex items-center justify-center">
                                    <img src="<?= $doc['url'] ?>" class="w-full h-full object-cover opacity-60 group-hover:opacity-100 transition-all">
                                    <div class="absolute bottom-0 left-0 right-0 p-2 bg-black/60 backdrop-blur-sm">
                                        <p class="text-[8px] font-black text-white uppercase truncate"><?= htmlspecialchars($doc['name']) ?></p>
                                    </div>
                                </a>
                                <?php endforeach; ?>
                            </div>
                            <?php else: ?>
                                <p class="text-xs italic text-slate-500">No documents submitted yet.</p>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="flex flex-col gap-3 justify-center min-w-[180px] border-l border-slate-100 dark:border-neutral-800 pl-8">
                        <?php if ($t['status'] === 'pending_review'): ?>
                        <form method="POST" onsubmit="return confirm('Approve this verification?')">
                            <input type="hidden" name="action" value="approve_task">
                            <input type="hidden" name="task_id" value="<?= $t['id'] ?>">
                            <button type="submit" class="w-full py-3 bg-emerald-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-900/20">Approve</button>
                        </form>
                        <button onclick="openRejectModal(<?= $t['id'] ?>)" class="w-full py-3 bg-rose-600/10 text-rose-600 border border-rose-600/20 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-rose-600 hover:text-white transition-all">Reject</button>
                        <?php endif; ?>

                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this request? This cannot be undone.')">
                            <input type="hidden" name="action" value="delete_task">
                            <input type="hidden" name="task_id" value="<?= $t['id'] ?>">
                            <button type="submit" class="w-full py-2 text-slate-400 hover:text-rose-500 font-bold text-[9px] uppercase tracking-widest flex items-center justify-center gap-2 transition-colors">
                                <i data-lucide="trash-2" size="12"></i> Delete
                            </button>
                        </form>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </main>
    </div>

    <!-- Reject Modal -->
    <div id="rejectModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[100] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
            <h3 class="text-xl font-black mb-1 uppercase tracking-tight">Reject Submission</h3>
            <p class="text-xs text-slate-500 mb-6">Explain to the tenant why their verification failed.</p>
            <form method="POST">
                <input type="hidden" name="action" value="reject_task">
                <input type="hidden" name="task_id" id="reject_task_id">
                <textarea name="reason" required placeholder="e.g. ID card image is too blurry..." class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-rose-500 mb-6 h-32 text-sm"></textarea>
                <div class="flex gap-3">
                    <button type="button" onclick="document.getElementById('rejectModal').classList.add('hidden')" class="flex-1 py-3 font-bold text-slate-500">Cancel</button>
                    <button type="submit" class="flex-[2] py-3 bg-rose-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-rose-900/20">Send Rejection</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Push Verification Task Modal -->
    <div id="pushTaskModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[100] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative overflow-hidden">
            <button type="button" onclick="document.getElementById('pushTaskModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500 transition-colors"><i data-lucide="x" size="24"></i></button>
            
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Push Verification</h2>
            <p class="text-xs text-indigo-500 font-bold uppercase tracking-widest mb-8">Request compliance documents</p>

            <form method="POST" class="space-y-5">
                <input type="hidden" name="action" value="push_verification_task">
                
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Target Audience</label>
                    <select name="target_tenant" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold">
                        <option value="all">📢 All Active Tenants</option>
                        <?php foreach($active_tenants as $at): ?>
                            <option value="<?= $at['id'] ?>"><?= htmlspecialchars($at['business_name']) ?> (#<?= $at['unique_id'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Task Title</label>
                    <input type="text" name="task_title" required placeholder="e.g. Verify Your NTN" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold">
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Instructions</label>
                    <textarea name="task_description" required placeholder="Tell the user why this is needed..." class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm h-24"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Priority</label>
                        <select name="priority" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold">
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High (Red Alert)</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Required Documents</label>
                        <div class="grid grid-cols-1 gap-1">
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400"><input type="checkbox" name="required_docs[]" value="ID Front" class="accent-orange-600"> ID Front</label>
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400"><input type="checkbox" name="required_docs[]" value="ID Back" class="accent-orange-600"> ID Back</label>
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400"><input type="checkbox" name="required_docs[]" value="Utility Bill" class="accent-orange-600"> Utility Bill</label>
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400"><input type="checkbox" name="required_docs[]" value="Tax Doc" class="accent-orange-600"> Tax Doc</label>
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400">
                                <input type="checkbox" id="other_doc_trigger" onchange="toggleOtherDoc()" class="accent-orange-600"> Other
                            </label>
                            <input type="text" name="other_doc_name" id="other_doc_field" placeholder="Enter document name..." class="hidden mt-1 w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg text-[10px] font-bold outline-none focus:border-indigo-500 transition-all">
                        </div>
                    </div>
                </div>

                <button type="submit" class="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-indigo-600/20 mt-4">Broadcast Request</button>
            </form>
        </div>
    </div>

    <script>
        function openRejectModal(id) {
            document.getElementById('reject_task_id').value = id;
            document.getElementById('rejectModal').classList.replace('hidden', 'flex');
        }

        function toggleTask(id) {
            const content = document.getElementById(`task-content-${id}`);
            const icon = document.getElementById(`toggle-icon-${id}`);
            content.classList.toggle('hidden');
            icon.classList.toggle('rotate-180');
        }

        function toggleOtherDoc() {
            const trigger = document.getElementById('other_doc_trigger');
            const field = document.getElementById('other_doc_field');
            field.classList.toggle('hidden', !trigger.checked);
            if (trigger.checked) field.focus();
        }

        function applySearch() {
            const search = document.getElementById('search-input').value;
            const status = '<?= $status_filter ?>';
            window.location.href = `?status=${status}&search=${encodeURIComponent(search)}`;
        }

        document.getElementById('search-input')?.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') applySearch();
        });

        // Render icons at the end
        lucide.createIcons();
    </script>
</body>
</html>