import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const db = new Database("inventory.db");

// Initialize Database Schema
db.exec(`
  CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    contact TEXT,
    email TEXT,
    phone TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    sku TEXT UNIQUE NOT NULL,
    category TEXT,
    price REAL NOT NULL,
    cost REAL NOT NULL,
    tax_rate REAL DEFAULT 0,
    stock_level INTEGER DEFAULT 0,
    reorder_point INTEGER DEFAULT 10,
    image_url TEXT,
    supplier_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supplier_id) REFERENCES suppliers(id)
  );

  CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    total_amount REAL NOT NULL,
    tax_amount REAL NOT NULL,
    discount_amount REAL DEFAULT 0,
    payment_method TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS sale_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sale_id INTEGER,
    product_id INTEGER,
    quantity INTEGER NOT NULL,
    unit_price REAL NOT NULL,
    FOREIGN KEY (sale_id) REFERENCES sales(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
  );

  CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER,
    type TEXT CHECK(type IN ('IN', 'OUT', 'ADJUSTMENT')),
    quantity INTEGER NOT NULL,
    reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (product_id) REFERENCES products(id)
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT
  );
`);

// Seed initial data if empty
const productCount = db.prepare("SELECT COUNT(*) as count FROM products").get() as { count: number };
if (productCount.count === 0) {
  const insertSupplier = db.prepare("INSERT INTO suppliers (name, contact, email, phone) VALUES (?, ?, ?, ?)");
  const supplierId = insertSupplier.run("Global Tech Supplies", "John Doe", "john@globaltech.com", "555-0123").lastInsertRowid;

  const insertProduct = db.prepare("INSERT INTO products (name, sku, category, price, cost, stock_level, reorder_point, supplier_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
  insertProduct.run("Wireless Mouse", "MS-001", "Electronics", 25.00, 12.50, 50, 10, supplierId);
  insertProduct.run("Mechanical Keyboard", "KB-002", "Electronics", 89.99, 45.00, 20, 5, supplierId);
  insertProduct.run("USB-C Hub", "HB-003", "Accessories", 35.00, 15.00, 15, 5, supplierId);
  insertProduct.run("Monitor Stand", "ST-004", "Furniture", 45.00, 20.00, 8, 10, supplierId);
}

// Seed default settings
const settingsCount = db.prepare("SELECT COUNT(*) as count FROM settings").get() as { count: number };
if (settingsCount.count === 0) {
  const insertSetting = db.prepare("INSERT INTO settings (key, value) VALUES (?, ?)");
  insertSetting.run("global_tax_rate", "8");
  insertSetting.run("business_name", "OmniStock POS");
  insertSetting.run("currency", "USD");
}


async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Routes
  app.get("/api/dashboard/stats", (req, res) => {
    const totalSales = db.prepare("SELECT SUM(total_amount) as total FROM sales").get() as { total: number };
    const lowStock = db.prepare("SELECT COUNT(*) as count FROM products WHERE stock_level <= reorder_point").get() as { count: number };
    const totalProducts = db.prepare("SELECT COUNT(*) as count FROM products").get() as { count: number };
    const recentSales = db.prepare("SELECT * FROM sales ORDER BY created_at DESC LIMIT 5").all();

    res.json({
      revenue: totalSales.total || 0,
      lowStockCount: lowStock.count,
      productCount: totalProducts.count,
      recentSales
    });
  });

  app.get("/api/products", (req, res) => {
    const products = db.prepare("SELECT * FROM products").all();
    res.json(products);
  });

  app.get("/api/suppliers", (req, res) => {
    const suppliers = db.prepare("SELECT * FROM suppliers").all();
    res.json(suppliers);
  });

  app.post("/api/suppliers", (req, res) => {
    const { name, contact, email, phone } = req.body;
    try {
      const info = db.prepare(`
        INSERT INTO suppliers (name, contact, email, phone)
        VALUES (?, ?, ?, ?)
      `).run(name, contact, email, phone);
      res.json({ id: info.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.post("/api/products", (req, res) => {
    const { name, sku, category, price, cost, tax_rate, stock_level, reorder_point, supplier_id } = req.body;
    try {
      const info = db.prepare(`
        INSERT INTO products (name, sku, category, price, cost, tax_rate, stock_level, reorder_point, supplier_id)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `).run(name, sku, category, price, cost, tax_rate, stock_level, reorder_point, supplier_id);
      res.json({ id: info.lastInsertRowid });
    } catch (err: any) {
      res.status(400).json({ error: err.message });
    }
  });

  app.get("/api/reports/generate", (req, res) => {
    const sales = db.prepare("SELECT * FROM sales").all();
    const products = db.prepare("SELECT * FROM products").all();
    const suppliers = db.prepare("SELECT * FROM suppliers").all();
    
    // Simple JSON report for now
    res.json({
      generatedAt: new Date().toISOString(),
      summary: {
        totalSales: sales.length,
        totalRevenue: sales.reduce((acc: any, s: any) => acc + s.total_amount, 0),
        inventoryValue: products.reduce((acc: any, p: any) => acc + (p.stock_level * p.cost), 0),
      },
      data: { sales, products, suppliers }
    });
  });

  app.get("/api/settings", (req, res) => {
    const settings = db.prepare("SELECT * FROM settings").all();
    const settingsMap = settings.reduce((acc: any, s: any) => {
      acc[s.key] = s.value;
      return acc;
    }, {});
    res.json(settingsMap);
  });

  app.post("/api/settings", (req, res) => {
    const settings = req.body;
    const updateSetting = db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)");
    
    const transaction = db.transaction(() => {
      for (const [key, value] of Object.entries(settings)) {
        updateSetting.run(key, String(value));
      }
    });

    try {
      transaction();
      res.json({ success: true });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  app.get("/api/sales/report", (req, res) => {
    const sales = db.prepare(`
      SELECT 
        date(created_at) as date, 
        SUM(total_amount) as total 
      FROM sales 
      GROUP BY date(created_at) 
      ORDER BY date ASC 
      LIMIT 30
    `).all();
    res.json(sales);
  });

  app.post("/api/pos/checkout", (req, res) => {
    const { items, total_amount, tax_amount, payment_method } = req.body;
    
    const transaction = db.transaction(() => {
      const sale = db.prepare(`
        INSERT INTO sales (total_amount, tax_amount, payment_method)
        VALUES (?, ?, ?)
      `).run(total_amount, tax_amount, payment_method);
      
      const saleId = sale.lastInsertRowid;

      for (const item of items) {
        db.prepare(`
          INSERT INTO sale_items (sale_id, product_id, quantity, unit_price)
          VALUES (?, ?, ?, ?)
        `).run(saleId, item.id, item.quantity, item.price);

        db.prepare(`
          UPDATE products SET stock_level = stock_level - ? WHERE id = ?
        `).run(item.quantity, item.id);

        db.prepare(`
          INSERT INTO stock_movements (product_id, type, quantity, reason)
          VALUES (?, 'OUT', ?, ?)
        `).run(item.id, item.quantity, `Sale #${saleId}`);
      }
      return saleId;
    });

    try {
      const saleId = transaction();
      res.json({ success: true, saleId });
    } catch (err: any) {
      res.status(500).json({ error: err.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
