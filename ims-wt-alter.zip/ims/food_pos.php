<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Fetch Active Branch Context
$active_branch = $_SESSION['active_branch_id'] ?? null;
$is_all = ($active_branch === 'all');
$stock_branch = $is_all ? null : get_active_stock_branch_id($active_branch);

// Fetch Products & Categories
try {
    $products = $tenant_conn->query("SELECT p.*, c.name as cat_name FROM products p LEFT JOIN categories c ON p.category_id = c.id WHERE p.is_raw = 0 ORDER BY c.name ASC, p.name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Fallback if categories table doesn't exist
    try {
        $products = $tenant_conn->query("SELECT *, NULL as cat_name FROM products WHERE is_raw = 0 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e2) { $products = []; }
}
$categories = array_unique(array_filter(array_column($products, 'cat_name'))) ?: [];

// Fetch Available Tables for this branch
$tables = [];
try {
    $table_sql = "SELECT id, table_number FROM restaurant_tables WHERE status = 'available'";
    if (!$is_all) {
        $table_sql .= " AND branch_id = ?";
    }
    $table_sql .= " ORDER BY table_number ASC";
    
    $t_stmt = $tenant_conn->prepare($table_sql);
    if ($is_all) {
        $t_stmt->execute();
    } else {
        $t_stmt->execute([$active_branch]);
    }
    $tables = $t_stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $tables = []; // Table might not exist yet
}

$selected_table_id = $_GET['table_id'] ?? null;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Food POS | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
        .hide-scrollbar::-webkit-scrollbar { display: none; }
        .active-cat { background-color: #f97316 !important; color: white !important; }
    </style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex overflow-hidden">
    
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 flex flex-col h-screen">
        <!-- Header / Topbar -->
        <header class="p-6 flex justify-between items-center bg-white dark:bg-neutral-900 border-b border-slate-200 dark:border-neutral-800">
            <div class="flex items-center gap-4">
                <button onclick="togglePOSFullScreen()" id="fs-toggle-btn" class="p-2.5 bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-slate-400 rounded-xl hover:bg-orange-500 hover:text-white transition-all shadow-sm" title="Toggle Counter Mode">
                    <i data-lucide="maximize" size="20"></i>
                </button>
                <!-- POS Settings Gear -->
                <button onclick="document.getElementById('posSettingsModal').classList.replace('hidden', 'flex')" class="p-2.5 bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-slate-400 rounded-xl hover:bg-orange-500 hover:text-white transition-all shadow-sm" title="POS Settings">
                    <i data-lucide="settings" size="20"></i>
                </button>
                <div>
                <h1 class="text-2xl font-black dark:text-white uppercase tracking-tight">Food POS</h1>
                <p class="text-[10px] text-orange-500 font-black uppercase tracking-widest">Restaurant Terminal</p>
                </div>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <div class="flex-1 flex overflow-hidden">
            <!-- Left Side: Menu Selection -->
            <div class="flex-1 flex flex-col p-6 overflow-hidden">
                <!-- Category Filter -->
                <div class="flex gap-3 overflow-x-auto pb-4 hide-scrollbar mb-4">
                    <button onclick="filterItems('all')" class="cat-btn active-cat px-6 py-3 bg-white dark:bg-neutral-900 dark:text-white border border-slate-200 dark:border-neutral-800 rounded-2xl text-xs font-black uppercase tracking-widest transition-all whitespace-nowrap">All</button>
                    <?php foreach($categories as $cat): ?>
                        <button onclick="filterItems('<?= addslashes($cat) ?>')" class="cat-btn px-6 py-3 bg-white dark:bg-neutral-900 dark:text-white border border-slate-200 dark:border-neutral-800 rounded-2xl text-xs font-black uppercase tracking-widest hover:border-orange-500 transition-all whitespace-nowrap">
                            <?= htmlspecialchars($cat) ?>
                        </button>
                    <?php endforeach; ?>
                </div>

                <!-- Product Grid -->
                <div class="flex-1 overflow-y-auto pr-2 custom-scrollbar">
                    <div id="itemGrid" class="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 pb-10">
                        <?php foreach($products as $p): ?>
                        <div data-category="<?= htmlspecialchars($p['cat_name'] ?: 'all') ?>" 
                             onclick='addToCart(<?= json_encode($p) ?>)'
                             class="item-card bg-white dark:bg-neutral-900 p-5 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm hover:border-orange-500 cursor-pointer transition-all active:scale-95 group text-center">
                            <div class="w-16 h-16 bg-slate-50 dark:bg-neutral-800 text-slate-400 group-hover:bg-orange-500 group-hover:text-white rounded-2xl flex items-center justify-center mx-auto mb-4 transition-colors">
                                <i data-lucide="utensils-cross-lines" size="28"></i>
                            </div>
                            <?php 
                                // Robust Price Logic for Restaurant Context
                                $display_price = (float)($p['price'] ?? 0);
                                if ($display_price <= 0) $display_price = (float)($p['sale_price'] ?? 0);
                            ?>
                            <h4 class="font-black text-sm dark:text-white mb-1 uppercase tracking-tight line-clamp-1"><?= htmlspecialchars($p['name']) ?></h4>
                            <p class="text-lg font-black text-orange-600"><?= $currency_symbol . number_format($display_price, 2) ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>

            <!-- Right Side: Cart / Order Sidebar -->
            <div class="w-96 bg-white dark:bg-neutral-900 border-l border-slate-200 dark:border-neutral-800 flex flex-col shadow-2xl">
                <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                    <h3 class="font-black dark:text-white uppercase tracking-widest text-sm mb-4">Cart Summary</h3>
                    
                    <!-- Table Selection -->
                    <div class="space-y-2">
                        <label class="text-[9px] font-black text-slate-400 uppercase tracking-widest ml-1">Select Table</label>
                        <select id="posTable" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-2xl outline-none dark:text-white font-bold text-base focus:border-orange-500 cursor-pointer transition-all shadow-sm" onchange="updateTableStatusDisplay()">
                            <option value="">-- No Table / Takeaway --</option>
                            <?php foreach($tables as $t): ?>
                                <option value="<?= $t['id'] ?>" <?= ($selected_table_id == $t['id']) ? 'selected' : '' ?>>🪑 Table <?= htmlspecialchars($t['table_number']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <!-- Cart Items Container -->
                <div id="cartList" class="flex-1 overflow-y-auto p-4 space-y-3">
                    <div class="h-full flex flex-col items-center justify-center text-slate-300 dark:text-neutral-700 gap-2 opacity-50">
                        <i data-lucide="shopping-cart" size="48"></i>
                        <p class="text-[10px] font-black uppercase tracking-widest text-center">Your basket is empty</p>
                    </div>
                </div>

                <!-- Totals & Checkout -->
                <div class="p-6 bg-slate-50 dark:bg-neutral-950/50 border-t border-slate-200 dark:border-neutral-800 space-y-4">
                    <div class="flex justify-between items-center">
                        <?php if ($selected_table_id): ?>
                        <span id="selectedTableName" class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Table: <?= htmlspecialchars($selected_table_id) ?></span>
                        <?php else: ?>
                        <span class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Payable Amount</span>
                        <?php endif; ?>
                        <span id="posTotal" class="text-3xl font-black text-slate-900 dark:text-white"><?= $currency_symbol ?>0.00</span>
                    </div>
                    <button onclick="checkoutOrder(event)" class="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-5 rounded-[24px] shadow-xl shadow-orange-600/20 transition-all active:scale-95 flex items-center justify-center gap-3 uppercase tracking-widest text-xs">
                        <i data-lucide="send"></i> Place Order (KOT)
                    </button>
                </div>
            </div>
        </div>
    </main>

    <!-- Order Success Modal -->
    <div id="successModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[100] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-sm shadow-2xl text-center">
            <div class="w-20 h-20 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i data-lucide="check-circle" size="48"></i>
            </div>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-2 tracking-tight">Order Placed!</h2>
            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mb-8">KOT has been sent to kitchen</p>
            
            <div class="space-y-3">
                <button id="printKOTBtn" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-lg shadow-orange-600/20 flex items-center justify-center gap-2">
                    <i data-lucide="printer" size="18"></i> Print KOT
                </button>
                <button id="printBillBtn" class="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase tracking-widest shadow-lg flex items-center justify-center gap-2">
                    <i data-lucide="receipt" size="18"></i> Print Bill
                </button>
                <div class="grid grid-cols-2 gap-3">
                    <button onclick="editCart()" class="py-3 bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-slate-400 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all flex items-center justify-center gap-1">
                        <i data-lucide="edit-2" size="12"></i> Edit Cart
                    </button>
                    <button onclick="cancelPlacedOrder()" class="py-3 bg-rose-500/10 text-rose-500 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all flex items-center justify-center gap-1">
                        <i data-lucide="trash-2" size="12"></i> Cancel
                    </button>
                </div>
                <button onclick="closeSuccessModal()" class="w-full py-4 bg-slate-100 dark:bg-neutral-800 text-slate-900 dark:text-white rounded-2xl font-black uppercase tracking-widest hover:bg-orange-500 hover:text-white transition-all flex items-center justify-center gap-2 mt-2">
                    <i data-lucide="check" size="18"></i> Done / New Order
                </button>
            </div>
        </div>
    </div>

    <!-- POS Settings Modal -->
    <div id="posSettingsModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[110] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-sm shadow-2xl relative">
            <button onclick="document.getElementById('posSettingsModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500">
                <i data-lucide="x" size="24"></i>
            </button>
            
            <h2 class="text-xl font-black dark:text-white uppercase mb-6 tracking-tight">Terminal Settings</h2>
            
            <div class="space-y-6">
                <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-800/50 rounded-2xl border border-slate-100 dark:border-neutral-800">
                    <div>
                        <p class="text-sm font-bold dark:text-white uppercase tracking-tight">Print KOT Receipt?</p>
                        <p class="text-[10px] text-slate-500 font-medium">Show KOT print option after order</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="kot_print_toggle" onchange="savePOSSettings()" class="sr-only peer">
                        <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-orange-600"></div>
                    </label>
                </div>
                <!-- New Setting: KOT Order List Visibility -->
                <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-800/50 rounded-2xl border border-slate-100 dark:border-neutral-800">
                    <div>
                        <p class="text-sm font-bold dark:text-white uppercase tracking-tight">KOT order List On KOT Screen</p>
                        <p class="text-[10px] text-slate-500 font-medium">Toggle visibility of order list on KOT screen</p>
                    </div>
                    <label id="kot_list_label" class="relative inline-flex items-center cursor-pointer transition-opacity">
                        <input type="checkbox" id="kot_list_toggle" onchange="savePOSSettings()" class="sr-only peer">
                        <div class="w-11 h-6 bg-slate-200 peer-focus:outline-none rounded-full peer dark:bg-neutral-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-neutral-600 peer-checked:bg-orange-600"></div>
                    </label>
                </div>
            </div>

            <button onclick="document.getElementById('posSettingsModal').classList.replace('flex', 'hidden')" class="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase tracking-widest mt-8">Close Settings</button>
        </div>
    </div>

    <script>
        lucide.createIcons();
        let cart = [];
        const currency = '<?= $currency_symbol ?>';

        function togglePOSFullScreen() {
            const sidebar = document.querySelector('aside');
            const isFull = document.body.classList.toggle('pos-full-mode');
            
            if (isFull) {
                sidebar?.classList.add('hidden');
                if (!document.fullscreenElement) {
                    document.documentElement.requestFullscreen().catch(err => console.log(err));
                }
            } else {
                sidebar?.classList.remove('hidden');
                if (document.fullscreenElement) {
                    document.exitFullscreen();
                }
            }
            
            // Update icon
            const btn = document.getElementById('fs-toggle-btn');
            const iconName = isFull ? 'minimize' : 'maximize';
            btn.innerHTML = `<i data-lucide="${iconName}" size="20"></i>`;
            lucide.createIcons();
        }

        document.addEventListener('fullscreenchange', () => {
            if (!document.fullscreenElement && document.body.classList.contains('pos-full-mode')) {
                const sidebar = document.querySelector('aside');
                document.body.classList.remove('pos-full-mode');
                sidebar?.classList.remove('hidden');
                const btn = document.getElementById('fs-toggle-btn');
                btn.innerHTML = `<i data-lucide="maximize" size="20"></i>`;
                lucide.createIcons();
            }
        });

        function filterItems(cat) {
            document.querySelectorAll('.cat-btn').forEach(btn => btn.classList.remove('active-cat'));
            event.target.classList.add('active-cat');

            document.querySelectorAll('.item-card').forEach(card => {
                if (cat === 'all' || card.dataset.category === cat) {
                    card.style.display = 'block';
                } else {
                    card.style.display = 'none';
                }
            });
        }

        function addToCart(p) {
            const existing = cart.find(i => i.id === p.id);
            // Robust Price Selection in JS
            let itemPrice = parseFloat(p.price || 0);
            if (itemPrice <= 0) itemPrice = parseFloat(p.sale_price || 0);

            if (existing) {
                existing.qty++;
            } else {
                cart.push({ 
                    id: p.id, 
                    name: p.name, 
                    price: itemPrice, 
                    qty: 1 
                });
            }
            renderCart();
        }

        function updateQty(index, delta) {
            cart[index].qty += delta;
            if (cart[index].qty <= 0) cart.splice(index, 1);
            renderCart();
        }

        function renderCart() {
            const container = document.getElementById('cartList');
            if (cart.length === 0) {
                container.innerHTML = `<div class="h-full flex flex-col items-center justify-center text-slate-300 dark:text-neutral-700 gap-2 opacity-50"><i data-lucide="shopping-cart" size="48"></i><p class="text-[10px] font-black uppercase tracking-widest text-center">Your basket is empty</p></div>`;
                document.getElementById('posTotal').innerText = currency + '0.00';
                lucide.createIcons();
                return;
            }

            container.innerHTML = cart.map((item, idx) => `
                <div class="flex items-center gap-3 p-4 bg-white dark:bg-neutral-800 border border-slate-100 dark:border-neutral-700 rounded-2xl shadow-sm">
                    <div class="flex-1">
                        <p class="text-xs font-black dark:text-white uppercase tracking-tight line-clamp-1">${item.name}</p>
                        <p class="text-[10px] text-orange-600 font-bold">${currency}${item.price.toFixed(2)}</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <button onclick="updateQty(${idx}, -1)" class="w-8 h-8 flex items-center justify-center rounded-xl bg-slate-100 dark:bg-neutral-900 dark:text-white text-xs font-black">-</button>
                        <span class="text-xs font-black w-6 text-center dark:text-white">${item.qty}</span>
                        <button onclick="updateQty(${idx}, 1)" class="w-8 h-8 flex items-center justify-center rounded-xl bg-slate-100 dark:bg-neutral-900 dark:text-white text-xs font-black">+</button>
                    </div>
                </div>
            `).join('');

            const total = cart.reduce((sum, i) => sum + (i.price * i.qty), 0);
            document.getElementById('posTotal').innerText = currency + total.toFixed(2);
            lucide.createIcons();
        }

        // Function to update the display of the selected table name
        function updateTableStatusDisplay() {
            const selectElement = document.getElementById('posTable');
            const selectedOption = selectElement.options[selectElement.selectedIndex];
            const tableNameDisplay = document.getElementById('selectedTableName');
            if (tableNameDisplay) {
                if (selectedOption.value) {
                    tableNameDisplay.innerText = `Table: ${selectedOption.text.replace('🪑 Table ', '')}`;
                } else {
                    tableNameDisplay.innerText = `Payable Amount`; // Fallback to default text
                }
            }
        }
        // POS Settings Persistence
        function savePOSSettings() {
            const kotPrint = document.getElementById('kot_print_toggle').checked;
            const kotListToggle = document.getElementById('kot_list_toggle');
            const kotListLabel = document.getElementById('kot_list_label');

            // Dependency Logic
            if (!kotPrint) {
                // If Print is OFF, force List to be ON and Disable it
                kotListToggle.checked = true;
                kotListToggle.disabled = true;
                kotListLabel.classList.add('opacity-50', 'cursor-not-allowed');
            } else {
                // If Print is ON, allow user to toggle List
                kotListToggle.disabled = false;
                kotListLabel.classList.remove('opacity-50', 'cursor-not-allowed');
            }

            localStorage.setItem('biltax_pos_kot_print', kotPrint);
            localStorage.setItem('biltax_pos_kot_list', kotListToggle.checked);
        }

        function loadPOSSettings() {
            // Default Print to true if new, but check storage
            const kotPrint = localStorage.getItem('biltax_pos_kot_print') !== 'false';
            const kotList = localStorage.getItem('biltax_pos_kot_list') === 'true';
            document.getElementById('kot_print_toggle').checked = kotPrint;
            document.getElementById('kot_list_toggle').checked = kotList;
            
            // Apply dependency rules immediately
            savePOSSettings();
            
            return { kotPrint, kotList: document.getElementById('kot_list_toggle').checked };
        }

        // Initial Load
        document.addEventListener('DOMContentLoaded', loadPOSSettings);

        // Pre-select table if table_id is in URL
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('table_id')) updateTableStatusDisplay();

        async function checkoutOrder(e) {
            if (cart.length === 0) return alert("Please select items first!");
            
            const tableId = document.getElementById('posTable').value;
            const totalAmount = cart.reduce((sum, i) => sum + (i.price * i.qty), 0);

            const settings = loadPOSSettings();
            const btn = e?.target || document.querySelector('button[onclick="checkoutOrder()"]');
            const originalHTML = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = '<i class="animate-spin" data-lucide="loader-2"></i> Placing...';
            lucide.createIcons();

            const orderData = {
                items: cart.map(i => ({ id: i.id, quantity: i.qty, price: i.price })),
                total_amount: totalAmount,
                table_id: tableId,
                payment_method: 'Cash', // Default for food order creation
                kot_list: settings.kotList // Pass the slider setting to API
            };

            try {
                const response = await fetch('api.php?route=pos/checkout', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(orderData)
                });
                
                const result = await response.json();

                if (result.success) {
                    // Update table status if a table was selected
                    if (tableId) {
                        await fetch('api.php?route=tables/update_status', {
                            method: 'POST',
                            body: JSON.stringify({ id: tableId, status: 'occupied' })
                        });
                    }
                    
                    // Configure Print Visibility based on Settings
                    const settings = loadPOSSettings();
                    const kotBtn = document.getElementById('printKOTBtn');
                    if (settings.kotPrint) {
                        kotBtn.classList.remove('hidden');
                    } else {
                        kotBtn.classList.add('hidden');
                    }

                    // Show Success Modal
                    const modal = document.getElementById('successModal');
                    modal.classList.remove('hidden');
                    modal.classList.add('flex');

                    // Configure Print Buttons
                    document.getElementById('printKOTBtn').onclick = () => window.open(`print_kot.php?sale_id=${result.sale_id}`, '_blank');
                    document.getElementById('printBillBtn').onclick = () => window.open(`print_receipt.php?sale_id=${result.sale_id}`, '_blank');
                } else {
                    alert("Error: " + result.message);
                }
            } catch (err) {
                console.error(err);
                alert("Failed to connect to server.");
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalHTML;
                lucide.createIcons();
            }
        }

        function closeSuccessModal() {
            // Clear cart and UI only when 'Done' is clicked
            cart = [];
            document.getElementById('posTable').value = "";
            renderCart();
            document.getElementById('successModal').classList.replace('flex', 'hidden');
        }

        function editCart() {
            // Close modal but keep items in cart
            document.getElementById('successModal').classList.replace('flex', 'hidden');
        }

        function cancelPlacedOrder() {
            // Clear cart and close modal
            if(!confirm("Are you sure you want to clear this cart?")) return;
            closeSuccessModal();
        }
    </script>

    <style>
        .custom-scrollbar::-webkit-scrollbar {
            width: 4px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #e2e8f0;
            border-radius: 10px;
        }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #262626;
        }
        .animate-in {
            animation: fadeIn 0.3s ease-out;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</body>
</html>