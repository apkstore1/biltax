<?php
// Wholesale Dashboard Stats
$pending_shipments = 0;
$total_products = 0;

if ($tenant_conn) {
    try {
        $stmt = $tenant_conn->query("SELECT COUNT(*) FROM bulk_orders WHERE status = 'pending'");
        $pending_shipments = $stmt->fetchColumn();
        
        $stmt = $tenant_conn->query("SELECT COUNT(*) FROM products");
        $total_products = $stmt->fetchColumn();

        $stmt = $tenant_conn->query("SELECT id, name, sku, stock_level, reorder_point FROM products WHERE stock_level <= reorder_point ORDER BY stock_level ASC LIMIT 5");
        $low_stock_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) { }
}
?>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-purple-100 dark:bg-purple-900/20 text-purple-600 dark:text-purple-500 rounded-xl flex items-center justify-center">
                <i data-lucide="truck" size="24"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-500 dark:text-neutral-500 uppercase">Pending Shipments</p>
                <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo $pending_shipments; ?></p>
            </div>
        </div>
    </div>
    
    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-indigo-100 dark:bg-indigo-900/20 text-indigo-600 dark:text-indigo-500 rounded-xl flex items-center justify-center">
                <i data-lucide="package" size="24"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-500 dark:text-neutral-500 uppercase">Total Products</p>
                <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo $total_products; ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Detailed Usage Section -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <div class="lg:col-span-2 space-y-8">
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <i data-lucide="package-search" class="text-rose-500"></i> Wholesale Stock Alerts
                </h3>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="text-[10px] font-bold uppercase text-slate-400 border-b border-slate-100 dark:border-neutral-800">
                        <tr>
                            <th class="pb-3">Product SKU</th>
                            <th class="pb-3">Qty on Hand</th>
                            <th class="pb-3 text-right">Procurement</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-neutral-900">
                        <?php foreach($low_stock_list as $item): ?>
                        <tr class="group">
                            <td class="py-3">
                                <p class="text-sm font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($item['name']); ?></p>
                                <p class="text-[10px] text-slate-400"><?php echo htmlspecialchars($item['sku']); ?></p>
                            </td>
                            <td class="py-3">
                                <span class="text-sm font-black text-rose-500"><?php echo $item['stock_level']; ?></span>
                            </td>
                            <td class="py-3 text-right">
                                <a href="purchase_entry.php?product_id=<?php echo $item['id']; ?>" class="inline-flex items-center gap-1 px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-black text-[10px] font-black rounded-lg transition-transform active:scale-95">
                                    RESTOCK NOW
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="bg-white dark:bg-neutral-950 p-8 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm transition-colors">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-xl font-black text-slate-900 dark:text-white">Storage Usage</h3>
            <i data-lucide="database" class="text-amber-500"></i>
        </div>
        <p class="text-3xl font-black text-slate-900 dark:text-white mb-2">1.2 GB <span class="text-sm text-slate-400 font-medium">/ 5 GB</span></p>
        <p class="text-sm text-slate-500 dark:text-neutral-500 mb-6 font-bold uppercase tracking-wider">3.8 GB Space Remaining</p>
        
        <div class="w-full bg-slate-100 dark:bg-neutral-800 rounded-full h-4 mb-4 overflow-hidden">
            <div class="bg-amber-500 h-full rounded-full transition-all duration-1000" style="width: 24%"></div>
        </div>
        <p class="text-xs text-slate-400 dark:text-neutral-600 italic">24.5% of your total capacity is used.</p>
    </div>
</div>