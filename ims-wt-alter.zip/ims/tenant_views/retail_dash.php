<?php
// Retail Dashboard Stats
$low_stock = 0;
$today_sales = 0;

if ($tenant_conn) {
    try {
        $stmt = $tenant_conn->query("SELECT COUNT(*) FROM products WHERE stock_level <= reorder_point");
        $low_stock = $stmt->fetchColumn();

        $stmt = $tenant_conn->query("SELECT SUM(total_amount) FROM sales WHERE DATE(created_at) = CURDATE()");
        $today_sales = $stmt->fetchColumn() ?: 0;

        // Fetch low stock items for the widget
        $stmt = $tenant_conn->query("SELECT id, name, sku, stock_level, reorder_point FROM products WHERE stock_level <= reorder_point ORDER BY stock_level ASC LIMIT 5");
        $low_stock_list = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e) { }
}
?>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-red-100 dark:bg-red-900/20 text-red-600 dark:text-red-500 rounded-xl flex items-center justify-center">
                <i data-lucide="alert-triangle" size="24"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-500 dark:text-neutral-500 uppercase">Low Stock Alerts</p>
                <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo $low_stock; ?></p>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-green-100 dark:bg-green-900/20 text-green-600 dark:text-green-500 rounded-xl flex items-center justify-center">
                <i data-lucide="dollar-sign" size="24"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-500 dark:text-neutral-500 uppercase">Today's Sales</p>
                <p class="text-3xl font-black text-slate-900 dark:text-white">$<?php echo number_format($today_sales, 2); ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Detailed Usage Section -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <div class="lg:col-span-2 space-y-8">
        <!-- Low Stock Alert Widget -->
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-lg font-bold text-slate-900 dark:text-white flex items-center gap-2">
                    <i data-lucide="alert-circle" class="text-rose-500"></i> Critical Stock Levels
                </h3>
                <a href="products.php" class="text-xs font-bold text-orange-500 hover:underline">View All Inventory</a>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="text-[10px] font-bold uppercase text-slate-400 border-b border-slate-100 dark:border-neutral-800">
                        <tr>
                            <th class="pb-3">Product</th>
                            <th class="pb-3">Current</th>
                            <th class="pb-3 text-right">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-50 dark:divide-neutral-900">
                        <?php foreach($low_stock_list as $item): ?>
                        <tr class="group">
                            <td class="py-3">
                                <p class="text-sm font-bold text-slate-800 dark:text-white"><?php echo htmlspecialchars($item['name']); ?></p>
                                <p class="text-[10px] text-slate-400"><?php echo htmlspecialchars($item['sku']); ?></p>
                            </td>
                            <td class="py-3">
                                <span class="text-sm font-black text-rose-500"><?php echo $item['stock_level']; ?></span>
                                <span class="text-[10px] text-slate-400">/ <?php echo $item['reorder_point']; ?></span>
                            </td>
                            <td class="py-3 text-right">
                                <a href="purchase_entry.php?product_id=<?php echo $item['id']; ?>" class="inline-flex items-center gap-1 px-3 py-1.5 bg-orange-500 hover:bg-orange-600 text-white text-[10px] font-bold rounded-lg transition-transform active:scale-95">
                                    <i data-lucide="shopping-cart" size="12"></i> Quick Order
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                        <?php if(empty($low_stock_list)): ?>
                            <tr><td colspan="3" class="py-10 text-center text-sm text-slate-400 italic">Inventory levels are healthy.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="flex flex-col gap-8">
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm transition-colors">
            <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-6">Recent Transactions</h3>
            <div class="text-center py-10 text-slate-400 text-sm italic">No recent sales found</div>
        </div>
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm transition-colors">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-lg font-bold text-slate-900 dark:text-white">Storage Usage</h3>
                <i data-lucide="database" class="text-amber-500"></i>
            </div>
            <p class="text-3xl font-black text-slate-900 dark:text-white mb-2">1.2 GB <span class="text-sm text-slate-400 font-medium">/ 5 GB</span></p>
            <p class="text-sm text-slate-500 dark:text-neutral-500 mb-6 font-bold uppercase tracking-wider">3.8 GB Remaining</p>
            <div class="w-full bg-slate-100 dark:bg-neutral-800 rounded-full h-4 mb-4 overflow-hidden">
                <div class="bg-amber-500 h-full rounded-full" style="width: 24%"></div>
            </div>
            <p class="text-[11px] text-slate-400 dark:text-neutral-600 italic">Usage is calculated based on database records and uploaded assets.</p>
        </div>
    </div>
</div>