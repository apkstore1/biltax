<?php
// Service Dashboard Stats
$active_jobs = 0;
$pending_reminders = 0;

if ($tenant_conn) {
    try {
        $stmt = $tenant_conn->query("SELECT COUNT(*) FROM job_cards WHERE status = 'in_progress'");
        $active_jobs = $stmt->fetchColumn();

        $stmt = $tenant_conn->query("SELECT COUNT(*) FROM reminders WHERE status = 'pending'");
        $pending_reminders = $stmt->fetchColumn();
    } catch (PDOException $e) { }
}
?>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-teal-100 dark:bg-teal-900/20 text-teal-600 dark:text-teal-500 rounded-xl flex items-center justify-center">
                <i data-lucide="wrench" size="24"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-500 dark:text-neutral-500 uppercase">Active Jobs</p>
                <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo $active_jobs; ?></p>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-yellow-100 dark:bg-yellow-900/20 text-yellow-600 dark:text-yellow-500 rounded-xl flex items-center justify-center">
                <i data-lucide="bell" size="24"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-500 dark:text-neutral-500 uppercase">Pending Reminders</p>
                <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo $pending_reminders; ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Detailed Usage Section -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <div class="lg:col-span-2">
        <div class="bg-slate-100 dark:bg-neutral-800/20 border border-dashed border-slate-200 dark:border-neutral-800 rounded-3xl h-[300px] flex items-center justify-center text-slate-400">
            Job Status Analytics Loading...
        </div>
    </div>
    <div class="bg-white dark:bg-neutral-950 p-8 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm transition-colors">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-xl font-black text-slate-900 dark:text-white">Storage Usage</h3>
            <i data-lucide="database" class="text-amber-500"></i>
        </div>
        <p class="text-3xl font-black text-slate-900 dark:text-white mb-2">1.2 GB <span class="text-sm text-slate-400 font-medium">/ 5 GB</span></p>
        <p class="text-sm text-slate-500 dark:text-neutral-500 mb-6 font-bold uppercase tracking-wider">3.8 GB Space Remaining</p>
        
        <div class="w-full bg-slate-100 dark:bg-neutral-800 rounded-full h-4 mb-4 overflow-hidden">
            <div class="bg-amber-500 h-full rounded-full transition-all duration-1000" style="width: 24%"></div>
        </div>
        <p class="text-xs text-slate-400 dark:text-neutral-600 italic">24.5% of your total capacity is used.</p>
    </div>
</div>