<?php
// Restaurant Dashboard Stats
$occupied_tables = 0;
$pending_orders = 0;

if ($tenant_conn) {
    try {
        $stmt = $tenant_conn->query("SELECT COUNT(*) FROM restaurant_tables WHERE status = 'occupied'");
        $occupied_tables = $stmt->fetchColumn();

        $stmt = $tenant_conn->query("SELECT COUNT(*) FROM orders WHERE status IN ('pending', 'cooking')");
        $pending_orders = $stmt->fetchColumn();
    } catch (PDOException $e) { }
}
?>
<div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-orange-100 dark:bg-orange-900/20 text-orange-600 dark:text-orange-500 rounded-xl flex items-center justify-center">
                <i data-lucide="users" size="24"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-500 dark:text-neutral-500 uppercase">Occupied Tables</p>
                <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo $occupied_tables; ?></p>
            </div>
        </div>
    </div>

    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
        <div class="flex items-center gap-4">
            <div class="w-12 h-12 bg-blue-100 dark:bg-blue-900/20 text-blue-600 dark:text-blue-500 rounded-xl flex items-center justify-center">
                <i data-lucide="chef-hat" size="24"></i>
            </div>
            <div>
                <p class="text-sm font-bold text-slate-500 dark:text-neutral-500 uppercase">Kitchen Orders</p>
                <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo $pending_orders; ?></p>
            </div>
        </div>
    </div>
</div>

<!-- Detailed Usage Section -->
<div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
    <div class="lg:col-span-2">
        <div class="bg-slate-100 dark:bg-neutral-800/20 border border-dashed border-slate-200 dark:border-neutral-800 rounded-3xl h-[300px] flex items-center justify-center text-slate-400">
            Recent Orders Analytics Loading...
        </div>
    </div>
    <div class="bg-white dark:bg-neutral-950 p-8 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm transition-colors">
        <div class="flex items-center justify-between mb-6">
            <h3 class="text-xl font-black text-slate-900 dark:text-white">Storage Usage</h3>
            <i data-lucide="database" class="text-amber-500"></i>
        </div>
        <p class="text-3xl font-black text-slate-900 dark:text-white mb-2">1.2 GB <span class="text-sm text-slate-400 font-medium">/ 5 GB</span></p>
        <p class="text-sm text-slate-500 dark:text-neutral-500 mb-6 font-bold uppercase tracking-wider">3.8 GB Space Remaining</p>
        
        <div class="w-full bg-slate-100 dark:bg-neutral-800 rounded-full h-4 mb-4 overflow-hidden">
            <div class="bg-amber-500 h-full rounded-full transition-all duration-1000" style="width: 24%"></div>
        </div>
        <p class="text-xs text-slate-400 dark:text-neutral-600 italic">24.5% of your total capacity is used.</p>
    </div>
</div>