<?php
/**
 * Biltax Universal Cron Engine
 * Centralized task scheduler for multi-tenant service ecosystem.
 */

require_once 'config/db_connect.php';

// 1. Security Check (Secret Key)
$secret_key = "BILTAX_SECRET_786"; // Change this in production
if (!isset($_GET['key']) || $_GET['key'] !== $secret_key) {
    http_response_code(403);
    die("Access Denied: Invalid Security Key.");
}

try {
    // 2. Connect to Central Database
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 3. Super Admin Integration (Global Enable/Disable)
    // Self-healing: Check if cron_enabled setting exists
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS system_settings (id INT PRIMARY KEY, cron_enabled TINYINT(1) DEFAULT 1)");
    $cron_enabled = $main_pdo->query("SELECT cron_enabled FROM system_settings LIMIT 1")->fetchColumn();
    
    if ($cron_enabled === '0') {
        die("Cron System is globally disabled by Super Admin.");
    }

    // 4. Fetch All Active Tenants
    $tenants = $main_pdo->query("SELECT id, db_name, business_name FROM tenants WHERE status = 'active'")->fetchAll(PDO::FETCH_ASSOC);

    foreach ($tenants as $t) {
        $db_name = $t['db_name'];
        try {
            // Connect to Tenant Database
            $t_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$db_name", DB_USER, DB_PASS);
            $t_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            // 5. Fetch Active Jobs for this Tenant from universal_cron_configs
            $jobs = $t_pdo->query("SELECT * FROM universal_cron_configs WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($jobs as $job) {
                $job_status = 'success';
                $job_message = "Executed successfully.";

                // --- TASK EXECUTION LOGIC ---
                if ($job['job_name'] === 'service_reminder') {
                    $job_message = executeServiceReminder($t_pdo, $t['id']);
                }

                // Record Execution Log
                $stmt_log = $t_pdo->prepare("INSERT INTO universal_cron_logs (job_name, status, message) VALUES (?, ?, ?)");
                $stmt_log->execute([$job['job_name'], $job_status, $job_message]);

                // Update Last Run in Config
                $t_pdo->prepare("UPDATE universal_cron_configs SET last_run = NOW() WHERE id = ?")->execute([$job['id']]);
            }

        } catch (Exception $e) {
            error_log("Cron Error for Tenant {$t['business_name']}: " . $e->getMessage());
        }
    }

    echo "Cron Job Cycle Completed at " . date('Y-m-d H:i:s');

} catch (Exception $e) {
    die("Central Cron Error: " . $e->getMessage());
}

/**
 * Task: Service Reminder Logic
 * Checks for recurring services that are due based on last_service_date.
 */
function executeServiceReminder($pdo, $tenant_id) {
    $count = 0;
    $today = date('Y-m-d');
    
    // Logic: last_service_date + interval <= today
    $query = "SELECT id, name, recurring_type, last_service_date, created_at 
              FROM customers 
              WHERE recurring_type != 'none'";
    
    $customers = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);

    foreach ($customers as $c) {
        $base_date = $c['last_service_date'] ?: $c['created_at'];
        $interval = match($c['recurring_type']) {
            'monthly'   => '1 MONTH',
            'quarterly' => '3 MONTH',
            'yearly'    => '1 YEAR',
            default     => null
        };

        if ($interval) {
            $stmt_check = $pdo->prepare("SELECT (DATE_ADD(?, INTERVAL $interval) <= ?) as is_due");
            $stmt_check->execute([$base_date, $today]);
            
            if ($stmt_check->fetchColumn()) {
                // Check if we already sent a notification for this cycle today
                $title = "Service Reminder: " . $c['name'];
                $msg = "A recurring service for {$c['name']} is now due. Please check their contract.";
                
                $dup = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE title = ? AND DATE(created_at) = ?");
                $dup->execute([$title, $today]);

                if ($dup->fetchColumn() == 0) {
                    $ins = $pdo->prepare("INSERT INTO notifications (title, message) VALUES (?, ?)");
                    $ins->execute([$title, $msg]);
                    $count++;
                }
            }
        }
    }

    return "Reminders generated: $count";
}
?>