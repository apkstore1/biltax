<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Access Denied</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex items-center justify-center">
    <div class="text-center p-8 bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl max-w-md">
        <i data-lucide="lock" size="64" class="text-orange-600 mx-auto mb-6"></i>
        <h1 class="text-3xl font-black uppercase tracking-tight mb-3">Access Denied</h1>
        <p class="text-slate-500 mb-6">
            <?php
                $message = $_GET['msg'] ?? "You do not have permission to access this feature.";
                echo htmlspecialchars($message);
            ?>
        </p>
        <div class="flex flex-col gap-3">
            <?php if (isset($_GET['type']) && $_GET['type'] === 'request_based'): ?>
                <a href="verification_center.php" class="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-indigo-600/20 transition-all">
                    <i data-lucide="send" size="18"></i> Request Access
                </a>
            <?php elseif (isset($_GET['type']) && $_GET['type'] === 'upgrade_required'): ?>
                <a href="setting.php" class="inline-flex items-center gap-2 px-6 py-3 bg-orange-600 hover:bg-orange-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 transition-all">
                    <i data-lucide="zap" size="18"></i> Upgrade Plan
                </a>
            <?php elseif (isset($_GET['feature_locked'])): ?>
                <p class="text-sm font-bold text-orange-600 mb-3">Feature: <?php echo htmlspecialchars($_GET['feature_locked']); ?></p>
                <a href="verification_center.php" class="inline-flex items-center gap-2 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-indigo-600/20 transition-all">
                    <i data-lucide="shield-check" size="18"></i> Go to Verification Center
                </a>
            <?php endif; ?>
            <a href="dashboard.php" class="inline-flex items-center justify-center gap-2 px-6 py-3 bg-slate-200 dark:bg-neutral-800 text-slate-700 dark:text-neutral-300 rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-slate-300 dark:hover:bg-neutral-700 transition-all">
                <i data-lucide="home" size="18"></i> Return to Dashboard
            </a>
        </div>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>