<?php
require_once 'config/db_connect.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Note: Using 'industry_type' from session as set during login.
$industry_type = $_SESSION['industry_type'] ?? 'retail'; // Default to retail if not set
$role = $_SESSION['role'] ?? 'admin';
$business_name = $_SESSION['business_name'] ?? 'Biltax';
$display_name = $_SESSION['staff_name'] ?? $_SESSION['owner_name'] ?? 'Admin';
$display_role = ucfirst($role);
$initials = strtoupper(substr($display_name, 0, 1) . (strpos($display_name, ' ') ? substr(strstr($display_name, ' '), 1, 1) : ''));

function render_menu_button($tab, $icon, $label) {
    global $is_system_locked, $is_system_inactive;
    $current_page = basename($_SERVER['PHP_SELF']);

    // Behavior for Inactive/Locked System
    $lock_class = "";
    $onclick = "setTab('{$tab}')";
    
    // If Inactive (but not hidden by Locked state), apply blur/disable
    if ($is_system_inactive && !is_link_whitelisted($tab . '.php')) {
        $lock_class = "opacity-40 grayscale pointer-events-none cursor-not-allowed";
        $onclick = "return false;";
    }

    $is_dashboard_page = ($current_page == 'dashboard.php' || $current_page == 'index.php');
    
    // Strictly check if we are on the dashboard page before marking a tab as active
    // This prevents Dashboard from appearing active when you are on pos.php
    $current_tab_param = ($is_dashboard_page) ? ($_GET['tab'] ?? 'dashboard') : null;
    $is_active = ($is_dashboard_page && $tab === $current_tab_param);

    $active_class = $is_active ? 'bg-orange-50 dark:bg-orange-500/10 text-orange-600 dark:text-orange-500 border-orange-200 dark:border-orange-500/20' : 'text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white border-transparent';

    // This function helps in creating menu buttons consistently.
    return <<<HTML
    <button class="sidebar-item flex items-center w-full gap-3 px-4 py-3 rounded-xl border {$active_class} {$lock_class} transition-all duration-200 group" data-tab="{$tab}" onclick="{$onclick}">
        <i data-lucide="{$icon}" class="transition-transform group-hover:scale-110"></i>
        <span class="font-medium">{$label}</span>
    </button>
HTML;
}

function is_link_whitelisted($href) {
    $whitelist = [
        'billing_plans_view.php', 'billing_history.php', 'setting.php', 
        'support_tickets.php', 'documentation.php', 'knowledge_base.php', 
        'pay_now.php', 'logout.php', 'auth/logout.php', 'login.php'
    ];
    return in_array(basename($href), $whitelist);
}

function render_submenu_link($href, $icon, $label, $badge_count = 0) {
    global $is_system_locked, $is_system_inactive;
    $is_active = (basename($_SERVER['PHP_SELF']) == basename($href) && basename($href) !== '#');

    // Apply blur if inactive
    $lock_class = ($is_system_inactive && !is_link_whitelisted($href)) ? "opacity-40 grayscale pointer-events-none blur-[0.5px]" : "";

    $active_class = $is_active ? 'bg-orange-50 dark:bg-orange-500/10 text-orange-600 dark:text-orange-500 border-orange-200 dark:border-orange-500/20' : 'text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white border-transparent';
    
    $base_id = str_replace(['.php', '/'], '', basename($href));
    $badge_id = "badge-" . $base_id;
    $dot_id = "dot-" . $base_id;
    $badge_html = '<span id="' . $badge_id . '" class="ml-auto bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full ' . ($badge_count > 0 ? '' : 'hidden') . '">' . ($badge_count > 0 ? $badge_count : '') . '</span>';
    $dot_html = '<span id="' . $dot_id . '" class="absolute top-2 left-7 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>';

    return <<<HTML
    <a href="{$href}" class="relative flex items-center gap-3 px-4 py-2 rounded-xl border transition-all duration-200 group {$active_class} {$lock_class} text-sm ml-4">
        <i data-lucide="{$icon}" size="16"></i>
        {$dot_html}
        <span class="font-medium">{$label}</span>
        {$badge_html}
    </a>
HTML;
}

function render_link_button($href, $icon, $label, $badge_count = 0) {
    global $is_system_locked, $is_system_inactive;
    $is_active = (basename($_SERVER['PHP_SELF']) == basename($href) && basename($href) !== '#');

    // Apply blur if inactive
    $lock_class = ($is_system_inactive && !is_link_whitelisted($href)) ? "opacity-40 grayscale pointer-events-none blur-[0.5px]" : "";

    $active_class = $is_active ? 'bg-orange-50 dark:bg-orange-500/10 text-orange-600 dark:text-orange-500 border-orange-200 dark:border-orange-500/20' : 'text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white border-transparent';
    
    $base_id = str_replace(['.php', '/'], '', basename($href));
    $badge_id = "badge-" . $base_id;
    $dot_id = "dot-" . $base_id;
    $badge_html = '<span id="' . $badge_id . '" class="ml-auto bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse ' . ($badge_count > 0 ? '' : 'hidden') . '">' . ($badge_count > 0 ? $badge_count : '') . '</span>';
    $dot_html = '<span id="' . $dot_id . '" class="absolute top-3 left-7 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>';

    return <<<HTML
    <a href="{$href}" class="sidebar-item relative flex items-center w-full gap-3 px-4 py-3 rounded-xl border {$active_class} {$lock_class} transition-all duration-200 group">
        <i data-lucide="{$icon}" class="transition-transform group-hover:scale-110"></i>
        {$dot_html}
        <span class="font-medium">{$label}</span>
        {$badge_html}
    </a>
HTML;
}

// --- Fetch Enabled Modules for Current Tenant ---
// Note: $active_modules and has_module() are now centrally handled in config/db_switch.php

// Fetch pending counts for badges (Using global main DB connection)
$pending_conn_count = 0;
$pending_returns_count = 0;
try {
    global $host, $user, $pass; // Provided by db_connect.php
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    
    $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
    $stmt->execute([$_SESSION['db_name'] ?? '']);
    $tenant_id = $stmt->fetchColumn();

    if ($tenant_id) {
        // Fetch pending connection requests count
        $c_stmt = $main_pdo->prepare("SELECT COUNT(*) FROM tenant_connections WHERE receiver_id = ? AND status = 'pending'");
        $c_stmt->execute([$tenant_id]);
        $pending_conn_count = $c_stmt->fetchColumn();

        // Fetch pending return requests count (where I am the provider)
        $r_stmt = $main_pdo->prepare("SELECT COUNT(*) FROM b2b_return_requests WHERE provider_id = ? AND status = 'pending'");
        $r_stmt->execute([$tenant_id]);
        $pending_returns_count = $r_stmt->fetchColumn();
    }
} catch (PDOException $e) {
    error_log("Sidebar Module Fetch Error: " . $e->getMessage());
}
?>

<script>
    function toggleSidebarDropdown(menuId, arrowId) {
        const menu = document.getElementById(menuId);
        const arrow = document.getElementById(arrowId);
        menu.classList.toggle('hidden');
        arrow.classList.toggle('rotate-180');
    }
    
    // Ensure setTab works even if we are on a separate PHP page like staff_add.php
    if (typeof setTab === 'undefined') {
        window.setTab = function(tab) {
            window.location.href = 'dashboard.php?tab=' + tab;
        };
    }

    document.addEventListener('DOMContentLoaded', () => {
        const inventoryMenu = document.getElementById('inventory-menu');
        const inventoryArrow = document.getElementById('inventory-arrow');
        const currentPath = window.location.pathname;
        
        if (inventoryMenu && (currentPath.includes('products.php') || currentPath.includes('stock.php') || currentPath.includes('stock_transfer.php') || currentPath.includes('manage_ingredients.php'))) {
            inventoryMenu.classList.remove('hidden');
            inventoryArrow.classList.add('rotate-180');
        }
        
        const purchaseMenu = document.getElementById('purchase-menu');
        const purchaseArrow = document.getElementById('purchase-arrow');
        if (purchaseMenu && (currentPath.includes('create_purchase.php') || currentPath.includes('purchase_management.php') || currentPath.includes('b2b_orders.php') || currentPath.includes('vendor_orders.php') || currentPath.includes('b2b_returns_manager.php'))) {
            purchaseMenu.classList.remove('hidden');
            purchaseArrow.classList.add('rotate-180');
        }

        const partnersMenu = document.getElementById('partners-menu');
        const partnersArrow = document.getElementById('partners-arrow');
        if (partnersMenu && (currentPath.includes('suppliers.php') || currentPath.includes('connect_partner.php') || currentPath.includes('vendors.php'))) {
            partnersMenu.classList.remove('hidden');
            partnersArrow.classList.add('rotate-180');
        }

        const marketplaceMenu = document.getElementById('marketplace-menu');
        const marketplaceArrow = document.getElementById('marketplace-arrow');
        if (marketplaceMenu && (currentPath.includes('marketplace.php') || currentPath.includes('biltax_shop.php') || currentPath.includes('payment_qr.php') || currentPath.includes('invoice_builder.php'))) {
            marketplaceMenu.classList.remove('hidden');
            marketplaceArrow.classList.add('rotate-180');
        }

        const supportMenu = document.getElementById('support-menu');
        const supportArrow = document.getElementById('support-arrow');
        if (supportMenu && (currentPath.includes('support_tickets.php') || currentPath.includes('documentation.php') || currentPath.includes('knowledge_base.php'))) {
            supportMenu.classList.remove('hidden');
            supportArrow.classList.add('rotate-180');
        }

        const serviceMenu = document.getElementById('service-suite-menu');
        const serviceArrow = document.getElementById('service-suite-arrow');
        if (serviceMenu && (currentPath.includes('jobs.php') || currentPath.includes('services.php') || currentPath.includes('customers.php') || currentPath.includes('reminders.php') || currentPath.includes('tech_jobs.php'))) {
            serviceMenu.classList.remove('hidden');
            serviceArrow.classList.add('rotate-180');
        }

        const staffMenu = document.getElementById('staff-menu');
        const staffArrow = document.getElementById('staff-arrow');
        if (staffMenu && (currentPath.includes('staff_list.php') || currentPath.includes('riders_management.php'))) {
            staffMenu.classList.remove('hidden');
            staffArrow.classList.add('rotate-180');
        }

        const financeMenu = document.getElementById('finance-menu');
        const financeArrow = document.getElementById('finance-arrow');
        if (financeMenu && (currentPath.includes('expenses.php') || currentPath.includes('payroll.php') || currentPath.includes('accounts_payable.php') || currentPath.includes('finance_reports.php'))) {
            financeMenu.classList.remove('hidden');
            financeArrow.classList.add('rotate-180');
        }
    });
</script>
<style>
    .sidebar-nav::-webkit-scrollbar { width: 4px; }
    .sidebar-nav::-webkit-scrollbar-track { background: transparent; }
    .sidebar-nav::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
    .dark .sidebar-nav::-webkit-scrollbar-thumb { background: #262626; }
</style>

<!-- Mobile Overlay -->
<div id="sidebar-overlay" onclick="toggleMobileSidebar()" class="fixed inset-0 bg-black/50 z-40 hidden lg:hidden backdrop-blur-sm"></div>

<aside id="main-sidebar" class="fixed lg:sticky top-0 left-0 z-50 w-72 h-screen bg-white dark:bg-neutral-950 border-r border-slate-200 dark:border-neutral-800 p-6 flex flex-col gap-6 transition-all duration-300 transform -translate-x-full lg:translate-x-0 overflow-hidden">
    <!-- Header -->
    <div class="flex items-center justify-between lg:justify-start gap-3 px-2">
        <div class="flex items-center gap-3">
        <div class="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-orange-900/20">
            <!---i data-lucide="layers" size="24"/i--------->
             <img src="assets/Biltax-icon.png" class="w-full h-full object-contain brightness-0 invert" alt="Biltax">
        </div>
        <div>
            <h1 class="text-xl font-bold tracking-tight text-slate-900 dark:text-white">Biltax</h1>
            <p class="text-[10px] font-bold text-orange-500 uppercase tracking-widest"><?php echo htmlspecialchars(ucfirst($industry_type)); ?> Panel</p>
        </div>
        </div>
        <button onclick="toggleMobileSidebar()" class="lg:hidden p-2 text-slate-400 hover:text-orange-500">
            <i data-lucide="x" size="20"></i>
        </button>
    </div>

    <!-- Main Navigation -->
    <nav class="flex-1 space-y-2 overflow-y-auto pr-2 sidebar-nav">
        <?php if (!$is_system_locked && has_module('dashboard')) echo render_menu_button('dashboard', 'layout-dashboard', 'Dashboard'); elseif($is_system_inactive) echo render_menu_button('dashboard', 'layout-dashboard', 'Dashboard'); ?>
        
        <!-- POS Terminals (Checks for any enabled POS module) -->
        <?php 
            $pos_target = ($industry_type === 'restaurant') ? 'food_pos.php' : 'pos.php';
            if (!$is_system_locked || $is_system_inactive)
            if (has_module('pos') || has_module('food_pos') || has_module('retail_pos') || has_module('wholesale_pos') || has_module('service_pos') || has_module('custom_pos')) echo render_link_button($pos_target, 'monitor', 'POS Terminal'); 
        ?>
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('pos_returns')) echo render_link_button('pos_returns.php', 'rotate-ccw', 'POS Returns'); ?>
        
        <!-- Restaurant Modules -->
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('tables')) echo render_menu_button('tables', 'layout-grid', 'Table Management'); ?>
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('kot')) echo render_menu_button('kot', 'chef-hat', 'Kitchen Orders (KOT)'); ?>
        
        <!-- Wholesale Modules -->
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('bulk_sales')) echo render_link_button('bulk_sales.php', 'layers', 'Bulk Sales'); ?>
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('ledgers')) echo render_link_button('ledgers.php', 'book', 'Party Ledger'); ?>

        <!-- Inventory Management -->
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('inventory')): ?>
        <div class="space-y-1">
            <button onclick="toggleSidebarDropdown('inventory-menu', 'inventory-arrow')" class="sidebar-item relative flex items-center w-full gap-3 px-4 py-3 rounded-xl transition-all duration-200 group text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white <?= $is_system_inactive ? 'opacity-40 grayscale pointer-events-none cursor-not-allowed blur-[1px]' : '' ?>">
                <i data-lucide="package" class="transition-transform group-hover:scale-110"></i>
                <span id="dot-inventory" class="absolute top-3 left-7 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>
                <span class="font-medium">Inventory</span>
                <i data-lucide="chevron-down" id="inventory-arrow" size="16" class="ml-auto transition-transform duration-200"></i>
            </button>
            <div id="inventory-menu" class="hidden flex flex-col gap-1">
                <?php if (has_module('recipes')) echo render_submenu_link('manage_ingredients.php', 'book-open', 'Ingredient / Recipe'); ?>
                <?php if (has_module('raw_material_system')) echo render_submenu_link('raw_materials.php', 'box', 'Raw Materials'); ?>
                <?php echo render_submenu_link('products.php', 'list', 'Products'); ?>
                <?php echo render_submenu_link('stock.php', 'activity', 'Stock Management'); ?>
                <?php if (has_module('manage_branches')) echo render_submenu_link('stock_transfer.php', 'repeat', 'Stock Transfer'); ?>
                <?php if (has_module('inventory')) echo render_submenu_link('stock_expiry.php', 'calendar-x', 'Stock Expiry'); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Purchase Management -->
        <?php if ((!$is_system_locked || $is_system_inactive) && (has_module('purchases') || has_module('b2b_orders') || has_module('b2b_returns'))): ?>
        <div class="space-y-1">
            <button onclick="toggleSidebarDropdown('purchase-menu', 'purchase-arrow')" class="sidebar-item relative flex items-center w-full gap-3 px-4 py-3 rounded-xl transition-all duration-200 group text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white <?= $is_system_inactive ? 'opacity-40 grayscale pointer-events-none cursor-not-allowed blur-[1px]' : '' ?>">
                <i data-lucide="shopping-bag" class="transition-transform group-hover:scale-110"></i>
                <span id="dot-purchase" class="absolute top-3 left-7 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>
                <span class="font-medium">Purchases</span>
                <i data-lucide="chevron-down" id="purchase-arrow" size="16" class="ml-auto transition-transform duration-200"></i>
            </button>
            <div id="purchase-menu" class="hidden flex flex-col gap-1">
                <?php if (has_module('purchases')) echo render_submenu_link('create_purchase.php', 'plus-circle', 'New Purchase'); ?>
                <?php if (has_module('purchases')) echo render_submenu_link('purchase_management.php', 'clipboard-list', 'Purchase History'); ?>
                <?php if (has_module('b2b_orders')) echo render_submenu_link('b2b_orders.php', 'truck', 'Orders/Status'); ?>
                <?php if (has_module('vendor_orders')) echo render_submenu_link('vendor_orders.php', 'history', 'Order History'); ?>
                <?php if (has_module('b2b_returns')) echo render_submenu_link('b2b_returns_manager.php', 'undo-2', 'Returns Manager', $pending_returns_count); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Suppliers Dropdown -->
        <?php if ((!$is_system_locked || $is_system_inactive) && (has_module('suppliers') || has_module('partner_network'))): ?>
        <div class="space-y-1">
            <button onclick="toggleSidebarDropdown('partners-menu', 'partners-arrow')" class="sidebar-item relative flex items-center w-full gap-3 px-4 py-3 rounded-xl border text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white border-transparent transition-all duration-200 group <?= $is_system_inactive ? 'opacity-40 grayscale pointer-events-none cursor-not-allowed blur-[1px]' : '' ?>">
                <span id="dot-partners" class="absolute top-3 left-7 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>
                <?php if (has_module('b2b_chat')): ?>
                    <span id="global-chat-dot" class="absolute top-3 left-7 w-2 h-2 bg-orange-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>
                <?php endif; ?>
                <i data-lucide="users-2" class="transition-transform group-hover:scale-110"></i>
                <span class="font-medium">Suppliers</span>
                <i data-lucide="chevron-down" id="partners-arrow" size="16" class="ml-auto transition-transform duration-200"></i>
            </button>
            <div id="partners-menu" class="hidden flex flex-col gap-1">
                <?php if (has_module('suppliers')) echo render_submenu_link('suppliers.php', 'truck', 'Local Suppliers'); ?>
                <?php if (has_module('vendors')) echo render_submenu_link('vendors.php', 'user-plus', 'Manage Vendors'); ?>
                <?php if (has_module('partner_network')) echo render_submenu_link('connect_partner.php', 'share-2', 'Partner Network', $pending_conn_count); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Sales Reports -->
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('sales_reports')) echo render_link_button('sales_report.php', 'bar-chart-horizontal', 'Sales Report'); ?>

        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('barcodes')) echo render_link_button('barcodes.php', 'barcode', 'Barcodes'); ?>

        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('staff')): ?>
        <div class="space-y-1">
            <button onclick="toggleSidebarDropdown('staff-menu', 'staff-arrow')" class="sidebar-item relative flex items-center w-full gap-3 px-4 py-3 rounded-xl transition-all duration-200 group text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white border-transparent <?= $is_system_inactive ? 'opacity-40 grayscale pointer-events-none cursor-not-allowed blur-[1px]' : '' ?>">
                <i data-lucide="users" class="transition-transform group-hover:scale-110"></i>
                <span id="dot-staff" class="absolute top-3 left-7 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>
                <span class="font-medium">Staff</span>
                <i data-lucide="chevron-down" id="staff-arrow" size="16" class="ml-auto transition-transform duration-200"></i>
            </button>
            <div id="staff-menu" class="hidden flex flex-col gap-1">
                <?php echo render_submenu_link('staff_list.php', 'users-2', 'Manage Staff'); ?>
                <?php if (has_module('rider_tracking')) echo render_submenu_link('riders_management.php', 'bike', 'Manage Riders'); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('manage_branches')) echo render_link_button('manage_branches.php', 'git-branch', 'Store & Branches'); ?>
        
        <!-- Service Management -->
        <?php if ((!$is_system_locked || $is_system_inactive) && ($industry_type === 'service' || has_module('jobs'))): ?>
        <div class="space-y-1">
            <button onclick="toggleSidebarDropdown('service-suite-menu', 'service-suite-arrow')" class="sidebar-item relative flex items-center w-full gap-3 px-4 py-3 rounded-xl transition-all duration-200 group text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white <?= $is_system_inactive ? 'opacity-40 grayscale pointer-events-none cursor-not-allowed blur-[1px]' : '' ?>">
                <i data-lucide="wrench" class="transition-transform group-hover:scale-110"></i>
                <span id="dot-service-suite" class="absolute top-3 left-7 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>
                <span class="font-medium">Service Suite</span>
                <i data-lucide="chevron-down" id="service-suite-arrow" size="16" class="ml-auto transition-transform duration-200"></i>
            </button>
            <div id="service-suite-menu" class="hidden flex flex-col gap-1">
                <?php echo render_submenu_link('services.php', 'book-open', 'Service Catalog'); ?>
                <?php if (has_module('jobs')) echo render_submenu_link('jobs.php', 'clipboard-list', 'Active Job Cards'); ?>

                <?php if (has_module('customers')) echo render_submenu_link('customers.php', 'contact-2', 'Customer CRM'); ?>
                <?php if (has_module('reminders')) echo render_submenu_link('reminders.php', 'alarm-clock', 'Service Reminders'); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Finance & Accounts Dropdown -->
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('finance_management')): ?>
        <div class="space-y-1">
            <button onclick="toggleSidebarDropdown('finance-menu', 'finance-arrow')" class="sidebar-item relative flex items-center w-full gap-3 px-4 py-3 rounded-xl transition-all duration-200 group text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white <?= $is_system_inactive ? 'opacity-40 grayscale pointer-events-none cursor-not-allowed blur-[1px]' : '' ?>">
                <i data-lucide="wallet" class="transition-transform group-hover:scale-110"></i>
                <span id="dot-finance" class="absolute top-3 left-7 w-2 h-2 bg-red-500 rounded-full border border-white dark:border-neutral-950 hidden animate-pulse"></span>
                <span class="font-medium">Financials</span>
                <i data-lucide="chevron-down" id="finance-arrow" size="16" class="ml-auto transition-transform duration-200"></i>
            </button>
            <div id="finance-menu" class="hidden flex flex-col gap-1">
                <?php if (has_module('expense_tracker')) echo render_submenu_link('expenses.php', 'receipt', 'Expense Tracker'); ?>
                <?php if (has_module('payroll_system')) echo render_submenu_link('payroll.php', 'banknote', 'Staff Payroll'); ?>
                <?php if (has_module('accounts_payable')) echo render_submenu_link('accounts_payable.php', 'landmark', 'Accounts Payable'); ?>
                <?php if (has_module('finance_reports')) echo render_submenu_link('finance_reports.php', 'pie-chart', 'Financial Reports'); ?>
            </div>
        </div>
        <?php endif; ?>

        <?php if ((!$is_system_locked || $is_system_inactive) && (has_module('biltax_hub') || has_module('shop_module') || has_module('payment_qr') || has_module('invoice_builder'))): ?>
        <div class="space-y-1">
            <button onclick="toggleSidebarDropdown('marketplace-menu', 'marketplace-arrow')" class="sidebar-item flex items-center w-full gap-3 px-4 py-3 rounded-xl transition-all duration-200 group text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white <?= $is_system_inactive ? 'opacity-40 grayscale pointer-events-none cursor-not-allowed blur-[1px]' : '' ?>">
                <i data-lucide="store" class="transition-transform group-hover:scale-110"></i>
                <span class="font-medium">Biltax Hub</span>
                <i data-lucide="chevron-down" id="marketplace-arrow" size="16" class="ml-auto transition-transform duration-200"></i>
            </button>
            <div id="marketplace-menu" class="hidden flex flex-col gap-1">
                <?php if (has_module('biltax_hub')) echo render_submenu_link('marketplace.php', 'globe', 'Marketplace'); ?>
                <?php if (has_module('shop_module')) echo render_submenu_link('biltax_shop.php', 'shopping-cart', 'Biltax Shop'); ?>
                <?php if (has_module('payment_qr')) echo render_submenu_link('payment_qr.php', 'qr-code', 'Payment QR'); ?>
                <?php if (has_module('invoice_builder')) echo render_submenu_link('invoice_builder.php', 'file-text', 'Invoice Builder'); ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Help & Support -->
        <?php if (has_module('support_tickets') || has_module('documentation') || has_module('knowledge_base')): ?>
        <div class="space-y-1">
            <button onclick="toggleSidebarDropdown('support-menu', 'support-arrow')" class="sidebar-item flex items-center w-full gap-3 px-4 py-3 rounded-xl transition-all duration-200 group text-slate-500 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600 dark:hover:text-white">
                <i data-lucide="life-buoy" class="transition-transform group-hover:scale-110"></i>
                <span class="font-medium">Help & Support</span>
                <i data-lucide="chevron-down" id="support-arrow" size="16" class="ml-auto transition-transform duration-200"></i>
            </button>
            <div id="support-menu" class="hidden flex flex-col gap-1">
                <?php if (has_module('support_tickets')) echo render_submenu_link('support_tickets.php', 'ticket', 'Support Tickets'); ?>
                <?php if (has_module('documentation')) echo render_submenu_link('document.html', 'book-open', 'Documentation'); ?>
                <?php if (has_module('knowledge_base')) echo render_submenu_link('knowledge_base.php', 'help-circle', 'Knowledge Base'); ?>
            </div>
        </div>
        <?php endif; ?>
    </nav>

    <!-- Common Navigation -->
    <div class="space-y-2 pt-8 border-t border-slate-100 dark:border-neutral-800">
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('reports')) echo render_menu_button('reports', 'bar-chart-3', 'Reports'); ?>
        <?php if ((!$is_system_locked || $is_system_inactive) && has_module('verification_center')) echo render_link_button('verification_center.php', 'shield-check', 'Verification Center'); ?>
        <?php if ($role === 'admin') echo render_link_button('billing_plans_view.php', 'credit-card', 'Billing & Plans'); ?>
        <?php if (has_module('settings')) echo render_link_button('setting.php', 'settings', 'Settings'); ?>
    </div>

    <!-- User Profile & Logout -->
    <div class="bg-slate-50 dark:bg-neutral-900 p-4 rounded-2xl border border-slate-100 dark:border-neutral-800 transition-colors mt-auto">
        <div class="flex items-center gap-3">
            <div class="w-8 h-8 rounded-full bg-orange-600 flex items-center justify-center text-white text-[10px] font-black"><?php echo htmlspecialchars($initials); ?></div>
            <div>
                <p class="text-sm font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($business_name); ?></p>
                <p class="text-[10px] text-slate-500 dark:text-neutral-400 font-bold uppercase tracking-tighter"><?php echo htmlspecialchars($display_name); ?> • <?= htmlspecialchars($display_role) ?></p>
            </div>
        </div>
        <div class="flex items-center justify-between mt-3 pt-3 border-t border-slate-200 dark:border-neutral-800">
            <button onclick="toggleTheme()" class="text-xs font-medium text-slate-500 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white flex items-center gap-1">
                <i id="theme-icon" data-lucide="moon" size="12"></i> <span id="theme-text">Theme</span>
            </button>
            <a href="auth/logout.php" class="text-xs text-orange-500 hover:underline font-medium">Logout</a>
        </div>
    </div>
</aside>

<script>
    function updateBadge(id, count) {
        const el = document.getElementById('badge-' + id);
        if (!el) return;
        if (count > 0) {
            el.innerText = count;
            el.classList.remove('hidden');
            updateDot(id, true); // Sub-menu par bhi dot dikhao agar number hai
            
            // Propagation: Main menu dot show karo agar sub-menu mein badge hai
            const parentMenu = el.closest('[id$="-menu"]');
            if (parentMenu) {
                const parentId = parentMenu.id.replace('-menu', '');
                updateDot(parentId, true);
            }
        } else {
            el.classList.add('hidden');
            updateDot(id, false);
        }
    }

    function updateDot(id, show) {
        const el = document.getElementById('dot-' + id);
        if (!el) return;
        if (show) el.classList.remove('hidden');
        else el.classList.add('hidden');
    }

    function updateTopbarBadge(count) {
        const el = document.getElementById('topbar-notification-count');
        if (!el) return;
        if (count > 0) {
            el.innerText = count;
            el.parentElement.classList.remove('hidden');
        } else {
            el.parentElement.classList.add('hidden');
        }
    }

    async function fetchSidebarNotifications() {
        try {
            const res = await fetch('api.php?route=notifications/counts');
            const data = await res.json();
            if (data.success) {
                const c = data.counts;
                
                // Reset all dots before update
                document.querySelectorAll('[id^="dot-"]').forEach(d => d.classList.add('hidden'));

                // Numbers
                updateBadge('verification_center', c.verification_requests);
                updateBadge('b2b_orders', c.b2b_orders);
                updateBadge('b2b_returns_manager', c.b2b_returns);
                updateBadge('support_tickets', c.support_tickets);
                updateBadge('reminders', c.service_reminders);
                updateBadge('manage_ingredients', (c.low_stock || 0));
                
                // Update Global Topbar Counter
                updateTopbarBadge(data.total_unread);
                
                // Dots for Dropdowns
                const hasInventoryAlert = (c.low_stock > 0 || c.expiring_stock > 0);
                updateDot('inventory', hasInventoryAlert);
                if (c.low_stock > 0) updateDot('stock', true); // Stock management sub-menu dot
                if (c.expiring_stock > 0) updateDot('stock_expiry', true); // Expiry sub-menu dot
                
                // Local Storage for sound/alert if needed
                if (window.lastNotificationCount && data.total_unread > window.lastNotificationCount) {
                    console.log("New system notification received");
                }
                window.lastNotificationCount = data.total_unread;
            }
        } catch (e) { console.error("Notif Error:", e); }
    }

    document.addEventListener('DOMContentLoaded', () => {
        fetchSidebarNotifications();
        // Poll every 30 seconds
        setInterval(fetchSidebarNotifications, 30000);

        // Auto-scroll sidebar to active menu item
        // 'center' block use karne se item screen ke beech mein rahay ga, upar se gap milay ga
        const activeLink = document.querySelector('aside .bg-orange-50');
        if (activeLink) {
            activeLink.scrollIntoView({ block: 'center', behavior: 'instant' });
        }
    });
</script>

<!-- Tawk.to Live Chat Script (Global Support) -->
<?php if (has_module('live_chat')): ?>
<script type="text/javascript">
    var Tawk_API = Tawk_API || {};
    var Tawk_LoadStart = new Date();

    <?php if (isset($_SESSION['user_id'])): ?>
    // Debugging: Check if PHP session has values (Check browser console)
    console.log("Tawk.to Sync: Attempting to link <?php echo $_SESSION['owner_name']; ?>");

    // Method 1: Direct Visitor Object (Priority)
    Tawk_API.visitor = {
        name  : '<?php echo addslashes($_SESSION['owner_name'] ?? ''); ?>',
        email : '<?php echo addslashes($_SESSION['email'] ?? ''); ?>'
    };

    // Method 2: API setAttributes (Failsafe)
    Tawk_API.onLoad = function(){
        Tawk_API.setAttributes({
            'name'  : '<?php echo addslashes($_SESSION['owner_name'] ?? ''); ?>',
            'email' : '<?php echo addslashes($_SESSION['email'] ?? ''); ?>',
            'tenant_id' : '<?php echo $_SESSION['tenant_id'] ?? 'N/A'; ?>'
        }, function(error){
            if(error) console.error("Tawk.to SetAttributes Error:", error);
        });
    };
    <?php endif; ?>

    (function() {
        var s1 = document.createElement("script"),
            s0 = document.getElementsByTagName("script")[0];
        s1.async = true;
        s1.src = 'https://embed.tawk.to/69dbe42329364d1c333e341b/1jm1f6aov';
        s1.charset = 'UTF-8';
        s1.setAttribute('crossorigin', '*');
        s0.parentNode.insertBefore(s1, s0);
    })();
</script>
<?php endif; ?>