<?php
require_once 'config/db_switch.php';

// Check if user is logged in
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

$industry_type = strtolower(trim($_SESSION['industry_type'] ?? 'retail'));

// Route based on Enabled Module Key or fallback to industry
if (has_module('food_pos') || (has_module('pos') && $industry_type === 'restaurant')) {
    // Safe include for Food POS to prevent blank white pages
    if (file_exists('food_pos.php')) {
        include 'food_pos.php';
    } else {
        echo "<div style='padding:50px; text-align:center; font-family:sans-serif;'><h1>404 - Food POS Not Found</h1><p>Specialized restaurant interface is missing. Please contact support.</p><a href='dashboard.php' style='color:orange; font-weight:bold;'>Back to Dashboard</a></div>";
        exit;
    }
} elseif (has_module('retail_pos') || has_module('wholesale_pos') || has_module('service_pos') || has_module('custom_pos') || has_module('pos')) {
    // Define labels based on module
    $pos_title = has_module('wholesale_pos') ? 'Wholesale POS' : (has_module('service_pos') ? 'Service POS' : 'Retail POS');
    
    // Load the Barcode-based Retail POS
    // Multi-Branch Fix: Only fetch products for the active branch
    $active_branch = $_SESSION['active_branch_id'] ?? null;
    $is_all = ($active_branch === 'all');
    $stock_branch = $is_all ? null : get_active_stock_branch_id($active_branch);

    $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
    $main_id = $stmt_main->fetchColumn();

    $where_clause = "WHERE stock_level > 0";
    $params = [];

    if (!$is_all) {
        if ($stock_branch == $main_id) {
            $where_clause .= " AND (branch_id = ? OR branch_id IS NULL)";
        } else {
            $where_clause .= " AND branch_id = ?";
        }
        $params[] = $stock_branch;
    }

    $products_stmt = $tenant_conn->prepare("SELECT p.id, p.name, p.sale_price as price, p.sku, p.stock_level, u.name as unit_name FROM products p LEFT JOIN units u ON p.unit_id = u.id $where_clause ORDER BY p.name ASC");
    $products_stmt->execute($params);
    $products = $products_stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>POS Terminal - Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        .cart-scroll::-webkit-scrollbar { width: 4px; }
        .cart-scroll::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        
        @media print {
            .no-print { display: none !important; }
            #receipt-print-area { 
                display: block !important; 
                width: 72mm; /* Standard Thermal Paper Width */
                margin: 0 auto; 
                font-family: 'Courier New', Courier, monospace; 
                color: black !important;
                text-transform: uppercase;
            }
            body { background: white !important; }
            @page { margin: 0; }
        }
        #receipt-print-area { display: none; line-height: 1.3; }
        .receipt-divider { border-top: 1px dashed #000; margin: 8px 0; }
    </style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors duration-300 relative">

    <!-- Hidden Print Area -->
    <div id="receipt-print-area" class="p-2 text-[11px]">
        <div class="text-center mb-4">
            <?php if (!empty($logo_url)): ?>
                <img src="<?= $logo_url ?>" class="h-10 mx-auto mb-1 object-contain" style="filter: grayscale(1) brightness(0);">
            <?php else: ?>
                <h1 class="text-lg font-black mb-1"><?= htmlspecialchars($business_name) ?></h1>
            <?php endif; ?>
            <p class="text-[9px] font-bold"><?= htmlspecialchars($_SESSION['address'] ?? 'Main Branch') ?></p>
            <p class="text-[9px]">Tel: <?= htmlspecialchars($_SESSION['phone'] ?? '') ?></p>
        </div>
        
        <div class="receipt-divider"></div>
        
        <div class="flex justify-between text-[9px] font-bold">
            <span>Inv: #<span id="r-inv-id"></span></span>
            <span id="r-date"></span>
        </div>
        
        <div class="receipt-divider"></div>
        
        <div class="flex font-bold mb-1 text-[9px]">
            <span class="flex-1">Description</span>
            <span class="w-12 text-center">Qty</span>
            <span class="w-16 text-right">Amount</span>
        </div>
        <div id="receipt-items-list" class="space-y-1"></div>
        
        <div class="receipt-divider"></div>
        
        <div id="receipt-totals" class="space-y-1"></div>
        
        <div class="receipt-divider"></div>
        
        <div class="text-center mt-6 space-y-1">
            <p class="font-bold text-xs">*** Thank You ***</p>
            <p class="text-[8px]">Follow us on social media for updates</p>
            <p class="text-[8px] italic">No refund without original receipt.</p>
            <div class="mt-4 pt-4 border-t border-black/10">
                <p class="text-[8px] font-mono">Powered by Biltax</p>
            </div>
        </div>
    </div>

    <div class="no-print flex w-full">
        <?php include 'sidebar.php'; ?>

    <main class="flex-1 flex flex-col h-screen overflow-hidden">
        <!-- Header -->
        <header class="p-6 flex justify-between items-center bg-white dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
            <div>
                <h2 class="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight"><?= $pos_title ?> Terminal</h2>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest"><?= ucfirst($industry_type) ?> Mode</p>
            </div>
            <div class="flex items-center gap-4">
                <?php if (has_module('pos_returns')): ?>
                <a href="pos_returns.php" class="flex items-center gap-2 px-4 py-2 bg-rose-600/10 text-rose-600 border border-rose-600/20 rounded-xl font-bold uppercase text-[10px] hover:bg-rose-600 hover:text-white transition-all shadow-sm">
                    <i data-lucide="rotate-ccw" size="14"></i> Sales Return
                </a>
                <?php endif; ?>
                <?php if (has_module('receipt_reprint') && $allow_receipt_reprint): ?>
                <button onclick="document.getElementById('reprintModal').classList.replace('hidden', 'flex')" class="flex items-center gap-2 px-4 py-2 bg-blue-600/10 text-blue-600 border border-blue-600/20 rounded-xl font-bold uppercase text-[10px] hover:bg-blue-600 hover:text-white transition-all shadow-sm">
                    <i data-lucide="printer" size="14"></i> Reprint Old Receipt
                </button>
                <?php endif; ?>
                <button onclick="toggleFullScreen()" id="fs-toggle-btn" class="p-2.5 rounded-xl bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-neutral-400 hover:text-orange-500 transition-colors" title="Toggle Sidebar">
                    <i data-lucide="maximize" size="18"></i>
                </button>
                <?php include 'topbar.php'; ?>
            </div>
        </header>

        <!-- Global Verification Alert Bar -->
        <div class="px-6 pt-4"><?php include 'alert_bar.php'; ?></div>

        <div class="flex-1 flex overflow-hidden">
            <!-- Left: Product Search & List -->
            <div class="flex-1 p-6 flex flex-col gap-6 overflow-hidden">
                <div class="relative">
                    <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                    <input type="text" id="barcode-input" placeholder="Scan Barcode or Type Product Name..." autofocus
                        class="w-full pl-12 pr-4 py-4 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-sm outline-none focus:border-orange-500 dark:text-white text-lg transition-all">
                </div>

                <div class="flex-1 overflow-y-auto flex flex-col gap-2 pb-10">
                    <?php foreach($products as $p): ?>
                    <div onclick="addToCart(<?= htmlspecialchars(json_encode($p)) ?>)" 
                        class="bg-white dark:bg-neutral-950 p-4 rounded-xl border border-slate-100 dark:border-neutral-800 shadow-sm hover:border-orange-500 cursor-pointer flex items-center justify-between group transition-all">
                        <div class="flex items-center gap-4">
                            <div class="w-10 h-10 bg-slate-50 dark:bg-neutral-900 rounded-lg flex items-center justify-center text-slate-400 group-hover:text-orange-500 transition-colors">
                                <i data-lucide="package" size="20"></i>
                            </div>
                            <div>
                                <h4 class="font-bold text-slate-900 dark:text-white text-sm"><?= htmlspecialchars($p['name']) ?></h4>
                                <p class="text-[10px] text-slate-400 font-mono uppercase tracking-tighter"><?= htmlspecialchars($p['sku'] ?: 'No SKU') ?></p>
                            </div>
                        </div>
                        <div class="text-right">
                            <div class="text-orange-600 font-black text-sm"><?= $currency_symbol ?><?= number_format($p['price'], 2) ?></div>
                            <div class="text-[10px] font-bold <?= $p['stock_level'] > 10 ? 'text-emerald-500' : 'text-rose-500' ?>"><?= $p['stock_level'] ?> in stock</div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Right: Cart & Checkout -->
            <div class="w-96 bg-white dark:bg-neutral-950 border-l border-slate-200 dark:border-neutral-800 flex flex-col shadow-2xl z-10">
                <div class="p-6 border-b border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                    <h3 class="font-black text-slate-900 dark:text-white uppercase tracking-wider">Current Sale</h3>
                    <button onclick="clearCart()" class="text-xs font-bold text-rose-500 hover:underline">Clear All</button>
                </div>

                <div id="cart-items" class="flex-1 overflow-y-auto p-4 space-y-3 cart-scroll">
                    <!-- Items injected here -->
                    <div class="h-full flex flex-col items-center justify-center text-slate-300 gap-2 opacity-50">
                        <i data-lucide="shopping-basket" size="48"></i>
                        <p class="text-sm font-bold uppercase tracking-widest">Cart is Empty</p>
                    </div>
                </div>

                <div class="p-6 bg-slate-50 dark:bg-neutral-900/50 space-y-4">
                    <div class="flex justify-between text-sm font-bold text-slate-500">
                        <span>Subtotal</span>
                        <span id="subtotal"><?= $currency_symbol ?>0.00</span>
                    </div>
                    <div class="flex justify-between text-xl font-black text-slate-900 dark:text-white">
                        <span>Total</span>
                        <span id="total"><?= $currency_symbol ?>0.00</span>
                    </div>
                    <button onclick="processCheckout()" class="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-4 rounded-2xl shadow-lg shadow-orange-600/20 transition-all active:scale-95 flex items-center justify-center gap-2">
                        <i data-lucide="banknote"></i> COMPLETE SALE
                    </button>
                </div>
            </div>
        </div>
    </main>

    <script>
        let cart = [];
        const currencySymbol = '<?= $currency_symbol ?>';
        const maxDiscountLimit = <?= $max_discount_limit ?>; // Settings se max discount limit fetch ki
        const discountLimitType = '<?= $discount_limit_type ?>';

        function addToCart(product) {
            const existing = cart.find(item => item.id === product.id);
            if (existing) {
                existing.qty++;
            } else {
                cart.push({ ...product, qty: 1 });
            }
            renderCart();
        }

        function renderCart() {
            const container = document.getElementById('cart-items');
            if (cart.length === 0) {
                container.innerHTML = `<div class="h-full flex flex-col items-center justify-center text-slate-300 gap-2 opacity-50"><i data-lucide="shopping-basket" size="48"></i><p class="text-sm font-bold uppercase tracking-widest">Cart is Empty</p></div>`;
                document.getElementById('subtotal').innerText = currencySymbol + '0.00';
                document.getElementById('total').innerText = currencySymbol + '0.00';
                lucide.createIcons();
                return;
            }

            container.innerHTML = cart.map((item, index) => `
                <div class="flex items-center gap-3 p-3 bg-white dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-xl shadow-sm">
                    <div class="flex-1">
                        <p class="text-sm font-bold text-slate-900 dark:text-white line-clamp-1">${item.name}</p>
                        <p class="text-[10px] text-orange-500 font-bold">${currencySymbol}${item.price} x ${item.qty}</p>
                    </div>
                    <div class="flex items-center gap-2">
                        <button onclick="updateQty(${index}, -1)" class="w-6 h-6 flex items-center justify-center rounded bg-slate-100 dark:bg-neutral-800 text-slate-500">-</button>
                        <span class="text-xs font-black w-6 text-center text-slate-900 dark:text-white">${item.qty}</span>
                        <button onclick="updateQty(${index}, 1)" class="w-6 h-6 flex items-center justify-center rounded bg-slate-100 dark:bg-neutral-800 text-slate-500">+</button>
                    </div>
                    <button onclick="removeFromCart(${index})" class="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-lg transition-colors">
                        <i data-lucide="trash-2" size="14"></i>
                    </button>
                </div>
            `).join('');

            let subtotal = cart.reduce((acc, item) => acc + (item.price * item.qty), 0);
            document.getElementById('subtotal').innerText = currencySymbol + subtotal.toFixed(2);
            document.getElementById('total').innerText = currencySymbol + subtotal.toFixed(2);
            lucide.createIcons();
        }

        function updateQty(index, delta) {
            cart[index].qty += delta;
            if (cart[index].qty <= 0) cart.splice(index, 1);
            renderCart();
        }

        function removeFromCart(index) {
            cart.splice(index, 1);
            renderCart();
        }

        function clearCart() {
            cart = [];
            renderCart();
        }

        let selectedPaymentMethod = 'Cash';
        let lastSaleInfo = null;

        function processCheckout() {
            if (cart.length === 0) return alert("Cart is empty!");
            const subtotal = cart.reduce((acc, item) => acc + (item.price * item.qty), 0);
            document.getElementById('checkout-total-display').innerText = currencySymbol + subtotal.toFixed(2);
            document.getElementById('amount-received-input').value = '';
            document.getElementById('discount-input').value = '0';
            document.getElementById('change-display').innerText = currencySymbol + '0.00';
            document.getElementById('checkoutModal').classList.replace('hidden', 'flex');
        }

        function setPaymentMethod(method, btn) {
            selectedPaymentMethod = method;
            document.querySelectorAll('.pay-method-btn').forEach(b => {
                b.classList.remove('bg-orange-600', 'text-white', 'border-orange-600');
                b.classList.add('bg-slate-50', 'dark:bg-neutral-800', 'text-slate-500');
            });
            btn.classList.remove('bg-slate-50', 'dark:bg-neutral-800', 'text-slate-500');
            btn.classList.add('bg-orange-600', 'text-white', 'border-orange-600');
        }

        function calculateChange() {
            const total = cart.reduce((acc, item) => acc + (item.price * item.qty), 0);
            const discount = parseFloat(document.getElementById('discount-input').value) || 0;
            const received = parseFloat(document.getElementById('amount-received-input').value) || 0;
            
            // Client-side validation for discount limit
            if (total > 0 && discount > 0) {
                let limitExceeded = false;
                if (discountLimitType === 'fixed') {
                    if (discount > maxDiscountLimit) limitExceeded = true;
                } else {
                    const discountPercentage = (discount / total) * 100;
                    if (parseFloat(discountPercentage.toFixed(2)) > parseFloat(maxDiscountLimit)) limitExceeded = true;
                }

                if (limitExceeded) {
                    document.getElementById('discount-input').classList.add('border-rose-500'); // Highlight input
                    document.getElementById('discount-error-msg').classList.remove('hidden');
                } else {
                    document.getElementById('discount-input').classList.remove('border-rose-500');
                    document.getElementById('discount-error-msg').classList.add('hidden');
                }
            } else {
                document.getElementById('discount-input').classList.remove('border-rose-500');
                document.getElementById('discount-error-msg').classList.add('hidden');
            }

            const payable = total - discount;
            const change = received - payable;
            
            document.getElementById('change-display').innerText = currencySymbol + (change > 0 ? change.toFixed(2) : '0.00');
            
            // Highlight red if received is less than payable
            if (received < payable && received > 0) {
                document.getElementById('change-display').classList.add('text-rose-500');
            } else {
                document.getElementById('change-display').classList.remove('text-rose-500');
            }
        }

        async function finalCheckout() {
            const subtotal = cart.reduce((acc, item) => acc + (item.price * item.qty), 0);
            const discount = parseFloat(document.getElementById('discount-input').value) || 0;
            const finalTotal = subtotal - discount;

            // Final strict validation check - Blocking any bypass
            const discountPercentage = subtotal > 0 ? (discount / subtotal) * 100 : 0;
            if (parseFloat(discountPercentage.toFixed(2)) > parseFloat(maxDiscountLimit)) {
                return alert(`CHECKOUT DENIED: Discount (${discountPercentage.toFixed(2)}%) exceeds your allowed limit of ${maxDiscountLimit}%.`);
            }

            if (finalTotal < 0) return alert("Discount cannot be greater than total amount.");

            const checkoutBtn = document.getElementById('final-checkout-btn');
            checkoutBtn.disabled = true;
            checkoutBtn.innerText = 'Processing...';

            try {
                const response = await fetch('api.php?route=pos/checkout', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        items: cart.map(i => ({ id: i.id, quantity: i.qty, price: i.price })),
                        total_amount: finalTotal,
                        discount_amount: discount,
                        payment_method: selectedPaymentMethod
                    })
                });
                
                const result = await response.json();
                
                if (result.success) {
                    lastSaleInfo = {
                        id: result.sale_id,
                        items: [...cart],
                        total: finalTotal,
                        discount: discount,
                        subtotal: subtotal,
                        method: selectedPaymentMethod
                    };
                    document.getElementById('checkoutModal').classList.add('hidden');
                    document.getElementById('successModal').classList.replace('hidden', 'flex');
                } else {
                    alert("Error: " + result.message);
                    checkoutBtn.disabled = false;
                    checkoutBtn.innerText = 'CHECKOUT';
                }
            } catch (err) {
                alert("Checkout failed. Check console for details.");
                checkoutBtn.disabled = false;
                checkoutBtn.innerText = 'CHECKOUT';
            }
        }

        function printReceipt() {
            if (!lastSaleInfo) return;
            
            const itemsList = document.getElementById('receipt-items-list');
            const totals = document.getElementById('receipt-totals');
            document.getElementById('r-inv-id').innerText = lastSaleInfo.id;
            document.getElementById('r-date').innerText = new Date().toLocaleDateString();
            
            itemsList.innerHTML = lastSaleInfo.items.map(i => ` 
                <div class="flex mb-1 text-[9px] items-start">
                    <div class="flex-1 flex flex-col">
                        <span class="font-bold text-[10px]">${i.name}</span>
                        <span class="text-[8px] italic">${i.unit_name || 'PCS'} @ ${i.price}</span>
                    </div>
                    <span class="w-12 text-center self-center">${i.qty}</span>
                    <span class="w-16 text-right self-center font-bold">${currencySymbol}${(i.price * i.qty).toFixed(2)}</span>
                </div>
            `).join('');
            
            totals.innerHTML = `
                <div class="flex justify-between"><span>Subtotal:</span><span>${currencySymbol}${lastSaleInfo.subtotal.toFixed(2)}</span></div>
                ${lastSaleInfo.discount > 0 ? `<div class="flex justify-between font-bold"><span>Total Savings:</span><span>-${currencySymbol}${lastSaleInfo.discount.toFixed(2)}</span></div>` : ''}
                <div class="flex justify-between text-sm font-black border-t border-black pt-1 mt-1">
                    <span>NET PAYABLE:</span>
                    <span>${currencySymbol}${lastSaleInfo.total.toFixed(2)}</span>
                </div>
                <div class="text-[9px] mt-2 text-center font-bold">Payment Method: ${lastSaleInfo.method}</div>
            `;
            
            window.print(); // This will print the hidden receipt-print-area
            location.reload();
        }

        // Barcode Listener
        document.getElementById('barcode-input').addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                // Simple mock logic: search by SKU
                const val = this.value.toLowerCase();
                const found = <?= json_encode($products) ?>.find(p => p.sku.toLowerCase() === val || p.name.toLowerCase().includes(val));
                if (found) addToCart(found);
                this.value = '';
            }
        });

        lucide.createIcons();
    </script>
    </div> <!-- End no-print wrapper -->

    <!-- Payment Checkout Modal -->
    <div id="checkoutModal" class="no-print hidden fixed inset-0 bg-black/80 backdrop-blur-sm items-center justify-center p-4 z-50">
        <div class="bg-white dark:bg-neutral-900 w-full max-w-md p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-2xl relative overflow-hidden">
            <!-- Modal Header -->
            <div class="text-center mb-8">
                <p class="text-[10px] font-black uppercase text-orange-500 tracking-[0.2em] mb-2">Checkout Summary</p>
                <h3 class="text-4xl font-black text-slate-900 dark:text-white tracking-tighter" id="checkout-total-display"><?= $currency_symbol ?>0.00</h3>
            </div>

            <div class="space-y-6">
                <!-- Payment Method -->
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-3 tracking-widest text-center">Payment Method</label>
                    <div class="grid grid-cols-3 gap-2">
                        <button onclick="setPaymentMethod('Cash', this)" class="pay-method-btn py-3 rounded-2xl border border-transparent font-bold text-xs bg-orange-600 text-white transition-all">Cash</button>
                        <button onclick="setPaymentMethod('Card', this)" class="pay-method-btn py-3 rounded-2xl border border-slate-100 dark:border-neutral-800 bg-slate-50 dark:bg-neutral-800 text-slate-500 font-bold text-xs transition-all">Card</button>
                        <button onclick="setPaymentMethod('Online', this)" class="pay-method-btn py-3 rounded-2xl border border-slate-100 dark:border-neutral-800 bg-slate-50 dark:bg-neutral-800 text-slate-500 font-bold text-xs transition-all">Online</button>
                    </div>
                </div>

                <!-- Inputs -->
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-1.5 ml-1">Amount Received</label>
                        <input type="number" id="amount-received-input" oninput="calculateChange()" placeholder="0.00" 
                            class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold text-center">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-1.5 ml-1">Discount</label>
                        <input type="number" id="discount-input" oninput="calculateChange()" value="0" 
                            class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold text-center">
                        <p id="discount-error-msg" class="text-[9px] text-rose-500 font-bold mt-1 hidden italic">Limit: <?= ($discount_limit_type === 'fixed' ? $currency_symbol : '') . $max_discount_limit . ($discount_limit_type === 'percentage' ? '%' : '') ?> Exceeded!</p>
                    </div>
                </div>

                <!-- Change Display -->
                <div class="p-6 bg-slate-50 dark:bg-neutral-950 border border-slate-100 dark:border-neutral-800 rounded-[30px] text-center">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-1 tracking-widest">Change / Refund</p>
                    <h4 class="text-2xl font-black text-slate-900 dark:text-white" id="change-display"><?= $currency_symbol ?>0.00</h4>
                </div>

                <!-- Actions -->
                <div class="space-y-3 pt-4">
                    <button id="final-checkout-btn" onclick="finalCheckout()" class="w-full bg-slate-900 dark:bg-white text-white dark:text-black font-black py-5 rounded-2xl shadow-xl transition-all active:scale-95 text-sm tracking-widest">
                        CHECKOUT
                    </button>
                    
                    <div class="grid grid-cols-2 gap-3">
                        <button onclick="document.getElementById('checkoutModal').classList.replace('flex', 'hidden')" class="py-4 text-[10px] font-black uppercase text-slate-400 hover:text-rose-500 transition-colors">
                            Cancel
                        </button>
                        <button onclick="document.getElementById('checkoutModal').classList.replace('flex', 'hidden')" class="py-4 text-[10px] font-black uppercase text-slate-400 hover:text-orange-500 transition-colors">
                            Edit Cart
                        </button>
                    </div>
                </div>
            </div>
            
            <!-- Decorative element -->
            <div class="absolute -bottom-10 -right-10 w-32 h-32 bg-orange-500/5 rounded-full blur-3xl"></div>
            <div class="absolute -top-10 -left-10 w-32 h-32 bg-blue-500/5 rounded-full blur-3xl"></div>
        </div>
    </div>

    <!-- Success Modal -->
    <div id="successModal" class="no-print hidden fixed inset-0 bg-black/80 backdrop-blur-sm items-center justify-center p-4 z-[60]">
        <div class="bg-white dark:bg-neutral-900 w-full max-w-sm p-8 rounded-[40px] text-center border border-slate-200 dark:border-neutral-800 shadow-2xl">
            <div class="w-20 h-20 bg-emerald-500/10 text-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i data-lucide="check-circle" size="40"></i>
            </div>
            <h3 class="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Sale Completed</h3>
            <p class="text-slate-500 text-sm mt-2 mb-8 uppercase tracking-widest font-bold">Transaction Recorded</p>
            
            <div class="space-y-3">
                <button onclick="printReceipt()" class="w-full bg-orange-600 text-white font-black py-4 rounded-2xl flex items-center justify-center gap-2 shadow-lg shadow-orange-600/20">
                    <i data-lucide="printer"></i> PRINT RECEIPT
                </button>
                <button onclick="location.reload()" class="w-full py-4 text-slate-400 font-bold text-xs uppercase hover:text-slate-900 dark:hover:text-white transition-colors">
                    Skip & New Sale
                </button>
                <?php if (has_module('receipt_reprint') && $allow_receipt_reprint): ?>
                <button onclick="reprintLastSale()" class="w-full py-4 text-slate-400 font-bold text-xs uppercase hover:text-slate-900 dark:hover:text-white transition-colors">
                    Reprint Last Sale
                </button>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Reprint Old Receipt Modal -->
    <div id="reprintModal" class="no-print hidden fixed inset-0 bg-black/80 backdrop-blur-sm items-center justify-center p-4 z-50">
        <div class="bg-white dark:bg-neutral-900 w-full max-w-md p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-2xl relative overflow-hidden">
            <button onclick="document.getElementById('reprintModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-rose-500"><i data-lucide="x" size="24"></i></button>
            
            <div class="text-center mb-6">
                <div class="w-16 h-16 bg-blue-500/10 text-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="printer" size="32"></i>
                </div>
                <h2 class="text-2xl font-black dark:text-white uppercase tracking-tight">Reprint Old Receipt</h2>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Enter Sale ID to reprint</p>
            </div>

            <div class="space-y-4">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 text-center">Sale / Invoice ID</label>
                    <input type="number" id="reprint_sale_id_input" placeholder="e.g. 12345" class="w-full px-4 py-5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-3xl outline-none focus:border-blue-500 dark:text-white font-black text-2xl text-center">
                </div>
                <button onclick="fetchAndPrintOldReceipt()" id="btnReprintOld" class="w-full py-5 bg-blue-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-blue-600/20 hover:bg-blue-700 transition-all mt-4">Reprint Receipt</button>
            </div>
        </div>
    </div>

    <script>
        // Global Toggle Sidebar / Full Width Mode
        function toggleFullScreen() {
            const sidebar = document.getElementById('main-sidebar');
            const btn = document.getElementById('fs-toggle-btn');
            if (!sidebar || !btn) return;
            
            const icon = btn.querySelector('i');
            const isHidden = sidebar.classList.toggle('lg:hidden');
            
            icon.setAttribute('data-lucide', isHidden ? 'minimize' : 'maximize');
            btn.title = isHidden ? "Show Sidebar" : "Hide Sidebar";
            
            lucide.createIcons();
        }
        async function fetchAndPrintOldReceipt() {
            const saleId = document.getElementById('reprint_sale_id_input').value;
            if (!saleId) { alert("Please enter a Sale ID."); return; }

            const btn = document.getElementById('btnReprintOld');
            btn.disabled = true;
            btn.innerText = 'Fetching...';

            try {
                const response = await fetch(`api.php?route=sales/get_sale_for_reprint&sale_id=${saleId}`);
                const result = await response.json();

                if (result.success) {
                    lastSaleInfo = result.data; // Use the fetched data
                    printReceipt(); // Call the existing print function
                } else {
                    alert("Error: " + result.message);
                }
            } catch (err) {
                alert("Failed to fetch sale details. Please check the Sale ID.");
            } finally {
                btn.disabled = false;
                btn.innerText = 'Reprint Receipt';
                document.getElementById('reprintModal').classList.replace('flex', 'hidden');
            }
        }

        function reprintLastSale() {
            if (lastSaleInfo) {
                printReceipt();
            } else {
                alert("No last sale found. Please complete a sale first or use 'Reprint Old Receipt' for past sales.");
            }
        }

        // ... (existing script) ...
    </script>
</body>
</html>
<?php } ?>