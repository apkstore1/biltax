<?php
require_once 'config/db_switch.php';

// Redirect if not logged in
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

// Gatekeeper check for this page
gatekeeper_check('manage_branches');

// Fetch tenant's branch limit
$tenant_branch_limit = $branch_limit; // From db_switch.php

// Handle Add/Delete Branch Actions
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'add_branch') {
        $branch_name = trim($_POST['branch_name']);
        $address = trim($_POST['address']);
        $has_own_stock = isset($_POST['has_own_stock']) ? 1 : 0;

        try {
            // Check current branch count
            $current_branches_count = $tenant_conn->query("SELECT COUNT(*) FROM branches WHERE is_main = 0")->fetchColumn();
            if ($current_branches_count >= $tenant_branch_limit) {
                throw new Exception("You have reached your branch limit ({$tenant_branch_limit}). Please upgrade your plan to add more branches.");
            }

            $stmt = $tenant_conn->prepare("INSERT INTO branches (branch_name, address, has_own_stock) VALUES (?, ?, ?)");
            $stmt->execute([$branch_name, $address, $has_own_stock]);
            $message = "Branch added successfully!";
        } catch (Exception $e) {
            $message = "Error adding branch: " . $e->getMessage();
        }
    } elseif (isset($_POST['action']) && $_POST['action'] === 'delete_branch') {
        $branch_id = $_POST['branch_id'];
        try {
            // Prevent deletion of main branch
            $stmt_check = $tenant_conn->prepare("SELECT is_main FROM branches WHERE id = ?");
            $stmt_check->execute([$branch_id]);
            if ($stmt_check->fetchColumn() == 1) {
                throw new Exception("Main branch cannot be deleted.");
            }

            // Reassign products to main branch before deleting
            $main_branch_id = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1")->fetchColumn();
            if ($main_branch_id) {
                $tenant_conn->prepare("UPDATE products SET branch_id = ? WHERE branch_id = ?")
                            ->execute([$main_branch_id, $branch_id]);
            }

            $stmt = $tenant_conn->prepare("DELETE FROM branches WHERE id = ?");
            $stmt->execute([$branch_id]);
            $message = "Branch deleted successfully!";
        } catch (Exception $e) {
            $message = "Error deleting branch: " . $e->getMessage();
        }
    }
}

// Fetch all non-main branches for display
$stmt = $tenant_conn->query("SELECT * FROM branches WHERE is_main = 0 ORDER BY branch_name ASC");
$branches = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch main branch info for display
$main_branch_info = $tenant_conn->query("SELECT * FROM branches WHERE is_main = 1 LIMIT 1")->fetch(PDO::FETCH_ASSOC);

// Current count of non-main branches
$current_branches_count = count($branches);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Store & Branches - Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors duration-300">
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h2 class="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Store & Branches</h2>
                <p class="text-xs text-orange-500 font-bold uppercase tracking-widest">Manage your physical locations and inventory</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <?php include 'alert_bar.php'; ?>

        <?php if ($message): ?>
            <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl text-sm font-bold animate-in fade-in duration-300">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <div class="max-w-4xl mx-auto">
            <!-- Branch Limit Info -->
            <div class="mb-8 p-6 bg-indigo-600 dark:bg-indigo-900 text-white rounded-[32px] flex items-center justify-between shadow-xl shadow-indigo-900/20 dark:shadow-indigo-900/40">
                <div>
                    <p class="text-xs font-black uppercase tracking-widest opacity-70 mb-1">Subscription Limit</p>
                    <h4 class="text-xl font-black italic">Branches: <?= $current_branches_count ?> / <?= $tenant_branch_limit ?> Added</h4>
                </div>
                <?php if ($current_branches_count < $tenant_branch_limit): ?>
                    <button onclick="document.getElementById('addBranchModal').classList.replace('hidden', 'flex')" class="px-6 py-3 bg-white text-indigo-600 dark:text-indigo-400 rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg hover:bg-slate-100 transition-all active:scale-95">
                        <i data-lucide="plus" size="14" class="inline mr-1"></i> Add New Branch
                    </button>
                <?php else: ?>
                    <a href="setting.php#subscription" class="px-6 py-3 bg-orange-600 dark:bg-orange-600 text-white dark:text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-orange-600/20 dark:shadow-none hover:bg-orange-700 dark:hover:bg-orange-700 transition-all">
                        <i data-lucide="zap" size="14" class="inline mr-1"></i> Upgrade Plan
                    </a>
                <?php endif; ?>
            </div>

            <!-- Main Branch Card -->
            <?php if ($main_branch_info): ?>
            <div class="mb-8 p-6 bg-emerald-500/10 border border-emerald-500/20 rounded-3xl">
                <div class="flex items-center gap-3 mb-4">
                    <i data-lucide="home" class="text-emerald-600" size="20"></i>
                    <h3 class="text-lg font-black text-emerald-600 uppercase tracking-tight">Main Account (Head Office)</h3>
                </div>
                <p class="text-sm font-bold dark:text-white"><?= htmlspecialchars($main_branch_info['branch_name']) ?></p>
                <p class="text-xs text-slate-500"><?= htmlspecialchars($main_branch_info['address'] ?: 'No address provided') ?></p>
                <p class="text-xs text-slate-500 mt-2">Own Stock: <span class="font-bold"><?= $main_branch_info['has_own_stock'] ? 'Yes' : 'No (Shares Main Stock)' ?></span></p>
            </div>
            <?php endif; ?>

            <!-- Other Branches List -->
            <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                <h3 class="text-xl font-black mb-6 dark:text-white uppercase tracking-tight">Other Branches</h3>
                <div class="space-y-4">
                    <?php if (empty($branches)): ?>
                        <div class="p-10 text-center text-slate-400 italic">No other branches added yet.</div>
                    <?php else: ?>
                        <?php foreach ($branches as $branch): ?>
                            <div class="p-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl flex items-center justify-between">
                                <div>
                                    <p class="text-sm font-black dark:text-white"><?= htmlspecialchars($branch['branch_name']) ?></p>
                                    <p class="text-xs text-slate-500"><?= htmlspecialchars($branch['address'] ?: 'No address provided') ?></p>
                                    <p class="text-xs text-slate-500 mt-1">Own Stock: <span class="font-bold"><?= $branch['has_own_stock'] ? 'Yes' : 'No (Shares Main Stock)' ?></span></p>
                                </div>
                                <form method="POST" onsubmit="return confirm('Are you sure you want to delete this branch? All products linked to this branch will be reassigned to the Main Account.')">
                                    <input type="hidden" name="action" value="delete_branch">
                                    <input type="hidden" name="branch_id" value="<?= $branch['id'] ?>">
                                    <button type="submit" class="p-2 text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all" title="Delete Branch">
                                        <i data-lucide="trash-2" size="20"></i>
                                    </button>
                                </form>
                            </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <!-- Add Branch Modal -->
    <div id="addBranchModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[110] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('addBranchModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500"><i data-lucide="x" size="20"></i></button>
            
            <h3 class="text-xl font-black mb-1 uppercase tracking-tight text-slate-900 dark:text-white">Add New Branch</h3>
            <p class="text-xs text-slate-500 mb-6 font-bold uppercase tracking-widest">Expand your business to new locations.</p>
            
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add_branch">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Branch Name</label>
                    <input type="text" name="branch_name" required placeholder="e.g. Downtown Store" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-600">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Address</label>
                    <textarea name="address" placeholder="e.g. 123 Main St, City, Country" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-600"></textarea>
                </div>
                <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl">
                    <div>
                        <label for="has_own_stock" class="block text-sm font-black dark:text-white">Separate Inventory/Warehouse</label>
                        <p class="text-[10px] text-slate-500 uppercase font-bold">If off, this branch will use Main Account's stock.</p>
                    </div>
                    <label class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" name="has_own_stock" id="has_own_stock" value="1" checked class="sr-only peer">
                        <div class="w-11 h-6 bg-slate-200 dark:bg-neutral-800 rounded-full peer peer-focus:ring-2 peer-focus:ring-orange-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
                    </label>
                </div>
                
                <div class="pt-4">
                    <button type="submit" class="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-slate-900/20 active:scale-95 transition-all">
                        Add Branch
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>