<?php
// Fetch all branches for the switcher
$all_branches = [];
if (isset($tenant_conn)) {
    $all_branches = $tenant_conn->query("SELECT id, branch_name FROM branches ORDER BY is_main DESC, branch_name ASC")->fetchAll(PDO::FETCH_ASSOC);
}
$current_branch_id = $_SESSION['active_branch_id'] ?? null;
$current_branch_name = 'Branch';
if ($current_branch_id === 'all') {
    $current_branch_name = 'All Locations';
} else foreach ($all_branches as $br) {
    if ($br['id'] == $current_branch_id) {
        $current_branch_name = $br['branch_name'];
        break;
    }
}
$role = $_SESSION['role'] ?? 'admin';
?>
<script>
    function toggleMobileSidebar() {
        const sidebar = document.getElementById('main-sidebar');
        const overlay = document.getElementById('sidebar-overlay');
        if (sidebar && overlay) {
            sidebar.classList.toggle('-translate-x-full');
            overlay.classList.toggle('hidden');
        }
    }
</script>

<div class="flex items-center justify-end gap-4 ml-auto">
    <!-- Mobile Menu Toggle -->
    <button onclick="toggleMobileSidebar()" class="lg:hidden mr-auto p-2.5 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl text-slate-500 dark:text-neutral-400 hover:text-orange-500 transition-all">
        <i data-lucide="menu" size="20"></i>
    </button>

    <?php if (has_module('manage_branches') && (!isset($_SESSION['staff_restricted']) || $_SESSION['staff_restricted'] === false)): ?>
    <!-- Branch Switcher -->
    <div class="relative group">
        <button class="flex items-center gap-2 px-4 py-2.5 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl text-sm font-bold text-slate-700 dark:text-neutral-300 hover:border-orange-500 transition-all shadow-sm">
            <i data-lucide="map-pin" size="16" class="text-orange-500"></i>
            <span class="max-w-[120px] truncate"><?= htmlspecialchars($current_branch_name) ?></span>
            <i data-lucide="chevron-down" size="14" class="ml-1 opacity-50 transition-transform group-hover:rotate-180"></i>
        </button>
        <div class="absolute right-0 mt-2 w-56 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-xl z-[60] invisible opacity-0 translate-y-2 group-hover:visible group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200 delay-500 group-hover:delay-0">
            <div class="p-2 space-y-1">
                <p class="px-4 py-2 text-[10px] font-black uppercase text-slate-400 tracking-widest">Select Location</p>
                <a href="?switch_branch_id=all" class="flex items-center justify-between px-4 py-2.5 rounded-xl text-xs font-bold <?= ($current_branch_id === 'all') ? 'bg-orange-600 text-white shadow-lg' : 'text-slate-600 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600' ?> transition-all">
                    All Locations (Global)
                    <?php if ($current_branch_id === 'all'): ?><i data-lucide="check" size="14"></i><?php endif; ?>
                </a>
                <?php foreach ($all_branches as $br): ?>
                <a href="?switch_branch_id=<?= $br['id'] ?>" class="flex items-center justify-between px-4 py-2.5 rounded-xl text-xs font-bold <?= ($br['id'] == $current_branch_id) ? 'bg-orange-600 text-white shadow-lg' : 'text-slate-600 dark:text-neutral-400 hover:bg-orange-50 dark:hover:bg-neutral-800 hover:text-orange-600' ?> transition-all">
                    <?= htmlspecialchars($br['branch_name']) ?>
                    <?php if ($br['id'] == $current_branch_id): ?>
                        <i data-lucide="check" size="14"></i>
                    <?php endif; ?>
                </a>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if ($role === 'admin' || has_module('notifications')): ?>
    <!-- Notification Bell -->
    <div class="relative">
        <button id="notif-btn" class="p-2.5 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl text-slate-500 dark:text-neutral-400 hover:text-orange-500 transition-all relative">
            <i data-lucide="bell" size="20"></i>
            <span id="notif-badge" class="<?= (isset($has_critical_verification) && $has_critical_verification) ? '' : 'hidden' ?> absolute -top-1 -right-1 w-4 h-4 bg-rose-500 text-white text-[9px] font-black flex items-center justify-center rounded-full">
                <span id="topbar-notification-count"><?= (isset($has_critical_verification) && $has_critical_verification) ? '!' : '0' ?></span>
            </span>
        </button>

        <!-- Dropdown Menu -->
        <div id="notif-dropdown" class="hidden absolute right-0 mt-3 w-80 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-xl z-50 overflow-hidden animate-in">
            <div class="p-4 border-b border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                <h4 class="text-sm font-black text-slate-900 dark:text-white uppercase tracking-wider">Notifications</h4>
                <span id="notif-count-text" class="text-[10px] font-bold text-slate-400">0 Unread</span>
            </div>
            
            <div id="notif-list" class="max-h-80 overflow-y-auto divide-y divide-slate-50 dark:divide-neutral-900">
                <!-- Notifications will be injected here -->
                <div class="p-8 text-center text-slate-400 text-xs italic">Loading...</div>
            </div>

            <a href="notifications_view.php" class="block p-4 text-center text-xs font-bold text-orange-500 hover:bg-slate-50 dark:hover:bg-neutral-900 transition-colors border-t border-slate-100 dark:border-neutral-800">
                View All Notifications
            </a>
        </div>
    </div>
    <?php endif; ?>

    <?php if (basename($_SERVER['PHP_SELF']) == 'dashboard.php'): ?>
        <!-- Current Date (Only shown on Dashboard) -->
        <div class="bg-white dark:bg-neutral-950 px-4 py-2.5 rounded-xl border border-slate-200 dark:border-neutral-800 text-sm font-bold text-slate-600 dark:text-neutral-300 shadow-sm transition-colors">
            <span id="current-date"></span>
        </div>
    <?php endif; ?>
</div>

<script>
<?php if ($role === 'admin' || has_module('notifications')): ?>
document.addEventListener('DOMContentLoaded', function() {
    const btn = document.getElementById('notif-btn');
    const dropdown = document.getElementById('notif-dropdown');
    const list = document.getElementById('notif-list');
    const badge = document.getElementById('notif-badge');
    const countText = document.getElementById('notif-count-text');
    const dateSpan = document.getElementById('current-date');

    // Set current date
    if (dateSpan) {
        const options = { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' };
        dateSpan.textContent = new Date().toLocaleDateString('en-US', options);
    }

    // Toggle Dropdown
    btn.onclick = (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('hidden');
    };

    document.onclick = () => dropdown.classList.add('hidden');
    dropdown.onclick = (e) => e.stopPropagation();

    // Open Notification Logic
    window.openNotification = async function(id) {
        try {
            // Mark as read in background
            const formData = new FormData();
            formData.append('id', id);
            
            fetch('api_mark_read.php', {
                method: 'POST',
                body: formData
            });

            // Redirect to view page
            window.location.href = `notifications_view.php?id=${id}`;
        } catch (err) {
            console.error(err);
        }
    };

    // AJAX Fetch
    async function loadNotifications() {
        try {
            const res = await fetch('api_notifications.php');
            const data = await res.json();

            if (data.success) {
                // Fetch data from centralized counts API instead of simple unread
                const total = data.unread_count; 
                if (total > 0) {
                    const countEl = document.getElementById('topbar-notification-count');
                    if(countEl) countEl.innerText = total;
                    badge.classList.remove('hidden');
                    countText.textContent = `${total} New System Alerts`;
                } else {
                    badge.classList.add('hidden');
                    countText.textContent = `All Caught Up`;
                }

                if (data.notifications.length === 0) {
                    list.innerHTML = '<div class="p-8 text-center text-slate-400 text-xs italic">No new notifications</div>';
                    return;
                }

                list.innerHTML = data.notifications.map(n => `
                    <div onclick="openNotification(${n.id})" class="p-4 hover:bg-slate-50 dark:hover:bg-neutral-900 transition-colors cursor-pointer group ${!n.is_read ? 'bg-orange-500/5' : ''}">
                        <div class="flex items-center justify-between mb-1">
                            <span class="text-[10px] font-black uppercase tracking-tighter ${n.type === 'alert' ? 'text-rose-500' : 'text-blue-500'}">${n.type}</span>
                            <span class="text-[9px] text-slate-400 font-mono">${n.time}</span>
                        </div>
                        <h5 class="text-sm font-bold text-slate-900 dark:text-white group-hover:text-orange-500 transition-colors">${n.title}</h5>
                        <p class="text-xs text-slate-500 dark:text-neutral-500 line-clamp-1">${n.snippet}</p>
                    </div>
                `).join('');
                
                if (window.lucide) lucide.createIcons();
            }
        } catch (err) {
            list.innerHTML = '<div class="p-4 text-center text-rose-500 text-xs">Failed to load</div>';
        }
    }

    loadNotifications();
    // Refresh every 5 minutes
    setInterval(loadNotifications, 300000);
});
<?php endif; ?>
</script>

<style>
    #notif-dropdown.animate-in { animation: slideDown 0.2s ease-out forwards; }
    @keyframes slideDown { from { opacity: 0; transform: translateY(-10px); } to { opacity: 1; transform: translateY(0); } }
</style>