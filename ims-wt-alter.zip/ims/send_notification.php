<?php
require_once 'config/db_switch.php';

// Super Admin credentials for biltax_main connection
// Using variables from db_switch.php but targeting biltax_main
try {
    $main_db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$message_status = '';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['send_notif'])) {
    try {
        $target = $_POST['target_audience']; // 'all' or 'specific'
        $tenant_id = ($target === 'all') ? null : $_POST['tenant_id'];
        $type = $_POST['type']; // announcement, system, alert
        $title = $_POST['title'];
        $notif_message = $_POST['message'];
        $sender_id = 1; // Placeholder for Super Admin ID

        $stmt = $main_db->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$sender_id, $tenant_id, $title, $notif_message, $type]);
        
        $message_status = 'success';
    } catch (PDOException $e) {
        $message_status = 'error: ' . $e->getMessage();
    }
}

// Fetch Tenants for dropdown
$tenants = $main_db->query("SELECT id, business_name FROM tenants ORDER BY business_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch Notification History
$history = $main_db->query("
    SELECT n.*, t.business_name 
    FROM notifications n 
    LEFT JOIN tenants t ON n.tenant_id = t.id 
    ORDER BY n.created_at DESC 
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Send Notification - Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8 overflow-y-auto">
        <div class="max-w-4xl mx-auto">
            <header class="mb-10">
                <h2 class="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Broadcast Center</h2>
                <p class="text-slate-500 dark:text-neutral-400">Send system-wide announcements or specific alerts to business owners.</p>
            </header>

            <?php if ($message_status === 'success'): ?>
                <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 rounded-2xl flex items-center gap-3 animate-in">
                    <i data-lucide="check-circle"></i> Notification broadcasted successfully!
                </div>
            <?php endif; ?>

            <!-- Notification Form -->
            <form method="POST" class="bg-white dark:bg-neutral-950 p-8 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="space-y-2">
                        <label class="text-xs font-bold uppercase text-slate-500">Target Audience</label>
                        <select name="target_audience" id="target_audience" onchange="toggleTenantSelect()" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all">
                            <option value="all">All Tenants (Global)</option>
                            <option value="specific">Specific Business</option>
                        </select>
                    </div>

                    <div class="space-y-2" id="tenant_select_container" style="display: none;">
                        <label class="text-xs font-bold uppercase text-slate-500">Select Business</label>
                        <select name="tenant_id" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all">
                            <?php foreach ($tenants as $t): ?>
                                <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['business_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="space-y-2">
                        <label class="text-xs font-bold uppercase text-slate-500">Notification Type</label>
                        <select name="type" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all">
                            <option value="announcement">📢 Info / Announcement</option>
                            <option value="alert">⚠️ Warning / Alert</option>
                            <option value="system">⚙️ System Update</option>
                        </select>
                    </div>

                    <div class="md:col-span-2 space-y-2">
                        <label class="text-xs font-bold uppercase text-slate-500">Title</label>
                        <input type="text" name="title" required placeholder="e.g. Scheduled Maintenance" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all">
                    </div>

                    <div class="md:col-span-2 space-y-2">
                        <label class="text-xs font-bold uppercase text-slate-500">Message Content</label>
                        <textarea name="message" required rows="4" placeholder="Type your detailed message here..." class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all"></textarea>
                    </div>
                </div>

                <div class="pt-4">
                    <button type="submit" name="send_notif" class="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 rounded-2xl shadow-lg shadow-orange-600/20 transition-all active:scale-95 flex items-center justify-center gap-2">
                        <i data-lucide="send"></i> Dispatch Notification
                    </button>
                </div>
            </form>

            <!-- History Table -->
            <div class="mt-16">
                <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-6">Recent Dispatches</h3>
                <div class="bg-white dark:bg-neutral-950 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-200 dark:border-neutral-800">
                            <tr>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500">Recipient</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500">Type</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500">Content</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 text-right">Sent At</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                            <?php foreach ($history as $h): ?>
                            <tr class="hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                                <td class="px-6 py-4">
                                    <span class="px-2.5 py-1 rounded-lg text-[10px] font-black uppercase tracking-wider <?= $h['tenant_id'] ? 'bg-blue-100 text-blue-600' : 'bg-orange-100 text-orange-600' ?>">
                                        <?= $h['tenant_id'] ? htmlspecialchars($h['business_name']) : 'ALL USERS' ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <?php 
                                        $type_icon = 'info';
                                        $type_class = 'text-blue-500';
                                        if($h['type'] == 'alert') { $type_icon = 'alert-circle'; $type_class = 'text-rose-500'; }
                                        if($h['type'] == 'system') { $type_icon = 'settings'; $type_class = 'text-slate-500'; }
                                    ?>
                                    <div class="flex items-center gap-2 <?= $type_class ?>">
                                        <i data-lucide="<?= $type_icon ?>" size="14"></i>
                                        <span class="text-xs font-bold capitalize"><?= $h['type'] ?></span>
                                    </div>
                                </td>
                                <td class="px-6 py-4">
                                    <div class="text-sm font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($h['title']) ?></div>
                                    <div class="text-xs text-slate-500 truncate max-w-xs"><?= htmlspecialchars($h['message']) ?></div>
                                </td>
                                <td class="px-6 py-4 text-right text-xs text-slate-400 font-mono">
                                    <?= date('d M, H:i', strtotime($h['created_at'])) ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($history)): ?>
                                <tr><td colspan="4" class="px-6 py-10 text-center text-slate-400 italic">No notifications sent yet.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <script>
        function toggleTenantSelect() {
            const target = document.getElementById('target_audience').value;
            const container = document.getElementById('tenant_select_container');
            if (target === 'specific') {
                container.style.display = 'block';
            } else {
                container.style.display = 'none';
            }
        }

        // Initialize Icons
        lucide.createIcons();
    </script>

    <style>
        .animate-in {
            animation: slideDown 0.4s ease-out forwards;
        }
        @keyframes slideDown {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>
</body>
</html>