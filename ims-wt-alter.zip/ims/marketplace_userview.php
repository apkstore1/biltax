<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

$target_id = $_GET['id'] ?? null;
if (!$target_id) { header("Location: marketplace.php"); exit; }

try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    
    // 1. Fetch Target Tenant Info
    $stmt = $main_pdo->prepare("SELECT * FROM tenants WHERE id = ? AND marketplace_listing_visibility = 1");
    $stmt->execute([$target_id]);
    $target = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$target) die("Business profile not found or private.");

    // 2. Fetch Public Inventory from Target's DB
    $target_products = [];
    try {
        $target_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . $target['db_name'], DB_USER, DB_PASS);
        // Self-healing: Ensure column exists
        $target_pdo->exec("ALTER TABLE products ADD COLUMN IF NOT EXISTS is_b2b_public TINYINT(1) DEFAULT 0");
        
        $p_stmt = $target_pdo->prepare("SELECT * FROM products WHERE is_b2b_public = 1 ORDER BY name ASC");
        $p_stmt->execute();
        $target_products = $p_stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) { $target_products = []; }

    // 3. Fetch Related Users (Random 4)
    $related_stmt = $main_pdo->prepare("SELECT id, business_name, industry_type, address FROM tenants WHERE marketplace_listing_visibility = 1 AND id != ? AND id != ? ORDER BY RAND() LIMIT 4");
    $related_stmt->execute([$target_id, $_SESSION['tenant_id']]);
    $related = $related_stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch My (Viewer's) Currency Symbol from main DB
    $stmt_curr = $main_pdo->prepare("SELECT currency_symbol FROM tenants WHERE id = ?");
    $stmt_curr->execute([$_SESSION['tenant_id']]);
    $my_currency = $stmt_curr->fetchColumn() ?: '$';

} catch (Exception $e) {
    die("Connection error: " . $e->getMessage());
}

$initial = strtoupper(substr($target['business_name'], 0, 1));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title><?= htmlspecialchars($target['business_name']) ?> | Biltax Marketplace</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 min-h-screen transition-colors duration-300 flex">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8">
        <!-- Header / Back -->
        <div class="mb-6 flex items-center gap-4">
            <a href="marketplace.php" class="p-2 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl hover:text-orange-600 transition-all">
                <i data-lucide="arrow-left" size="20"></i>
            </a>
            <span class="text-xs font-bold text-slate-400 uppercase tracking-widest">Marketplace / Business Profile</span>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Main Content (Left 2/3) -->
            <div class="lg:col-span-2 space-y-8">
                <!-- Big Image Card -->
                <div class="bg-white dark:bg-neutral-900 rounded-[32px] border border-slate-200 dark:border-neutral-800 overflow-hidden shadow-sm">
                    <div class="aspect-[16/7] bg-slate-100 dark:bg-neutral-800 flex items-center justify-center border-b border-slate-100 dark:border-neutral-800 relative">
                        <i data-lucide="store" size="80" class="text-slate-300 dark:text-neutral-700"></i>
                        <div class="absolute bottom-6 left-6 px-4 py-2 bg-black/50 backdrop-blur-md text-white rounded-xl text-[10px] font-bold uppercase flex items-center gap-2">
                            <i data-lucide="image" size="14"></i> View All Photos
                        </div>
                    </div>
                    <div class="p-8">
                        <h1 class="text-3xl font-black text-slate-900 dark:text-white uppercase mb-2 flex items-center gap-2">
                            <?= htmlspecialchars($target['business_name']) ?>
                            <?php if ($target['is_verified']): ?>
                                <i data-lucide="badge-check" class="text-blue-500" size="28"></i>
                            <?php endif; ?>
                        </h1>
                        <div class="flex items-center gap-4 text-slate-500 dark:text-neutral-400">
                            <div class="flex items-center gap-1.5 text-sm font-medium">
                                <i data-lucide="map-pin" size="16" class="text-orange-500"></i> <?= htmlspecialchars($target['address'] ?: 'Location Not Specified') ?>
                            </div>
                            <div class="flex items-center gap-1.5 text-sm font-medium">
                                <i data-lucide="tag" size="16" class="text-orange-500"></i> <?= htmlspecialchars($target['industry_type']) ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Inventory List -->
                <div class="space-y-4">
                    <h2 class="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight flex items-center gap-2">
                        <i data-lucide="package" class="text-orange-500"></i> Available Inventory
                    </h2>
                    <?php if (empty($target_products)): ?>
                        <div class="p-10 bg-white dark:bg-neutral-900 rounded-3xl border border-dashed border-slate-200 dark:border-neutral-800 text-center">
                            <p class="text-slate-500 text-sm font-bold uppercase">No public products listed by this partner.</p>
                        </div>
                    <?php else: ?>
                        <div class="bg-white dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
                            <table class="w-full text-left">
                                <thead class="bg-slate-50 dark:bg-neutral-900/50 border-b border-slate-200 dark:border-neutral-800">
                                    <tr>
                                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Product Name</th>
                                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">SKU</th>
                                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-right">Price</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                                    <?php foreach($target_products as $prod): ?>
                                        <tr class="transition-colors hover:bg-slate-50 dark:hover:bg-neutral-800/30">
                                            <td class="px-6 py-4">
                                                <div class="flex items-center gap-3">
                                                    <div class="w-8 h-8 bg-slate-50 dark:bg-neutral-800 rounded-lg flex items-center justify-center text-slate-300">
                                                        <i data-lucide="package-search" size="16"></i>
                                                    </div>
                                                    <span class="font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($prod['name']) ?></span>
                                                </div>
                                            </td>
                                            <td class="px-6 py-4 text-sm text-slate-500 dark:text-neutral-400 font-mono">
                                                <?= htmlspecialchars($prod['sku'] ?: 'N/A') ?>
                                            </td>
                                            <td class="px-6 py-4 text-right text-sm font-black text-orange-600">
                                                <?= $my_currency ?><?= number_format($prod['sale_price'], 2) ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Related Users -->
                <div class="space-y-4 pt-8">
                    <h2 class="text-lg font-black text-slate-900 dark:text-white uppercase tracking-tight">You might also like</h2>
                    <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <?php foreach($related as $rel): ?>
                            <a href="marketplace_userview.php?id=<?= $rel['id'] ?>" class="bg-white dark:bg-neutral-900 p-4 rounded-2xl border border-slate-200 dark:border-neutral-800 hover:shadow-lg transition-all text-center">
                                <div class="w-10 h-10 bg-slate-100 dark:bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-3 text-slate-400 font-black">
                                    <?= strtoupper(substr($rel['business_name'], 0, 1)) ?>
                                </div>
                                <h5 class="text-[10px] font-black dark:text-white line-clamp-1 mb-1 uppercase"><?= htmlspecialchars($rel['business_name']) ?></h5>
                                <p class="text-[8px] text-slate-400 font-bold uppercase"><?= htmlspecialchars($rel['industry_type']) ?></p>
                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>

                <!-- Precautions -->
                <div class="p-6 bg-amber-50 dark:bg-amber-900/10 border border-amber-200 dark:border-amber-900/20 rounded-3xl">
                    <h4 class="text-xs font-black text-amber-700 dark:text-amber-500 uppercase flex items-center gap-2 mb-2">
                        <i data-lucide="shield-alert" size="16"></i> Safety Precautions
                    </h4>
                    <ul class="text-[10px] text-amber-600 dark:text-amber-600/80 space-y-1 font-bold list-disc pl-4">
                        <li>Always verify product quality before finalizing bulk orders.</li>
                        <li>Use Biltax Hub connection requests for formal B2B networking.</li>
                        <li>Do not share sensitive bank details outside official channels.</li>
                        <li>Check partner ratings and history before making large payments.</li>
                    </ul>
                </div>
            </div>

            <!-- Sidebar (Right 1/3) -->
            <div class="space-y-6">
                <!-- Profile Card -->
                <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm sticky top-8">
                    <div class="text-center mb-8">
                        <div class="w-24 h-24 bg-orange-600 rounded-[32px] flex items-center justify-center text-white text-4xl font-black mx-auto mb-4 shadow-xl shadow-orange-600/20">
                            <?= $initial ?>
                        </div>
                        <h2 class="text-xl font-black text-slate-900 dark:text-white uppercase flex items-center justify-center gap-1">
                            <?= htmlspecialchars($target['owner_name']) ?>
                            <?php if ($target['is_verified']): ?>
                                <i data-lucide="badge-check" class="text-blue-500" size="18"></i>
                            <?php endif; ?>
                        </h2>
                        <p class="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">Verified Partner</p>
                    </div>

                    <!-- Stats -->
                    <div class="grid grid-cols-2 gap-4 mb-8">
                        <div class="bg-slate-50 dark:bg-neutral-800/50 p-4 rounded-2xl text-center">
                            <p class="text-[10px] text-slate-400 font-bold uppercase">Total Product</p>
                            <p class="text-lg font-black dark:text-white"><?= count($target_products) ?></p>
                        </div>
                        <div class="bg-slate-50 dark:bg-neutral-800/50 p-4 rounded-2xl text-center">
                            <p class="text-[10px] text-slate-400 font-bold uppercase">Reviews</p>
                            <p class="text-lg font-black dark:text-white">0</p>
                        </div>
                    </div>

                    <!-- Actions -->
                    <div class="space-y-3">
                        <button onclick="alert('Chat coming soon!')" class="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 hover:opacity-90 transition-all">
                            <i data-lucide="message-circle" size="18"></i> Chat with Partner
                        </button>
                        <button onclick="window.location.href='connect_partner.php?target=<?= $target['id'] ?>'" class="w-full py-4 border-2 border-orange-600 text-orange-600 rounded-2xl font-black text-xs uppercase tracking-widest flex items-center justify-center gap-2 hover:bg-orange-600 hover:text-white transition-all">
                            <i data-lucide="user-plus" size="18"></i> Connect Now
                        </button>
                    </div>

                    <div class="mt-8 pt-8 border-t border-slate-100 dark:border-neutral-800">
                        <div class="flex items-center gap-3 text-slate-500 dark:text-neutral-400 mb-4">
                            <i data-lucide="mail" size="16"></i>
                            <span class="text-xs font-bold"><?= htmlspecialchars($target['email']) ?></span>
                        </div>
                        <div class="flex items-center gap-3 text-slate-500 dark:text-neutral-400">
                            <i data-lucide="phone" size="16"></i>
                            <span class="text-xs font-bold"><?= htmlspecialchars($target['phone'] ?: 'No Phone Provided') ?></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script>
        lucide.createIcons();
        
        // Smooth Scroll for Related Cards
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });
    </script>
</body>
</html>