<?php
require_once 'config/db_switch.php';

// Check login
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

$success_msg = $error_msg = '';

// --- Multi-Branch Context ---
$active_branch = $_SESSION['active_branch_id'] ?? null;
$target_branch = get_active_stock_branch_id($active_branch);

// --- Handle Stock Adjustment ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'adjust_stock') {
    try {
        $product_id = $_POST['product_id'];
        $adjustment = (int)$_POST['adjustment_qty'];
        $reason = $_POST['reason'] ?? 'Manual Adjustment';

        if ($adjustment == 0) throw new Exception("Adjustment value cannot be zero.");

        $tenant_conn->beginTransaction();

        // 1. Update Products Table
        $stmt = $tenant_conn->prepare("UPDATE products SET stock_level = stock_level + ? WHERE id = ? AND branch_id = ?");
        $stmt->execute([$adjustment, $product_id, $target_branch]);

        // 2. Insert into Stock Movement History
        $stmt = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)");
        $stmt->execute([$product_id, $adjustment, $reason]);

        $tenant_conn->commit();
        $success_msg = "Inventory adjusted successfully!";
    } catch (Exception $e) {
        if ($tenant_conn->inTransaction()) $tenant_conn->rollBack();
        $error_msg = "Error: " . $e->getMessage();
    }
}

// --- Fetch Stock Data ---
$industry = strtolower($_SESSION['industry_type'] ?? 'retail');
$active_branch = $_SESSION['active_branch_id'] ?? null;
$is_all = ($active_branch === 'all');
$stock_branch = get_active_stock_branch_id($active_branch);

$stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
$main_id = $stmt_main->fetchColumn();

$where_clauses = [];
$params = [];

if (!$is_all) {
    $where_clauses[] = ($stock_branch == $main_id) ? "(p.branch_id = ? OR p.branch_id IS NULL)" : "p.branch_id = ?";
    $params[] = $stock_branch;
}

if ($industry === 'restaurant') {
    $where_clauses[] = "(p.is_raw = 1 OR p.has_stock = 1)";
}

$where_sql = !empty($where_clauses) ? " WHERE " . implode(" AND ", $where_clauses) : "";

$sql = "SELECT p.id, p.name, p.sku, p.category, p.stock_level, p.alert_level, p.updated_at, p.is_raw,
               c.name as cat_name, u.name as unit_name
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        LEFT JOIN units u ON p.unit_id = u.id 
        $where_sql
        ORDER BY p.stock_level ASC";

try {
    $stmt = $tenant_conn->prepare($sql);
    $stmt->execute($params);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $error_msg = "Database Error: " . $e->getMessage();
    $products = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Management | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        @media print {
            .no-print { display: none !important; }
            body { background: white !important; }
            .print-area { width: 100% !important; margin: 0 !important; padding: 0 !important; }
        }
    </style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-950 transition-colors duration-300">

    <div class="no-print"><?php include 'sidebar.php'; ?></div>

    <main class="flex-1 p-8 overflow-y-auto print-area">
        <!-- Header -->
        <div class="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-10 no-print">
            <div>
                <h1 class="text-3xl font-black text-slate-900 dark:text-white tracking-tight uppercase">Stock Management</h1>
                <p class="text-sm text-slate-500 dark:text-neutral-400 font-medium">Monitor live quantities and adjust inventory levels.</p>
            </div>
            <div class="flex items-center gap-3">
                <button onclick="exportToCSV()" class="p-2.5 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl text-slate-600 dark:text-neutral-400 hover:text-orange-500 transition-all shadow-sm" title="Export Excel">
                    <i data-lucide="file-spreadsheet" size="20"></i>
                </button>
                <button onclick="window.print()" class="p-2.5 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl text-slate-600 dark:text-neutral-400 hover:text-orange-500 transition-all shadow-sm" title="Export PDF">
                    <i data-lucide="printer" size="20"></i>
                </button>
                <?php include 'topbar.php'; ?>
            </div>
        </div>

        <!-- Global Verification Alert Bar -->
        <?php include 'alert_bar.php'; ?>

        <!-- Alerts -->
        <?php if ($success_msg): ?>
            <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-2xl flex items-center gap-2 no-print">
                <i data-lucide="check-circle" size="18"></i> <span class="font-bold"><?= $success_msg ?></span>
            </div>
        <?php endif; ?>

        <!-- Stock Table -->
        <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
            <table class="w-full text-left border-collapse" id="stock-table">
                <thead class="bg-slate-50 dark:bg-neutral-900/50 border-b border-slate-200 dark:border-neutral-800">
                    <tr>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Product / SKU</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Category</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-center">Unit</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-center">Quantity</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Last Movement</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-right no-print">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach ($products as $p): 
                        $isLow = ($p['stock_level'] <= $p['alert_level']);
                        $itemType = (($p['is_raw'] ?? 0) == 1) ? 'Raw Material' : 'Dish/Product';
                    ?>
                    <tr class="transition-colors <?= $isLow ? 'bg-rose-50/50 dark:bg-rose-500/5' : 'hover:bg-slate-50 dark:hover:bg-neutral-800/30' ?>">
                        <td class="px-6 py-4">
                            <div class="font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($p['name']) ?></div>
                            <div class="flex items-center gap-2 mt-1">
                                <div class="text-[10px] font-mono text-slate-400 uppercase tracking-tighter"><?= htmlspecialchars($p['sku'] ?: 'NO-SKU') ?></div>
                                <span class="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 dark:bg-neutral-800 text-slate-500 font-black uppercase"><?= $itemType ?></span>
                            </div>
                        </td>
                        <td class="px-6 py-4 text-sm text-slate-600 dark:text-slate-400"><?= htmlspecialchars($p['cat_name'] ?: ($p['category'] ?: 'General')) ?></td>
                        <td class="px-6 py-4 text-sm text-center text-slate-500"><?= htmlspecialchars($p['unit_name'] ?: 'pcs') ?></td>
                        <td class="px-6 py-4 text-center">
                            <span class="inline-block px-3 py-1 rounded-lg font-black text-sm <?= $isLow ? 'text-rose-600 bg-rose-100 dark:bg-rose-500/20' : 'text-slate-700 dark:text-slate-300' ?>">
                                <?= $p['stock_level'] ?>
                            </span>
                            <?php if($isLow): ?>
                                <div class="text-[9px] text-rose-500 font-bold uppercase mt-1">Low Stock Alert</div>
                            <?php endif; ?>
                        </td>
                        <td class="px-6 py-4 text-xs text-slate-400">
                            <?= date('M d, H:i', strtotime($p['updated_at'])) ?>
                        </td>
                        <td class="px-6 py-4 text-right no-print">
                            <button onclick="openAdjustmentModal(<?= htmlspecialchars(json_encode($p)) ?>)" class="px-4 py-2 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-xs font-black hover:bg-orange-600 hover:text-white transition-all">
                                ADJUST
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Adjustment Modal -->
    <div id="adjModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 no-print">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('adjModal').classList.replace('flex', 'hidden')" class="absolute top-4 right-4 text-slate-400 hover:text-white"><i data-lucide="x" size="20"></i></button>
            
            <div class="text-center mb-6">
                <h3 class="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Adjust Inventory</h3>
                <p class="text-xs text-orange-500 font-bold mt-1" id="adj_product_name"></p>
            </div>

            <form method="POST" class="space-y-5">
                <input type="hidden" name="action" value="adjust_stock">
                <input type="hidden" name="product_id" id="adj_id">

                <div>
                    <label class="block text-[10px] font-black uppercase mb-1.5 text-slate-500">Adjustment Amount</label>
                    <input type="number" name="adjustment_qty" required placeholder="e.g. 10 or -5" 
                        class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 text-slate-900 dark:text-white text-lg font-bold text-center">
                    <p class="text-[9px] text-slate-400 mt-2 italic text-center">Use positive (+) to add, negative (-) to subtract stock.</p>
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase mb-1.5 text-slate-500">Reason for Change</label>
                    <select name="reason" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm font-medium text-slate-900 dark:text-white">
                        <option value="Manual Entry">Manual Entry</option>
                        <option value="Damage / Spoilage">Damage / Spoilage</option>
                        <option value="Wastage">Wastage</option>
                        <option value="Expired Product">Expired Product</option>
                        <option value="Stock Audit Correction">Stock Audit Correction</option>
                        <option value="Returned Item">Returned Item</option>
                        <option value="Found in Warehouse">Found in Warehouse</option>
                    </select>
                </div>

                <button type="submit" class="w-full bg-orange-600 hover:bg-orange-700 text-white font-black py-4 rounded-2xl transition-all shadow-lg shadow-orange-600/20 active:scale-95 text-sm uppercase tracking-widest">
                    Update Stock Level
                </button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();

        function openAdjustmentModal(product) {
            document.getElementById('adj_id').value = product.id;
            document.getElementById('adj_product_name').innerText = product.name + ' (' + product.sku + ')';
            document.getElementById('adjModal').classList.replace('hidden', 'flex');
        }

        function exportToCSV() {
            const table = document.getElementById("stock-table");
            let csv = [];
            for (let i = 0; i < table.rows.length; i++) {
                let row = [], cols = table.rows[i].querySelectorAll("td, th");
                for (let j = 0; j < cols.length - 1; j++) { // Skip actions column
                    let text = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, " ").trim();
                    row.push('"' + text + '"');
                }
                csv.push(row.join(","));
            }
            
            const csvContent = "data:text/csv;charset=utf-8," + csv.join("\n");
            const encodedUri = encodeURI(csvContent);
            const link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", "Biltax_Inventory_Report_" + new Date().toLocaleDateString() + ".csv");
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    </script>
</body>
</html>