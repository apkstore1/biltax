/**
 * Biltax Chat Security Restrictions
 * Handles client-side validation for chat messages.
 */
const ChatRestrictions = {
    /**
     * Define restricted keywords, links, or patterns here.
     * You can easily add more items to this list later.
     */
    forbidden: [
        'http', 'https', 'www', 'ftp', // Protocol links
        '.com', '.net', '.org', '.pk', // Common domains
        '\\d{8,}'                      // Phone numbers (8 or more digits)
    ],

    /**
     * Validates message text against security rules.
     * @param {string} text
     * @returns {object} { isValid: boolean, message: string }
     */
    validate: function(text) {
        // Construct a dynamic regex from the forbidden list above
        const pattern = new RegExp(this.forbidden.join('|'), 'i');

        if (pattern.test(text)) {
            return { isValid: false, message: "Sharing phone numbers or links is not allowed in chat or this text is not allowed in this chat." };
        }

        return { isValid: true, message: "" };
    },

    /**
     * Uploads a file to Cloudinary using an unsigned preset.
     * @param {File} file 
     * @returns {Promise<string|null>} Secure URL or null
     */
    uploadToCloudinary: async function(file) {
        const cloudName = "dumptsnaj"; 
        const uploadPreset = "biltax_unsigned"; // Ensure this matches your Cloudinary Settings

        const formData = new FormData();
        formData.append("file", file);
        formData.append("upload_preset", uploadPreset);

        try {
            const response = await fetch(`https://api.cloudinary.com/v1_1/${cloudName}/image/upload`, {
                method: "POST",
                body: formData
            });
            const data = await response.json();
            console.log("Cloudinary Response:", data); // Debugging: See Cloudinary response
            return data.secure_url || null; // Return the secure URL
        } catch (err) {
            console.error("Cloudinary Upload Error:", err);
            alert("Image upload failed. Check console for Cloudinary error."); // User feedback
            return null;
        }
    }
};