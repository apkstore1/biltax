<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

if (!has_module('raw_material_system')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

// Fetch only Raw Materials
$sql = "SELECT p.*, c.name as cat_name, u.name as unit_name 
        FROM products p 
        LEFT JOIN categories c ON p.category_id = c.id 
        LEFT JOIN units u ON p.unit_id = u.id 
        WHERE p.is_raw_component = 1 
        ORDER BY p.id DESC";
$products = $tenant_conn->query($sql)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Raw Material Management | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Raw Materials</h1>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Inventory assigned as production components</p>
            </div>
            <div class="flex items-center gap-3">
                <?php include 'topbar.php'; ?>
                <a href="products.php" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase shadow-lg shadow-orange-600/20">Manage All Products</a>
            </div>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div class="bg-white dark:bg-neutral-950 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                <p class="text-[10px] font-black uppercase text-slate-400 mb-1">Total Raw Materials</p>
                <h3 class="text-2xl font-black dark:text-white"><?= count($products) ?> Items</h3>
            </div>
        </div>

        <div class="bg-white dark:bg-neutral-950 rounded-[32px] border border-slate-200 dark:border-neutral-800 overflow-hidden shadow-sm">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-200 dark:border-neutral-800">
                    <tr class="text-[10px] font-black uppercase text-slate-500">
                        <th class="px-8 py-5">Material Name</th>
                        <th class="px-8 py-5">SKU</th>
                        <th class="px-8 py-5 text-center">Unit</th>
                        <th class="px-8 py-5 text-center">Stock</th>
                        <th class="px-8 py-5 text-center">Sellable?</th>
                        <th class="px-8 py-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-900">
                    <?php foreach($products as $p): ?>
                    <tr class="hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                        <td class="px-8 py-5">
                            <div class="font-bold dark:text-white"><?= htmlspecialchars($p['name']) ?></div>
                            <div class="text-[10px] text-slate-400 font-bold uppercase"><?= htmlspecialchars($p['cat_name'] ?? 'General') ?></div>
                        </td>
                        <td class="px-8 py-5 font-mono text-xs text-slate-500"><?= htmlspecialchars($p['sku']) ?></td>
                        <td class="px-8 py-5 text-center text-sm font-bold text-slate-500"><?= htmlspecialchars($p['unit_name'] ?? 'pcs') ?></td>
                        <td class="px-8 py-5 text-center">
                            <span class="px-3 py-1 rounded-lg bg-slate-100 dark:bg-neutral-800 font-black text-sm <?= $p['stock_level'] <= $p['alert_level'] ? 'text-rose-500' : 'text-slate-700 dark:text-slate-300' ?>">
                                <?= $p['stock_level'] ?>
                            </span>
                        </td>
                        <td class="px-8 py-5 text-center">
                            <?php if($p['is_sellable']): ?>
                                <span class="px-2 py-1 bg-emerald-500/10 text-emerald-600 rounded text-[9px] font-black uppercase">Yes</span>
                            <?php else: ?>
                                <span class="px-2 py-1 bg-slate-100 text-slate-400 rounded text-[9px] font-black uppercase">No</span>
                            <?php endif; ?>
                        </td>
                        <td class="px-8 py-5 text-right">
                            <a href="products.php?search=<?= urlencode($p['name']) ?>" class="text-orange-600 hover:underline text-[10px] font-black uppercase">Edit Item</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>