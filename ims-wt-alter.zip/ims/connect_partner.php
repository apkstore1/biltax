<?php
require_once 'config/db_switch.php';

// Redirect if not logged in
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

// 1. Setup Main DB Connection & Table
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Self-healing: Ensure unique_id column exists in tenants table
    $current_cols = $main_pdo->query("SHOW COLUMNS FROM tenants")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('unique_id', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN unique_id VARCHAR(20) UNIQUE AFTER id");
    }

    // Create connections table in main DB
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS tenant_connections (
        id INT PRIMARY KEY AUTO_INCREMENT,
        sender_id INT NOT NULL,
        receiver_id INT NOT NULL,
        status ENUM('pending', 'accepted', 'rejected') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY unique_conn (sender_id, receiver_id)
    )");

    // Get current tenant's ID from main DB
    $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
    $stmt->execute([$_SESSION['db_name']]);
    $my_main_id = $stmt->fetchColumn();

    // 1a. Fetch Pending Incoming Requests
    $stmt = $main_pdo->prepare("SELECT tc.id, t.business_name, t.unique_id, t.owner_name FROM tenant_connections tc JOIN tenants t ON tc.sender_id = t.id WHERE tc.receiver_id = ? AND tc.status = 'pending'");
    $stmt->execute([$my_main_id]);
    $pending_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 1b. Fetch Sent Pending Requests
    $stmt = $main_pdo->prepare("SELECT tc.id, t.business_name, t.unique_id, t.owner_name FROM tenant_connections tc JOIN tenants t ON tc.receiver_id = t.id WHERE tc.sender_id = ? AND tc.status = 'pending'");
    $stmt->execute([$my_main_id]);
    $sent_requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // 1c. Fetch Accepted Partners with sender_id to ensure consistent Chat Room IDs
    $stmt = $main_pdo->prepare("SELECT tc.id, t.id as partner_tenant_id, t.business_name, t.unique_id, t.owner_name, t.industry_type, tc.receiver_branch_id, tc.sender_id 
                                FROM tenant_connections tc 
                                JOIN tenants t ON (CASE WHEN tc.sender_id = ? THEN tc.receiver_id ELSE tc.sender_id END) = t.id 
                                WHERE (tc.sender_id = ? OR tc.receiver_id = ?) AND tc.status = 'accepted'");
    $stmt->execute([$my_main_id, $my_main_id, $my_main_id]);
    $my_partners = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Connection Error: " . $e->getMessage());
}

// 2. Handle AJAX Requests
if (isset($_POST['action'])) {
    header('Content-Type: application/json');
    
    // Action: Find Partner
    if ($_POST['action'] === 'find_partner') {
        $target_id = strtoupper(trim($_POST['biltax_id']));
        $stmt = $main_pdo->prepare("SELECT id, business_name, owner_name FROM tenants WHERE unique_id = ? AND id != ?");
        $stmt->execute([$target_id, $my_main_id]);
        $partner = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($partner) {
            echo json_encode(['success' => true, 'business' => $partner['business_name'], 'owner' => $partner['owner_name'], 'id' => $partner['id']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid Biltax ID or you cannot connect to yourself.']);
        }
        exit;
    }

    // Action: Send Request
    if ($_POST['action'] === 'send_request') {
        try {
            $receiver_id = $_POST['receiver_id'];
            $stmt = $main_pdo->prepare("INSERT INTO tenant_connections (sender_id, receiver_id) VALUES (?, ?)");
            $stmt->execute([$my_main_id, $receiver_id]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Request already exists or failed.']);
        }
        exit;
    }

    // Action: Accept/Reject Request
    if ($_POST['action'] === 'accept_request' || $_POST['action'] === 'reject_request') {
        try {
            $conn_id = $_POST['conn_id'];
            if ($_POST['action'] === 'accept_request') {
                $branch_id = $_POST['branch_id'] ?? null; // Wholesaler's assigned branch
                $stmt = $main_pdo->prepare("UPDATE tenant_connections SET status = 'accepted', receiver_branch_id = ? WHERE id = ? AND receiver_id = ?");
                $stmt->execute([$branch_id, $conn_id, $my_main_id]);
            } else {
                // Delete the connection record entirely instead of just updating status to rejected
                $stmt = $main_pdo->prepare("DELETE FROM tenant_connections WHERE id = ? AND (sender_id = ? OR receiver_id = ?)");
                $stmt->execute([$conn_id, $my_main_id, $my_main_id]);
            }
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Connect Partner | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>

    <!-- SweetAlert2 for Security Alerts -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Firebase SDKs (Compat Version for Global Instance) -->
    <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-app-compat.js"></script>
    <script src="https://www.gstatic.com/firebasejs/9.22.0/firebase-database-compat.js"></script>
    <script src="firebase-init.js"></script>
    <script src="chat_restrictions.js"></script>

    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-950 transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8">
        <div class="max-w-2xl mx-auto">
            <header class="mb-10 text-center">
                <h1 class="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Connect Partner</h1>
                <p class="text-slate-500 text-sm">Grow your network by connecting with other Biltax businesses.</p>
            </header>

            <!-- Global Verification Alert Bar -->
            <?php include 'alert_bar.php'; ?>

            <!-- Incoming Pending Requests Section (Moved Up for better visibility) -->
            <?php if (!empty($pending_requests)): ?>
            <div class="mb-8 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl shadow-xl border-l-4 border-l-orange-500">
                <div class="flex items-center gap-2 mb-6">
                    <div class="w-2 h-2 bg-orange-500 rounded-full animate-pulse"></div>
                    <h2 class="text-xs font-black uppercase text-orange-500 tracking-widest">Incoming Connection Requests</h2>
                </div>
                <div class="space-y-4">
                    <?php foreach ($pending_requests as $req): ?>
                    <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl">
                        <div>
                            <h4 class="font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($req['business_name']) ?></h4>
                            <p class="text-[10px] text-slate-500 font-mono uppercase"><?= htmlspecialchars($req['unique_id']) ?> • <?= htmlspecialchars($req['owner_name']) ?></p>
                        </div>
                        <div class="flex gap-2">
                            <button onclick="handleRequest(<?= $req['id'] ?>, 'reject_request')" class="p-2 text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all" title="Reject">
                                <i data-lucide="x-circle" size="20"></i>
                            </button>
                            <button onclick="openAcceptModal(<?= $req['id'] ?>)" class="flex items-center gap-2 px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20">
                                <i data-lucide="check" size="14"></i> Accept & Assign Branch
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Search Card -->
            <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl shadow-xl">
                <div class="flex flex-col gap-6">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Enter Partner Biltax ID</label>
                        <div class="flex gap-3">
                            <input type="text" id="biltax_id" placeholder="e.g. BTX-XXXXXX" class="flex-1 px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-mono text-lg uppercase">
                            <button onclick="findPartner()" class="px-8 bg-slate-900 dark:bg-white text-white dark:text-black font-black rounded-2xl hover:bg-orange-600 hover:text-white transition-all uppercase text-xs tracking-widest">Find</button>
                        </div>
                    </div>

                    <!-- Result Area -->
                    <div id="result_area" class="hidden animate-in fade-in slide-in-from-top-4 duration-300">
                        <div class="p-6 bg-orange-500/5 border border-orange-500/10 rounded-2xl flex items-center justify-between">
                            <div>
                                <p class="text-[10px] font-black text-orange-500 uppercase">Business Found</p>
                                <h3 id="res_name" class="text-xl font-black text-slate-900 dark:text-white"></h3>
                                <p id="res_owner" class="text-xs text-slate-500"></p>
                            </div>
                            <button id="send_btn" onclick="sendRequest()" class="bg-orange-600 text-white px-6 py-3 rounded-xl font-bold text-xs uppercase tracking-wider shadow-lg shadow-orange-600/20 active:scale-95">Send Connection Request</button>
                        </div>
                    </div>

                    <!-- Error Area -->
                    <div id="error_area" class="hidden p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-xl text-xs font-bold flex items-center gap-2">
                        <i data-lucide="alert-circle" size="16"></i>
                        <span id="error_msg"></span>
                    </div>
                </div>
            </div>

            <!-- Sent Pending Requests Section -->
            <?php if (!empty($sent_requests)): ?>
            <div class="mt-8 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl shadow-xl">
                <h2 class="text-xs font-black uppercase text-slate-400 mb-6 tracking-widest">Sent Requests (Pending)</h2>
                <div class="space-y-4">
                    <?php foreach ($sent_requests as $sreq): ?>
                    <div class="flex items-center justify-between p-4 bg-slate-50/50 dark:bg-neutral-950/50 border border-dashed border-slate-200 dark:border-neutral-800 rounded-2xl opacity-75">
                        <div>
                            <h4 class="font-bold text-slate-700 dark:text-neutral-400"><?= htmlspecialchars($sreq['business_name']) ?></h4>
                            <p class="text-[10px] text-slate-500 font-mono uppercase">Request Sent • <?= htmlspecialchars($sreq['unique_id']) ?></p>
                        </div>
                        <span class="text-[10px] font-bold text-slate-400 italic">Waiting...</span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Connected Partners Section -->
            <?php if (!empty($my_partners)): ?>
            <div class="mt-8 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl shadow-xl">
                <h2 class="text-xs font-black uppercase text-emerald-500 mb-6 tracking-widest">My Partners</h2>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <?php foreach ($my_partners as $partner): ?>
                    <div class="p-4 bg-emerald-500/5 border border-emerald-500/10 rounded-2xl group hover:border-emerald-500/30 transition-all">
                        <div class="flex items-start justify-between">
                            <div>
                                <h4 class="font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($partner['business_name']) ?></h4>
                                <p class="text-[10px] text-slate-500 font-mono uppercase mb-2"><?= htmlspecialchars($partner['unique_id']) ?></p>
                                <span class="px-2 py-0.5 bg-slate-100 dark:bg-neutral-800 rounded text-[9px] font-black uppercase text-slate-500"><?= htmlspecialchars($partner['industry_type']) ?></span>
                            </div>
                            <div class="flex items-center gap-2">
                                <?php if (has_module('b2b_chat')): ?>
                                <button title="Message" class="chat-btn relative p-2 text-slate-400 hover:text-orange-500 transition-colors bg-slate-50 dark:bg-neutral-800 rounded-lg"
                                    data-provider-id="<?= $partner['partner_tenant_id'] ?>"
                                    data-subscriber-id="<?= $partner['sender_id'] ?>"
                                    data-branch-id="<?= $partner['receiver_branch_id'] ?? 0 ?>"
                                    data-provider-name="<?= htmlspecialchars($partner['business_name']) ?>">
                                    <i data-lucide="message-square" size="18"></i>
                                    <span id="dot-<?= $partner['sender_id'] ?>-<?= $partner['receiver_branch_id'] ?? 0 ?>" class="unread-dot absolute -top-1 -right-1 w-3 h-3 bg-rose-500 border-2 border-white dark:border-neutral-900 rounded-full hidden animate-bounce"></span>
                                </button>
                                <?php endif; ?>
                                <button title="Disconnect" onclick="handleRequest(<?= $partner['id'] ?>, 'reject_request')" class="p-2 text-slate-400 hover:text-rose-500 transition-all bg-slate-50 dark:bg-neutral-800 rounded-lg">
                                    <i data-lucide="user-minus" size="18"></i>
                                </button>
                                <!-- More Options Dropdown -->
                                <div class="relative group/more">
                                    <button class="p-2 text-slate-400 hover:text-orange-500 transition-all bg-slate-50 dark:bg-neutral-800 rounded-lg">
                                        <i data-lucide="more-vertical" size="18"></i>
                                    </button>
                                    <div class="absolute right-0 top-full pt-1 w-40 z-50 invisible opacity-0 translate-y-2 group-hover/more:visible group-hover/more:opacity-100 group-hover/more:translate-y-0 transition-all duration-200 delay-150 group-hover/more:delay-0">
                                        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl shadow-xl overflow-hidden">
                                            <button class="w-full text-left px-4 py-2.5 text-[10px] font-bold text-slate-700 dark:text-neutral-300 hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2"><i data-lucide="user" size="14"></i> View Profile</button>
                                            <a href="view_partner_catalog.php?provider_id=<?= $partner['partner_tenant_id'] ?>" class="w-full text-left px-4 py-2.5 text-[10px] font-bold text-slate-700 dark:text-neutral-300 hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2"><i data-lucide="shopping-bag" size="14"></i> Browse Inventory</a>
                                            <button class="w-full text-left px-4 py-2.5 text-[10px] font-bold text-slate-700 dark:text-neutral-300 hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2"><i data-lucide="refresh-cw" size="14"></i> Sync Inventory</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Info Card -->
            <div class="mt-8 p-6 border border-dashed border-slate-200 dark:border-neutral-800 rounded-3xl flex items-start gap-4">
                <div class="p-3 bg-blue-500/10 text-blue-500 rounded-xl"><i data-lucide="info" size="20"></i></div>
                <p class="text-xs text-slate-500 leading-relaxed">Connecting with a partner allows you to sync inventory, share digital catalogs, and automate wholesale orders in future updates. Make sure the ID is correct before sending.</p>
            </div>
        </div>
    </main>

    <!-- B2B Chat Container -->
    <div id="chat-container" class="fixed bottom-6 right-6 md:right-24 md:w-96 w-[calc(100%-2rem)] bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[32px] shadow-2xl hidden z-[200] overflow-hidden flex flex-col animate-in fade-in slide-in-from-bottom-4 duration-300 max-h-[600px]">
        <div class="p-4 bg-orange-600 text-white flex justify-between items-center">
            <div class="flex items-center gap-2">
                <div class="w-2 h-2 bg-emerald-400 rounded-full animate-pulse"></div>
                <div>
                    <p id="chat-partner-name" class="font-black uppercase text-xs tracking-widest"></p>
                    <p class="text-[9px] opacity-80 uppercase font-bold">Secure B2B Connection</p>
                </div>
            </div>
            <button onclick="closeChatWindow()" class="p-1.5 hover:bg-black/10 rounded-xl transition-colors"><i data-lucide="x" size="18"></i></button>
        </div>
        <div id="chat-messages-area" class="flex-1 p-4 h-80 overflow-y-auto bg-slate-50 dark:bg-neutral-950 space-y-3 custom-scrollbar">
            <!-- Messages load here -->
        </div>
        <div class="p-4 bg-white dark:bg-neutral-900 border-t border-slate-100 dark:border-neutral-800">
            <div class="flex items-center gap-2">
                <?php if (has_module('chat_images')): ?>
                <input type="file" id="chat-file-input" class="hidden" accept="image/*" onchange="handleImageUpload(this)">
                <button onclick="document.getElementById('chat-file-input').click()" title="Attach Image" class="p-2.5 text-slate-400 hover:text-orange-500 transition-colors bg-slate-50 dark:bg-neutral-800 rounded-2xl">
                    <i data-lucide="image" size="20"></i>
                </button>
                <?php endif; ?>
                <div class="relative flex-1">
                    <input type="text" id="chat-input" onkeypress="if(event.key === 'Enter') sendMessage()" placeholder="Type a message..." class="w-full pl-4 pr-12 py-3 bg-slate-100 dark:bg-neutral-800 border-none rounded-2xl outline-none text-sm dark:text-white font-medium focus:ring-2 focus:ring-orange-500/20 transition-all">
                    <button id="chat-send-btn" onclick="sendMessage()" class="absolute right-2 top-1/2 -translate-y-1/2 p-2 text-orange-600 hover:text-orange-700 transition-all">
                        <i data-lucide="send" size="18"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Image Zoom Modal -->
    <div id="imageZoomModal" class="fixed inset-0 bg-black/90 hidden items-center justify-center backdrop-blur-sm z-[210] p-4" onclick="closeImageZoom()">
        <button class="absolute top-6 right-6 text-white hover:text-orange-500 transition-colors"><i data-lucide="x" size="32"></i></button>
        <img id="zoomedImage" src="" class="max-w-full max-h-full rounded-2xl shadow-2xl animate-in zoom-in duration-300">
    </div>

    <script>
        let currentPartnerId = null;
        let currentChatRoomId = null;
        let activeChatRef = null;
        const notificationSound = new Audio('https://assets.mixkit.co/active_storage/sfx/2358/2358-preview.mp3');
        const myTenantId = "<?= $_SESSION['tenant_id'] ?>";

        // Handle Chat Button Clicks
        document.querySelectorAll('.chat-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                const providerId = this.dataset.providerId;
                const subscriberId = this.dataset.subscriberId;
                const branchId = this.dataset.branchId;
                const providerName = this.dataset.providerName;

                // Deterministic Chat Room ID so both parties join the same node
                const chatRoomId = `room_${subscriberId}_${branchId}`;

                // Update UI
                document.getElementById('chat-partner-name').innerText = providerName;
                
                // Mark room as read for ME
                db.ref(`chats/${chatRoomId}/unread/${myTenantId}`).set(false);

                // Show Container
                const container = document.getElementById('chat-container');
                container.classList.remove('hidden');
                
                listenForMessages(chatRoomId);
            });
        });

        // Global Listener for Unread Dots on Partner Cards
        function initUnreadListeners() {
            document.querySelectorAll('.chat-btn').forEach(btn => {
                const rid = `room_${btn.dataset.subscriberId}_${btn.dataset.branchId}`;
                const dot = document.getElementById(`dot-${btn.dataset.subscriberId}-${btn.dataset.branchId}`);
                
                db.ref(`chats/${rid}/unread/${myTenantId}`).on('value', (snapshot) => {
                    if (snapshot.val() === true && currentChatRoomId !== rid) {
                        dot.classList.remove('hidden');
                    } else {
                        dot.classList.add('hidden');
                    }
                });
            });
        }
        document.addEventListener('DOMContentLoaded', initUnreadListeners);

        function closeChatWindow() {
            if (activeChatRef) activeChatRef.off(); // Stop listening when closed
            document.getElementById('chat-container').classList.add('hidden');
            currentChatRoomId = null;
        }

        function listenForMessages(chatRoomId) {
            if (activeChatRef) activeChatRef.off(); // Remove previous listener
            
            currentChatRoomId = chatRoomId;
            const messagesArea = document.getElementById('chat-messages-area');
            messagesArea.innerHTML = ''; // Clear for new room

            activeChatRef = db.ref(`chats/${chatRoomId}/messages`);
            activeChatRef.on('child_added', (snapshot) => {
                const msg = snapshot.val();
                appendMessageToUI(msg);
                
                // If message is from partner and chat is open, play sound
                if (msg.sender_id != myTenantId) {
                    notificationSound.play().catch(e => {});
                    // Auto-mark as read since I'm looking at it
                    db.ref(`chats/${chatRoomId}/unread/${myTenantId}`).set(false);
                }
            });
        }

        function appendMessageToUI(msg) {
            const messagesArea = document.getElementById('chat-messages-area');
            const isMe = msg.sender_id == myTenantId;
            
            const msgDiv = document.createElement('div');
            msgDiv.className = `flex ${isMe ? 'justify-end' : 'justify-start'} animate-in fade-in slide-in-from-bottom-2 duration-300`;
            
            let contentHtml = msg.text;
            if (msg.type === 'image') {
                contentHtml = `<img src="${msg.text}" onclick="openImageZoom('${msg.text}')" class="rounded-xl max-w-full h-auto cursor-zoom-in hover:opacity-90 transition-all shadow-sm">`;
            }

            msgDiv.innerHTML = `
                <div class="max-w-[80%] px-4 py-2.5 rounded-2xl text-sm font-medium ${isMe ? 'bg-orange-600 text-white rounded-tr-none' : 'bg-white dark:bg-neutral-800 text-slate-700 dark:text-neutral-200 border border-slate-100 dark:border-neutral-700 rounded-tl-none'} shadow-sm">
                    ${contentHtml}
                    <p class="text-[8px] mt-1 opacity-50 ${isMe ? 'text-right' : 'text-left'}">${new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</p>
                </div>
            `;
            
            messagesArea.appendChild(msgDiv);
            messagesArea.scrollTop = messagesArea.scrollHeight; // Auto-scroll
        }

        async function sendMessage() {
            const input = document.getElementById('chat-input');
            const text = input.value.trim();
            if (!text || !currentChatRoomId) return;

            // Apply Code-based Restrictions (from chat_restrictions.js)
            const validation = ChatRestrictions.validate(text);
            if (!validation.isValid) {
                Swal.fire({
                    title: 'Biltax Security',
                    text: validation.message,
                    icon: 'warning',
                    confirmButtonColor: '#ea580c',
                    customClass: {
                        popup: 'rounded-[32px] border border-slate-200 dark:border-neutral-800 bg-white dark:bg-neutral-900',
                        title: 'dark:text-white font-black uppercase tracking-tight',
                        htmlContainer: 'dark:text-slate-400 font-medium'
                    }
                });
                return; // Stop execution: Do not send to Firebase
            }

            const msgData = {
                sender_id: myTenantId,
                text: text,
                timestamp: Date.now(),
                type: 'text'
            };

            // Get Partner ID (Receiver)
            const btn = document.querySelector(`.chat-btn[data-subscriber-id="${currentChatRoomId.split('_')[1]}"][data-branch-id="${currentChatRoomId.split('_')[2]}"]`);
            const partnerTenantId = btn ? btn.dataset.providerId : null;

            try {
                // 1. Send Message to Firebase (This will trigger .validate rules)
                await db.ref(`chats/${currentChatRoomId}/messages`).push(msgData);

                // 2. Set unread flag for the PARTNER
                if (partnerTenantId) {
                    await db.ref(`chats/${currentChatRoomId}/unread/${partnerTenantId}`).set(true);
                }

                // Clear input only on success
                input.value = '';
            } catch (err) {
                // Detailed Error Handling
                console.error("Firebase API Error:", err);
                Swal.fire({
                    title: 'Biltax Chat Error',
                    text: 'Firebase Rejected: ' + err.message + '. Please ensure your Database Rules are set to true.',
                    icon: 'error',
                    confirmButtonColor: '#ea580c'
                });
            }
        }

        async function findPartner() {
            const idInput = document.getElementById('biltax_id');
            const resArea = document.getElementById('result_area');
            const errArea = document.getElementById('error_area');
            
            resArea.classList.add('hidden');
            errArea.classList.add('hidden');

            const formData = new FormData();
            formData.append('action', 'find_partner');
            formData.append('biltax_id', idInput.value);

            const response = await fetch('connect_partner.php', { method: 'POST', body: formData });
            const data = await response.json();

            if (data.success) {
                document.getElementById('res_name').innerText = data.business;
                document.getElementById('res_owner').innerText = 'Managed by: ' + data.owner;
                currentPartnerId = data.id;
                resArea.classList.remove('hidden');
            } else {
                document.getElementById('error_msg').innerText = data.message;
                errArea.classList.remove('hidden');
            }
        }

        async function sendRequest() {
            const btn = document.getElementById('send_btn');
            btn.disabled = true;
            btn.innerText = 'Sending...';

            const formData = new FormData();
            formData.append('action', 'send_request');
            formData.append('receiver_id', currentPartnerId);

            const response = await fetch('connect_partner.php', { method: 'POST', body: formData });
            const data = await response.json();

            if (data.success) {
                btn.innerText = 'Request Sent!';
                btn.className = "bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold text-xs uppercase";
                setTimeout(() => location.reload(), 2000);
            } else {
                alert(data.message);
                btn.disabled = false;
                btn.innerText = 'Send Connection Request';
            }
        }

        async function handleRequest(connId, action) {
            if (!confirm('Are you sure you want to perform this action?')) return;
            
            const formData = new FormData();
            formData.append('action', action);
            formData.append('conn_id', connId);

            const response = await fetch('connect_partner.php', { method: 'POST', body: formData });
            const data = await response.json();

            if (data.success) {
                location.reload();
            } else {
                alert(data.message);
            }
        }
        lucide.createIcons();
    </script>
</body>
</html>