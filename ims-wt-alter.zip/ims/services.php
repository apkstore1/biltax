<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

$my_tenant_id = $_SESSION['tenant_id'] ?? 0;

// Handle Save/Edit Service
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_service' || $_POST['action'] === 'edit_service') {
        $checklists = isset($_POST['checklist']) ? json_encode(array_filter($_POST['checklist'])) : null;
        
        if ($_POST['action'] === 'add_service') {
            $stmt = $tenant_conn->prepare("INSERT INTO services (tenant_id, service_name, description, base_price, category, checklists) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$my_tenant_id, $_POST['name'], $_POST['desc'], $_POST['price'], $_POST['cat'], $checklists]);
        } else {
            $stmt = $tenant_conn->prepare("UPDATE services SET service_name=?, description=?, base_price=?, category=?, checklists=? WHERE id=? AND tenant_id=?");
            $stmt->execute([$_POST['name'], $_POST['desc'], $_POST['price'], $_POST['cat'], $checklists, $_POST['id'], $my_tenant_id]);
        }
        header("Location: services.php?msg=success"); exit;
    }
}

// Handle Status Toggle (Disable/Enable)
if (isset($_GET['toggle_id'])) {
    $id = (int)$_GET['toggle_id'];
    $stmt = $tenant_conn->prepare("UPDATE services SET is_active = NOT is_active WHERE id = ? AND tenant_id = ?");
    $stmt->execute([$id, $my_tenant_id]);
    header("Location: services.php?msg=success"); exit;
}

$services = $tenant_conn->query("SELECT * FROM services ORDER BY category ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Service Catalog | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Service Catalog</h1>
                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Define your service offerings and pricing</p>
            </div>
            <button onclick="document.getElementById('addServiceModal').classList.remove('hidden')" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-orange-600/20">Add New Service</button>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php foreach($services as $s): ?>
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm group <?= !$s['is_active'] ? 'opacity-60 grayscale' : '' ?>">
                <div class="flex justify-between mb-4">
                    <div class="flex items-center gap-2">
                        <span class="text-[8px] font-black uppercase px-2 py-1 bg-orange-500/10 text-orange-500 rounded-lg"><?= htmlspecialchars($s['category'] ?: 'General') ?></span>
                        <?php if(!$s['is_active']): ?><span class="text-[8px] font-black uppercase px-2 py-1 bg-rose-500 text-white rounded-lg">Disabled</span><?php endif; ?>
                    </div>
                    <p class="text-lg font-black text-orange-600"><?= $currency_symbol ?><?= number_format($s['base_price'], 2) ?></p>
                </div>
                <h3 class="text-lg font-black dark:text-white uppercase"><?= htmlspecialchars($s['service_name']) ?></h3>
                <p class="text-xs text-slate-500 dark:text-neutral-400 mt-2 line-clamp-2 mb-4"><?= htmlspecialchars($s['description']) ?></p>
                
                <?php 
                $tasks = json_decode($s['checklists'], true);
                if(!empty($tasks)): ?>
                <div class="space-y-1.5 mb-4">
                    <p class="text-[9px] font-black uppercase text-slate-400">Standard Checklist:</p>
                    <?php foreach($tasks as $t): ?>
                        <div class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-neutral-300">
                            <i data-lucide="check-square" size="12" class="text-orange-500"></i> <?= htmlspecialchars($t) ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <div class="mt-6 pt-4 border-t border-slate-100 dark:border-neutral-800 flex gap-2">
                    <button onclick='openEditModal(<?= json_encode($s) ?>)' class="flex-1 py-2 bg-slate-100 dark:bg-neutral-800 text-[9px] font-black uppercase dark:text-white rounded-xl hover:bg-orange-600 transition-all">Edit</button>
                    <button onclick="confirmStatusToggle(<?= $s['id'] ?>, <?= $s['is_active'] ?>)" class="flex-1 py-2 <?= $s['is_active'] ? 'bg-rose-500/10 text-rose-500' : 'bg-emerald-500/10 text-emerald-500' ?> text-[9px] font-black uppercase rounded-xl">
                        <?= $s['is_active'] ? 'Disable' : 'Enable' ?>
                    </button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <!-- Add Service Modal -->
    <div id="addServiceModal" class="fixed inset-0 bg-black/80 hidden flex items-center justify-center p-4 z-50 backdrop-blur-sm">
        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] w-full max-w-lg border border-slate-200 dark:border-neutral-800 shadow-2xl max-h-[90vh] overflow-y-auto custom-scrollbar">
            <h2 id="modalTitle" class="text-2xl font-black dark:text-white uppercase mb-6 text-center">Define Service</h2>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" id="formAction" value="add_service">
                <input type="hidden" name="id" id="serviceId">
                
                <div class="grid grid-cols-2 gap-4">
                    <input type="text" name="name" id="serviceName" placeholder="Service Name" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                    <input type="text" name="cat" id="serviceCat" placeholder="Category" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                </div>

                <input type="number" step="0.01" name="price" id="servicePrice" placeholder="Base Price (<?= $currency_symbol ?>)" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                
                <textarea name="desc" id="serviceDesc" placeholder="Service Description..." class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm"></textarea>

                <!-- Dynamic Checklist Section -->
                <div class="pt-4 border-t border-slate-100 dark:border-neutral-800">
                    <div class="flex justify-between items-center mb-4">
                        <label class="text-[10px] font-black uppercase text-slate-400">Service Checklist / Tasks</label>
                        <button type="button" onclick="addTaskField('')" class="text-[10px] font-black uppercase text-orange-600 flex items-center gap-1 hover:underline">
                            <i data-lucide="plus-circle" size="14"></i> Add Task
                        </button>
                    </div>
                    <div id="checklistContainer" class="space-y-3">
                        <!-- Tasks will be injected here -->
                    </div>
                </div>

                <div class="pt-6">
                    <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 active:scale-95 transition-all">Save Service</button>
                    <button type="button" onclick="document.getElementById('addServiceModal').classList.add('hidden')" class="w-full text-slate-400 text-[10px] font-black uppercase mt-3">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();

        function addTaskField(val = '') {
            const container = document.getElementById('checklistContainer');
            const div = document.createElement('div');
            div.className = "flex gap-2 group animate-in fade-in slide-in-from-top-1";
            div.innerHTML = `
                <input type="text" name="checklist[]" value="${val}" placeholder="Task Name" class="flex-1 p-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold text-xs">
                <button type="button" onclick="this.parentElement.remove()" class="p-3 text-rose-500 hover:bg-rose-500/10 rounded-xl transition-all"><i data-lucide="x" size="16"></i></button>
            `;
            container.appendChild(div);
            lucide.createIcons();
        }

        function openEditModal(service) {
            document.getElementById('modalTitle').innerText = 'Edit Service';
            document.getElementById('serviceId').value = service.id;
            document.getElementById('formAction').value = 'edit_service';
            document.getElementById('serviceName').value = service.service_name;
            document.getElementById('serviceCat').value = service.category;
            document.getElementById('servicePrice').value = service.base_price;
            document.getElementById('serviceDesc').value = service.description;
            
            const container = document.getElementById('checklistContainer');
            container.innerHTML = '';
            const checklist = JSON.parse(service.checklists || '[]');
            if (checklist.length > 0) {
                checklist.forEach(task => addTaskField(task));
            } else {
                addTaskField('');
            }
            
            document.getElementById('addServiceModal').classList.remove('hidden');
        }

        function confirmStatusToggle(id, isActive) {
            if (isActive) {
                if (confirm("This will be deleted shortly after disabling. Are you sure you want to disable it?")) {
                    window.location.href = `services.php?toggle_id=${id}`;
                }
            } else {
                window.location.href = `services.php?toggle_id=${id}`;
            }
        }
    </script>
</body>
</html>