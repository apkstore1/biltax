<?php
require_once 'config/db_switch.php';

// Session handling for Technician (Standalone Login)
if (isset($_POST['tech_login'])) {
    $name = $_POST['name'];
    $pass = $_POST['password'];
    
    // Technician check logic
    $stmt = $tenant_conn->prepare("SELECT * FROM users WHERE name = ? AND role IN ('technician', 'staff', 'admin')");
    $stmt->execute([$name]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($pass, $user['password'])) {
        $_SESSION['staff_id'] = $user['id'];
        $_SESSION['staff_name'] = $user['name'];
        $_SESSION['staff_role'] = $user['role'];
        header("Location: tech_jobs.php"); exit;
    } else { 
        $error = "Invalid name or password."; 
    }
}

if (isset($_GET['logout'])) { 
    unset($_SESSION['staff_id']);
    unset($_SESSION['staff_name']);
    unset($_SESSION['staff_role']);
    header("Location: tech_jobs.php"); exit; 
}

$is_logged_in = isset($_SESSION['staff_id']);
$tech_id = $_SESSION['staff_id'] ?? null;

// Fetch Assigned Jobs
$jobs = [];
if ($is_logged_in) {
    try {
        $stmt = $tenant_conn->prepare("
            SELECT j.*, c.name as customer_name, c.phone as customer_phone, c.address, s.service_name, s.checklists as service_checklist
            FROM job_cards j
            LEFT JOIN customers c ON j.customer_id = c.id
            LEFT JOIN services s ON j.service_id = s.id 
            WHERE j.assigned_to = ? AND j.status IN ('pending', 'in_progress', 'received', 'completed')
            ORDER BY j.id DESC
        ");
        $stmt->execute([$tech_id]);
        $jobs = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) {
        $jobs = [];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>My Jobs | Tech Portal</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; -webkit-tap-highlight-color: transparent; }
        .job-card { transition: transform 0.2s ease; }
        .job-card:active { transform: scale(0.98); }
    </style>
</head>
<body class="bg-slate-50 min-h-screen">

    <?php if (!$is_logged_in): ?>
        <!-- Login Screen (Same as Rider Portal Style) -->
        <div class="flex items-center justify-center p-6 min-h-screen">
            <div class="w-full max-w-sm bg-white p-8 rounded-[40px] shadow-2xl border border-slate-200">
                <div class="text-center mb-8">
                    <div class="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-4 shadow-lg shadow-orange-600/20">
                        <i data-lucide="wrench" size="32"></i>
                    </div>
                    <h1 class="text-2xl font-800 uppercase tracking-tighter">Tech Login</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Service Man Portal</p>
                </div>
                <?php if(isset($error)): ?>
                    <p class="mb-4 text-rose-500 text-center text-xs font-bold"><?= $error ?></p>
                <?php endif; ?>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="tech_login" value="1">
                    <input type="text" name="name" placeholder="Full Name" required class="w-full p-4 bg-slate-50 rounded-2xl outline-none font-bold text-sm border border-slate-100">
                    <input type="password" name="password" placeholder="Password" required class="w-full p-4 bg-slate-50 rounded-2xl outline-none font-bold text-sm border border-slate-100">
                    <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 active:scale-95 transition-all mt-4">Launch Jobs</button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <!-- Header -->
        <header class="bg-white border-b sticky top-0 z-30 px-6 py-4 flex justify-between items-center">
            <div>
                <h1 class="text-xl font-800 text-slate-900">Hello, <?= htmlspecialchars($_SESSION['staff_name']) ?></h1>
                <p class="text-[10px] font-black text-orange-600 uppercase tracking-widest">Active Shift</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="?logout=1" class="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-400 hover:text-rose-500 transition-colors">
                    <i data-lucide="log-out" size="18"></i>
                </a>
            </div>
        </header>

        <main class="p-4 space-y-4 pb-24">
            <div class="flex items-center justify-between mb-2">
                <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest">Assigned Tasks</h3>
                <span class="px-2 py-1 bg-orange-600 text-white text-[9px] font-black rounded-lg"><?= count($jobs) ?> Jobs</span>
            </div>

            <?php if (empty($jobs)): ?>
                <div class="text-center py-20 opacity-30">
                    <i data-lucide="clipboard-check" size="48" class="mx-auto mb-2 text-slate-400"></i>
                    <p class="font-bold text-sm">No pending tasks.</p>
                </div>
            <?php endif; ?>

            <?php foreach ($jobs as $job): 
                $checklist = json_decode($job['task_completion_data'] ?: $job['service_checklist'] ?: '[]', true);
                $status_color = match($job['status']) {
                    'in_progress' => 'bg-blue-500',
                    'completed' => 'bg-emerald-500',
                    'received' => 'bg-amber-500',
                    default => 'bg-slate-400'
                };
            ?>
            <div class="job-card bg-white rounded-[24px] border border-slate-200 shadow-sm overflow-hidden" id="job-<?= $job['id'] ?>">
                <div class="p-5">
                    <div class="flex justify-between items-start mb-3">
                        <span class="px-3 py-1 <?= $status_color ?> text-white text-[9px] font-black uppercase rounded-full">
                            <?= $job['status'] ?>
                        </span>
                        <span class="text-[10px] font-mono text-slate-400">#JC-<?= $job['id'] ?></span>
                    </div>
                    
                    <h3 class="text-lg font-bold text-slate-900 leading-tight mb-1"><?= htmlspecialchars($job['customer_name'] ?: 'Walk-in Customer') ?></h3>
                    <p class="text-sm font-semibold text-orange-600 mb-4"><?= htmlspecialchars($job['service_name'] ?: 'General Service') ?></p>

                    <div class="grid grid-cols-2 gap-2">
                        <a href="tel:<?= $job['customer_phone'] ?>" class="flex items-center justify-center gap-2 py-3 bg-emerald-500 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-500/20 active:scale-95 transition-all">
                            <i data-lucide="phone" size="14"></i> Call
                        </a>
                        <a href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($job['address']) ?>" target="_blank" class="flex items-center justify-center gap-2 py-3 bg-slate-100 text-slate-600 rounded-2xl text-[10px] font-black uppercase tracking-widest active:scale-95 transition-all">
                            <i data-lucide="navigation" size="14"></i> Locate
                        </a>
                    </div>
                </div>
                
                <?php if(!empty($job['address'])): ?>
                <div class="px-5 pb-4">
                    <p class="text-[9px] text-slate-400 font-bold uppercase truncate"><i data-lucide="map-pin" size="10" class="inline mb-0.5"></i> <?= htmlspecialchars($job['address']) ?></p>
                </div>
                <?php endif; ?>

                <!-- Checklist Section -->
                <div class="bg-slate-50 border-t p-5">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-3 tracking-widest">Service Checklist</p>
                    <div class="space-y-2">
                        <?php foreach ($checklist as $index => $item): 
                            $label = is_array($item) ? ($item['label'] ?? '') : $item;
                            $checked = is_array($item) && isset($item['completed']) && $item['completed'] ? 'checked' : '';
                        ?>
                            <label class="flex items-center gap-3 bg-white p-3 rounded-xl border border-slate-200 cursor-pointer">
                                <input type="checkbox" class="w-5 h-5 rounded-md border-slate-300 text-orange-600 focus:ring-orange-500 checklist-item" 
                                       data-job-id="<?= $job['id'] ?>" data-index="<?= $index ?>" <?= $checked ?>>
                                <span class="text-sm font-semibold text-slate-700"><?= htmlspecialchars($label) ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    
                    <!-- Actions -->
                    <div class="mt-6 grid grid-cols-2 gap-3">
                        <?php if ($job['status'] === 'pending' || $job['status'] === 'received'): ?>
                            <button onclick="updateJobStatus(<?= $job['id'] ?>, 'in_progress')" class="col-span-2 py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 shadow-xl shadow-orange-600/20">
                                <i data-lucide="play" size="18"></i> Start Work
                            </button>
                        <?php elseif ($job['status'] === 'in_progress'): ?>
                            <button onclick="updateJobStatus(<?= $job['id'] ?>, 'completed')" class="col-span-2 py-4 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 shadow-xl shadow-emerald-600/20">
                                <i data-lucide="check-circle" size="18"></i> Mark as Done
                            </button>
                        <?php elseif ($job['status'] === 'completed'): ?>
                            <button onclick="updateJobStatus(<?= $job['id'] ?>, 'delivered')" class="col-span-2 py-4 bg-slate-900 text-white rounded-2xl font-black uppercase tracking-widest text-[10px] flex items-center justify-center gap-2 shadow-xl">
                                <i data-lucide="truck" size="18"></i> Deliver to Client
                            </button>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        </main>

        <!-- Bottom Nav -->
        <nav class="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-lg border-t px-8 py-4 flex justify-around items-center z-40">
            <a href="tech_jobs.php" class="text-orange-600 flex flex-col items-center">
                <i data-lucide="wrench" size="20"></i>
                <span class="text-[9px] font-black mt-1 uppercase tracking-tighter">My Tasks</span>
            </a>
            <a href="dashboard.php" class="text-slate-400 flex flex-col items-center">
                <i data-lucide="layout-dashboard" size="20"></i>
                <span class="text-[9px] font-black mt-1 uppercase tracking-tighter">Admin Panel</span>
            </a>
        </nav>
    <?php endif; ?>

    <script>
        lucide.createIcons();

        async function updateJobStatus(id, status) {
            if (!confirm(`Are you sure you want to set this job to ${status}?`)) return;
            
            try {
                const res = await fetch(`api.php?route=jobs/update_status`, {
                    method: 'POST',
                    body: JSON.stringify({ id, status })
                });
                const data = await res.json();
                if (data.success) location.reload();
                else alert(data.message || 'Status update failed');
            } catch (e) { alert('Network error'); }
        }

        // Handle Checklist Toggling
        document.querySelectorAll('.checklist-item').forEach(checkbox => {
            checkbox.addEventListener('change', async (e) => {
                const jobId = e.target.dataset.jobId;
                const index = e.target.dataset.index;
                const completed = e.target.checked;

                try {
                    await fetch(`api.php?route=jobs/update_checklist`, {
                        method: 'POST',
                        body: JSON.stringify({ 
                            job_id: jobId, 
                            index: index, 
                            completed: completed 
                        })
                    });
                } catch (e) { 
                    e.target.checked = !completed; // Revert on failure
                    alert('Progress could not be saved'); 
                }
            });
        });
    </script>
</body>
</html>