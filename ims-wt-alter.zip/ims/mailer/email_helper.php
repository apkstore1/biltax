<?php
/**
 * Biltax Global Email Helper
 * Location: /mailer/email_helper.php
 */

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Safety Check: Prevent 500 error if PHPMailer files are missing
if (file_exists(__DIR__ . '/PHPMailer/src/PHPMailer.php')) {
    require_once __DIR__ . '/PHPMailer/src/Exception.php';
    require_once __DIR__ . '/PHPMailer/src/PHPMailer.php';
    require_once __DIR__ . '/PHPMailer/src/SMTP.php';
    define('PHPMAILER_AVAILABLE', true);
} else {
    define('PHPMAILER_AVAILABLE', false);
    error_log("Biltax Warning: PHPMailer library missing in /mailer/PHPMailer/src/");
}

/**
 * Sends a branded Biltax HTML Email
 * 
 * @param string $to Recipient email
 * @param string $subject Email subject
 * @param mixed $data Content string or Array for templates
 * @param string $type Template type: 'activation', 'expiry', 'stock_alert', 'general'
 * @return bool
 */
function sendBiltaxEmail($to, $subject, $data, $type = 'general') {
    if (!PHPMAILER_AVAILABLE) {
        error_log("Biltax Mailer: Cannot send email because PHPMailer is missing.");
        return false;
    }

    $mail = new PHPMailer(true);

    try {
        // --- SMTP CONFIGURATION ---
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com'; // Or email-smtp.us-east-1.amazonaws.com
        $mail->SMTPAuth   = true;
        $mail->Username   = 'biltaxofficial@gmail.com'; // SMTP Username
        $mail->Password   = 'mgpa thdo ublq ipzq';    // SMTP Password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // Recipients
        $mail->setFrom('noreply@biltax.com', 'Biltax System');
        $mail->addAddress($to);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = getBiltaxTemplate($subject, $data, $type);
        $mail->AltBody = is_array($data) ? "Please view this email in an HTML compatible client." : strip_tags($data);

        $mail->send();
        return true;
    } catch (Exception $e) {
        error_log("Biltax Mailer Error: " . $mail->ErrorInfo);
        return false;
    }
}

/**
 * Generates HTML Template based on type
 */
function getBiltaxTemplate($subject, $data, $type) {
    $logo = "https://res.cloudinary.com/dumptsnaj/image/upload/v1/assets/Biltax-icon.png"; // Replace with your actual hosted logo
    $primaryColor = "#2563eb"; // Dark Blue
    $accentColor = "#f97316";  // Biltax Orange
    $darkBg = "#0f172a";       // Slate 900

    $header = "
    <div style='background-color: $darkBg; padding: 40px 20px; font-family: Helvetica, Arial, sans-serif; color: #ffffff;'>
        <center>
            <table width='600' border='0' cellspacing='0' cellpadding='0' style='background: #1e293b; border-radius: 24px; overflow: hidden; border: 1px solid #334155;'>
                <tr>
                    <td style='padding: 40px; text-align: center; border-bottom: 1px solid #334155;'>
                        <img src='$logo' width='60' style='margin-bottom: 15px;'>
                        <h1 style='margin: 0; font-size: 24px; font-weight: 900; letter-spacing: -1px;'>BILTAX</h1>
                        <p style='margin: 5px 0 0; font-size: 10px; font-weight: bold; color: $accentColor; text-transform: uppercase; letter-spacing: 2px;'>Intelligent Management System</p>
                    </td>
                </tr>
                <tr>
                    <td style='padding: 40px;'>";

    $footer = "
                    </td>
                </tr>
                <tr>
                    <td style='padding: 30px; text-align: center; background: #0f172a; border-top: 1px solid #334155;'>
                        <p style='margin: 0; font-size: 11px; color: #64748b;'>&copy; ".date('Y')." Biltax. All rights reserved.</p>
                        <div style='margin-top: 10px;'>
                            <a href='#' style='color: $accentColor; text-decoration: none; font-size: 11px; font-weight: bold;'>Support Center</a> &bull; 
                            <a href='#' style='color: $accentColor; text-decoration: none; font-size: 11px; font-weight: bold;'>Documentation</a>
                        </div>
                    </td>
                </tr>
            </table>
        </center>
    </div>";

    $content = "";

    switch ($type) {
        case 'activation':
            $name = $data['name'] ?? 'Partner';
            $content = "
                <h2 style='color: #ffffff; margin-bottom: 20px;'>Welcome to the Ecosystem!</h2>
                <p style='font-size: 15px; line-height: 1.6; color: #94a3b8;'>Hello <b>$name</b>,</p>
                <p style='font-size: 15px; line-height: 1.6; color: #94a3b8;'>Your Biltax account has been successfully activated. You now have full access to our world-class inventory and financial tools.</p>
                <div style='margin: 35px 0; text-align: center;'>
                    <a href='https://biltax.com/login' style='background: $primaryColor; color: #ffffff; padding: 16px 40px; border-radius: 14px; text-decoration: none; font-weight: bold; font-size: 14px; box-shadow: 0 10px 20px rgba(37, 99, 235, 0.2);'>Access Your Dashboard</a>
                </div>
                <p style='font-size: 12px; color: #64748b;'>If you didn't create this account, please ignore this email.</p>";
            break;

        case 'expiry':
            $days = $data['days_left'] ?? '0';
            $plan = $data['plan_name'] ?? 'Current Plan';
            $content = "
                <div style='background: rgba(225, 29, 72, 0.1); border: 1px solid #e11d48; padding: 20px; border-radius: 16px; margin-bottom: 25px;'>
                    <h2 style='color: #e11d48; margin: 0; font-size: 18px;'>Action Required: Plan Expiring</h2>
                </div>
                <p style='font-size: 15px; line-height: 1.6; color: #94a3b8;'>Your subscription for the <b>$plan</b> is set to expire in <b style='color: #ffffff;'>$days days</b>.</p>
                <p style='font-size: 15px; line-height: 1.6; color: #94a3b8;'>To prevent any service interruption or loss of data access, please renew your subscription now.</p>
                <div style='margin: 35px 0; text-align: center;'>
                    <a href='https://biltax.com/billing' style='background: #e11d48; color: #ffffff; padding: 16px 40px; border-radius: 14px; text-decoration: none; font-weight: bold; font-size: 14px; box-shadow: 0 10px 20px rgba(225, 29, 72, 0.2);'>Upgrade / Renew Now</a>
                </div>";
            break;

        case 'stock_alert':
            $items = $data['items'] ?? [];
            $items_html = "";
            foreach($items as $item) {
                $items_html .= "<tr>
                    <td style='padding: 12px 0; border-bottom: 1px solid #334155; color: #ffffff; font-size: 14px;'>".$item['name']."</td>
                    <td style='padding: 12px 0; border-bottom: 1px solid #334155; color: #e11d48; font-weight: bold; text-align: right;'>".$item['stock']." remaining</td>
                </tr>";
            }
            $content = "
                <h2 style='color: #f59e0b; margin-bottom: 10px;'>Low Stock Warning</h2>
                <p style='font-size: 14px; color: #94a3b8; margin-bottom: 25px;'>The following items in your inventory have reached critical levels:</p>
                <table width='100%' cellspacing='0' cellpadding='0'>
                    $items_html
                </table>
                <div style='margin-top: 30px; text-align: center;'>
                    <a href='https://biltax.com/inventory' style='color: #f59e0b; font-weight: bold; text-decoration: underline;'>Manage Inventory</a>
                </div>";
            break;

        default:
            $msg = is_array($data) ? ($data['message'] ?? '') : $data;
            $content = "
                <h2 style='color: #ffffff; margin-bottom: 20px;'>$subject</h2>
                <p style='font-size: 15px; line-height: 1.8; color: #94a3b8;'>$msg</p>";
            break;
    }

    return $header . $content . $footer;
}