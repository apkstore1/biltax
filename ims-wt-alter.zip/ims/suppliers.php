<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Ensure table exists
$tenant_conn->exec("CREATE TABLE IF NOT EXISTS suppliers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    company VARCHAR(100),
    phone VARCHAR(20),
    email VARCHAR(100),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;");

// Self-healing: Ensure company column exists for older databases
try { $tenant_conn->exec("ALTER TABLE suppliers ADD COLUMN IF NOT EXISTS company VARCHAR(100) AFTER name"); } catch(Exception $e){}

// --- Setup Main DB Connection for Partner Features ---
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Self-healing: Ensure unique_id column exists in tenants table
    $current_cols = $main_pdo->query("SHOW COLUMNS FROM tenants")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('unique_id', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN unique_id VARCHAR(20) UNIQUE AFTER id");
    }

    // Get current tenant's ID from main DB
    $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
    $stmt->execute([$_SESSION['db_name']]);
    $my_main_id = $stmt->fetchColumn();

} catch (Exception $e) {
    $error_msg = "Main DB Connection Error: " . $e->getMessage();
}

// --- Handle AJAX Requests for Partner Connection ---
if (isset($_POST['action']) && in_array($_POST['action'], ['find_partner', 'send_request'])) {
    header('Content-Type: application/json');
    
    if ($_POST['action'] === 'find_partner') {
        $target_id = strtoupper(trim($_POST['biltax_id']));
        $stmt = $main_pdo->prepare("SELECT id, business_name, owner_name FROM tenants WHERE unique_id = ? AND id != ?");
        $stmt->execute([$target_id, $my_main_id]);
        $partner = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($partner) {
            echo json_encode(['success' => true, 'business' => $partner['business_name'], 'owner' => $partner['owner_name'], 'id' => $partner['id']]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Invalid Biltax ID or you cannot connect to yourself.']);
        }
        exit;
    }

    if ($_POST['action'] === 'send_request') {
        try {
            $receiver_id = $_POST['receiver_id'];
            $stmt = $main_pdo->prepare("INSERT INTO tenant_connections (sender_id, receiver_id) VALUES (?, ?)");
            $stmt->execute([$my_main_id, $receiver_id]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Request already exists or failed.']);
        }
        exit;
    }
}

$message = ''; $error_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        if (isset($_POST['add_supplier']) && !isset($_POST['action'])) {
            if (empty($_POST['name'])) throw new Exception("Name is required.");
            $stmt = $tenant_conn->prepare("INSERT INTO suppliers (name, company, phone, email, address) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['name'], $_POST['company'], $_POST['phone'], $_POST['email'], $_POST['address']]);
            $message = "Supplier added!";
        } elseif (isset($_POST['delete_id'])) {
            $stmt = $tenant_conn->prepare("DELETE FROM suppliers WHERE id = ?");
            $stmt->execute([$_POST['delete_id']]);
            $message = "Supplier deleted!";
        }
    } catch (Exception $e) {
        $error_msg = "Database Error: " . $e->getMessage();
    }
}

$suppliers = $tenant_conn->query("SELECT * FROM suppliers ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Suppliers - Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <div class="max-w-6xl mx-auto">
            <div class="flex justify-between items-start mb-10">
                <div>
                    <h2 class="text-3xl font-black text-slate-900 dark:text-white">Supplier Directory</h2>
                    <p class="text-slate-500">Manage your product sources and vendors.</p>
                </div>
                <div class="flex items-center gap-4">
                    <?php include 'topbar.php'; ?>
                    <?php if (has_module('partner_network')): ?>
                    <button onclick="document.getElementById('connectPartnerModal').classList.remove('hidden'); document.getElementById('connectPartnerModal').classList.add('flex')" class="bg-slate-900 dark:bg-white text-white dark:text-black px-6 py-3 rounded-xl font-bold flex items-center gap-2 shadow-lg transition-all">
                        <i data-lucide="share-2" size="18"></i> Connect Partner
                    </button>
                    <?php endif; ?>
                    <button onclick="document.getElementById('addModal').classList.remove('hidden')" class="bg-orange-600 text-white px-6 py-3 rounded-xl font-bold shadow-lg shadow-orange-600/20">Add Supplier</button>
                </div>
            </div>

            <!-- Global Verification Alert Bar -->
            <?php include 'alert_bar.php'; ?>

            <div class="bg-white dark:bg-neutral-950 rounded-3xl border border-slate-200 dark:border-neutral-800 overflow-hidden">
                <table class="w-full text-left">
                    <thead class="bg-slate-50 dark:bg-neutral-900 text-xs font-bold uppercase text-slate-500">
                        <tr><th class="px-6 py-4">Name / Company</th><th class="px-6 py-4">Contact</th><th class="px-6 py-4">Address</th><th class="px-6 py-4">Actions</th></tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                        <?php foreach($suppliers as $s): ?>
                        <tr class="dark:text-white">
                            <td class="px-6 py-4">
                                <div class="font-bold"><?= htmlspecialchars($s['name']) ?></div>
                                <div class="text-xs text-slate-400"><?= htmlspecialchars($s['company']) ?></div>
                            </td>
                            <td class="px-6 py-4 text-sm">
                                <div><?= htmlspecialchars($s['phone']) ?></div>
                                <div class="text-xs text-slate-400"><?= htmlspecialchars($s['email']) ?></div>
                            </td>
                            <td class="px-6 py-4 text-sm"><?= htmlspecialchars($s['address']) ?></td>
                            <td class="px-6 py-4">
                                <form method="POST" onsubmit="return confirm('Delete this supplier?')">
                                    <input type="hidden" name="delete_id" value="<?= $s['id'] ?>">
                                    <button type="submit" class="text-rose-500"><i data-lucide="trash-2" size="18"></i></button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Add Modal -->
    <div id="addModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center p-4">
        <div class="bg-white dark:bg-neutral-950 w-full max-w-lg p-8 rounded-3xl border border-neutral-800">
            <h3 class="text-xl font-bold mb-6 dark:text-white">New Supplier</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="add_supplier" value="1">
                <input type="text" name="name" placeholder="Contact Name" required class="w-full p-3 rounded-xl bg-slate-50 dark:bg-neutral-900 dark:text-white border border-neutral-800 outline-none">
                <input type="text" name="company" placeholder="Company Name" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-neutral-900 dark:text-white border border-neutral-800 outline-none">
                <div class="grid grid-cols-2 gap-4">
                    <input type="text" name="phone" placeholder="Phone" class="p-3 rounded-xl bg-slate-50 dark:bg-neutral-900 dark:text-white border border-neutral-800">
                    <input type="email" name="email" placeholder="Email" class="p-3 rounded-xl bg-slate-50 dark:bg-neutral-900 dark:text-white border border-neutral-800">
                </div>
                <textarea name="address" placeholder="Business Address" class="w-full p-3 rounded-xl bg-slate-50 dark:bg-neutral-900 dark:text-white border border-neutral-800 h-24"></textarea>
                <div class="flex gap-4 pt-4">
                    <button type="button" onclick="document.getElementById('addModal').classList.add('hidden')" class="flex-1 py-3 text-slate-500">Cancel</button>
                    <button type="submit" class="flex-1 bg-orange-600 text-white py-3 rounded-xl font-bold">Save Supplier</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Connect Partner Modal -->
    <div id="connectPartnerModal" class="hidden fixed inset-0 bg-black/50 backdrop-blur-sm items-center justify-center p-4 z-50">
        <div class="bg-white dark:bg-neutral-900 w-full max-w-lg p-8 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-2xl relative">
            <button onclick="document.getElementById('connectPartnerModal').classList.replace('flex', 'hidden')" class="absolute top-4 right-4 text-slate-400 hover:text-slate-900 dark:hover:text-white"><i data-lucide="x" size="20"></i></button>
            
            <h3 class="text-2xl font-black mb-1 text-slate-900 dark:text-white uppercase tracking-tight">Connect Biltax Partner</h3>
            <p class="text-xs text-slate-500 mb-8 uppercase tracking-widest">Find and link with other businesses</p>
            
            <div class="space-y-6">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Enter Partner Biltax ID</label>
                    <div class="flex gap-2">
                        <input type="text" id="partner_id_input" placeholder="e.g. BTX-XXXXXX" class="flex-1 px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-mono uppercase">
                        <button onclick="findPartnerInSuppliers()" class="px-6 bg-orange-600 text-white font-black rounded-2xl hover:bg-orange-700 transition-all uppercase text-xs tracking-widest">Find</button>
                    </div>
                </div>

                <!-- Result Area -->
                <div id="partner_result" class="hidden animate-in fade-in slide-in-from-top-4 duration-300">
                    <div class="p-6 bg-orange-500/5 border border-orange-500/10 rounded-2xl flex items-center justify-between">
                        <div>
                            <p class="text-[10px] font-black text-orange-500 uppercase">Business Found</p>
                            <h3 id="partner_biz_name" class="text-lg font-black text-slate-900 dark:text-white"></h3>
                            <p id="partner_owner" class="text-xs text-slate-500"></p>
                        </div>
                        <button id="send_request_btn" onclick="sendPartnerRequest()" class="bg-orange-600 text-white px-4 py-2.5 rounded-xl font-bold text-[10px] uppercase tracking-wider shadow-lg shadow-orange-600/20 active:scale-95">Send Request</button>
                    </div>
                </div>

                <!-- Error Area -->
                <div id="partner_error" class="hidden p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-xl text-xs font-bold flex items-center gap-2">
                    <i data-lucide="alert-circle" size="16"></i>
                    <span id="partner_error_msg"></span>
                </div>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();
        let currentTargetId = null;

        async function findPartnerInSuppliers() {
            const idInput = document.getElementById('partner_id_input');
            const resArea = document.getElementById('partner_result');
            const errArea = document.getElementById('partner_error');
            
            resArea.classList.add('hidden');
            errArea.classList.add('hidden');

            const formData = new FormData();
            formData.append('action', 'find_partner');
            formData.append('biltax_id', idInput.value);

            const response = await fetch('suppliers.php', { method: 'POST', body: formData });
            const data = await response.json();

            if (data.success) {
                document.getElementById('partner_biz_name').innerText = data.business;
                document.getElementById('partner_owner').innerText = 'Owner: ' + data.owner;
                currentTargetId = data.id;
                resArea.classList.remove('hidden');
            } else {
                document.getElementById('partner_error_msg').innerText = data.message;
                errArea.classList.remove('hidden');
            }
        }

        async function sendPartnerRequest() {
            const btn = document.getElementById('send_request_btn');
            btn.disabled = true;
            btn.innerText = 'Sending...';

            const formData = new FormData();
            formData.append('action', 'send_request');
            formData.append('receiver_id', currentTargetId);

            const response = await fetch('suppliers.php', { method: 'POST', body: formData });
            const data = await response.json();

            if (data.success) {
                btn.innerText = 'Request Sent!';
                btn.className = "bg-emerald-600 text-white px-4 py-2.5 rounded-xl font-bold text-[10px] uppercase";
                setTimeout(() => location.reload(), 1500);
            } else {
                alert(data.message);
                btn.disabled = false;
                btn.innerText = 'Send Request';
            }
        }
    </script>
</body>
</html>