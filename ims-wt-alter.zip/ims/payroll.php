<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }
if (!has_module('payroll_system')) { header("Location: dashboard.php?error=module_disabled"); exit; }

$currency = $currency_symbol ?? '$';
$current_month = date('F Y');

// Fetch all staff members (users)
try {
    $staff_members = $tenant_conn->query("SELECT u.id, u.name, u.role, pc.base_salary, pc.allowances, pc.deductions, (SELECT COUNT(*) FROM salary_payments WHERE user_id = u.id AND month_year = '$current_month') as paid_this_month FROM users u LEFT JOIN payroll_configs pc ON u.id = pc.user_id ORDER BY u.name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Payroll Error fetching staff members: " . $e->getMessage());
    $staff_members = [];
}

// Fetch salary payment history
try {
    $payment_history = $tenant_conn->query("SELECT sp.*, u.name as staff_name FROM salary_payments sp JOIN users u ON sp.user_id = u.id ORDER BY sp.payment_date DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    error_log("Payroll Error fetching payment history: " . $e->getMessage());
    $payment_history = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Staff Payroll | Biltax Financials</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Staff Payroll</h1>
                <p class="text-xs text-slate-500 uppercase tracking-widest font-bold mt-1">Financials Sub-Module</p>
            </div>
            <div class="flex items-center gap-3">
                <?php if (!empty($staff_members)): ?>
                <button onclick="openPayAllModal()" class="px-6 py-3 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg hover:scale-105 transition-all">
                    <i data-lucide="zap" class="inline mr-2" size="16"></i> Pay All Pending
                </button>
                <?php endif; ?>
                <?php include 'topbar.php'; ?>
            </div>
        </header>

        <!-- Staff List -->
        <div class="bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden mb-8">
            <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                <h2 class="text-sm font-black dark:text-white uppercase tracking-widest">Manage Staff Salaries</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <tr>
                            <th class="px-8 py-4">Staff Name</th>
                            <th class="px-8 py-4">Role</th>
                            <th class="px-8 py-4 text-right">Base Salary</th>
                            <th class="px-8 py-4 text-right">Allowances</th>
                            <th class="px-8 py-4 text-right">Deductions</th>
                            <th class="px-8 py-4 text-right">Net Payable</th>
                            <th class="px-8 py-4 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="staffPayrollBody" class="divide-y divide-slate-100 dark:divide-neutral-800">
                        <?php if (empty($staff_members)): ?>
                            <tr><td colspan="7" class="p-20 text-center text-slate-400 italic font-bold">No staff members found.</td></tr>
                        <?php else: ?>
                            <?php foreach ($staff_members as $staff): 
                                $is_paid = (int)($staff['paid_this_month'] ?? 0) > 0;
                                $net_payable = ($staff['base_salary'] ?? 0) + ($staff['allowances'] ?? 0) - ($staff['deductions'] ?? 0);
                            ?>
                            <tr class="hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                                <td class="px-8 py-5 text-sm font-bold dark:text-white"><?= htmlspecialchars($staff['name']) ?></td>
                                <td class="px-8 py-5 text-xs text-slate-500 uppercase"><?= htmlspecialchars($staff['role']) ?></td>
                                <td class="px-8 py-5 text-right font-mono dark:text-white"><?= $currency . number_format($staff['base_salary'] ?? 0, 2) ?></td>
                                <td class="px-8 py-5 text-right font-mono text-emerald-500"><?= $currency . number_format($staff['allowances'] ?? 0, 2) ?></td>
                                <td class="px-8 py-5 text-right font-mono text-rose-500"><?= $currency . number_format($staff['deductions'] ?? 0, 2) ?></td>
                                <td class="px-8 py-5 text-right font-black text-orange-600"><?= $currency . number_format($net_payable, 2) ?></td>
                                <td class="px-8 py-5 text-right">
                                    <button onclick='openPayrollConfigModal(<?= json_encode($staff) ?>)' class="px-3 py-1 bg-blue-500/10 text-blue-500 rounded-xl text-[10px] font-black uppercase hover:bg-blue-500 hover:text-white transition-all">Configure</button>
                                    <?php if ($is_paid): ?>
                                    <span class="px-3 py-1 bg-emerald-500/10 text-emerald-500 rounded-xl text-[10px] font-black uppercase">Paid</span>
                                    <?php else: ?>
                                    <button onclick='openPaySalaryModal(<?= json_encode($staff) ?>, <?= $net_payable ?>)' class="px-3 py-1 bg-emerald-500/10 text-emerald-500 rounded-xl text-[10px] font-black uppercase hover:bg-emerald-500 hover:text-white transition-all">Pay</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Recent Salary Payments -->
        <div class="bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
            <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                <h2 class="text-sm font-black dark:text-white uppercase tracking-widest">Recent Salary Payments</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <tr>
                            <th class="px-8 py-4">Date</th>
                            <th class="px-8 py-4">Staff</th>
                            <th class="px-8 py-4">Month</th>
                            <th class="px-8 py-4">Method</th>
                            <th class="px-8 py-4 text-right">Amount Paid</th>
                        </tr>
                    </thead>
                    <tbody id="paymentHistoryBody" class="divide-y divide-slate-100 dark:divide-neutral-800">
                        <?php if (empty($payment_history)): ?>
                            <tr><td colspan="5" class="p-20 text-center text-slate-400 italic font-bold">No payments recorded yet.</td></tr>
                        <?php else: ?>
                            <?php foreach ($payment_history as $payment): ?>
                            <tr class="hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                                <td class="px-8 py-5 text-xs text-slate-500 font-bold uppercase"><?= htmlspecialchars($payment['payment_date']) ?></td>
                                <td class="px-8 py-5 text-sm font-bold dark:text-white"><?= htmlspecialchars($payment['staff_name']) ?></td>
                                <td class="px-8 py-5 text-sm dark:text-white"><?= htmlspecialchars($payment['month_year']) ?></td>
                                <td class="px-8 py-5 text-xs text-slate-500 uppercase"><?= htmlspecialchars($payment['payment_method']) ?></td>
                                <td class="px-8 py-5 text-right text-lg font-black text-emerald-500"><?= $currency . number_format($payment['amount_paid'], 2) ?></td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Payroll Config Modal -->
    <div id="payrollConfigModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('payrollConfigModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-6 tracking-tight">Configure Payroll</h2>
            
            <form id="payrollConfigForm" class="space-y-4">
                <input type="hidden" id="config_user_id">
                <p class="text-sm font-bold dark:text-white mb-4" id="config_staff_name"></p>

                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Base Salary (<?= $currency ?>)</label>
                    <input type="number" id="base_salary" step="0.01" value="0" class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-black text-xl">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Allowances (<?= $currency ?>)</label>
                    <input type="number" id="allowances" step="0.01" value="0" class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-black text-xl">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Deductions (<?= $currency ?>)</label>
                    <input type="number" id="deductions" step="0.01" value="0" class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-black text-xl">
                </div>
                <button type="submit" class="w-full py-5 bg-blue-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-blue-600/20 hover:bg-blue-700 transition-all mt-4">Save Configuration</button>
            </form>
        </div>
    </div>

    <!-- Pay Salary Modal -->
    <div id="paySalaryModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('paySalaryModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-6 tracking-tight">Pay Salary</h2>
            
            <form id="paySalaryForm" class="space-y-4">
                <input type="hidden" id="pay_user_id">
                <p class="text-sm font-bold dark:text-white mb-4" id="pay_staff_name"></p>

                <div class="bg-slate-50 dark:bg-neutral-950/50 p-6 rounded-3xl border border-slate-100 dark:border-neutral-800 text-center">
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">Net Payable Amount</label>
                    <p id="pay_amount_display" class="text-4xl font-black text-slate-900 dark:text-white tracking-tighter"><?= $currency ?>0.00</p>
                    <input type="hidden" id="pay_amount">
                </div>

                <div class="grid grid-cols-2 gap-3">
                    <button type="button" onclick="shareSalarySlip('whatsapp')" class="flex items-center justify-center gap-2 py-4 bg-emerald-600/10 text-emerald-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-emerald-600 hover:text-white transition-all">
                        <i data-lucide="message-circle" size="14"></i> WhatsApp Slip
                    </button>
                    <button type="button" onclick="shareSalarySlip('email')" class="flex items-center justify-center gap-2 py-4 bg-blue-600/10 text-blue-600 rounded-2xl font-black text-[10px] uppercase tracking-widest hover:bg-blue-600 hover:text-white transition-all">
                        <i data-lucide="mail" size="14"></i> Email Slip
                    </button>
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">For Month/Year</label>
                    <input type="text" id="pay_month_year" value="<?= date('F Y') ?>" class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-black text-xl">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Payment Method</label>
                    <select id="pay_method" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                        <option value="Cash">Cash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                </div>
                <button type="submit" class="w-full py-5 bg-emerald-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all mt-4">Record Payment</button>
            </form>
        </div>
    </div>

    <!-- Pay All Pending Modal -->
    <div id="payAllModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-xl shadow-2xl relative">
            <button onclick="document.getElementById('payAllModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-2 tracking-tight">Bulk Payroll</h2>
            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mb-6">Processing for <?= $current_month ?></p>
            
            <div id="payAllInitial">
                <div class="bg-slate-50 dark:bg-neutral-950/50 p-6 rounded-3xl mb-6 text-center border border-slate-100 dark:border-neutral-800">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-1">Total Employees to Pay</p>
                    <p id="bulkStaffCount" class="text-3xl font-black dark:text-white">0</p>
                    <p class="text-[10px] font-black uppercase text-slate-400 mt-4 mb-1">Total Payout Amount</p>
                    <p id="bulkTotalAmount" class="text-4xl font-black text-orange-600"><?= $currency ?>0.00</p>
                </div>

                <div class="mb-6">
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Payment Method</label>
                    <select id="bulk_pay_method" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                        <option value="Cash">Cash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                    </select>
                </div>

                <button onclick="processBulkPayment()" id="bulkPayBtn" class="w-full py-5 bg-orange-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:bg-orange-700 transition-all">Process All Payments</button>
            </div>

            <div id="payAllSuccess" class="hidden space-y-4">
                <div class="p-4 bg-emerald-500/10 text-emerald-500 rounded-2xl text-center font-bold text-sm mb-4">
                    <i data-lucide="check-circle" class="inline mr-2"></i> All payments recorded successfully!
                </div>
                <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-2">Share Slips Individually:</p>
                <div id="bulkShareList" class="space-y-2 max-h-60 overflow-y-auto pr-2 custom-scrollbar"></div>
                <button onclick="location.reload()" class="w-full py-4 bg-slate-100 dark:bg-neutral-800 dark:text-white rounded-2xl font-black uppercase text-xs mt-4">Done</button>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();
        const currency = '<?= $currency ?>';
        let currentStaffForSharing = null;
        const staffData = <?= json_encode($staff_members) ?>;
        const currentMonthYear = '<?= $current_month ?>';

        function openPayrollConfigModal(staff) {
            document.getElementById('config_user_id').value = staff.id;
            document.getElementById('config_staff_name').innerText = staff.name;
            document.getElementById('base_salary').value = staff.base_salary || 0;
            document.getElementById('allowances').value = staff.allowances || 0;
            document.getElementById('deductions').value = staff.deductions || 0;
            document.getElementById('payrollConfigModal').classList.replace('hidden', 'flex');
        }

        document.getElementById('payrollConfigForm').onsubmit = async (e) => {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.disabled = true;
            btn.disabled = true; btn.innerText = "Saving...";

            const data = {
                user_id: document.getElementById('config_user_id').value,
                base_salary: document.getElementById('base_salary').value,
                allowances: document.getElementById('allowances').value,
                deductions: document.getElementById('deductions').value
            };

            try {
                const res = await fetch('api.php?route=finance/payroll/configs/save', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
                const result = await res.json();
                if (result.success) location.reload();
                else alert("Error: " + result.message);
            } catch (err) { alert("System Error."); }
            btn.disabled = false; btn.innerText = "Save Configuration";
        };

        function openPaySalaryModal(staff, netPayable) {
            currentStaffForSharing = staff;
            document.getElementById('pay_user_id').value = staff.id;
            document.getElementById('pay_staff_name').innerText = staff.name;
            document.getElementById('pay_amount').value = netPayable.toFixed(2);
            document.getElementById('pay_amount_display').innerText = currency + netPayable.toFixed(2);
            document.getElementById('paySalaryModal').classList.replace('hidden', 'flex');
        }

        function shareSalarySlip(method) {
            const staff = currentStaffForSharing;
            if (!staff) return;
            const month = document.getElementById('pay_month_year')?.value || currentMonthYear;
            const amount = document.getElementById('pay_amount')?.value || (parseFloat(staff.base_salary||0) + parseFloat(staff.allowances||0) - parseFloat(staff.deductions||0));
            const payMethod = document.getElementById('pay_method')?.value || 'System';
            const businessName = '<?= $_SESSION['business_name'] ?? "Biltax Financials" ?>';
            
            const message = `*SALARY PAYMENT ADVICE*\n--------------------------\n*Business:* ${businessName}\n*Staff:* ${currentStaffForSharing.name}\n*Period:* ${month}\n*Amount Paid:* ${currency}${amount}\n*Method:* ${payMethod}\n*Status:* Paid\n--------------------------\nThank you for your service!`;

            if (method === 'whatsapp') {
                window.open(`https://api.whatsapp.com/send?text=${encodeURIComponent(message)}`, '_blank');
            } else {
                const subject = encodeURIComponent(`Salary Slip - ${month}`);
                window.open(`mailto:?subject=${subject}&body=${encodeURIComponent(message)}`, '_self');
            }
        }

        function openPayAllModal() {
            const pending = staffData.filter(s => parseInt(s.paid_this_month) === 0);
            if (pending.length === 0) return alert("All staff members have already been paid for this month!");

            let total = 0;
            pending.forEach(s => {
                total += (parseFloat(s.base_salary||0) + parseFloat(s.allowances||0) - parseFloat(s.deductions||0));
            });

            document.getElementById('bulkStaffCount').innerText = pending.length;
            document.getElementById('bulkTotalAmount').innerText = currency + total.toFixed(2);
            document.getElementById('payAllInitial').classList.remove('hidden');
            document.getElementById('payAllSuccess').classList.add('hidden');
            document.getElementById('payAllModal').classList.replace('hidden', 'flex');
        }

        async function processBulkPayment() {
            const pending = staffData.filter(s => parseInt(s.paid_this_month) === 0);
            const method = document.getElementById('bulk_pay_method').value;
            const btn = document.getElementById('bulkPayBtn');
            
            btn.disabled = true;
            btn.innerText = "Processing Payments...";

            const results = [];
            for (const staff of pending) {
                const net = (parseFloat(staff.base_salary||0) + parseFloat(staff.allowances||0) - parseFloat(staff.deductions||0));
                try {
                    const res = await fetch('api.php?route=finance/payroll/pay', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ user_id: staff.id, amount: net, month_year: currentMonthYear, payment_method: method })
                    });
                    const data = await res.json();
                    if (data.success) results.push(staff);
                } catch (e) { console.error("Failed to pay " + staff.name); }
            }

            // Show success and share list
            document.getElementById('payAllInitial').classList.add('hidden');
            const shareList = document.getElementById('bulkShareList');
            shareList.innerHTML = results.map(s => `
                <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-800 rounded-2xl border border-slate-100 dark:border-neutral-700">
                    <span class="text-xs font-bold dark:text-white">${s.name}</span>
                    <div class="flex gap-2">
                        <button onclick="triggerIndividualShare(${s.id}, 'whatsapp')" class="p-2 bg-emerald-500/10 text-emerald-500 rounded-lg hover:bg-emerald-500 hover:text-white transition-all"><i data-lucide="message-circle" size="14"></i></button>
                        <button onclick="triggerIndividualShare(${s.id}, 'email')" class="p-2 bg-blue-500/10 text-blue-500 rounded-lg hover:bg-blue-50 hover:text-white transition-all"><i data-lucide="mail" size="14"></i></button>
                    </div>
                </div>
            `).join('');
            
            document.getElementById('payAllSuccess').classList.remove('hidden');
            lucide.createIcons();
        }

        function triggerIndividualShare(userId, method) {
            const staff = staffData.find(s => s.id == userId);
            if (!staff) return;
            currentStaffForSharing = staff;
            shareSalarySlip(method);
        }

        document.getElementById('paySalaryForm').onsubmit = async (e) => {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.disabled = true;
            btn.innerText = "Recording...";

            const data = {
                user_id: document.getElementById('pay_user_id').value,
                amount: document.getElementById('pay_amount').value,
                month_year: document.getElementById('pay_month_year').value,
                payment_method: document.getElementById('pay_method').value
            };

            try {
                const res = await fetch('api.php?route=finance/payroll/pay', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await res.json();
                if (result.success) {
                    location.reload();
                } else {
                    alert("Error: " + result.message);
                }
            } catch (err) { alert("System Error."); }
            btn.disabled = false; btn.innerText = "Record Payment";
        };
    </script>
</body>
</html>