<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) { header("Location: login.php"); exit; }

try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Self-healing: Ensure Shop tables exist in main DB
    // Fixed: Changed image_url to TEXT to support multiple long URLs
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS shop_products (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(15,2) NOT NULL,
        image_url TEXT,
        stock INT DEFAULT 0,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $main_pdo->exec("CREATE TABLE IF NOT EXISTS shop_orders (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        total_amount DECIMAL(15,2) NOT NULL,
        status ENUM('pending', 'processing', 'fulfilled', 'cancelled') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    // Self-healing: Add custom_image_url column
    $main_pdo->exec("ALTER TABLE shop_orders ADD COLUMN IF NOT EXISTS custom_image_url TEXT AFTER total_amount");

    $main_pdo->exec("CREATE TABLE IF NOT EXISTS shop_order_items (
        id INT PRIMARY KEY AUTO_INCREMENT,
        order_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        price DECIMAL(15,2) NOT NULL
    )");

        // Fetch Current Tenant's Currency Symbol
        $stmt_curr = $main_pdo->prepare("SELECT currency_symbol FROM tenants WHERE id = ?");
        $stmt_curr->execute([$_SESSION['tenant_id']]);
        $currency_symbol = $stmt_curr->fetchColumn() ?: '$';

} catch (Exception $e) { die("Database Error: " . $e->getMessage()); }

// Handle Order Placement
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['buy_id'])) {
    require_once 'config/CloudinaryStorage.php';
    
    $product_id = $_POST['buy_id'];
    $tenant_id = $_SESSION['tenant_id'];
    $custom_url = null;

    $p_stmt = $main_pdo->prepare("SELECT * FROM shop_products WHERE id = ?");
    $p_stmt->execute([$product_id]);
    $product = $p_stmt->fetch(PDO::FETCH_ASSOC);

    if ($product && $product['stock'] > 0) {
        // Handle Custom Image Upload
        if ($product['requires_custom_image'] == 1 && isset($_FILES['custom_image']) && $_FILES['custom_image']['error'] === 0) {
            $folder = "biltax_shop_custom/$tenant_id";
            $public_id = "custom_order_" . time();
            $custom_url = uploadToCloud($_FILES['custom_image']['tmp_name'], $folder, $public_id);
            
            // Trigger storage update after upload
            require_once 'config/storage_manager.php';
            calculateTenantStorage($tenant_id);
        }

        $main_pdo->beginTransaction();
        $stmt = $main_pdo->prepare("INSERT INTO shop_orders (tenant_id, total_amount, custom_image_url) VALUES (?, ?, ?)");
        $stmt->execute([$tenant_id, $product['price'], $custom_url]);
        $order_id = $main_pdo->lastInsertId();

        $item_stmt = $main_pdo->prepare("INSERT INTO shop_order_items (order_id, product_id, quantity, price) VALUES (?, ?, 1, ?)");
        $item_stmt->execute([$order_id, $product_id, $product['price']]);

        $main_pdo->prepare("UPDATE shop_products SET stock = stock - 1 WHERE id = ?")->execute([$product_id]);
        $main_pdo->commit();
        $msg = "Order placed successfully! Super Admin will fulfill it soon.";
    }
}

$products = $main_pdo->query("SELECT * FROM shop_products WHERE status = 'active' ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Biltax Shop</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Biltax Official Shop</h1>
                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Premium supplies and services by Biltax</p>
            </div>
            <div class="flex items-center gap-3 shrink-0">
                <a href="biltax_shop_orders.php" class="bg-orange-600 text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-orange-700 transition-all flex items-center gap-2 shadow-lg shadow-orange-600/20">
                    <i data-lucide="shopping-bag" size="16"></i> My Orders
                </a>
                <?php include 'topbar.php'; ?>
            </div>
        </header>

        <!-- Global Verification Alert Bar -->
        <?php include 'alert_bar.php'; ?>

        <?php if(isset($msg)): ?>
            <div class="mb-8 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl text-sm font-bold flex items-center gap-2">
                <i data-lucide="check-circle" size="18"></i> <?= $msg ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <?php foreach($products as $p): ?>
            <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[32px] overflow-hidden group hover:shadow-2xl transition-all">
                <div class="aspect-square bg-slate-100 dark:bg-neutral-800 flex items-center justify-center border-b border-slate-100 dark:border-neutral-800 overflow-hidden">
                    <?php 
                    $images = explode("\n", $p['image_url']);
                    if(!empty(trim($images[0]))): ?>
                        <img src="<?= htmlspecialchars(trim($images[0])) ?>" class="w-full h-full object-cover group-hover:scale-110 transition-transform">
                    <?php else: ?>
                        <i data-lucide="shopping-bag" size="48" class="text-slate-300 group-hover:scale-110 transition-transform"></i>
                    <?php endif; ?>
                </div>
                <div class="p-6">
                    <h3 class="text-base font-black dark:text-white uppercase mb-1"><?= htmlspecialchars($p['name']) ?></h3>
                    <p class="text-xs text-slate-500 dark:text-neutral-500 mb-6 h-8 line-clamp-2"><?= htmlspecialchars($p['description']) ?></p>
                    
                    <form method="POST" enctype="multipart/form-data">
                        <input type="hidden" name="buy_id" value="<?= $p['id'] ?>">
                        <?php if (isset($p['requires_custom_image']) && $p['requires_custom_image'] == 1): ?>
                            <div class="mb-4">
                                <label class="block text-[9px] font-black uppercase text-orange-500 mb-1">Upload Your Design</label>
                                <input type="file" name="custom_image" required class="w-full text-[10px] text-slate-500 file:mr-2 file:py-1 file:px-3 file:rounded-full file:border-0 file:text-[10px] file:font-black file:bg-orange-100 file:text-orange-600 hover:file:bg-orange-200 cursor-pointer">
                            </div>
                        <?php endif; ?>

                        <div class="flex items-center justify-between gap-4">
                            <span class="text-xl font-black text-orange-600"><?= $currency_symbol ?><?= number_format($p['price'], 2) ?></span>
                            <?php if ($p['stock'] > 0): ?>
                                <button type="submit" class="bg-slate-900 dark:bg-white text-white dark:text-black px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-orange-600 hover:text-white transition-all">Order Now</button>
                            <?php else: ?>
                                <button disabled class="bg-slate-100 dark:bg-neutral-800 text-slate-400 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest cursor-not-allowed">Out of Stock</button>
                            <?php endif; ?>
                        </div>
                    </form>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>