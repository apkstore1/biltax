<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }
if (!has_module('finance_reports')) { header("Location: dashboard.php?error=module_disabled"); exit; }

$start = $_GET['start'] ?? date('Y-m-01');
$end = $_GET['end'] ?? date('Y-m-t');

// 1. Calculate P&L
$revenue = $tenant_conn->prepare("SELECT SUM(total_amount) FROM sales WHERE DATE(created_at) BETWEEN ? AND ?");
$revenue->execute([$start, $end]);
$total_rev = $revenue->fetchColumn() ?: 0;

$expenses = $tenant_conn->prepare("SELECT SUM(amount) FROM expenses WHERE expense_date BETWEEN ? AND ?");
$expenses->execute([$start, $end]);
$total_exp = $expenses->fetchColumn() ?: 0;

// 2. Cash Position Logic (From Ledgers)
$cash_hand = $tenant_conn->query("SELECT SUM(credit - debit) FROM ledgers WHERE party_name IN (SELECT payment_method FROM sales WHERE payment_method = 'Cash') OR party_name = 'Walk-in' OR description LIKE '%Cash%'")->fetchColumn() ?: 0;
$cash_bank = $tenant_conn->query("SELECT SUM(credit - debit) FROM ledgers WHERE description LIKE '%Bank%' OR description LIKE '%Transfer%' OR description LIKE '%Card%'")->fetchColumn() ?: 0;

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Financial Reports | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tighter">Financial Insights</h1>
                <p class="text-[10px] text-orange-500 font-bold uppercase tracking-widest">Profit & Loss and Cash Liquidity</p>
            </div>
            <form class="flex gap-2">
                <input type="date" name="start" value="<?= $start ?>" class="px-4 py-2 bg-white dark:bg-neutral-900 border rounded-xl text-xs font-bold">
                <input type="date" name="end" value="<?= $end ?>" class="px-4 py-2 bg-white dark:bg-neutral-900 border rounded-xl text-xs font-bold">
                <button type="submit" class="bg-orange-600 text-white px-4 py-2 rounded-xl text-[10px] font-black uppercase">Filter</button>
            </form>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <!-- P&L Statement -->
            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                <h2 class="text-xl font-black dark:text-white uppercase mb-8 border-b pb-4">Profit & Loss</h2>
                <div class="space-y-6">
                    <div class="flex justify-between items-center">
                        <span class="text-sm font-bold text-slate-500 uppercase">Total Revenue (Sales)</span>
                        <span class="text-lg font-black text-emerald-500">+ <?= $currency_symbol . number_format($total_rev, 2) ?></span>
                    </div>
                    <div class="flex justify-between items-center">
                        <span class="text-sm font-bold text-slate-500 uppercase">Operating Expenses</span>
                        <span class="text-lg font-black text-rose-500">- <?= $currency_symbol . number_format($total_exp, 2) ?></span>
                    </div>
                    <div class="pt-6 border-t flex justify-between items-center">
                        <span class="text-lg font-black dark:text-white uppercase">Net Profit</span>
                        <span class="text-3xl font-black <?= ($total_rev - $total_exp >= 0) ? 'text-emerald-500' : 'text-rose-500' ?>">
                            <?= $currency_symbol . number_format($total_rev - $total_exp, 2) ?>
                        </span>
                    </div>
                </div>
            </div>

            <!-- Cash Position -->
            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                <h2 class="text-xl font-black dark:text-white uppercase mb-8 border-b pb-4">Liquidity Summary</h2>
                <div class="grid grid-cols-1 gap-4">
                    <div class="p-6 bg-slate-50 dark:bg-neutral-950 rounded-3xl border border-slate-100 dark:border-neutral-800">
                        <div class="flex items-center gap-4">
                            <div class="w-12 h-12 bg-orange-500/10 text-orange-600 rounded-2xl flex items-center justify-center"><i data-lucide="wallet"></i></div>
                            <div>
                                <p class="text-[10px] font-black text-slate-400 uppercase">Total Cash in Hand</p>
                                <h4 class="text-2xl font-black dark:text-white"><?= $currency_symbol . number_format($cash_hand, 2) ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="p-6 bg-slate-50 dark:bg-neutral-950 rounded-3xl border border-slate-100 dark:border-neutral-800">
                        <div class="flex items-center gap-4">
                            <div class="w-12 h-12 bg-blue-500/10 text-blue-500 rounded-2xl flex items-center justify-center"><i data-lucide="landmark"></i></div>
                            <div>
                                <p class="text-[10px] font-black text-slate-400 uppercase">Total Bank Balance</p>
                                <h4 class="text-2xl font-black dark:text-white"><?= $currency_symbol . number_format($cash_bank, 2) ?></h4>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>