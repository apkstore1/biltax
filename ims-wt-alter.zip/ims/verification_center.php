<?php
require_once 'config/db_switch.php';
require_once 'config/CloudinaryStorage.php';

if (!$tenant_conn) { header("Location: login.php"); exit; }

// 1. Get Tenant ID from Main DB
$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
$stmt_tid = $main_pdo->prepare("SELECT id, business_name FROM tenants WHERE db_name = ?");
$stmt_tid->execute([$_SESSION['db_name']]);
$tenant_info = $stmt_tid->fetch(PDO::FETCH_ASSOC);
$tenant_id = $tenant_info['id'];

// Self-healing: Add submitted_docs column if not exists to store response
try { $main_pdo->exec("ALTER TABLE verification_tasks ADD COLUMN IF NOT EXISTS submitted_docs TEXT AFTER required_docs"); } catch(Exception $e) {}

// 2. Handle Task Submission
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_task') {
    $task_id = $_POST['task_id'];
    $submitted_files = [];
    $safe_biz_name = preg_replace('/[^a-z0-9_]/', '', str_replace(' ', '_', strtolower($tenant_info['business_name'])));

    if (isset($_FILES['docs']) && is_array($_FILES['docs']['name'])) {
        foreach ($_FILES['docs']['tmp_name'] as $key => $tmp_name) {
            if ($_FILES['docs']['error'][$key] === 0) {
                $doc_name = $_POST['doc_names'][$key];
                // Random suffix to prevent cache issues
                $public_id = $safe_biz_name . "_v" . $task_id . "_" . $key . "_" . time();
                $url = uploadToCloud($tmp_name, "biltax_verifications/$tenant_id", $public_id);
                if ($url) {
                    $submitted_files[] = ['name' => $doc_name, 'url' => $url];
                }
            }
        }
    }

    if (!empty($submitted_files)) {
        $stmt = $main_pdo->prepare("UPDATE verification_tasks SET submitted_docs = ?, status = 'pending_review' WHERE id = ? AND tenant_id = ?");
        $stmt->execute([json_encode($submitted_files), $task_id, $tenant_id]);
        header("Location: verification_center.php?msg=submitted");
    } else {
        header("Location: verification_center.php?msg=error");
    }
    exit;
}

// 3. Fetch Tasks
$stmt = $main_pdo->prepare("SELECT * FROM verification_tasks WHERE tenant_id = ? ORDER BY FIELD(priority, 'high', 'medium', 'low'), created_at DESC");
$stmt->execute([$tenant_id]);
$tasks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verification Center | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-900 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Verification Center</h1>
                <p class="text-xs text-orange-500 font-bold uppercase tracking-widest">Required Actions & Compliance</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <?php if (isset($_GET['msg'])): ?>
            <div class="mb-6 p-4 <?= $_GET['msg'] === 'submitted' ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-600' : 'bg-rose-500/10 border-rose-500/20 text-rose-600' ?> border rounded-2xl text-sm font-bold">
                <?= $_GET['msg'] === 'submitted' ? 'Task submitted for review successfully!' : 'Error: No documents were uploaded or submission failed.' ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php if (empty($tasks)): ?>
                <div class="col-span-full py-20 text-center text-slate-400">
                    <i data-lucide="check-circle-2" size="48" class="mx-auto mb-4 opacity-20"></i>
                    <p class="font-bold uppercase tracking-widest text-xs">All caught up! No pending verification tasks.</p>
                </div>
            <?php endif; ?>

            <?php foreach($tasks as $t): 
                $priorityClass = match($t['priority']) {
                    'high' => 'bg-rose-500/10 text-rose-500 border-rose-500/20',
                    'medium' => 'bg-amber-500/10 text-amber-500 border-amber-500/20',
                    default => 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20'
                };
                $statusClass = match($t['status']) {
                    'pending_review' => 'bg-blue-500/10 text-blue-500',
                    'approved' => 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/20',
                    'rejected' => 'bg-rose-600 text-white',
                    default => 'bg-slate-100 dark:bg-neutral-800 text-slate-500'
                };
            ?>
            <div class="bg-white dark:bg-neutral-950 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-xl flex flex-col transition-all hover:scale-[1.01]">
                <div class="flex justify-between items-start mb-4">
                    <span class="px-2 py-0.5 rounded-md text-[8px] font-black uppercase border <?= $priorityClass ?>">
                        <?= $t['priority'] ?> Priority
                    </span>
                    <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase <?= $statusClass ?>">
                        <?= str_replace('_', ' ', $t['status']) ?>
                    </span>
                </div>

                <h3 class="text-lg font-black dark:text-white mb-2"><?= htmlspecialchars($t['task_title']) ?></h3>
                <p class="text-xs text-slate-500 dark:text-neutral-400 line-clamp-3 mb-4"><?= htmlspecialchars($t['task_description']) ?></p>

                <?php if ($t['status'] === 'rejected' && !empty($t['admin_reason'])): ?>
                    <div class="p-3 bg-rose-500/10 border border-rose-500/20 rounded-xl mb-4">
                        <p class="text-[9px] font-black text-rose-500 uppercase mb-1">Admin Feedback:</p>
                        <p class="text-[11px] text-rose-600 dark:text-rose-400 font-bold italic">"<?= htmlspecialchars($t['admin_reason']) ?>"</p>
                    </div>
                <?php endif; ?>

                <div class="mt-auto pt-4 border-t border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                    <span class="text-[9px] text-slate-400 font-mono"><?= date('M d, Y', strtotime($t['created_at'])) ?></span>
                    <?php if ($t['status'] === 'not_started' || $t['status'] === 'rejected'): ?>
                        <button onclick='openTaskModal(<?= htmlspecialchars(json_encode($t), ENT_QUOTES, "UTF-8") ?>)' class="px-4 py-2 bg-orange-600 hover:bg-orange-700 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all">Submit Documents</button>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <!-- Submission Modal -->
    <div id="taskModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="closeModal()" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            
            <div class="mb-6">
                <h2 id="modalTitle" class="text-2xl font-black dark:text-white uppercase mb-1">Complete Task</h2>
                <p id="modalDesc" class="text-xs text-slate-500 font-medium"></p>
            </div>

            <form method="POST" enctype="multipart/form-data" class="space-y-6" id="submissionForm" onsubmit="handleSubmit(this)">
                <input type="hidden" name="action" value="submit_task">
                <input type="hidden" name="task_id" id="modalTaskId">
                
                <div id="docsContainer" class="space-y-4">
                    <!-- Dynamic document fields will be injected here -->
                </div>

                <button type="submit" id="submitBtn" class="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase tracking-widest text-xs shadow-xl active:scale-95 transition-all">Submit for Review</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();

        function openTaskModal(task) {
            document.getElementById('modalTaskId').value = task.id;
            document.getElementById('modalTitle').innerText = task.task_title;
            document.getElementById('modalDesc').innerText = task.task_description;

            const container = document.getElementById('docsContainer');
            container.innerHTML = '';

            // Create fields based on required_docs (comma separated)
            const docs = task.required_docs.split(',').map(d => d.trim());
            docs.forEach((doc, index) => {
                if (!doc) return;
                const div = document.createElement('div');
                div.className = "p-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl";
                div.innerHTML = `
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">${doc}</label>
                    <input type="hidden" name="doc_names[]" value="${doc}">
                    <input type="file" name="docs[]" required class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-[10px] file:font-black file:bg-orange-600 file:text-white hover:file:bg-orange-700 cursor-pointer">
                `;
                container.appendChild(div);
            });

            document.getElementById('taskModal').classList.replace('hidden', 'flex');
        }

        function closeModal() {
            document.getElementById('taskModal').classList.replace('flex', 'hidden');
        }

        function handleSubmit(form) {
            const btn = document.getElementById('submitBtn');
            btn.disabled = true;
            btn.innerHTML = '<span class="flex items-center justify-center gap-2"><div class="animate-spin h-4 w-4 border-2 border-current border-t-transparent rounded-full"></div> Uploading...</span>';
        }
    </script>
</body>
</html>