<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

// Page Restriction Logic
if (!has_module('purchases')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
$my_id = $_SESSION['tenant_id'];

$filter = $_GET['filter'] ?? 'all';
$search = $_GET['search'] ?? '';
$type = $_GET['type'] ?? 'all';

$active_branch = $_SESSION['active_branch_id'] ?? null;
$is_all = ($active_branch === 'all');
$stock_branch = $is_all ? null : get_active_stock_branch_id($active_branch);

// Get Main Branch ID for legacy data support
$stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
$main_id = $stmt_main->fetchColumn();
if (!$main_id) $main_id = 0;

// 1. Fetch B2B Orders (Outgoing) from Main DB
$b2b_orders = [];
if ($type === 'all' || $type === 'partner') {
    $b2b_sql = "SELECT o.id, o.total_amount, o.created_at, o.status, o.payment_status, t.business_name as supplier_name, 'Partner' as type 
                FROM b2b_orders o 
                JOIN tenants t ON o.receiver_tenant_id = t.id 
                WHERE o.sender_tenant_id = ?";

    $b2b_params = [$my_id];
    if (!$is_all) {
        if ($active_branch == $main_id) {
            $b2b_sql .= " AND (o.sender_branch_id = ? OR o.sender_branch_id IS NULL)";
        } else {
            $b2b_sql .= " AND o.sender_branch_id = ?";
        }
        $b2b_params[] = $active_branch;
    }

    if ($filter === 'pending') $b2b_sql .= " AND o.status IN ('pending', 'shipped')";
    elseif ($filter === 'completed') $b2b_sql .= " AND o.status IN ('received', 'finalized')";
    elseif ($filter === 'disputed') $b2b_sql .= " AND o.status = 'disputed'";

    if ($search) {
        $b2b_sql .= " AND (t.business_name LIKE ? OR o.id LIKE ?)";
        $b2b_params[] = "%$search%";
        $b2b_params[] = "%$search%";
    }

    $stmt = $main_pdo->prepare($b2b_sql);
    $stmt->execute($b2b_params);
    $b2b_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// 2. Fetch Manual Purchases from Tenant DB
$manual_orders = [];
if ($type === 'all' || $type === 'manual') {
    try {
        $man_sql = "SELECT p.id, p.total_amount, p.created_at, p.status, p.payment_status, s.name as supplier_name, 'Manual' as type
                    FROM purchases p 
                    LEFT JOIN suppliers s ON p.supplier_id = s.id";
        $man_params = [];
        $where_clauses = [];

        if (!$is_all) {
            if ($stock_branch == $main_id) {
                $where_clauses[] = "(p.branch_id = ? OR p.branch_id IS NULL)";
            } else {
                $where_clauses[] = "p.branch_id = ?";
            }
            $man_params[] = $stock_branch;
        }

        if ($filter === 'pending') {
            $where_clauses[] = "p.status = 'pending'";
        } elseif ($filter === 'completed') {
            $where_clauses[] = "p.status = 'finalized'";
        } elseif ($filter === 'disputed') {
            // Manual purchases don't have a 'disputed' status by default.
            // If 'disputed' is added to the ENUM for manual purchases, this can be uncommented.
            // $where_clauses[] = "p.status = 'disputed'";
        }

        if ($search) {
            $where_clauses[] = "(s.name LIKE ? OR p.id LIKE ?)";
            $man_params[] = "%$search%";
            $man_params[] = "%$search%";
        }

        if (!empty($where_clauses)) {
            $man_sql .= " WHERE " . implode(" AND ", $where_clauses);
        }

        $man_sql .= " ORDER BY p.created_at DESC";
        $stmt = $tenant_conn->prepare($man_sql);
        $stmt->execute($man_params);
        $manual_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (Exception $e) { /* Table might not exist yet */ }
}

// 3. Combine both lists and sort by newest first
$orders = array_merge($b2b_orders, $manual_orders);
usort($orders, function($a, $b) {
    return strtotime($b['created_at']) - strtotime($a['created_at']);
});
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Purchase Management | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 min-h-screen transition-colors duration-300">
    <div class="flex">
        <?php include 'sidebar.php'; ?>
        
        <main class="flex-1 p-8">
            <header class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Purchase Management</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Track manual and partner supply chains</p>
                </div>
                <div class="flex items-center gap-4">
                    <?php include 'topbar.php'; ?>
                    <a href="create_purchase.php" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-sm uppercase flex items-center gap-2 hover:bg-orange-700 transition-all">
                        <i data-lucide="plus" size="18"></i> New Purchase
                    </a>
                </div>
            </header>

            <!-- Global Verification Alert Bar -->
            <?php include 'alert_bar.php'; ?>

            <!-- Filter & Search Section -->
            <form method="GET" class="flex flex-col lg:flex-row items-start lg:items-center gap-4 mb-8">
                <input type="hidden" name="filter" value="<?= htmlspecialchars($filter) ?>">
                <div class="flex gap-2 bg-white dark:bg-neutral-900 p-1.5 rounded-2xl border border-slate-200 dark:border-neutral-800 w-fit">
                    <?php 
                    $tabs = ['all' => 'All Orders', 'pending' => 'Outgoing (Pending)', 'completed' => 'Completed', 'disputed' => 'Disputed'];
                    foreach($tabs as $key => $label): 
                        $active = ($filter === $key) ? 'bg-orange-600 text-white shadow-lg shadow-orange-600/20' : 'text-slate-500 hover:text-orange-600';
                    ?>
                        <a href="?filter=<?= $key ?>&search=<?= urlencode($search) ?>&type=<?= urlencode($type) ?>" class="px-5 py-2.5 rounded-xl text-xs font-black uppercase tracking-tight transition-all <?= $active ?>"><?= $label ?></a>
                    <?php endforeach; ?>
                </div>
                
                <div class="flex flex-1 w-full gap-2 items-center">
                    <select name="type" onchange="this.form.submit()" class="px-4 py-3 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl text-sm focus:border-orange-500 outline-none transition-colors dark:text-white font-bold">
                        <option value="all" <?= $type === 'all' ? 'selected' : '' ?>>All Types</option>
                        <option value="partner" <?= $type === 'partner' ? 'selected' : '' ?>>Partner (B2B)</option>
                        <option value="manual" <?= $type === 'manual' ? 'selected' : '' ?>>Manual Purchases</option>
                    </select>
                    <div class="relative flex-1">
                        <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                        <input type="text" name="search" value="<?= htmlspecialchars($search) ?>" placeholder="Search Supplier or Order ID..." class="w-full pl-12 pr-4 py-3 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl text-sm focus:border-orange-500 outline-none transition-colors dark:text-white">
                    </div>
                </div>
            </form>

            <!-- Orders Table -->
            <div class="bg-white dark:bg-neutral-900 rounded-[32px] shadow-2xl border border-slate-200 dark:border-neutral-800 overflow-hidden">
                <table class="w-full text-left">
                    <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                        <tr class="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            <th class="px-8 py-5">Order ID</th>
                            <th class="px-8 py-5">Supplier</th>
                            <th class="px-8 py-5">Type</th>
                            <th class="px-8 py-5 text-right">Total Amount</th>
                            <th class="px-8 py-5">Date</th>
                            <th class="px-8 py-5 text-center">Status</th>
                            <th class="px-8 py-5 text-right">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                        <?php if(empty($orders)): ?>
                            <tr><td colspan="7" class="px-8 py-20 text-center text-slate-400 italic">No purchase orders found matching this filter.</td></tr>
                        <?php endif; ?>
                        <?php foreach($orders as $o): 
                            $statusColors = [
                                'pending' => 'bg-amber-500/10 text-amber-500 border-amber-500/20',
                                'shipped' => 'bg-blue-500/10 text-blue-500 border-blue-500/20',
                                'received' => 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
                                'finalized' => 'bg-slate-500/10 text-slate-500 border-slate-500/20',
                                'disputed' => 'bg-rose-500/10 text-rose-500 border-rose-500/20',
                                'return_requested' => 'bg-orange-500/10 text-orange-500 border-orange-500/20',
                                'cancelled' => 'bg-red-500/10 text-red-500 border-red-500/20'
                            ];
                            $badge = $statusColors[$o['status']] ?? 'bg-slate-100 text-slate-500';
                        ?>
                        <tr class="group hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors">
                            <td class="px-8 py-5 font-mono text-xs font-bold text-slate-400 group-hover:text-orange-600 transition-colors">#<?= ($o['type'] === 'Partner' ? 'B2B-' : 'MAN-') . $o['id'] ?></td>
                            <td class="px-8 py-5">
                                <div class="font-black dark:text-white text-sm"><?= htmlspecialchars($o['supplier_name']) ?></div>
                            <div class="flex items-center gap-1.5 mt-1">
                                <span class="text-[8px] font-black uppercase px-1.5 py-0.5 rounded-md <?= ($o['payment_status'] ?? 'Unpaid') === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500' ?>">
                                    <?= $o['payment_status'] ?? 'Unpaid' ?>
                                </span>
                            </div>
                            </td>
                            <td class="px-8 py-5">
                                <span class="text-[10px] font-black uppercase px-2 py-1 rounded bg-slate-100 dark:bg-neutral-800 text-slate-500"><?= $o['type'] ?></span>
                            </td>
                            <td class="px-8 py-5 text-right font-black text-slate-900 dark:text-white"><?= $currency_symbol ?><?= number_format($o['total_amount'], 2) ?></td>
                            <td class="px-8 py-5 text-xs text-slate-500"><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                            <td class="px-8 py-5">
                                <div class="flex flex-col items-center gap-1">
                                    <?php if(($o['payment_status'] ?? 'Unpaid') === 'Unpaid'): ?>
                                        <span class="text-[8px] font-black uppercase px-2 py-0.5 bg-rose-600 text-white rounded shadow-sm">Unpaid</span>
                                    <?php endif; ?>
                                    <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase border <?= $badge ?>">
                                        <?= $o['status'] ?>
                                    </span>
                                </div>
                            </td>
                            <td class="px-8 py-5 text-right">
                                <a href="view_order_details.php?id=<?= $o['id'] ?>&type=<?= strtolower($o['type']) ?>" class="p-2 text-slate-400 hover:text-orange-600 hover:bg-orange-50 dark:hover:bg-orange-950 rounded-xl transition-all inline-block">
                                    <i data-lucide="eye" size="18"></i>
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>

    <script>
        lucide.createIcons();
        function viewDetails(id) {
            // This could open a modal or redirect to a detail page
            alert("Redirecting to detailed view for Order #" + id);
        }
    </script>
</body>
</html>