<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }
if (!has_module('accounts_payable')) { header("Location: dashboard.php?error=module_disabled"); exit; }

$currency = $currency_symbol ?? '$';

// --- Self-Healing: Ensure ledgers table exists ---
try {
    $tenant_conn->exec("CREATE TABLE IF NOT EXISTS ledgers (
        id INT PRIMARY KEY AUTO_INCREMENT,
        branch_id INT,
        party_name VARCHAR(255) NOT NULL,
        party_type ENUM('customer', 'supplier') NOT NULL,
        description TEXT,
        debit DECIMAL(15,2) DEFAULT 0,
        credit DECIMAL(15,2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        INDEX (party_name),
        INDEX (branch_id)
    )");
} catch (Exception $e) {}

// Fetch Active Branch Context
$active_branch = $_SESSION['active_branch_id'] ?? 'all';
$is_all = ($active_branch === 'all');
$branch_cond = $is_all ? "" : " AND branch_id = " . (int)$active_branch;

// Fetch Summary Stats
try {
    $total_payable = $tenant_conn->query("SELECT SUM(credit - debit) FROM ledgers WHERE party_type = 'supplier' $branch_cond")->fetchColumn() ?: 0;
} catch(Exception $e) { $total_payable = 0; }

// Fetch Supplier Balances
try {
    $suppliers = $tenant_conn->query("SELECT party_name, SUM(credit) as total_credit, SUM(debit) as total_debit FROM ledgers WHERE party_type = 'supplier' $branch_cond GROUP BY party_name HAVING (total_credit - total_debit) > 0 ORDER BY (total_credit - total_debit) DESC")->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) { $suppliers = []; }

// Fetch Recent Payments
try {
    $recent_payments = $tenant_conn->query("SELECT * FROM ledgers WHERE party_type = 'supplier' AND debit > 0 $branch_cond ORDER BY created_at DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) { $recent_payments = []; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Accounts Payable | Biltax Financials</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Accounts Payable</h1>
                <p class="text-xs text-slate-500 uppercase tracking-widest font-bold mt-1">Manage outstanding supplier liabilities</p>
            </div>
            <div class="flex items-center gap-3">
                <?php include 'topbar.php'; ?>
            </div>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                <p class="text-[10px] font-black uppercase text-slate-400 mb-1 tracking-widest">Total Outstanding Debt</p>
                <h3 class="text-4xl font-black text-rose-500"><?= $currency . number_format($total_payable, 2) ?></h3>
            </div>
            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm flex items-center justify-between">
                <div>
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-1 tracking-widest">Active Creditors</p>
                    <h3 class="text-4xl font-black dark:text-white"><?= count($suppliers) ?> Vendors</h3>
                </div>
                <i data-lucide="landmark" class="text-slate-200 dark:text-neutral-800" size="48"></i>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div class="lg:col-span-2 bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
                <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                    <h2 class="text-sm font-black dark:text-white uppercase tracking-widest">Payable Balances</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                            <tr>
                                <th class="px-8 py-4">Supplier Name</th>
                                <th class="px-8 py-4 text-right">Balance Due</th>
                                <th class="px-8 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                            <?php if (empty($suppliers)): ?>
                                <tr><td colspan="3" class="p-20 text-center text-slate-400 italic font-bold">No outstanding payables.</td></tr>
                            <?php else: ?>
                                <?php foreach ($suppliers as $s): 
                                    $balance = $s['total_credit'] - $s['total_debit'];
                                ?>
                                <tr class="hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                                    <td class="px-8 py-5 text-sm font-bold dark:text-white"><?= htmlspecialchars($s['party_name']) ?></td>
                                    <td class="px-8 py-5 text-right text-lg font-black text-rose-500"><?= $currency . number_format($balance, 2) ?></td>
                                    <td class="px-8 py-5 text-right">
                                        <button onclick='openPaymentModal("<?= addslashes($s['party_name']) ?>", <?= $balance ?>)' class="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase hover:bg-emerald-700 transition-all shadow-lg shadow-emerald-600/20">Record Payment</button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="lg:col-span-1 bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
                <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                    <h2 class="text-sm font-black dark:text-white uppercase tracking-widest">Recent Payments</h2>
                </div>
                <div class="p-4 space-y-4">
                    <?php if (empty($recent_payments)): ?>
                        <p class="text-center py-10 text-slate-400 italic text-xs">No recent payments recorded.</p>
                    <?php else: ?>
                        <?php foreach ($recent_payments as $rp): ?>
                        <div class="p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800">
                            <div class="flex justify-between items-start mb-1">
                                <h4 class="text-xs font-black dark:text-white uppercase"><?= htmlspecialchars($rp['party_name']) ?></h4>
                                <span class="text-[9px] font-black text-emerald-500 uppercase"><?= $currency . number_format($rp['debit'], 2) ?></span>
                            </div>
                            <p class="text-[10px] text-slate-400 font-medium"><?= htmlspecialchars($rp['description']) ?></p>
                            <p class="text-[8px] text-slate-500 mt-2 font-mono"><?= date('d M, Y', strtotime($rp['created_at'])) ?></p>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <div id="paymentModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('paymentModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-6 tracking-tight">Record Supplier Payment</h2>
            <form id="paymentForm" class="space-y-4">
                <input type="hidden" id="pay_party_name">
                <div class="p-4 bg-rose-500/5 rounded-2xl border border-rose-500/10 mb-4">
                    <p class="text-[10px] font-black uppercase text-slate-400">Supplier</p>
                    <p class="text-sm font-bold dark:text-white" id="display_party_name"></p>
                    <p class="text-[10px] font-black uppercase text-rose-500 mt-2">Current Balance: <?= $currency ?><span id="display_balance"></span></p>
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Amount Paid (<?= $currency ?>)</label>
                    <input type="number" id="pay_amount" step="0.01" required class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-black text-xl focus:border-emerald-500">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Payment Description</label>
                    <input type="text" id="pay_desc" placeholder="e.g. Paid via Bank Transfer" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                </div>
                <button type="submit" class="w-full py-5 bg-emerald-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all mt-4">Confirm Payment</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function openPaymentModal(name, balance) {
            document.getElementById('pay_party_name').value = name;
            document.getElementById('display_party_name').innerText = name;
            document.getElementById('display_balance').innerText = balance.toLocaleString(undefined, {minimumFractionDigits: 2});
            document.getElementById('pay_amount').value = balance;
            document.getElementById('paymentModal').classList.replace('hidden', 'flex');
        }
        document.getElementById('paymentForm').onsubmit = async (e) => {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.disabled = true; btn.innerText = "Processing...";
            const data = { party_name: document.getElementById('pay_party_name').value, amount: document.getElementById('pay_amount').value, description: document.getElementById('pay_desc').value };
            try {
                const res = await fetch('api.php?route=finance/payables/pay', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
                const result = await res.json();
                if (result.success) location.reload();
                else alert("Error: " + result.message);
            } catch (err) { alert("System Error."); }
            btn.disabled = false; btn.innerText = "Confirm Payment";
        };
    </script>
</body>
</html>