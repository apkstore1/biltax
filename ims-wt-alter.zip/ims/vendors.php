<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Self-healing: Ensure vendors table exists
$tenant_conn->exec("CREATE TABLE IF NOT EXISTS vendors (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(255) NOT NULL,
    company VARCHAR(255),
    phone VARCHAR(50),
    email VARCHAR(100),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if ($_POST['action'] === 'add_vendor') {
        $stmt = $tenant_conn->prepare("INSERT INTO vendors (name, company, phone, email, address) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$_POST['name'], $_POST['company'], $_POST['phone'], $_POST['email'], $_POST['address']]);
        $message = "Vendor added successfully!";
    }
    if ($_POST['action'] === 'delete_vendor') {
        $stmt = $tenant_conn->prepare("DELETE FROM vendors WHERE id = ?");
        $stmt->execute([$_POST['id']]);
        $message = "Vendor removed.";
    }
}

$vendors = $tenant_conn->query("SELECT * FROM vendors ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Manage Vendors | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h2 class="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Vendor Directory</h2>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Manual entry for local or non-B2B vendors</p>
            </div>
            <button onclick="document.getElementById('addModal').classList.replace('hidden', 'flex')" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase shadow-lg shadow-orange-600/20 hover:scale-105 transition-all">Add New Vendor</button>
        </header>

        <?php if($message): ?>
            <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-2xl text-xs font-bold"><?= $message ?></div>
        <?php endif; ?>

        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-[32px] overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-200 dark:border-neutral-800">
                    <tr class="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <th class="px-8 py-5">Vendor Name</th>
                        <th class="px-8 py-5">Company</th>
                        <th class="px-8 py-5">Contact</th>
                        <th class="px-8 py-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-900">
                    <?php foreach($vendors as $v): ?>
                    <tr class="hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                        <td class="px-8 py-5 font-bold dark:text-white"><?= htmlspecialchars($v['name']) ?></td>
                        <td class="px-8 py-5 text-sm text-slate-500"><?= htmlspecialchars($v['company']) ?></td>
                        <td class="px-8 py-5 text-xs text-slate-400"><?= htmlspecialchars($v['phone']) ?><br><?= htmlspecialchars($v['email']) ?></td>
                        <td class="px-8 py-5 text-right">
                            <form method="POST" class="inline" onsubmit="return confirm('Delete vendor?');">
                                <input type="hidden" name="action" value="delete_vendor">
                                <input type="hidden" name="id" value="<?= $v['id'] ?>">
                                <button class="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 rounded-xl"><i data-lucide="trash-2" size="18"></i></button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Add Modal -->
    <div id="addModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center p-4 z-[100] backdrop-blur-sm">
        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('addModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors"><i data-lucide="x" size="24"></i></button>
            <h3 class="text-xl font-black mb-6 dark:text-white uppercase">Register Vendor</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add_vendor">
                <input type="text" name="name" placeholder="Full Name" required class="w-full px-5 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white">
                <input type="text" name="company" placeholder="Company Name" class="w-full px-5 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white">
                <input type="text" name="phone" placeholder="Phone" class="w-full px-5 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white">
                <input type="email" name="email" placeholder="Email" class="w-full px-5 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white">
                <textarea name="address" placeholder="Address" class="w-full px-5 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white"></textarea>
                <button type="submit" class="w-full bg-orange-600 text-white py-4 rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-orange-600/20">Save Vendor</button>
            </form>
        </div>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>