<?php
require_once 'config/db_switch.php';
header('Content-Type: application/json');

if (!$tenant_conn || !isset($_POST['id'])) {
    echo json_encode(['success' => false]);
    exit;
}

try {
    $main_db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    
    // Get Tenant ID
    $stmt = $main_db->prepare("SELECT id FROM tenants WHERE db_name = ?");
    $stmt->execute([$_SESSION['db_name']]);
    $tenant_id = $stmt->fetchColumn();

    // Mark as read only if it belongs to this tenant or is global
    $stmt = $main_db->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND (tenant_id = ? OR tenant_id IS NULL)");
    $stmt->execute([$_POST['id'], $tenant_id]);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => $e->getMessage()]);
}
?>