<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

// Page Restriction Logic
if (!has_module('b2b_orders')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
$my_id = $_SESSION['tenant_id'];

$active_branch = $_SESSION['active_branch_id'] ?? null;
$is_all = ($active_branch === 'all');

// Get Main Branch ID for legacy data support
$stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
$main_id = $stmt_main->fetchColumn();
if (!$main_id) $main_id = 0;

// Self-healing: Ensure 'processing' status is allowed in the database ENUM
$main_pdo->exec("ALTER TABLE b2b_orders MODIFY COLUMN status ENUM('pending', 'processing', 'shipped', 'received', 'finalized', 'disputed', 'return_requested') DEFAULT 'pending'"); // Already done in b2b_actions.php
// Ensure payment_status column exists
try { $main_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN payment_status ENUM('Unpaid', 'Paid') DEFAULT 'Unpaid'"); } catch(Exception $e) {}
// Ensure branch_id columns exist
try { $main_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN sender_branch_id INT DEFAULT NULL AFTER sender_tenant_id"); } catch(Exception $e) {}
try { $main_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN receiver_branch_id INT DEFAULT NULL AFTER receiver_tenant_id"); } catch(Exception $e) {}

// Fetch Incoming Orders (as Provider) - These are orders placed by other tenants to ME
$incoming_sql = "SELECT o.*, t.business_name as customer FROM b2b_orders o JOIN tenants t ON o.sender_tenant_id = t.id WHERE o.receiver_tenant_id = ?";
$incoming_params = [$my_id];
if (!$is_all) {
    // Show orders assigned to this branch OR pending orders that haven't been claimed yet
    $incoming_sql .= " AND (o.receiver_branch_id = ? OR (o.receiver_branch_id IS NULL AND o.status = 'pending'))";
    $incoming_params[] = $active_branch;
}
$incoming_sql .= " ORDER BY o.id DESC";

$stmt = $main_pdo->prepare($incoming_sql);
$stmt->execute($incoming_params);
$incoming = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch Outgoing Orders (as Subscriber)
$outgoing_sql = "SELECT o.*, t.business_name as supplier FROM b2b_orders o JOIN tenants t ON o.receiver_tenant_id = t.id WHERE o.sender_tenant_id = ?";
$outgoing_params = [$my_id];
if (!$is_all) {
    if ($active_branch == $main_id) {
        $outgoing_sql .= " AND (o.sender_branch_id = ? OR o.sender_branch_id IS NULL)";
    } else {
        $outgoing_sql .= " AND o.sender_branch_id = ?";
    }
    $outgoing_params[] = $active_branch;
}
$outgoing_sql .= " ORDER BY o.id DESC";

$stmt = $main_pdo->prepare($outgoing_sql);
$stmt->execute($outgoing_params);
$outgoing = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Fetch Marketplace Status
$stmt = $main_pdo->prepare("SELECT marketplace_listing_status FROM tenants WHERE id = ?");
$stmt->execute([$my_id]);
$marketplace_enabled = (bool)$stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>B2B Orders | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 p-8">
    <div class="max-w-6xl mx-auto">
        <div class="flex items-center gap-4 mb-8">
            <a href="dashboard.php" class="flex items-center gap-2 px-4 py-2 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl text-slate-400 hover:text-orange-500 transition-all shadow-sm group">
                <i data-lucide="chevron-left" size="24"></i>
                <span class="text-xs font-black uppercase tracking-widest">Back to Dashboard</span>
            </a>
            <h1 class="text-3xl font-black dark:text-white">B2B Order Management</h1>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Incoming Section -->
            <?php if ($marketplace_enabled): ?>
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl shadow-xl">
                <h2 class="text-xs font-black uppercase text-orange-500 mb-6 tracking-widest">Incoming Orders (Sales)</h2>
                <?php foreach($incoming as $o): ?>
                <div class="mb-4 p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 flex justify-between items-center">
                    <div>
                        <div class="font-bold dark:text-white"><?= $o['customer'] ?></div>
                        <div class="flex items-center gap-2">
                            <span class="text-[10px] text-slate-500 font-mono">#B2B-<?= $o['id'] ?> • <?= $currency_symbol ?><?= number_format($o['total_amount'],2) ?></span>
                            <span class="text-[8px] font-black uppercase px-1.5 py-0.5 rounded-md <?= ($o['payment_status'] ?? 'Unpaid') === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500' ?>">
                                <?= $o['payment_status'] ?? 'Unpaid' ?>
                            </span>
                        </div>
                    </div>
                    <div class="flex flex-col items-end gap-1.5">
                        <?php if(($o['payment_status'] ?? 'Unpaid') === 'Unpaid'): ?>
                            <span class="text-[9px] font-black uppercase px-2 py-0.5 bg-rose-600 text-white rounded-md shadow-sm">Unpaid Balance</span>
                        <?php endif; ?>
                        <div class="flex items-center gap-2">
                        <a href="view_order_details.php?id=<?= $o['id'] ?>&type=b2b" class="px-4 py-2 bg-white dark:bg-neutral-800 border border-slate-200 dark:border-neutral-800 rounded-xl text-xs font-bold text-slate-500 dark:text-neutral-400 hover:text-orange-600 transition-all">View Order</a>
                        <?php if($o['status'] === 'pending'): ?>
                            <button onclick="updateStatus(<?= $o['id'] ?>, 'processing')" class="bg-indigo-600 text-white px-4 py-2 rounded-xl text-xs font-bold">Process Order</button>
                        <?php elseif($o['status'] === 'processing'): ?>
                            <button onclick="updateStatus(<?= $o['id'] ?>, 'shipped')" class="bg-orange-600 text-white px-4 py-2 rounded-xl text-xs font-bold">Ship Order</button>
                        <?php elseif(($o['status'] === 'received' || $o['status'] === 'finalized' || $o['status'] === 'return_requested') && ($o['payment_status'] ?? 'Unpaid') === 'Unpaid'): ?>
                            <button onclick="updateStatus(<?= $o['id'] ?>, 'finalized')" class="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold">Confirm Payment Received</button>
                        <?php elseif($o['status'] === 'return_requested'): ?>
                            <span class="text-[9px] font-black uppercase px-3 py-1 bg-orange-500/10 text-orange-500 rounded-full border border-orange-500/20">Return In Progress</span>
                        <?php else: ?>
                            <span class="text-[10px] font-black uppercase px-3 py-1 bg-slate-200 dark:bg-neutral-800 text-slate-500 rounded-full"><?= $o['status'] ?></span>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>

            <!-- Outgoing Section -->
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl shadow-xl <?php echo !$marketplace_enabled ? 'md:col-span-2' : ''; ?>">
                <h2 class="text-xs font-black uppercase text-emerald-500 mb-6 tracking-widest">My Purchases</h2>
                <?php foreach($outgoing as $o): ?>
                <div class="mb-4 p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 flex justify-between items-center">
                    <div>
                        <div class="font-bold dark:text-white"><?= $o['supplier'] ?></div>
                        <div class="flex items-center gap-2">
                            <span class="text-[10px] text-slate-500 font-mono">#B2B-<?= $o['id'] ?> • <?= $currency_symbol ?><?= number_format($o['total_amount'],2) ?></span>
                            <span class="text-[8px] font-black uppercase px-1.5 py-0.5 rounded-md <?= ($o['payment_status'] ?? 'Unpaid') === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500' ?>">
                                <?= $o['payment_status'] ?? 'Unpaid' ?>
                            </span>
                        </div>
                    </div>
                    <div class="flex flex-col items-end gap-1.5">
                        <?php if(($o['payment_status'] ?? 'Unpaid') === 'Unpaid'): ?>
                            <span class="text-[9px] font-black uppercase px-2 py-0.5 bg-rose-600 text-white rounded-md shadow-sm">Payment Due</span>
                        <?php endif; ?>
                        <div class="flex items-center gap-2">
                        <?php if($o['status'] === 'shipped'): ?>
                            <button onclick="updateStatus(<?= $o['id'] ?>, 'received')" class="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold tracking-tight">Confirm Receipt</button>
                        <?php elseif($o['status'] === 'received'): ?>
                            <a href="b2b_price_review.php?order_id=<?= $o['id'] ?>" class="bg-blue-600 text-white px-4 py-2 rounded-xl text-xs font-bold tracking-tight">Review Prices</a>
                        <?php else: ?>
                            <span class="text-[10px] font-black uppercase px-3 py-1 bg-slate-200 rounded-full"><?= $o['status'] ?></span>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    <script>
        lucide.createIcons();
        async function updateStatus(id, status) {
            try {
                const response = await fetch(`./b2b_actions.php?action=update_status&id=${id}&status=${status}`);
                const data = await response.json();
                if (data.success) {
                    location.reload();
                } else {
                    alert("Error: " + (data.message || "Failed to update status"));
                }
            } catch (e) {
                // Fallback if backend doesn't return JSON
                location.reload();
            }
        }
    </script>
</body>
</html>