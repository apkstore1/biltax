<?php
require_once 'config/db_switch.php';

// Redirect if not logged in
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

$industry_type = $_SESSION['industry_type'] ?? 'retail';
$message = '';

// --- Handle Main Form Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_product') {
    try {
        $active_branch = $_SESSION['active_branch_id'] ?? null;
        $target_branch = get_active_stock_branch_id($active_branch);

        // Input Sanitization
        $name = $_POST['name'] ?? '';
        $barcode = $_POST['barcode'] ?? '';
        $category_id = $_POST['category_id'] ?? null;
        $unit_id = $_POST['unit_id'] ?? null;
        $supplier_id = $_POST['supplier_id'] ?? null;
        $purchase_price = (float)($_POST['purchase_price'] ?? 0);
        $sale_price = (float)($_POST['sale_price'] ?? 0);
        $price = (float)($_POST['price'] ?? 0); // Unified price field
        $opening_stock = (int)($_POST['opening_stock'] ?? 0);
        $alert_level = (int)($_POST['alert_level'] ?? 10);
        $category = $_POST['category'] ?? null; 

        if (empty($name)) throw new Exception("Product Name is mandatory.");

                // 1. Start Transaction
                $tenant_conn->beginTransaction();

                if ($industry_type === 'restaurant' || $industry_type === 'service') {
                    // Restaurant/Service Logic: Insert into products table with 'price' column
                    $final_price = ($price > 0) ? $price : $sale_price;
                    $stmt = $tenant_conn->prepare("
                        INSERT INTO products (branch_id, name, price, category, description, is_active) 
                        VALUES (?, ?, ?, ?, ?, 1)
                    ");
                    $stmt->execute([
                        $target_branch,
                        $name,
                        $final_price,
                        $category,
                        $_POST['description'] ?? null
                    ]);
                } else {
                    // Duplicate Barcode/SKU Check for retail/wholesale
                    if (!empty($barcode)) {
                        $check_stmt = $tenant_conn->prepare("SELECT COUNT(*) FROM products WHERE sku = ? OR barcode = ?");
                        $check_stmt->execute([$barcode, $barcode]);
                        if ($check_stmt->fetchColumn() > 0) throw new Exception("Duplicate Error: Product with Barcode/SKU '$barcode' already exists.");
                    }

                    // Retail/Wholesale Logic: Insert into products table with 'sale_price' and 'purchase_price'
                    $stmt = $tenant_conn->prepare("
                        INSERT INTO products (branch_id, name, sku, barcode, sale_price, purchase_price, 
                        category_id, unit_id, supplier_id, stock_level, alert_level) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                    ");
                    
                    $stmt->execute([
                        $target_branch,
                        $name,
                        $barcode, // Barcode is used as SKU here
                        $barcode,
                        $sale_price,
                        $purchase_price,
                        $category_id,
                        $unit_id,
                        $supplier_id,
                        $opening_stock,
                        $alert_level
                    ]);
        }
                
        $product_id = $tenant_conn->lastInsertId();

        // 3. Insert into Stock Table (Opening Stock)
        if ($opening_stock > 0) {
            $stock_stmt = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (:pid, :qty, :reason)");
            $stock_stmt->execute([
                ':pid' => $product_id,
                ':qty' => $opening_stock,
                ':reason' => 'Opening Stock'
            ]);
        }

        // 4. Commit everything
        $tenant_conn->commit();
        // Success redirect to prevent duplicate POST on reload
        header("Location: products.php?msg=added");
        exit;
    } catch (Exception $e) {
        if ($tenant_conn && $tenant_conn->inTransaction()) {
            $tenant_conn->rollBack();
        }
        $message = "error: " . $e->getMessage();
    }
}

// --- Fetch Dropdown Data ---
try {
    $categories = $tenant_conn->query("SELECT id, name FROM categories WHERE is_allowed = 1 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

    $unit_stmt = $tenant_conn->query("SELECT id, name FROM units WHERE is_allowed = 1 ORDER BY name ASC");
    $units = $unit_stmt->fetchAll(PDO::FETCH_ASSOC);

    $suppliers = $tenant_conn->query("SELECT id, name FROM suppliers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $categories = $units = $suppliers = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add New Product | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        /* Custom select styling to remove default arrow in some browsers */
        select { appearance: none; -webkit-appearance: none; }
    </style>
</head>
<body class="flex min-h-screen bg-neutral-50 dark:bg-neutral-950 transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8 overflow-y-auto flex justify-center">
        <div class="w-full max-w-4xl">
            <header class="flex justify-between items-center mb-10">
                <div>
                    <h2 class="text-3xl font-black text-slate-900 dark:text-white tracking-tight">Add New Product</h2>
                    <p class="text-slate-500 dark:text-neutral-400">Inventory Management Terminal</p>
                </div>
                <?php include 'topbar.php'; ?>
            </header>

            <?php if ($message == 'success'): ?>
                <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center gap-3 animate-bounce">
                    <i data-lucide="check-circle"></i> 
                    <span class="font-bold">Product catalog updated successfully!</span>
                </div>
            <?php elseif (strpos($message, 'error') === 0): ?>
                <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-2xl flex items-center gap-3">
                    <i data-lucide="alert-circle"></i> 
                    <span class="font-bold"><?= htmlspecialchars($message) ?></span>
                </div>
            <?php endif; ?>

            <form method="POST" class="bg-white dark:bg-neutral-900 p-6 md:p-10 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-xl space-y-8">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Name & Barcode -->
                    <div class="flex flex-col gap-2">
                        <label class="text-xs font-black uppercase tracking-widest text-slate-400">Product Name</label>
                        <input type="text" name="name" required placeholder="e.g. Wireless Mouse" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white transition-all">
                    </div>
                <?php if ($industry_type !== 'restaurant'): ?>
                    <div class="space-y-2">
                        <label class="text-xs font-black uppercase tracking-widest text-slate-400">Barcode / SKU</label>
                        <div class="flex gap-2">
                            <input type="text" name="barcode" id="barcode-field" required placeholder="Scan or Generate" class="flex-1 px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white transition-all font-mono">
                            <button type="button" onclick="generateBarcode()" class="p-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl hover:bg-orange-600 hover:text-white transition-all">
                                <i data-lucide="refresh-cw" size="20"></i>
                            </button>
                        </div>
                    </div>
                <?php endif; ?>
                    <!-- Dropdowns -->
                    <div class="flex flex-col gap-2 relative">
                        <label class="text-xs font-black uppercase tracking-widest text-slate-400">Category</label>
                        <select name="category_id" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white transition-all appearance-none">
                            <option value="">Select Category</option>
                            <?php if(!empty($categories)): foreach($categories as $c): ?>
                                <option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?></option>
                            <?php endforeach; else: ?>
                                <option disabled>No categories found</option>
                            <?php endif; ?>
                        </select>
                        <i data-lucide="chevron-down" class="absolute right-5 bottom-4 text-slate-400 pointer-events-none" size="18"></i>
                    </div>
                <?php if ($industry_type !== 'restaurant'): ?>
                    <div class="flex flex-col gap-2 relative">
                        <label class="text-xs font-black uppercase tracking-widest text-slate-400">Unit of Measure</label>
                        <select name="unit_id" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white transition-all appearance-none">
                            <option value="">Select Unit</option>
                            <?php if(!empty($units)): foreach($units as $u): ?>
                                <option value="<?= $u['id'] ?>"><?= htmlspecialchars($u['name']) ?></option>
                            <?php endforeach; else: ?>
                                <option disabled>No units found</option>
                            <?php endif; ?>
                        </select>
                        <i data-lucide="chevron-down" class="absolute right-5 bottom-4 text-slate-400 pointer-events-none" size="18"></i>
                    </div>
                <?php endif; ?>
                    <div class="flex flex-col gap-2 relative">
                        <label class="text-xs font-black uppercase tracking-widest text-slate-400">Supplier</label>
                        <select name="supplier_id" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white transition-all appearance-none">
                            <option value="">Select Supplier</option>
                            <?php if(!empty($suppliers)): foreach($suppliers as $s): ?>
                                <option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option>
                            <?php endforeach; else: ?>
                                <option disabled>No suppliers found</option>
                            <?php endif; ?>
                        </select>
                        <i data-lucide="chevron-down" class="absolute right-5 bottom-4 text-slate-400 pointer-events-none" size="18"></i>
                    </div>
                <?php if ($industry_type === 'restaurant'): ?>
                    <div class="space-y-2">
                        <label class="text-xs font-black uppercase tracking-widest text-slate-400">Price</label>
                        <input type="number" step="0.01" name="price" required placeholder="0.00" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white">
                    </div>
                <?php else: ?>
                    <!-- Pricing & Stock -->
                    <div class="grid grid-cols-2 gap-4">
                        <div class="space-y-2">
                            <label class="text-xs font-black uppercase tracking-widest text-slate-400">Purchase Cost</label>
                            <input type="number" step="0.01" name="purchase_price" placeholder="0.00" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white">
                        </div>
                        <div class="space-y-2">
                            <label class="text-xs font-black uppercase tracking-widest text-slate-400">Sale Price</label> <!-- Changed from 'Sale Price' to 'Selling Price' for clarity -->
                            <input type="number" step="0.01" name="sale_price" required placeholder="0.00" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white">
                        </div>
                    </div>
                    <div class="space-y-2">
                        <label class="text-xs font-black uppercase tracking-widest text-slate-400">Opening Stock</label>
                        <input type="number" name="opening_stock" value="0" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white">
                    </div>
                <?php endif; ?>

                <?php if ($industry_type !== 'restaurant'): ?>
                    <div class="space-y-2">
                        <label class="text-xs font-black uppercase tracking-widest text-slate-400">Min Alert Level</label>
                        <input type="number" name="alert_level" value="10" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white">
                    </div>
                <?php endif; ?>
                </div>

                <div class="pt-10 border-t border-slate-100 dark:border-neutral-800 flex justify-end">
                    <button type="submit" class="w-full md:w-64 bg-orange-600 hover:bg-orange-700 text-white font-black py-5 rounded-2xl shadow-xl shadow-orange-600/30 transition-all active:scale-95 flex items-center justify-center gap-3">
                        <i data-lucide="plus-circle"></i> SAVE PRODUCT
                    </button>
                </div>
            </form>
        </div>
    </main>

    <script>
        function generateBarcode() {
            const prefix = 'BX-';
            const rand = Math.floor(1000000 + Math.random() * 9000000);
            document.getElementById('barcode-field').value = prefix + rand;
        }
        lucide.createIcons();
    </script>
</body>
</html>