-- Notifications table for biltax_main database
-- This table handles announcements from Super Admin to Tenants

CREATE TABLE IF NOT EXISTS notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    sender_id INT NOT NULL COMMENT 'Admin ID who sent the notification',
    tenant_id INT DEFAULT NULL COMMENT 'NULL for all tenants, specific ID for a business',
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('announcement', 'system', 'alert') DEFAULT 'announcement',
    is_read TINYINT(1) DEFAULT 0 COMMENT '0 for unread, 1 for read',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_tenant (tenant_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;