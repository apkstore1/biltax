<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) { header("Location: login.php"); exit; }

try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $tenant_id = $_SESSION['tenant_id'];
    $orders = $main_pdo->prepare("SELECT * FROM shop_orders WHERE tenant_id = ? ORDER BY created_at DESC");
    $orders->execute([$tenant_id]);
    $my_orders = $orders->fetchAll(PDO::FETCH_ASSOC);

    // Fetch Currency Symbol
    $stmt_curr = $main_pdo->prepare("SELECT currency_symbol FROM tenants WHERE id = ?");
    $stmt_curr->execute([$tenant_id]);
    $currency_symbol = $stmt_curr->fetchColumn() ?: '$';

} catch (Exception $e) { die("Error: " . $e->getMessage()); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>My Biltax Orders</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Order History</h1>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Track your Biltax official purchases</p>
            </div>
            <a href="biltax_shop.php" class="bg-orange-600 text-white px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all shadow-lg shadow-orange-600/20 flex items-center gap-2">
                <i data-lucide="shopping-cart" size="14"></i> Back to Shop
            </a>
        </header>

        <div class="bg-white dark:bg-neutral-900 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                    <tr>
                        <th class="px-6 py-5 text-[10px] font-black uppercase text-slate-500 tracking-widest">Order Ref</th>
                        <th class="px-6 py-5 text-[10px] font-black uppercase text-slate-500 tracking-widest">Date</th>
                        <th class="px-6 py-5 text-[10px] font-black uppercase text-slate-500 tracking-widest">Total Amount</th>
                        <th class="px-6 py-5 text-[10px] font-black uppercase text-slate-500 tracking-widest">Current Status</th>
                        <th class="px-6 py-5 text-[10px] font-black uppercase text-slate-500 tracking-widest text-right">Track</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach ($my_orders as $o): ?>
                    <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors">
                        <td class="px-6 py-5 font-mono text-xs font-bold text-slate-400">#BTX-ORD-<?= $o['id'] ?></td>
                        <td class="px-6 py-5 text-sm font-bold dark:text-white"><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                        <td class="px-6 py-5 font-black text-orange-600 text-sm"><?= $currency_symbol ?><?= number_format($o['total_amount'], 2) ?></td>
                        <td class="px-6 py-5">
                            <?php 
                                $status_classes = [
                                    'pending' => 'bg-amber-500',
                                    'processing' => 'bg-blue-500',
                                    'fulfilled' => 'bg-emerald-500',
                                    'cancelled' => 'bg-rose-500'
                                ];
                                $current_status = $o['status'] ?? 'pending';
                            ?>
                            <span class="<?= $status_classes[$current_status] ?> text-white text-[9px] font-black uppercase px-2.5 py-1 rounded-lg">
                                <?= $current_status ?>
                            </span>
                        </td>
                        <td class="px-6 py-5 text-right">
                            <div class="flex items-center justify-end gap-1">
                                <div class="w-2 h-2 rounded-full <?= $current_status == 'pending' ? 'bg-orange-500 animate-pulse' : 'bg-slate-200' ?>"></div>
                                <div class="w-8 h-0.5 <?= in_array($current_status, ['processing', 'fulfilled']) ? 'bg-orange-500' : 'bg-slate-200' ?>"></div>
                                <div class="w-2 h-2 rounded-full <?= $current_status == 'processing' ? 'bg-orange-500 animate-pulse' : 'bg-slate-200' ?>"></div>
                                <div class="w-8 h-0.5 <?= $current_status == 'fulfilled' ? 'bg-orange-500' : 'bg-slate-200' ?>"></div>
                                <div class="w-2 h-2 rounded-full <?= $current_status == 'fulfilled' ? 'bg-orange-500' : 'bg-slate-200' ?>"></div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if (empty($my_orders)): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-20 text-center">
                                <div class="w-16 h-16 bg-slate-100 dark:bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <i data-lucide="package" class="text-slate-300"></i>
                                </div>
                                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">You haven't placed any orders yet.</p>
                                <a href="biltax_shop.php" class="text-orange-600 text-[10px] font-black uppercase mt-2 inline-block">Visit Shop Now</a>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>