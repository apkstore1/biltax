<?php
session_start();
header("Content-Type: application/json");
require_once '../config/db_connect.php';

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Database connection failed']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['status' => 'error', 'message' => 'Method not allowed']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$identifier = trim($input['identifier'] ?? '');
$password = $input['password'] ?? '';
$business_id = trim($input['business_id'] ?? '');

if (empty($identifier) || empty($password)) {
    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'All fields are required']);
    exit;
}

try {
    if (empty($business_id)) {
        // 1. Admin / Tenant Login Flow
        $stmt = $pdo->prepare("SELECT * FROM tenants WHERE email = :email");
        $stmt->execute([':email' => $identifier]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['tenant_id'] = $user['id'];
            $_SESSION['owner_name'] = $user['owner_name'];
            $_SESSION['business_name'] = $user['business_name'];
            $_SESSION['db_name'] = $user['db_name'];
            $_SESSION['industry_type'] = $user['industry_type'];
            $_SESSION['role'] = 'admin';
            echo json_encode(['status' => 'success', 'redirect' => 'dashboard.php']);
            exit;
        }
    } else {
        // 2. Staff Login Flow (Business ID provided)
        $stmt = $pdo->prepare("SELECT * FROM tenants WHERE unique_id = :uid");
        $stmt->execute([':uid' => $business_id]);
        $tenant = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($tenant) {
            $t_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . $tenant['db_name'], DB_USER, DB_PASS);
            $t_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $s_stmt = $t_pdo->prepare("SELECT * FROM users WHERE name = :name");
            $s_stmt->execute([':name' => $identifier]);
            $staff = $s_stmt->fetch(PDO::FETCH_ASSOC);

            if ($staff && password_verify($password, $staff['password'])) {
                // Set Tenant Context first
                $_SESSION['tenant_id'] = $tenant['id'];
                $_SESSION['db_name'] = $tenant['db_name'];
                $_SESSION['business_name'] = $tenant['business_name'];
                $_SESSION['industry_type'] = $tenant['industry_type'];
                
                // Set Staff Context
                $_SESSION['staff_id'] = $staff['id'];
                $_SESSION['staff_name'] = $staff['name'];
                $_SESSION['role'] = strtolower($staff['role']); // e.g. cashier, manager, technician
                
                // Branch Restriction Logic
                if (!empty($staff['assigned_branch_id'])) {
                    $_SESSION['active_branch_id'] = $staff['assigned_branch_id'];
                    $_SESSION['staff_restricted'] = true;
                }

                echo json_encode(['status' => 'success', 'redirect' => 'dashboard.php']);
                exit;
            }
        }
    }
    http_response_code(401);
    echo json_encode(['status' => 'error', 'message' => 'Invalid ID, Username or Password']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Query failed: ' . $e->getMessage()]);
}