<?php
require_once 'config/db_switch.php';

header('Content-Type: application/json');

if (!$tenant_conn) {
    echo json_encode(['success' => false, 'error' => 'Not logged in']);
    exit;
}

try {
    // Connect to biltax_main to get notifications
    $main_db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Get Tenant ID from session db_name
    $stmt = $main_db->prepare("SELECT id FROM tenants WHERE db_name = ?");
    $stmt->execute([$_SESSION['db_name']]);
    $tenant_id = $stmt->fetchColumn();

    // Fetch latest 5 notifications (Specific to tenant OR Global NULL)
    $query = "SELECT id, title, message, created_at, is_read, type 
              FROM notifications 
              WHERE (tenant_id = :tid OR tenant_id IS NULL) 
              ORDER BY created_at DESC 
              LIMIT 5";
    
    $stmt = $main_db->prepare($query);
    $stmt->execute([':tid' => $tenant_id]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Function for professional "Time Ago" format
    function timeAgo($timestamp) {
        $time = strtotime($timestamp);
        $diff = time() - $time;
        
        if ($diff < 60) return "Just now";
        if ($diff < 3600) return round($diff / 60) . " mins ago";
        if ($diff < 86400) return round($diff / 3600) . " hours ago";
        return date('d M', $time);
    }

    $formatted = [];
    $unread_count = 0;

    foreach ($notifications as $n) {
        if (!$n['is_read']) $unread_count++;
        
        $formatted[] = [
            'id' => $n['id'],
            'title' => htmlspecialchars($n['title']),
            'snippet' => htmlspecialchars(substr($n['message'], 0, 45)) . '...',
            'time' => timeAgo($n['created_at']),
            'type' => $n['type'],
            'is_read' => (bool)$n['is_read']
        ];
    }

    echo json_encode([
        'success' => true,
        'notifications' => $formatted,
        'unread_count' => $unread_count
    ]);

} catch (PDOException $e) {
    echo json_encode([
        'success' => false,
        'error' => $e->getMessage()
    ]);
}
?>