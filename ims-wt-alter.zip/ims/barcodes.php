<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Fetch Printer Configs from biltax_main
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $printer_types = $main_pdo->query("SELECT * FROM printer_types")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $printer_types = [];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barcodes - Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/jsbarcode@3.11.5/dist/JsBarcode.all.min.js"></script>
    <style>
        .search-results { z-index: 50; }

        /* Print Container Hidden by default on screen */
        #dynamic-print-style { display: none; }
        #barcode-print-area { display: none; }

        @media print {
            .no-print { display: none !important; }
            #barcode-print-area { background: white; color: black; width: 100%; }
            body { background: white !important; margin: 0; padding: 0; }

            /* Dynamic labels logic */
            .label-grid {
                display: grid; 
                margin: 0 auto;
            }
            .label-continuous { display: block; margin: 0 auto; }

            .label-item {
                text-align: center;
                border: 0.1mm solid #ccc;
                padding: 2mm;
                display: flex;
                flex-direction: column;
                justify-content: center;
                align-items: center;
                background: white;
                page-break-inside: avoid;
            }
            
            .label-biz { font-size: 7pt; font-weight: 900; text-transform: uppercase; margin-bottom: 0.5mm; line-height: 1; }
            .label-name { font-size: 6pt; font-weight: 700; line-height: 1.1; margin-bottom: 0.5mm; white-space: normal; word-wrap: break-word; }
            .label-price { font-size: 8pt; font-weight: 900; margin-top: 0.5mm; color: black; }
            svg { width: auto; max-width: 100%; height: auto; max-height: 14mm; display: block; margin: 0 auto; }
        }
    </style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors duration-300">
    
    <!-- Dynamic Style Holder -->
    <div id="dynamic-print-style"></div>
    <div id="barcode-print-area"></div>

    <div class="no-print">
        <?php include 'sidebar.php'; ?>
    </div>

    <main class="flex-1 p-8 overflow-y-auto">
        <header class="no-print flex justify-between items-center mb-10">
            <div>
                <h2 class="text-3xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Barcode Generator</h2>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Select products to print labels</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <!-- Global Verification Alert Bar -->
        <?php include 'alert_bar.php'; ?>

        <!-- Print Settings Section -->
        <div class="no-print bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl mb-12 transition-colors">
            <h3 class="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight mb-6">Print Settings</h3>
            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Printer Type</label>
                    <select id="printer-type" onchange="handleTypeChange()" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                        <option value="">Select Type</option>
                        <?php foreach($printer_types as $t): ?>
                            <option value="<?= $t['id'] ?>" data-fixed="<?= $t['has_fixed_size'] ?>"><?= $t['name'] ?></option>
                        <?php endforeach; ?>
                        <option value="custom">Custom Size</option>
                    </select>
                </div>
                <div id="size-dropdown-container" class="hidden">
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Select Size</label>
                    <select id="printer-size" onchange="handleSizeChange()" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </select>
                </div>
                <div id="custom-dims" class="hidden grid grid-cols-2 gap-2">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Width (mm)</label>
                        <input type="number" id="custom-width" value="80" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest">Height (mm)</label>
                        <input type="number" id="custom-height" value="50" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>
                </div>
            </div>
            <div class="mt-6 border-t border-slate-100 dark:border-neutral-800 pt-6">
                <label class="block text-[10px] font-black uppercase text-slate-500 mb-4 tracking-widest">Label Content</label>
                <div class="flex flex-wrap gap-6">
                    <label class="flex items-center gap-2 cursor-pointer group">
                        <input type="checkbox" id="include-name" checked class="w-5 h-5 accent-orange-600 rounded transition-all">
                        <span class="text-sm font-bold text-slate-600 dark:text-neutral-400 group-hover:text-orange-500 transition-colors">Product Name</span>
                    </label>
                    <label class="flex items-center gap-2 cursor-pointer group">
                        <input type="checkbox" id="include-price" checked class="w-5 h-5 accent-orange-600 rounded transition-all">
                        <span class="text-sm font-bold text-slate-600 dark:text-neutral-400 group-hover:text-orange-500 transition-colors">Price</span>
                    </label>
                    <label class="flex items-center gap-2 cursor-pointer group">
                        <input type="checkbox" id="include-biz" class="w-5 h-5 accent-orange-600 rounded transition-all">
                        <span class="text-sm font-bold text-slate-600 dark:text-neutral-400 group-hover:text-orange-500 transition-colors">Business Name</span>
                    </label>
                </div>
            </div>
        </div>

        <!-- Search Bar Section -->
        <div class="no-print relative mb-8 mt-12">
            <div class="relative group">
                <i data-lucide="search" class="absolute left-5 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-orange-500 transition-colors"></i>
                <input type="text" id="product-search" placeholder="Search product by name or SKU..." 
                    class="w-full pl-14 pr-6 py-5 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-[32px] shadow-sm outline-none focus:border-orange-500 dark:text-white text-lg transition-all"
                    autocomplete="off">
            </div>
            
            <!-- Search Results Dropdown -->
            <div id="search-results" class="hidden absolute top-full left-0 right-0 mt-2 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-2xl max-h-80 overflow-y-auto search-results">
            </div>
        </div>

        <!-- Selection Table -->
        <div class="no-print bg-white dark:bg-neutral-950 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead>
                    <tr class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-100 dark:border-neutral-800">
                        <th class="px-8 py-6 text-[10px] font-black uppercase text-slate-400 tracking-widest">Product Name</th>
                        <th class="px-8 py-6 text-[10px] font-black uppercase text-slate-400 tracking-widest">SKU</th>
                        <th class="px-8 py-6 text-[10px] font-black uppercase text-slate-400 tracking-widest text-center">Available Stock</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-400 text-center">Qty to Print</th>
                        <th class="px-8 py-6 text-[10px] font-black uppercase text-slate-400 tracking-widest text-right">Action</th>
                    </tr>
                </thead>
                <tbody id="selected-products-body" class="divide-y divide-slate-50 dark:divide-neutral-900">
                    <tr id="empty-state">
                        <td colspan="5" class="px-8 py-20 text-center text-slate-400 uppercase font-black text-xs tracking-widest opacity-30">No products selected</td>
                    </tr>
                </tbody>
            </table>
            
            <div id="table-footer" class="hidden p-8 bg-slate-50 dark:bg-neutral-900/50 flex justify-end gap-4 border-t border-slate-100 dark:border-neutral-800">
                <button onclick="clearAll()" class="px-6 py-4 text-xs font-black uppercase text-slate-400 hover:text-rose-500 transition-colors">Clear All</button>
                <button onclick="generateBarcodes()" class="px-10 py-4 bg-orange-600 hover:bg-orange-700 text-white font-black rounded-2xl shadow-lg shadow-orange-600/20 transition-all active:scale-95 text-xs uppercase tracking-widest flex items-center gap-2">
                    <i data-lucide="printer" size="16"></i> Print Labels
                </button>
            </div>
        </div>
    </main>

    <script>
        let selectedProducts = [];
        const currencySymbol = '<?= $currency_symbol ?>';
        const searchInput = document.getElementById('product-search');
        const resultsBox = document.getElementById('search-results');
        const tableBody = document.getElementById('selected-products-body');
        const emptyState = document.getElementById('empty-state');
        const tableFooter = document.getElementById('table-footer');

        let searchTimeout;
        searchInput.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            const query = e.target.value.trim(); // Allow empty query or single character search

            searchTimeout = setTimeout(async () => {
                try {
                    const res = await fetch(`api.php?route=products/search&q=${encodeURIComponent(query)}`);
                    const products = await res.json();
                    
                    if (products.length > 0) {
                        window.currentSearchResults = products; // Store globally for easy access
                        resultsBox.innerHTML = products.map((p, index) => `
                            <div onclick="addByIndex(${index})" class="px-6 py-4 hover:bg-slate-50 dark:hover:bg-neutral-800 cursor-pointer flex justify-between items-center group transition-colors border-b border-slate-50 dark:border-neutral-800 last:border-0">
                                <div>
                                    <p class="font-bold text-slate-900 dark:text-white group-hover:text-orange-500 transition-colors">${p.name}</p>
                                    <p class="text-[10px] text-slate-400 font-mono uppercase">${p.sku || 'No SKU'}</p>
                                </div>
                                <div class="text-right"><p class="text-xs font-black text-slate-500">${p.stock_level} in stock</p></div>
                            </div>
                        `).join('');
                        resultsBox.classList.remove('hidden');
                    } else {
                        resultsBox.innerHTML = '<div class="px-6 py-8 text-center text-slate-400 text-xs font-bold uppercase tracking-widest">No products found</div>';
                        resultsBox.classList.remove('hidden');
                    }
                } catch (err) { console.error(err); }
            }, 300);
        });

        function addByIndex(index) {
            if (window.currentSearchResults && window.currentSearchResults[index]) {
                addProduct(window.currentSearchResults[index]);
            }
        }

        document.addEventListener('click', (e) => {
            if (!searchInput.contains(e.target) && !resultsBox.contains(e.target)) resultsBox.classList.add('hidden');
        });

        function addProduct(product) {
            const exists = selectedProducts.find(p => p.id === product.id);
            if (exists) { exists.printQty++; } 
            else {
                selectedProducts.push({
                    id: product.id, name: product.name, sku: product.sku,
                    stock: product.stock_level, price: product.price, printQty: 1
                });
            }
            searchInput.value = '';
            resultsBox.classList.add('hidden');
            renderTable();
        }

        function removeProduct(id) {
            selectedProducts = selectedProducts.filter(p => p.id !== id);
            renderTable();
        }

        function updateQty(id, qty) {
            const product = selectedProducts.find(p => p.id === id);
            if (product) product.printQty = parseInt(qty) || 0;
        }

        function clearAll() {
            if (confirm("Remove all selected products?")) { selectedProducts = []; renderTable(); }
        }

        async function handleTypeChange() {
            const typeSelect = document.getElementById('printer-type');
            const selectedOption = typeSelect.options[typeSelect.selectedIndex];
            const sizeContainer = document.getElementById('size-dropdown-container');
            const sizeSelect = document.getElementById('printer-size');
            const customContainer = document.getElementById('custom-dims');
            
            // Reset view
            sizeContainer.classList.add('hidden');
            customContainer.classList.add('hidden');
            window.fixedPrinterConfig = null;

            if (!typeSelect.value) {
                return;
            }

            if (typeSelect.value === 'custom') {
                customContainer.classList.remove('hidden');
                return;
            }

            const isFixed = selectedOption.getAttribute('data-fixed') === '1';
            
            // Fetch sizes for this type
            const response = await fetch(`get_printer_sizes.php?type_id=${typeSelect.value}`);
            const sizes = await response.json();

            if (isFixed) {
                // If fixed, we pick the first available size config automatically and don't show dropdown
                if (sizes.length > 0) {
                    window.fixedPrinterConfig = sizes[0]; 
                    console.log("Fixed config loaded:", window.fixedPrinterConfig);
                }
            } else {
                // If not fixed (multiple sizes), show the dropdown
                sizeContainer.classList.remove('hidden');
                sizeSelect.innerHTML = '<option value="">-- Choose Size --</option>' + 
                    sizes.map(s => `
                        <option value="${s.id}" data-w="${s.width_mm}" data-h="${s.height_mm}" data-cols="${s.labels_per_row}">
                            ${s.name}
                        </option>`).join('');
            }
        }

        function handleSizeChange() {
            // Size specific logic if needed
        }

        function generateBarcodes() {
            if (selectedProducts.length === 0) return alert("Please select at least one product to print.");

            const typeSelect = document.getElementById('printer-type');
            const sizeSelect = document.getElementById('printer-size');
            const typeOpt = typeSelect.options[typeSelect.selectedIndex];
            const isFixedType = typeOpt.getAttribute('data-fixed') === '1';
            
            let width, height, cols = 1;
            
            if (typeSelect.value === 'custom') {
                width = parseFloat(document.getElementById('custom-width').value);
                height = parseFloat(document.getElementById('custom-height').value);
                cols = 1;
            } else if (isFixedType) {
                // Pick from auto-loaded fixed config
                if (!window.fixedPrinterConfig) return alert("Configuration not found for this fixed printer.");
                width = window.fixedPrinterConfig.width_mm;
                height = window.fixedPrinterConfig.height_mm;
                cols = parseInt(window.fixedPrinterConfig.labels_per_row) || 1;
            } else {
                // Pick from selected size dropdown
                const opt = sizeSelect.options[sizeSelect.selectedIndex];
                if (!opt || !opt.value) return alert("Please select a printer size.");
                width = parseFloat(opt.getAttribute('data-w'));
                height = parseFloat(opt.getAttribute('data-h'));
                cols = parseInt(opt.getAttribute('data-cols')) || 1;
            }

            // Final Validation
            if (!width || !height) return alert("Invalid printer dimensions.");
            const isGrid = cols > 1;

            const incName = document.getElementById('include-name').checked;
            const incPrice = document.getElementById('include-price').checked;
            const incBiz = document.getElementById('include-biz').checked;
            const bizName = <?= json_encode($_SESSION['business_name'] ?? 'Biltax') ?>;
            
            let printArea = document.getElementById('barcode-print-area');
            
            // Safety check: if div is missing, create it
            if (!printArea) {
                printArea = document.createElement('div');
                printArea.id = 'barcode-print-area';
                document.body.appendChild(printArea);
            }

            // Dynamic Styling Logic based on Printer Type
            let pageStyle = '';
            if (isGrid || isFixedType) {
                // Grid Layout for A4 or Multi-column sheets
                pageStyle = `
                    @page { size: ${width}mm ${height}mm; margin: 0; }
                    #barcode-print-area { width: ${width}mm; margin: 0 auto; display: grid !important; grid-template-columns: repeat(${cols}, 1fr) !important; gap: 1mm; /* Small gap between labels */ }
                    .label-item { border: 0.1mm solid #eee; height: auto; min-height: 20mm; page-break-inside: avoid; display: flex !important; flex-direction: column !important; justify-content: center !important; align-items: center !important; text-align: center !important; }
                `;
                printArea.className = 'label-grid';
            } else {
                // Single Column / Thermal Roll Logic
                pageStyle = `
                    @page { size: ${width}mm ${height}mm; margin: 0; }
                    html, body { margin: 0 !important; padding: 0 !important; }
                    #barcode-print-area { width: 100% !important; margin: 0 !important; padding: 0 !important; display: flex !important; flex-direction: column !important; align-items: center !important; }
                    .label-item { width: ${width}mm !important; height: ${height}mm !important; page-break-after: always !important; border: none !important; margin: 0 auto !important; padding: 1mm !important; display: flex !important; flex-direction: column !important; justify-content: center !important; align-items: center !important; text-align: center !important; box-sizing: border-box !important; }
                `;
                printArea.className = 'label-continuous';
            }

            document.getElementById('dynamic-print-style').innerHTML = `<style media="print">${pageStyle}</style>`;

            printArea.innerHTML = '';

            selectedProducts.forEach((product, pIndex) => {
                for (let i = 0; i < product.printQty; i++) {
                    const label = document.createElement('div');
                    label.className = 'label-item';
                    
                    if (incBiz) {
                        const bizDiv = document.createElement('div');
                        bizDiv.className = 'label-biz';
                        bizDiv.innerText = bizName;
                        label.appendChild(bizDiv);
                    }
                    if (incName) {
                        const nameDiv = document.createElement('div');
                        nameDiv.className = 'label-name';
                        nameDiv.innerText = product.name;
                        label.appendChild(nameDiv);
                    }
                    
                    const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
                    label.appendChild(svg);
                    
                    if (incPrice) {
                        const priceDiv = document.createElement('div');
                        priceDiv.className = 'label-price';
                        priceDiv.innerText = `${currencySymbol}${parseFloat(product.price).toFixed(2)}`;
                        label.appendChild(priceDiv);
                    }
                    
                    printArea.appendChild(label);

                    // Generate Barcode Synchronously
                    JsBarcode(svg, product.sku || '000000', {
                        format: "CODE128",
                        width: 1.5,
                        height: 40,
                        displayValue: true,
                        fontSize: 10,
                        margin: 0
                    });
                }
            });

            // Call print after a tiny delay to allow browser to calculate layout
            setTimeout(() => { window.print(); }, 100);
        }

        function renderTable() {
            const rows = tableBody.querySelectorAll('.product-row');
            rows.forEach(r => r.remove());

            if (selectedProducts.length === 0) {
                emptyState.classList.remove('hidden');
                tableFooter.classList.add('hidden');
                return;
            }

            emptyState.classList.add('hidden');
            tableFooter.classList.remove('hidden');

            const dynamicRows = selectedProducts.map(p => `
                <tr class="product-row hover:bg-slate-50/50 dark:hover:bg-neutral-800/30 transition-colors group">
                    <td class="px-8 py-5"><p class="font-bold text-slate-900 dark:text-white">${p.name}</p></td>
                    <td class="px-8 py-5"><p class="text-[10px] font-mono font-black text-slate-400 uppercase tracking-tighter">${p.sku || 'N/A'}</p></td>
                    <td class="px-8 py-5 text-center"><span class="px-3 py-1 bg-slate-100 dark:bg-neutral-900 rounded-full text-[10px] font-black ${p.stock > 10 ? 'text-emerald-500' : 'text-rose-500'}">${p.stock} Units</span></td>
                    <td class="px-8 py-5">
                        <div class="flex justify-center">
                            <input type="number" value="${p.printQty}" onchange="updateQty(${p.id}, this.value)" 
                                class="w-24 px-4 py-2 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl text-center font-black text-orange-600 outline-none focus:border-orange-500 transition-all">
                        </div>
                    </td>
                    <td class="px-8 py-5 text-right">
                        <button onclick="removeProduct(${p.id})" class="p-3 text-slate-300 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/20 rounded-xl transition-all"><i data-lucide="trash-2" size="18"></i></button>
                    </td>
                </tr>
            `).join('');

            tableBody.insertAdjacentHTML('beforeend', dynamicRows);
            lucide.createIcons();
        }
        lucide.createIcons();
    </script>
</body>
</html>