<?php
require_once 'config/db_switch.php';
// Check if user is logged in
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biltax POS</title>
    <!-- Tailwind CSS for styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Lucide Icons for icons -->
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Chart.js for charts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Theme Logic -->
    <script src="theme.js"></script>
    <style>
        /* Custom styles to match the original app */
        body { font-family: 'Inter', system-ui, -apple-system, sans-serif; }
        .animate-in { animation: fadeIn 0.5s; }
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        /* Custom scrollbar for a cleaner look */
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #f1f5f9; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #94a3b8; }
    </style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 font-sans text-slate-900 dark:text-neutral-200 transition-colors duration-300">
    <script>
        // Set initialTab for app.js based on URL parameter
        const urlParams = new URLSearchParams(window.location.search);
        if (urlParams.has('tab')) {
            window.initialTab = urlParams.get('tab');
        }

        // Handle Browser Back/Forward buttons
        window.addEventListener('popstate', function() {
            const params = new URLSearchParams(window.location.search);
            const tab = params.get('tab') || 'dashboard';
            if (typeof setTab === 'function') {
                setTab(tab, false);
            }
        });
    </script>

    <?php
    // Load the appropriate sidebar based on industry type
    $industry_type = $_SESSION['industry_type'] ?? 'retail';
    
    switch ($industry_type) {
        case 'restaurant':
        case 'wholesale':
        case 'service':
        case 'retail':
        default:
            include 'sidebar.php'; 
            break;
    }
    ?>

    <!-- Main Content -->
    <main class="flex-1 p-4 md:p-8 overflow-y-auto w-full">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h2 id="header-title" class="text-3xl font-black text-slate-900 dark:text-white capitalize tracking-tight">Dashboard</h2>
                <p class="text-slate-500 dark:text-neutral-400">Welcome back, here's what's happening today.</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <!-- Global Verification Alert Bar -->
        <?php include 'alert_bar.php'; ?>

        <!-- Dynamic Content Area -->
        <div id="main-content" class="<?= $is_system_inactive ? 'opacity-40 pointer-events-none select-none blur-[1.5px] grayscale' : '' ?>">
            <div class="flex items-center justify-center min-h-[400px]">
                <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-600"></div>
            </div>
        </div>
    </main>

    <!-- Main JavaScript file -->
    <script src="app.js"></script>
</body>
</html>
