<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }
if (!has_module('bulk_sales')) { header("Location: dashboard.php?error=access_denied"); exit; }

$currency = $currency_symbol ?? '$';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Bulk Sales | Wholesale Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Bulk Sales</h1>
                <p class="text-xs text-slate-500 uppercase tracking-widest font-bold mt-1">Wholesale Order Processing</p>
            </div>
            <div class="flex items-center gap-3">
                <?php include 'topbar.php'; ?>
            </div>
        </header>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
            <!-- Left: Customer -->
            <div class="lg:col-span-1">
                <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm h-full">
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Customer Selection</label>
                    <select id="customerSelect" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold focus:border-orange-500">
                        <option value="0">Walk-in Customer</option>
                    </select>
                </div>
            </div>

            <!-- Right: Bulk Cart -->
            <div class="lg:col-span-2">
                <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
                    <div class="p-6 border-b border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                        <h2 class="text-xl font-black dark:text-white uppercase">Order Items</h2>
                        <span id="itemCount" class="text-[10px] px-3 py-1 bg-orange-500/10 text-orange-600 rounded-full font-black">0 ITEMS</span>
                    </div>
                    
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                <tr>
                                    <th class="px-6 py-4">Product</th>
                                    <th class="px-6 py-4 text-center">Quantity</th>
                                    <th class="px-6 py-4 text-right">Price</th>
                                    <th class="px-6 py-4 text-right">Total</th>
                                    <th class="px-6 py-4"></th>
                                </tr>
                            </thead>
                            <tbody id="cartBody" class="divide-y divide-slate-100 dark:divide-neutral-800">
                                <tr><td colspan="5" class="p-10 text-center text-slate-400 italic">Select products to start bulk order.</td></tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="p-8 bg-slate-50 dark:bg-neutral-950 border-t border-slate-100 dark:border-neutral-800">
                        <div class="flex justify-between items-center mb-2">
                            <span class="text-xs font-bold text-slate-400 uppercase tracking-widest">Subtotal</span>
                            <span id="subTotal" class="text-lg font-bold text-slate-600 dark:text-slate-400"><?= $currency ?>0.00</span>
                        </div>
                        <div class="flex justify-between items-center mb-6">
                            <div class="flex flex-col">
                                <span class="text-xs font-bold text-slate-400 uppercase tracking-widest">Discount</span>
                                <p class="text-[9px] text-orange-500 font-bold uppercase">Limit: <?= ($discount_limit_type == 'percentage' ? $max_discount_limit.'%' : $currency.$max_discount_limit) ?></p>
                            </div>
                            <div class="flex items-center gap-2">
                                <span class="text-slate-400 font-bold">-</span>
                                <input type="number" id="discountInput" oninput="updateUI()" value="0" step="0.01" class="w-24 px-3 py-1 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none focus:border-orange-500 dark:text-white text-right font-bold">
                            </div>
                        </div>
                        <div class="flex justify-between items-center mb-6">
                            <span class="text-sm font-bold text-slate-500 uppercase tracking-widest">Grand Total</span>
                            <span id="grandTotal" class="text-4xl font-black text-slate-900 dark:text-white"><?= $currency ?>0.00</span>
                        </div>
                        <button onclick="processCheckout()" class="w-full py-5 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:bg-orange-700 transition-all flex items-center justify-center gap-2">
                            <i data-lucide="check-circle"></i> Finalize Bulk Sale
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Search Products (Now at the bottom) -->
        <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm">
            <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Search Products</label>
            <div class="relative">
                <i data-lucide="search" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                <input type="text" id="pSearch" onkeyup="filterDisplayedProducts(this.value)" placeholder="Enter Name or SKU..." class="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm">
            </div>
            <div id="resList" class="mt-4 space-y-2 max-h-96 overflow-y-auto custom-scrollbar grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"></div>
        </div>
    </main>

    <script>
        lucide.createIcons();
        let cart = [];
        const currency = '<?= $currency ?>';
        let allProducts = []; // To store all fetched products
        let filteredProducts = []; // To store currently filtered products for display

        // Settings from PHP (Enforced by Admin)
        const discountLimitValue = <?= (float)($max_discount_limit ?? 100) ?>;
        const discountLimitType = '<?= $discount_limit_type ?? 'percentage' ?>';

        // Function to fetch customers and vendors for the selection dropdown
        async function fetchParties() {
            try {
                const res = await fetch('api.php?route=customers');
                const data = await res.json();
                const select = document.getElementById('customerSelect');
                
                data.forEach(p => {
                    const opt = document.createElement('option');
                    opt.value = `${p.party_type}:${p.id}`;
                    opt.textContent = `${p.name} (${p.party_type.charAt(0).toUpperCase() + p.party_type.slice(1)})`;
                    select.appendChild(opt);
                });
            } catch (e) { console.error("Error loading parties:", e); }
        }

        // Function to render products into the search results list
        function renderProductList(productsToRender) {
            const container = document.getElementById('resList');
            container.innerHTML = productsToRender.map(p => `
                <div onclick='addToCart(${JSON.stringify(p)})' class="p-3 bg-slate-100 dark:bg-neutral-800 hover:bg-orange-500/10 rounded-xl cursor-pointer border border-slate-200 dark:border-neutral-700 flex justify-between items-center group transition-all">
                    <div>
                        <div class="font-bold text-sm dark:text-white group-hover:text-orange-600">${p.name}</div>
                        <div class="text-[10px] text-slate-500">Stock: ${p.stock_level} | SKU: ${p.sku || 'N/A'}</div>
                    </div>
                    <div class="text-orange-600 font-black text-sm">${currency}${p.price}</div>
                </div>
            `).join('');
            lucide.createIcons(); // Re-render Lucide icons for new elements
        }

        function addToCart(p) {
            const existing = cart.find(item => item.id === p.id);
            if(existing) existing.qty++;
            else cart.push({ id: p.id, name: p.name, price: p.price, qty: 1 });
            updateUI();
        }

        function updateUI() {
            const body = document.getElementById('cartBody');
            if(cart.length === 0) {
                body.innerHTML = '<tr><td colspan="5" class="p-10 text-center text-slate-400 italic">Select products to start bulk order.</td></tr>';
            } else {
                body.innerHTML = cart.map((item, index) => `
                    <tr class="dark:text-white text-sm">
                        <td class="px-6 py-4 font-bold">${item.name}</td>
                        <td class="px-6 py-4 text-center">
                            <input type="number" onchange="updateQty(${index}, this.value)" value="${item.qty}" class="w-20 px-2 py-1 bg-slate-100 dark:bg-neutral-800 rounded-lg text-center border-none focus:ring-1 focus:ring-orange-500 outline-none">
                        </td>
                        <td class="px-6 py-4 text-right font-mono">${currency}${item.price}</td>
                        <td class="px-6 py-4 text-right font-black text-orange-600 font-mono">${currency}${(item.qty * item.price).toFixed(2)}</td>
                        <td class="px-6 py-4 text-right">
                            <button onclick="removeItem(${index})" class="text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 p-2 rounded-lg transition-colors"><i data-lucide="trash-2" size="16"></i></button>
                        </td>
                    </tr>
                `).join('');
            }
            
            const subtotal = cart.reduce((sum, item) => sum + (item.qty * item.price), 0);
            let discount = parseFloat(document.getElementById('discountInput').value) || 0;

            // Enforce limit based on settings
            if (discountLimitType === 'disabled') {
                // No limit applied, proceed with raw input value
            } else if (discountLimitType === 'percentage') {
                const maxAllowed = (subtotal * discountLimitValue) / 100;
                if (discount > maxAllowed) {
                    discount = maxAllowed;
                    document.getElementById('discountInput').value = maxAllowed.toFixed(2);
                }
            } else if (discount > discountLimitValue) {
                discount = discountLimitValue;
                document.getElementById('discountInput').value = discountLimitValue.toFixed(2);
            }
            
            document.getElementById('subTotal').innerText = currency + subtotal.toFixed(2);
            document.getElementById('grandTotal').innerText = currency + (subtotal - discount).toFixed(2);
            document.getElementById('itemCount').innerText = cart.length + ' ITEMS';
            lucide.createIcons();
        }

        function updateQty(index, val) {
            if(val < 1) val = 1;
            cart[index].qty = parseInt(val);
            updateUI();
        }

        function removeItem(index) {
            cart.splice(index, 1);
            updateUI();
        }

        // Function to fetch all products for the current branch
        async function fetchAllProducts() {
            const res = await fetch(`api.php?route=products/search`); // No 'q' parameter to get all
            const data = await res.json();
            allProducts = data;
            filteredProducts = data; // Initially, all products are displayed
            renderProductList(filteredProducts);
        }

        // Function to filter products based on search query (client-side)
        function filterDisplayedProducts(q) {
            const query = q.toLowerCase();
            filteredProducts = allProducts.filter(p => p.name.toLowerCase().includes(query) || (p.sku && p.sku.toLowerCase().includes(query)));
            renderProductList(filteredProducts);
        }

        async function processCheckout() {
            if(cart.length === 0) return alert("Cart is empty!");
            if(!confirm("Are you sure you want to finalize this bulk sale?")) return;

            const subtotal = cart.reduce((sum, item) => sum + (item.qty * item.price), 0);
            const discount = parseFloat(document.getElementById('discountInput').value) || 0;
            const total = subtotal - discount;
            const customerId = document.getElementById('customerSelect').value;

            const res = await fetch('api.php?route=bulk_sales/checkout', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customer_id: customerId,
                    items: cart,
                    discount_amount: discount,
                    total_amount: total,
                    payment_method: 'Bulk Invoice'
                })
            });

            const data = await res.json();
            if(data.success) {
                alert(data.message);
                window.location.reload();
            } else {
                alert("Error: " + data.message);
            }
        }

        // Initial load of all products when the page is ready
        document.addEventListener('DOMContentLoaded', () => {
            fetchAllProducts();
            fetchParties();
        });
    </script>
</body>
</html>