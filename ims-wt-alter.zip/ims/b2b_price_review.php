<?php
require_once 'config/db_switch.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

$order_id = $_GET['order_id'];
$type = $_GET['type'] ?? 'partner';
$industry = strtolower($_SESSION['industry_type'] ?? 'retail');

$active_branch = $_SESSION['active_branch_id'] ?? null;
$target_branch = get_active_stock_branch_id($active_branch);
$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);

if ($type === 'manual') {
    // Fetch Manual Purchase Items from Tenant DB
    $stmt = $tenant_conn->prepare("SELECT pi.id, pi.product_id as subscriber_item_id, pi.quantity, pi.purchase_price as price, s.name as supplier, p.status 
                                  FROM purchase_items pi 
                                  JOIN purchases p ON pi.purchase_id = p.id 
                                  LEFT JOIN suppliers s ON p.supplier_id = s.id 
                                  WHERE pi.purchase_id = ?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Fetch B2B Order Items & Wholesaler Info from Main DB
    $stmt = $main_pdo->prepare("SELECT oi.*, t.business_name as supplier, t.id as supplier_tenant_id, o.status FROM b2b_order_items oi JOIN b2b_orders o ON oi.order_id = o.id JOIN tenants t ON o.receiver_tenant_id = t.id WHERE oi.order_id = ?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

if (empty($items)) die("No items found for this order.");

if ($items[0]['status'] === 'disputed') {
    die("<div style='background:#fef2f2; color:#ef4444; padding:20px; border-radius:12px; font-family:sans-serif; border:1px solid #fee2e2;'><b>⚠️ Dispute Active:</b> This order cannot be finalized while a dispute is open. Contact the supplier to resolve. <br><br><a href='view_order_details.php?id=$order_id' style='color:#ef4444; font-weight:bold;'>Back to Details</a></div>");
}

$error_msg = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Ensure Ledger Table Exists (Self-healing) - MUST BE OUTSIDE TRANSACTION
        // Because DDL statements (like CREATE TABLE) cause implicit commits in MySQL
        $tenant_conn->exec("CREATE TABLE IF NOT EXISTS ledgers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            branch_id INT,
            party_name VARCHAR(255),
            party_type ENUM('customer', 'supplier') DEFAULT 'supplier',
            description TEXT,
            debit DECIMAL(15,2) DEFAULT 0,
            credit DECIMAL(15,2) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )");

        // Self-healing columns for existing tables
        try { $tenant_conn->exec("ALTER TABLE ledgers ADD COLUMN branch_id INT AFTER id"); } catch(Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE ledgers ADD COLUMN party_type ENUM('customer', 'supplier') DEFAULT 'supplier' AFTER party_name"); } catch(Exception $e) {}

        $tenant_conn->beginTransaction();
        $total_order = 0;
        $supplier_name = $items[0]['supplier'];

        foreach ($items as $index => $item) {
            if (!isset($_POST['prices'][$index])) continue;
            
            $new_price = $_POST['prices'][$index];
            $cost = $item['price'];
            $qty = $item['quantity'];
            $sub_item_id = $item['subscriber_item_id'];

            // Update Product: Price Only (Stock already updated on receipt)
            if ($industry === 'restaurant') {
                $stmt = $tenant_conn->prepare("UPDATE products SET price = ?, updated_at = NOW() WHERE id = ? AND branch_id = ?");
                $stmt->execute([$new_price, $sub_item_id, $target_branch]);
            } else {
                $stmt = $tenant_conn->prepare("UPDATE products SET sale_price = ?, purchase_price = ? WHERE id = ? AND branch_id = ?");
                $stmt->execute([$new_price, $cost, $sub_item_id, $target_branch]);
            }
            $total_order += ($cost * $qty);
        }

        // Create Ledger Entry (Accounts Payable)
        // Ensuring the supplier exists in local db or creating a generic one
        $description = ($type === 'manual' ? "Manual Purchase #$order_id" : "B2B Order #$order_id");
        $tenant_conn->prepare("INSERT INTO ledgers (branch_id, party_name, party_type, description, credit) VALUES (?, ?, 'supplier', ?, ?)")
                    ->execute([$target_branch, $supplier_name, $description, $total_order]);

        if ($type === 'manual') {
            $tenant_conn->prepare("UPDATE purchases SET status = 'finalized' WHERE id = ?")->execute([$order_id]);
        } else {
            $main_pdo->prepare("UPDATE b2b_orders SET status = 'finalized' WHERE id = ?")->execute([$order_id]);
        }
        $tenant_conn->commit();
        
        header("Location: " . ($type === 'manual' ? "purchase_management.php" : "b2b_orders.php"));
        exit;
    } catch (Exception $e) {
        if ($tenant_conn->inTransaction()) $tenant_conn->rollBack();
        $error_msg = "Error finalizing order: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head><script src="https://cdn.tailwindcss.com"></script><script src="theme.js"></script></head>
<body class="bg-neutral-50 dark:bg-neutral-950 p-12">
    <div class="max-w-4xl mx-auto bg-white dark:bg-neutral-900 p-8 rounded-3xl shadow-2xl">
        <?php if ($error_msg): ?>
            <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-2xl text-sm font-bold flex items-center gap-2">
                <i data-lucide="alert-circle" size="18"></i>
                <?= htmlspecialchars($error_msg) ?>
            </div>
        <?php endif; ?>
        <h1 class="text-2xl font-black dark:text-white mb-2 uppercase">Price & Stock Review</h1>
        <p class="text-xs text-slate-500 mb-8 tracking-widest">Review your new selling prices before finalizing stock update.</p>
        
        <form method="POST">
            <table class="w-full text-left mb-8">
                <thead class="text-[10px] uppercase text-slate-400 font-black border-b border-slate-100 dark:border-neutral-800">
                    <tr>
                        <th class="py-3">Product</th>
                        <th class="py-3">Unit Cost</th>
                        <th class="py-3">Quantity</th>
                        <th class="py-3">New Selling Price</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach($items as $index => $i): 
                        // Industry-aware current price fetching
                        $price_col = ($industry === 'restaurant') ? 'price' : 'sale_price';
                        $p = $tenant_conn->prepare("SELECT name, $price_col as current_price, is_raw FROM products WHERE id = ?");
                        $p->execute([$i['subscriber_item_id']]);
                        $prod = $p->fetch(PDO::FETCH_ASSOC);

                        $is_raw = (int)($prod['is_raw'] ?? 0);
                        $current_price = (float)($prod['current_price'] ?? 0);
                    ?>
                    <tr>
                        <td class="py-4 font-bold dark:text-white text-sm"><?= htmlspecialchars($prod['name']) ?></td>
                        <td class="py-4 text-sm font-mono text-slate-500">$<?= number_format($i['price'],2) ?></td>
                        <td class="py-4 text-[10px] font-black text-slate-400 uppercase">Current: $<?= number_format($current_price, 2) ?></td>
                        <td class="py-4 text-sm font-bold"><?= $i['quantity'] ?></td>
                        <td class="py-4">
                            <?php if ($industry === 'restaurant' && $is_raw === 1): ?>
                                <input type="hidden" name="prices[]" value="<?= $i['price'] ?>">
                                <span class="text-[10px] font-black text-slate-400 bg-slate-100 dark:bg-neutral-800 px-3 py-2 rounded-xl uppercase tracking-widest">N/A (Ingredient)</span>
                            <?php else: ?>
                                <input type="number" step="0.01" name="prices[]" value="<?= $i['price'] * 1.2 ?>" 
                                    class="w-24 px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-700 rounded-xl outline-none focus:border-orange-500 dark:text-white text-sm">
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <button type="submit" class="w-full bg-emerald-600 text-white font-black py-4 rounded-2xl shadow-xl hover:bg-emerald-700 transition-all uppercase tracking-widest">Approve & Finalize Inventory</button>
        </form>
    </div>
</body>
</html>