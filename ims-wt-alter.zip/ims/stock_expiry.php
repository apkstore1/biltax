<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

// Page Restriction Logic
if (!has_module('inventory')) { // Assuming inventory module controls this
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$industry = strtolower($_SESSION['industry_type'] ?? 'retail');
$search_query = $_GET['search_query'] ?? '';
$expiry_status_filter = $_GET['expiry_status'] ?? 'all';

$expiring_stock = [];
$active_branch = $_SESSION['active_branch_id'] ?? null;
$stock_branch = get_active_stock_branch_id($active_branch);

// Detect correct stock column (Wholesale uses stock_quantity, Retail uses stock_level)
$stockCol = 'p.stock_level';
try {
    $checkCol = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'stock_quantity'")->fetch();
    if ($checkCol) $stockCol = 'p.stock_quantity';
} catch (Exception $e) {}

try {
    $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
    $main_id = $stmt_main->fetchColumn();

    $where_clauses = ["s.quantity_change >= 0", "s.expiry_date IS NOT NULL"];
    $params = [];

    // Only show expirable products
    $where_clauses[] = "p.is_expirable = 1";

    // Restaurant specific: Only Raw items (Ingredients)
    if ($industry === 'restaurant') {
        $where_clauses[] = "(p.is_raw = 1 OR p.has_stock = 1)";
    }

    if ($search_query) {
        $where_clauses[] = "(p.name LIKE ? OR p.sku LIKE ?)";
        $params[] = "%$search_query%";
        $params[] = "%$search_query%";
    }

    // Branch context logic (allowing NULL for main branch/legacy data)
    if ($stock_branch == $main_id) {
        $where_clauses[] = "(p.branch_id = ? OR p.branch_id IS NULL)";
    } else {
        $where_clauses[] = "p.branch_id = ?";
    }
    $params[] = $stock_branch;

    if ($expiry_status_filter === 'expired') {
        $where_clauses[] = "s.expiry_date < CURDATE()";
    } elseif ($expiry_status_filter === 'expiring_soon') {
        $where_clauses[] = "s.expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
    } elseif ($expiry_status_filter === 'good') {
        $where_clauses[] = "s.expiry_date > DATE_ADD(CURDATE(), INTERVAL 30 DAY)";
    }

    $sql = "SELECT s.id as stock_entry_id, s.quantity_change, s.expiry_date, s.created_at as stock_date,
                   p.name as product_name, p.sku, $stockCol as current_product_stock, p.alert_level
            FROM stock s
            JOIN products p ON s.product_id = p.id
            WHERE " . implode(" AND ", $where_clauses) . "
            ORDER BY s.expiry_date ASC";

    $stmt = $tenant_conn->prepare($sql);
    $stmt->execute($params);
    $expiring_stock = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    error_log("Error fetching expiring stock: " . $e->getMessage());
    // Handle error gracefully, maybe show an empty table or an error message
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stock Expiry | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-950 transition-colors duration-300">
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black dark:text-white tracking-tight uppercase">Stock Expiry</h1>
                <p class="text-sm text-slate-500 dark:text-neutral-400 font-medium">Monitor products nearing their expiration dates.</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <!-- Global Verification Alert Bar -->
        <?php include 'alert_bar.php'; ?>

        <!-- Filter and Search Section -->
        <form method="GET" class="flex flex-col lg:flex-row items-center gap-4 mb-8">
            <div class="relative flex-1 w-full">
                <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                <input type="text" name="search_query" value="<?= htmlspecialchars($search_query) ?>" placeholder="Search product name or SKU..." 
                       class="w-full pl-12 pr-4 py-3 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white transition-all">
            </div>
            
            <select name="expiry_status" onchange="this.form.submit()"
                    class="px-4 py-3 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl text-sm focus:border-orange-500 outline-none transition-colors dark:text-white font-bold w-full lg:w-fit">
                <option value="all" <?= $expiry_status_filter === 'all' ? 'selected' : '' ?>>All Statuses</option>
                <option value="expired" <?= $expiry_status_filter === 'expired' ? 'selected' : '' ?>>Expired</option>
                <option value="expiring_soon" <?= $expiry_status_filter === 'expiring_soon' ? 'selected' : '' ?>>Expiring Soon</option>
                <option value="good" <?= $expiry_status_filter === 'good' ? 'selected' : '' ?>>Good</option>
            </select>

            <button type="submit" class="px-6 py-3 bg-orange-600 text-white font-black rounded-2xl shadow-lg shadow-orange-600/20 hover:scale-105 transition-all text-sm uppercase w-full lg:w-fit">Filter</button>
            <a href="stock_expiry.php" class="px-6 py-3 bg-slate-100 dark:bg-neutral-800 text-slate-500 font-bold rounded-2xl text-sm uppercase w-full lg:w-fit text-center">Reset</a>
        </form>

        <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
            <table class="w-full text-left border-collapse">
                <thead class="bg-slate-50 dark:bg-neutral-900/50 border-b border-slate-200 dark:border-neutral-800">
                    <tr>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Batch #</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Product / SKU</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-center">Batch Qty</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-center">Purchased On</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-center">Expiry Date</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-center">Days Left</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-right">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php if (empty($expiring_stock)): ?>
                        <tr><td colspan="7" class="px-6 py-10 text-center text-slate-400 italic">No expirable stock batches found matching your criteria.</td></tr>
                    <?php else: ?>
                        <?php $batch_number = 1; ?>
                        <?php foreach ($expiring_stock as $item):
                            $expiry_date = new DateTime($item['expiry_date']);
                            $today = new DateTime();
                            $interval = $today->diff($expiry_date);
                            $days_left = (int)$interval->format('%r%a'); // %r for sign (+/-)

                            $status_class = '';
                            $status_text = '';

                            if ($days_left < 0) {
                                $status_class = 'bg-rose-500/10 text-rose-500 border-rose-500/20';
                                $status_text = 'Expired';
                            } elseif ($days_left <= 30) {
                                $status_class = 'bg-orange-500/10 text-orange-500 border-orange-500/20';
                                $status_text = 'Expiring Soon';
                            } else {
                                $status_class = 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20';
                                $status_text = 'Good';
                            }
                        ?>
                        <tr class="transition-colors hover:bg-slate-50 dark:hover:bg-neutral-800/30">
                            <td class="px-6 py-4 text-xs font-black text-orange-600">
                                Batch #<?= $batch_number++ ?>
                            </td>
                            <td class="px-6 py-4">
                                <div class="font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($item['product_name']) ?></div>
                                <div class="text-[10px] font-mono text-slate-400 uppercase tracking-tighter"><?= htmlspecialchars($item['sku']) ?></div>
                            </td>
                            <td class="px-6 py-4 text-center">
                                <span class="inline-block px-3 py-1 rounded-lg font-black text-sm text-slate-700 dark:text-slate-300">
                                    <?= $item['quantity_change'] ?>
                                </span>
                            </td>
                            <td class="px-6 py-4 text-center text-sm text-slate-500">
                                <?= date('M d, Y', strtotime($item['stock_date'])) ?>
                            </td>
                            <td class="px-6 py-4 text-center text-sm text-slate-600 dark:text-slate-400">
                                <?= date('M d, Y', strtotime($item['expiry_date'])) ?>
                            </td>
                            <td class="px-6 py-4 text-center text-sm font-bold <?= $days_left < 0 ? 'text-rose-500' : ($days_left <= 30 ? 'text-orange-500' : 'text-emerald-500') ?>">
                                <?= $days_left < 0 ? abs($days_left) . ' days ago' : $days_left . ' days' ?>
                            </td>
                            <td class="px-6 py-4 text-right">
                                <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold <?= $status_class ?>">
                                    <?= $status_text ?>
                                </span>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>