<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

// Module Restriction
if (!has_module('biltax_hub')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$my_tenant_id = $_SESSION['tenant_id'];
$search_query = $_GET['q'] ?? '';
$industry_filter = $_GET['industry'] ?? '';
$verified_filter = $_GET['verified'] ?? '';

// Fetch Listed Partners from Main DB
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    
    // Base Query: Only show those who opted-in (marketplace_listing_visibility = 1) and are active
    // Also exclude current user
    $sql = "SELECT id, business_name, owner_name, email, phone, address, industry_type, is_verified, is_featured 
            FROM tenants 
            WHERE marketplace_listing_visibility = 1 AND status = 'active' AND id != ?";
    $params = [$my_tenant_id];

    if (!empty($search_query)) {
        $sql .= " AND business_name LIKE ?";
        $params[] = "%$search_query%";
    }

    if (!empty($industry_filter)) {
        $sql .= " AND industry_type = ?";
        $params[] = $industry_filter;
    }

    if ($verified_filter !== '') {
        $sql .= " AND is_verified = ?";
        $params[] = (int)$verified_filter;
    }

    // Order: Featured first, then Oldest to Newest (id ASC)
    $sql .= " ORDER BY is_featured DESC, id ASC";
    $stmt = $main_pdo->prepare($sql);
    $stmt->execute($params);
    $partners = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch unique industries for filter dropdown
    $industries = $main_pdo->query("SELECT DISTINCT industry_type FROM tenants WHERE marketplace_listing_visibility = 1")->fetchAll(PDO::FETCH_COLUMN);

} catch (Exception $e) {
    $partners = [];
    $error_msg = "Marketplace connectivity issue.";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Marketplace | Biltax Hub</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 min-h-screen transition-colors duration-300 flex">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Marketplace</h1>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Explore and connect with global partners</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <!-- Search & Filter Bar -->
        <form method="GET" class="no-print bg-white dark:bg-neutral-950 p-4 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm mb-10 flex flex-wrap items-center gap-4">
            <div class="flex-1 relative">
                <i data-lucide="search" size="18" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"></i>
                <input type="text" name="q" value="<?= htmlspecialchars($search_query) ?>" placeholder="Search businesses..." 
                    class="w-full pl-12 pr-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white transition-all">
            </div>

            <select name="industry" onchange="this.form.submit()" class="px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl text-sm font-bold outline-none dark:text-white">
                <option value="">All Categories</option>
                <?php foreach($industries as $ind): ?>
                    <option value="<?= $ind ?>" <?= $industry_filter === $ind ? 'selected' : '' ?>><?= ucfirst($ind) ?></option>
                <?php endforeach; ?>
            </select>

            <select name="verified" onchange="this.form.submit()" class="px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl text-sm font-bold outline-none dark:text-white">
                <option value="">All Types</option>
                <option value="1" <?= $verified_filter === '1' ? 'selected' : '' ?>>Trusted Only</option>
                <option value="0" <?= $verified_filter === '0' ? 'selected' : '' ?>>Normal Only</option>
            </select>

            <button type="submit" class="px-8 py-3 bg-orange-600 text-white font-black rounded-2xl shadow-lg shadow-orange-600/20 hover:scale-105 transition-all text-sm uppercase">Find Partners</button>
        </form>

        <!-- Marketplace Grid -->
        <?php if (empty($partners)): ?>
            <div class="bg-white dark:bg-neutral-900 rounded-[32px] border border-slate-200 dark:border-neutral-800 p-20 text-center">
                <div class="w-20 h-20 bg-slate-500/10 text-slate-500 rounded-full flex items-center justify-center mx-auto mb-6"><i data-lucide="search-x" size="40"></i></div>
                <h2 class="text-xl font-black dark:text-white uppercase">No Partners Found</h2>
                <p class="text-slate-500 text-sm mt-2">Try adjusting your filters or search terms.</p>
            </div>
        <?php else: ?>
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
                <?php foreach($partners as $p): ?>
                    <a href="marketplace_userview.php?id=<?= $p['id'] ?>" class="bg-white dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm hover:shadow-xl transition-all group overflow-hidden flex flex-col">
                        <!-- Shop Image Placeholder (OLX Style) -->
                        <div class="aspect-video bg-slate-100 dark:bg-neutral-800 relative flex items-center justify-center overflow-hidden border-b border-slate-100 dark:border-neutral-800">
                            <i data-lucide="store" size="40" class="text-slate-300 dark:text-neutral-700 group-hover:scale-110 transition-transform"></i>
                            <!-- Top Left Badge for Industry -->
                            <div class="absolute top-3 left-3 px-2 py-1 bg-white/90 dark:bg-neutral-950/90 backdrop-blur-sm rounded-lg text-[9px] font-black uppercase text-orange-600 border border-orange-500/20">
                                <?= htmlspecialchars($p['industry_type']) ?>
                            </div>
                            <?php if ($p['is_featured']): ?>
                                <div class="absolute top-3 right-3 px-2 py-1 bg-orange-600 text-white rounded-lg text-[8px] font-black uppercase flex items-center gap-1 shadow-lg animate-pulse">
                                    <i data-lucide="zap" size="10"></i> Featured
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- Card Body -->
                        <div class="p-4 flex-1 flex flex-col">
                            <!-- Business Name -->
                            <h3 class="text-base font-black text-slate-900 dark:text-white line-clamp-1 group-hover:text-orange-600 transition-colors mb-1">
                                <?= htmlspecialchars($p['business_name']) ?>
                                <?php if ($p['is_verified']): ?>
                                    <i data-lucide="badge-check" class="inline-block text-blue-500 ml-1" size="16"></i>
                                <?php endif; ?>
                            </h3>

                            <!-- Person Name -->
                            <p class="text-xs text-slate-500 dark:text-neutral-400 font-bold uppercase tracking-tight flex items-center gap-1.5 mb-3">
                                <i data-lucide="user" size="12" class="text-slate-400"></i> <?= htmlspecialchars($p['owner_name']) ?>
                            </p>

                            <!-- Address & Action (Sticky Bottom) -->
                            <div class="mt-auto pt-3 border-t border-slate-50 dark:border-neutral-800 flex items-center justify-between gap-2">
                                <div class="flex items-center gap-1.5 text-[10px] text-slate-400 font-bold uppercase truncate max-w-[120px]">
                                    <i data-lucide="map-pin" size="12" class="text-orange-500 shrink-0"></i> 
                                    <?= htmlspecialchars($p['address'] ?: 'Global') ?>
                                </div>
                                <span class="text-[10px] font-black uppercase text-orange-600 tracking-widest flex items-center gap-1 group-hover:gap-2 transition-all">
                                    Open <i data-lucide="arrow-right" size="12"></i>
                                </span>
                            </div>
                        </div>
                    </a>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>