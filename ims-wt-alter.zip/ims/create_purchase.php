<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
$my_id = $_SESSION['tenant_id'];

// 1. Fetch Local Suppliers
$local_suppliers = [];
try { $local_suppliers = $tenant_conn->query("SELECT id, name FROM suppliers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC); } catch(Exception $e) {}

// 2. Fetch B2B Partners
$stmt = $main_pdo->prepare("SELECT t.id, t.business_name FROM tenant_connections c JOIN tenants t ON (c.sender_id = t.id OR c.receiver_id = t.id) WHERE (c.sender_id = ? OR c.receiver_id = ?) AND t.id != ? AND c.status = 'accepted'");
$stmt->execute([$my_id, $my_id, $my_id]);
$b2b_partners = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Filter out B2B partners from Local Suppliers list to avoid duplicates in the manual dropdown group
$b2b_names = array_column($b2b_partners, 'business_name');
$local_suppliers = array_filter($local_suppliers, function($sup) use ($b2b_names) {
    return !in_array($sup['name'], $b2b_names);
});

// --- Handle Manual Purchase Submission ---
$input = json_decode(file_get_contents('php://input'), true);
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($input['action']) && $input['action'] === 'save_manual_purchase') {
    ob_start();
    header('Content-Type: application/json');
    try {
        $active_branch = $_SESSION['active_branch_id'] ?? null;
        
        // Resolve Target Branch: If 'All' is selected, default to Main Account for entry
        if ($active_branch === 'all') {
            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $target_branch = $stmt_main->fetchColumn();
        } else {
            $target_branch = get_active_stock_branch_id($active_branch);
        }

        $supplier_id = $input['supplier_id'];
        $supplier_type = $input['supplier_type'] ?? 'local';
        $items = $input['items'];
        $total_amount = $input['total_amount'];

        // Ensure tables exist and columns for type and branch_id exists
        $tenant_conn->exec("CREATE TABLE IF NOT EXISTS purchases (id INT AUTO_INCREMENT PRIMARY KEY, supplier_id INT, total_amount DECIMAL(15,2), reference_no VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)"); // Base table
        try { $tenant_conn->exec("ALTER TABLE purchases ADD COLUMN supplier_type VARCHAR(20) DEFAULT 'local'"); } catch(Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE purchases ADD COLUMN status ENUM('pending', 'received', 'finalized', 'cancelled') DEFAULT 'pending'"); } catch(Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE purchases ADD COLUMN branch_id INT AFTER id"); } catch(Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE purchases ADD COLUMN payment_status ENUM('Unpaid', 'Paid') DEFAULT 'Unpaid'"); } catch(Exception $e) {}
        $tenant_conn->exec("CREATE TABLE IF NOT EXISTS purchase_items (id INT AUTO_INCREMENT PRIMARY KEY, purchase_id INT, product_id INT, quantity DECIMAL(10,2), purchase_price DECIMAL(15,2))");
        // Self-healing for purchase_items expiry
        try { $tenant_conn->exec("ALTER TABLE purchase_items ADD COLUMN expiry_date DATE DEFAULT NULL"); } catch(Exception $e) {}

        $tenant_conn->beginTransaction();

        // 1. Insert Purchase Record
        $ref = "MAN-" . strtoupper(uniqid()); // Generate a unique reference number
        $stmt = $tenant_conn->prepare("INSERT INTO purchases (branch_id, supplier_id, total_amount, reference_no, supplier_type, status, payment_status) VALUES (?, ?, ?, ?, ?, 'pending', 'Unpaid')");
        $stmt->execute([$target_branch, $supplier_id, $total_amount, $ref, $supplier_type]); // Default status and payment
        $purchase_id = $tenant_conn->lastInsertId();

        // 2. Insert Items and Update Stock
        foreach ($items as $item) {
            $stmt = $tenant_conn->prepare("INSERT INTO purchase_items (purchase_id, product_id, quantity, purchase_price, expiry_date) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$purchase_id, $item['id'], $item['qty'], $item['cost'], $item['expiry_date'] ?? null]);

            // Update stock level
            // Restaurant panel uses 'price' column for raw materials cost
            $industry = strtolower($_SESSION['industry_type'] ?? 'retail');
            $costCol = ($industry === 'restaurant') ? 'price' : 'purchase_price';
            
            $stmt = $tenant_conn->prepare("UPDATE products SET stock_level = stock_level + ?, $costCol = ? WHERE id = ? AND branch_id = ?");
            $stmt->execute([$item['qty'], $item['cost'], $item['id'], $target_branch]);

            // Record stock movement (only if stock table exists)
            try { // Attempt to insert into stock table, but don't fail if it doesn't exist
                $stmt_stock = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason, expiry_date) VALUES (?, ?, ?, ?)");
                $stmt_stock->execute([$item['id'], $item['qty'], "Manual Purchase #$purchase_id", $item['expiry_date'] ?? null]);
            } catch (Exception $e) { /* Stock table might not exist */ }
        }

        $tenant_conn->commit();
        ob_clean();
        echo json_encode(['success' => true, 'message' => 'Purchase recorded successfully!']);
        exit;
    } catch (Throwable $e) {
        if (isset($tenant_conn) && $tenant_conn->inTransaction()) $tenant_conn->rollBack();
        ob_clean();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}

// --- Handle Manual Purchase Status Update ---
elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($input['action']) && $input['action'] === 'update_manual_purchase_status') {
    ob_start();
    header('Content-Type: application/json');
    try {
        $purchase_id = $input['purchase_id'];
        $new_status = $input['status'] ?? null;
        $new_payment_status = $input['payment_status'] ?? null;

        $tenant_conn->beginTransaction();

        $update_sql = "UPDATE purchases SET ";
        $updates = [];
        $params = [];
        if ($new_status !== null) { $updates[] = "status = ?"; $params[] = $new_status; }
        if ($new_payment_status !== null) { $updates[] = "payment_status = ?"; $params[] = $new_payment_status; }
        
        if (empty($updates)) throw new Exception("No status or payment status provided for update.");
        $update_sql .= implode(", ", $updates) . " WHERE id = ?";
        $params[] = $purchase_id;

        $stmt = $tenant_conn->prepare($update_sql);
        $stmt->execute($params);

        $tenant_conn->commit();
        ob_clean();
        echo json_encode(['success' => true, 'message' => 'Purchase status updated successfully!']);
        exit;
    } catch (Throwable $e) {
        if (isset($tenant_conn) && $tenant_conn->inTransaction()) $tenant_conn->rollBack();
        ob_clean();
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        exit;
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Create Purchase Order | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen">
    <div class="flex">
        <?php include 'sidebar.php'; ?>
        
        <main class="flex-1 p-8">
            <header class="flex justify-between items-center mb-8">
                <div>
                    <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Purchase Entry</h1>
                    <p class="text-xs text-slate-500 uppercase tracking-widest font-bold mt-1">Manual & B2B Partner Integration</p>
                </div>
                <div class="flex items-center gap-3">
                    <?php include 'topbar.php'; ?>
                    <button onclick="toggleTheme()" class="p-2 rounded-xl bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 text-slate-400 hover:text-orange-500 transition-all">
                        <i id="theme-icon" data-lucide="sun" size="20"></i>
                    </button>
                </div>
            </header>

            <!-- Global Verification Alert Bar -->
            <?php include 'alert_bar.php'; ?>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Left: Configuration -->
                <div class="lg:col-span-1 space-y-6">
                    <div class="bg-white dark:bg-neutral-900 p-6 rounded-3xl shadow-xl border border-slate-200 dark:border-neutral-800">
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Select Supplier</label>
                        <select id="supplierSelect" onchange="handleSupplierChange()" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold focus:border-orange-500">
                            <option value="">-- Choose Supplier --</option>
                            <?php if (has_module('partner_network')): ?>
                                <optgroup id="b2bGroup" label="B2B Partners (Automated)">
                                    <?php foreach($b2b_partners as $p): ?>
                                        <option value="b2b_<?= $p['id'] ?>" data-name="<?= $p['business_name'] ?>">🏢 <?= $p['business_name'] ?></option>
                                    <?php endforeach; ?>
                                </optgroup>
                            <?php endif; ?>
                            <optgroup id="localGroup" label="Local Suppliers (Manual)">
                                <?php foreach($local_suppliers as $s): ?>
                                    <option value="local_<?= $s['id'] ?>" data-name="<?= $s['name'] ?>">👤 <?= $s['name'] ?></option>
                                <?php endforeach; ?>
                            </optgroup>
                        </select>

                        <div id="supplierInfo" class="mt-4 p-4 bg-orange-500/5 border border-orange-500/10 rounded-2xl hidden">
                            <p id="supplierTypeBadge" class="text-[9px] font-black uppercase text-orange-500"></p>
                            <h3 id="selectedSupplierName" class="text-lg font-black dark:text-white"></h3>
                        </div>
                    </div>

                    <div id="manualSearch" class="bg-white dark:bg-neutral-900 p-6 rounded-3xl shadow-xl border border-slate-200 dark:border-neutral-800 hidden">
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Search Local Inventory</label>
                        <div class="relative">
                            <i data-lucide="search" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size="16"></i>
                            <input type="text" id="productSearch" onkeyup="searchLocalProducts(this.value)" placeholder="Type SKU or Name..." class="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm">
                        </div>
                        <div id="searchResults" class="mt-4 space-y-2 max-h-48 overflow-y-auto"></div>
                    </div>

                    <button id="openCatalogBtn" onclick="openPartnerCatalog()" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black text-sm uppercase tracking-widest hidden shadow-lg shadow-orange-600/20 hover:scale-[1.02] transition-all">
                        <i data-lucide="layout-grid" class="inline mr-2" size="18"></i> Open Partner Catalog
                    </button>
                </div>

                <!-- Right: Purchase Cart -->
                <div class="lg:col-span-2">
                    <div class="bg-white dark:bg-neutral-900 rounded-3xl shadow-2xl border border-slate-200 dark:border-neutral-800 overflow-hidden">
                        <div class="p-6 border-b border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                            <h2 class="text-xl font-black dark:text-white uppercase tracking-tight">Order Items</h2>
                            <span class="text-[10px] px-3 py-1 bg-emerald-500/10 text-emerald-500 rounded-full font-black uppercase" id="cartCount">0 Items</span>
                        </div>
                        <div class="p-0">
                            <table class="w-full text-left">
                                <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                    <tr>
                                        <th class="px-6 py-4">Item Details</th>
                                        <th class="px-6 py-4 text-center">Qty</th>
                                        <th class="px-6 py-4 text-right">Unit Cost</th>
                                        <th class="px-6 py-4 text-right">Total</th>
                                        <th class="px-6 py-4"></th>
                                    </tr>
                                </thead>
                                <tbody id="cartItems" class="divide-y divide-slate-100 dark:divide-neutral-800">
                                    <!-- Cart items will appear here -->
                                </tbody>
                            </table>
                            <div id="emptyCart" class="p-20 text-center text-slate-400 italic text-sm">Cart is empty. Select a supplier and add items to start.</div>
                        </div>
                        <div class="p-8 bg-slate-50 dark:bg-neutral-950 border-t border-slate-100 dark:border-neutral-800">
                            <div class="flex justify-between items-center mb-6">
                                <span class="text-sm font-bold text-slate-500 uppercase tracking-widest">Grand Total</span>
                                <span class="text-4xl font-black text-slate-900 dark:text-white" id="grandTotal"><?= $currency_symbol ?>0.00</span>
                            </div>
                            <button onclick="submitPurchase()" class="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all">
                                <i data-lucide="check-circle" class="inline mr-2"></i> Finalize Purchase
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Partner Catalog Modal -->
    <div id="catalogModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-4xl shadow-2xl relative max-h-[85vh] overflow-hidden flex flex-col">
            <button onclick="closeModal()" class="absolute top-6 right-6 text-slate-400 hover:text-white transition-colors"><i data-lucide="x" size="24"></i></button>
            
            <div class="mb-6">
                <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Partner Inventory</h2>
                <p id="partnerCatalogName" class="text-xs text-orange-500 font-bold uppercase tracking-widest"></p>
            </div>

            <!-- Partner Branch Selection -->
            <div id="partnerBranchContainer" class="hidden mb-6 p-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[24px]">
                <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">Partner Warehouse/Branch</label>
                <select id="partnerBranchSelect" onchange="openPartnerCatalog(this.value)" class="w-full px-4 py-3 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-orange-500 font-bold text-sm">
                </select>
            </div>

            <!-- Modal Search Bar -->
            <div class="relative mb-6">
                <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                <input type="text" onkeyup="filterPartnerProducts(this.value)" placeholder="Search in partner catalog..." class="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
            </div>

            <div class="overflow-y-auto custom-scrollbar flex-1 pr-2">
                <div id="partnerProductGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4"></div>
            </div>
        </div>
    </div>

    <!-- Inner Link to Existing Modal (within create_purchase) -->
    <div id="innerLinkModal" class="fixed inset-0 bg-black/90 hidden items-center justify-center backdrop-blur-sm z-[60] p-4">
        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('innerLinkModal').classList.add('hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h3 class="text-xl font-black dark:text-white uppercase mb-1">Link to Your Product</h3>
            <p class="text-xs text-slate-500 mb-6 uppercase tracking-widest font-bold">Mapping: <span id="linkingProviderName" class="text-orange-500"></span></p>
            
            <div class="space-y-4">
                <div class="relative">
                    <i data-lucide="search" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size="16"></i>
                    <input type="text" onkeyup="searchLocalToLink(this.value)" placeholder="Search your inventory..." class="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-white text-sm font-bold">
                </div>
                <div id="linkSearchResults" class="max-h-60 overflow-y-auto space-y-2 custom-scrollbar"></div>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();
        const currencySymbol = '<?= $currency_symbol ?>';
        let cart = [];
        let selectedSupplierId = null;
        let isB2B = false;
        let allPartnerProducts = [];
        let currentLinkingPid = null;
        let cartBranchId = null; // Track which partner branch is locked to the current cart
        let selectedPartnerBranchId = null;

        function setPurchaseMode(mode) {
            const isManual = (mode === 'manual');
            
            // UI Button Highlighting
            document.getElementById('mode-manual').className = isManual ? 'flex-1 py-2.5 text-[10px] font-black uppercase rounded-xl transition-all bg-orange-600 text-white shadow-lg shadow-orange-600/20' : 'flex-1 py-2.5 text-[10px] font-black uppercase rounded-xl transition-all text-slate-500 hover:text-orange-600';
            if(document.getElementById('mode-b2b')) {
                document.getElementById('mode-b2b').className = !isManual ? 'flex-1 py-2.5 text-[10px] font-black uppercase rounded-xl transition-all bg-orange-600 text-white shadow-lg shadow-orange-600/20' : 'flex-1 py-2.5 text-[10px] font-black uppercase rounded-xl transition-all text-slate-500 hover:text-orange-600';
            }

            // Filter Supplier Dropdown groups
            const b2bGrp = document.getElementById('b2bGroup');
            if(b2bGrp) b2bGrp.style.display = isManual ? 'none' : 'block';
            document.getElementById('localGroup').style.display = isManual ? 'block' : 'none';
            
            document.getElementById('supplierSelect').value = "";
            resetUI();
        }

        function handleSupplierChange() {
            const select = document.getElementById('supplierSelect');
            const val = select.value;
            if(!val) return resetUI();

            selectedSupplierId = val.split('_')[1];
            isB2B = val.startsWith('b2b');
            const name = select.options[select.selectedIndex].dataset.name;

            document.getElementById('supplierInfo').classList.remove('hidden');
            document.getElementById('selectedSupplierName').innerText = name;
            document.getElementById('supplierTypeBadge').innerText = isB2B ? 'B2B Partner' : 'Manual Entry';
            
            if(isB2B) {
                document.getElementById('openCatalogBtn').classList.remove('hidden');
                document.getElementById('manualSearch').classList.add('hidden');
            } else {
                document.getElementById('openCatalogBtn').classList.add('hidden');
                document.getElementById('manualSearch').classList.remove('hidden');
            }
            cart = []; updateCartUI();
        }

        async function searchLocalProducts(q) {
            if(q.length < 2) return;
            const res = await fetch(`api.php?route=products/search&q=${q}&purchase_context=1`);
            const data = await res.json(); // This will contain is_expirable
            const container = document.getElementById('searchResults');
            container.innerHTML = data.map(p => `
                <div onclick='addToCart(${JSON.stringify(p)})' class="p-3 bg-slate-100 dark:bg-neutral-800 hover:bg-orange-600/10 rounded-xl cursor-pointer transition-all border border-slate-200 dark:border-neutral-700 flex justify-between items-center">
                    <div class="font-bold text-sm dark:text-white">${p.name}</div>
                    <div class="text-[10px] text-slate-500">
                        SKU: ${p.sku || 'N/A'} | 
                        Cost: ${currencySymbol}${p.price || p.purchase_price || 0} 
                        ${p.is_expirable ? '<span class="ml-2 px-1 py-0.5 bg-rose-500/10 text-rose-500 rounded-md font-bold">Expirable</span>' : ''}
                    </div>
                </div>
            `).join('');
        }

        async function openPartnerCatalog(branchId = null) {
            document.getElementById('partnerCatalogName').innerText = document.getElementById('selectedSupplierName').innerText;
            
            let url = `./b2b_actions.php?action=get_partner_products&partner_id=${selectedSupplierId}`;
            if (branchId) url += `&branch_id=${branchId}`;
            
            const res = await fetch(url);
            const data = await res.json();
            
            allPartnerProducts = data.products;
            renderPartnerGrid(allPartnerProducts);
            
            // Handle Branch Selection UI
            const branchContainer = document.getElementById('partnerBranchContainer');
            const branchSelect = document.getElementById('partnerBranchSelect');

            if (data.has_branches_mod && data.branches && data.branches.length > 1) {
                branchContainer.classList.remove('hidden');
                if (branchSelect.innerHTML.trim() === "" || !branchId) {
                    branchSelect.innerHTML = data.branches.map(b =>
                        `<option value="${b.id}" ${b.id == branchId || (!branchId && b.is_main) ? 'selected' : ''}>🏢 ${b.branch_name} ${b.address ? `(${b.address})` : ''} ${b.is_main ? '(Main Branch)' : ''}</option>`
                    ).join('');
                }
                selectedPartnerBranchId = branchSelect.value;
            } else {
                branchContainer.classList.add('hidden');
                // Agar sirf 1 branch hai to wahi select kar lo background mein, dropdown hide rakho
                selectedPartnerBranchId = (data.has_branches_mod && data.branches && data.branches.length === 1) ? data.branches[0].id : null;
            }

            document.getElementById('catalogModal').classList.remove('hidden');
            document.getElementById('catalogModal').classList.add('flex');
            lucide.createIcons();
        }

        function renderPartnerGrid(products) {
            const grid = document.getElementById('partnerProductGrid');
            grid.innerHTML = products.map(p => {
                const isMapped = p.subscriber_item_id !== null;
                return `
                <div class="bg-slate-50 dark:bg-neutral-900 p-4 rounded-3xl border border-slate-200 dark:border-neutral-800">
                    <div class="font-black text-sm mb-1 dark:text-white">${p.name}</div>
                    <div class="text-[10px] text-slate-500 mb-3">${p.sku || 'No SKU'} | ${p.category_name || 'General'}</div>
                    
                    <div id="mapped_actions_${p.id}">
                        <?php // Map checking logic here ?>
                        ${isMapped ? `
                            <div class="flex justify-between items-center bg-emerald-500/5 p-2 rounded-2xl border border-emerald-500/10">
                                <span class="text-emerald-500 font-black text-sm">${currencySymbol}${parseFloat(p.cost).toFixed(2)}</span>
                                <button onclick='addToCart(${JSON.stringify(p)})' class="p-2 bg-emerald-600 text-white rounded-xl hover:scale-110 transition-transform"><i data-lucide="plus" size="14"></i></button>
                            </div>
                        ` : `
                            <div class="grid grid-cols-2 gap-2">
                                <button onclick="importAsNew(${p.id}, '${p.name.replace(/'/g, "\\'")}', ${p.cost})" class="py-2 bg-orange-600 text-white rounded-xl text-[10px] font-black uppercase">Import</button>
                                <button onclick="openInnerLink(${p.id}, '${p.name.replace(/'/g, "\\'")}')" class="py-2 bg-slate-200 dark:bg-neutral-800 text-slate-600 dark:text-slate-400 rounded-xl text-[10px] font-black uppercase">Link</button>
                            </div>
                        `}
                    </div>
                </div>
                `;
            }).join('');
            lucide.createIcons();
        }

        function filterPartnerProducts(q) {
            const filtered = allPartnerProducts.filter(p => p.name.toLowerCase().includes(q.toLowerCase()) || (p.sku && p.sku.toLowerCase().includes(q.toLowerCase())));
            renderPartnerGrid(filtered);
        }

        async function importAsNew(pid, name, cost) {
            if(!confirm(`Import ${name} to your inventory?`)) return;
            const res = await fetch('b2b_actions.php?action=import', {
                method: 'POST',
                body: JSON.stringify({ provider_id: selectedSupplierId, item_id: pid, product_name: name })
            });
            const data = await res.json();
            if(data.success) { alert("Imported!"); openPartnerCatalog(); }
        }

        function openInnerLink(pid, name) {
            currentLinkingPid = pid;
            document.getElementById('linkingProviderName').innerText = name;
            document.getElementById('innerLinkModal').classList.remove('hidden');
            document.getElementById('innerLinkModal').classList.add('flex');
        }

        async function searchLocalToLink(q) {
            if(q.length < 2) return;
            const res = await fetch(`./b2b_actions.php?action=search&q=${encodeURIComponent(q)}`);
            const data = await res.json();
            const container = document.getElementById('linkSearchResults');
            container.innerHTML = data.results.map(prod => `
                <div onclick="confirmInnerLink(${prod.id})" class="p-3 bg-neutral-800 hover:bg-orange-600/20 border border-neutral-700 rounded-xl cursor-pointer flex justify-between items-center group">
                    <div class="text-sm font-bold text-white">${prod.name}</div>
                    <i data-lucide="link-2" size="14" class="text-neutral-500 group-hover:text-orange-500"></i>
                </div>
            `).join('');
            lucide.createIcons();
        }

        async function confirmInnerLink(subId) {
            const res = await fetch('./b2b_actions.php?action=link', {
                method: 'POST',
                body: JSON.stringify({ provider_id: selectedSupplierId, provider_item_id: currentLinkingPid, subscriber_item_id: subId })
            });
            const data = await res.json();
            if(data.success) { 
                document.getElementById('innerLinkModal').classList.add('hidden');
                openPartnerCatalog(); 
            }
        }

        function addToCart(p) {
            // Multi-Branch Cart Validation for B2B Partners
            if (isB2B && selectedPartnerBranchId) {
                if (cart.length > 0 && cartBranchId !== null && cartBranchId != selectedPartnerBranchId) {
                    const confirmClear = confirm("Your cart already contains items from a different branch. Clear cart and add this item instead?");
                    if (confirmClear) {
                        cart = [];
                        cartBranchId = selectedPartnerBranchId;
                    } else {
                        return; // Cancel adding the item
                    }
                } else if (cart.length === 0) {
                    cartBranchId = selectedPartnerBranchId;
                }
            }

            const productId = p.id || p.product_id;
            const existing = cart.find(i => i.id === productId);
            // Fix NaN: Check price or purchase_price based on available data
            const itemCost = parseFloat(p.price || p.purchase_price || p.cost || 0);

            if (existing) {
                existing.qty++;
            } else {
                cart.push({ 
                    id: productId, 
                    name: p.name, 
                    cost: itemCost, 
                    qty: 1, 
                    is_expirable: p.is_expirable || 0, // Add is_expirable flag
                    expiry_date: null // Default null, will be set by user if expirable
                });
            }
            updateCartUI();
        }

        function updateCartUI() {
            const container = document.getElementById('cartItems');
            const empty = document.getElementById('emptyCart');
            if(cart.length === 0) { 
                empty.classList.remove('hidden'); 
                container.innerHTML = ''; 
                cartBranchId = null; // Reset branch lock when cart is empty
            }
            else {
                empty.classList.add('hidden');
                container.innerHTML = cart.map((item, index) => `
                    <tr class="dark:text-white text-sm">
                        <td class="px-6 py-4 font-bold">
                            ${item.name}
                            ${item.is_expirable ? `
                                <div class="mt-1 flex items-center gap-1">
                                    <input type="date" onchange="cart[${index}].expiry_date=this.value" value="${item.expiry_date || ''}" class="w-full px-2 py-1 bg-slate-100 dark:bg-neutral-800 rounded-md text-xs">
                                    <span class="text-[8px] font-black uppercase text-rose-500">Expiry</span>
                                </div>
                            ` : ''}
                        </td>
                        <td class="px-6 py-4 text-center"><input type="number" onchange="cart[${index}].qty=this.value; updateCartUI()" value="${item.qty}" class="w-16 bg-slate-100 dark:bg-neutral-800 rounded border-none text-center"></td>
                        <td class="px-6 py-4 text-right font-mono">
                            ${!isB2B ? 
                                `<div class="flex items-center justify-end gap-1">
                                    <span>${currencySymbol}</span>
                                    <input type="number" step="0.01" onchange="cart[${index}].cost=parseFloat(this.value) || 0; updateCartUI()" value="${item.cost.toFixed(2)}" class="w-20 px-2 py-1 bg-slate-100 dark:bg-neutral-800 rounded-md text-right border-none focus:ring-1 focus:ring-orange-500 outline-none font-mono">
                                 </div>` : 
                                `${currencySymbol}${item.cost.toFixed(2)}`
                            }
                        </td>
                        <td class="px-6 py-4 text-right font-black text-emerald-500">${currencySymbol}${(item.qty * item.cost).toFixed(2)}</td>
                        <td class="px-6 py-4 text-right"><button onclick="cart.splice(${index},1); updateCartUI()" class="text-rose-500"><i data-lucide="trash-2" size="14"></i></button></td>
                    </tr>
                `).join('');
                lucide.createIcons();
            }
            
            let total = cart.reduce((acc, i) => acc + (i.qty * i.cost), 0);
            document.getElementById('grandTotal').innerText = `${currencySymbol}${total.toFixed(2)}`;
            document.getElementById('cartCount').innerText = `${cart.length} Items`;
        }

        function resetUI() {
            document.getElementById('supplierInfo').classList.add('hidden');
            document.getElementById('openCatalogBtn').classList.add('hidden');
            document.getElementById('manualSearch').classList.add('hidden');
            
            // Clear Branch State
            document.getElementById('partnerBranchSelect').innerHTML = '';
            document.getElementById('partnerBranchContainer').classList.add('hidden');
            selectedPartnerBranchId = null;
            
            cart = []; updateCartUI();
        }
        function closeModal() { document.getElementById('catalogModal').classList.add('hidden'); }
        async function submitPurchase() {
            if (cart.length === 0) return alert("Cart is empty!");
            if (!selectedSupplierId) return alert("Please select a supplier first!");

            const total = cart.reduce((acc, i) => acc + (i.qty * i.cost), 0);
            
            if (isB2B) {
                if (!confirm("Send this Purchase Order to B2B Partner?")) return;
                // Map cart items to match B2B API expectation (cost -> price)
                const b2bItems = cart.map(i => ({ id: i.id, qty: i.qty, price: i.cost }));
                
                try {
                    const res = await fetch('b2b_actions.php?action=place_order', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ provider_id: selectedSupplierId, items: b2bItems, receiver_branch_id: cartBranchId })
                    });
                    const data = await res.json();
                    if (data.success) {
                        alert("B2B Order placed successfully!");
                        window.location.href = "purchase_management.php";
                    } else alert("Error: " + data.message);
                } catch (e) { alert("Network error occurred."); }
            } else {
                if (!confirm("Save this Manual Purchase and update stock?")) return;
                try {
                    const res = await fetch('create_purchase.php', {
                        method: 'POST',
                        headers: { 'Content-Type': 'application/json' },
                        body: JSON.stringify({ 
                            action: 'save_manual_purchase', 
                            supplier_id: selectedSupplierId, 
                            supplier_type: isB2B ? 'partner' : 'local', 
                            items: cart, 
                            total_amount: total 
                        })
                    });
                    const data = await res.json();
                    if (data.success) {
                        alert(data.message);
                        window.location.href = "purchase_management.php";
                    } else alert("Error: " + data.message);
                } catch (e) { console.error(e); alert("Network error occurred: " + e.message); }
            }
        }
    </script>
</body>
</html>