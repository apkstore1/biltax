<?php
session_start();
require_once 'config/db_switch.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST["name"];
    $password = $_POST["password"];

    try {
        $stmt = $tenant_conn->prepare("SELECT * FROM users WHERE name = :name");
        $stmt->execute([':name' => $name]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            // Set session variables for staff
            $_SESSION['staff_id'] = $user['id'];
            $_SESSION['staff_name'] = $user['name'];
            $_SESSION['staff_role'] = $user['role'];
            
            // Set active branch if assigned
            if (!empty($user['assigned_branch_id'])) {
                $_SESSION['active_branch_id'] = $user['assigned_branch_id'];
                $_SESSION['staff_restricted'] = true; // Flag to hide switcher
            } else {
                $_SESSION['staff_restricted'] = false;
            }

            // Redirect to a staff-specific dashboard or page
            header("Location: dashboard.php"); // Change this to the appropriate URL
            exit;
        } else {
            $error_message = "Invalid name or password";
            // Redirect back to the login form with an error message
            header("Location: staff_login.php?error=" . urlencode($error_message));
            exit;
        }
    } catch (PDOException $e) {
        $error_message = "Login error: " . $e->getMessage();
        // Redirect back to the login form with an error message
        header("Location: staff_login.php?error=" . urlencode($error_message));
        exit;
    }
} else {
    // If the form is not submitted, redirect to the login page
    header("Location: staff_login.php");
    exit;
}
?>