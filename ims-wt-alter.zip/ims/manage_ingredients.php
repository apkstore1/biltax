<?php
require_once 'config/db_switch.php';

if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

if (!has_module('recipes')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$success_msg = $error_msg = '';
$active_branch = $_SESSION['active_branch_id'] ?? null;
$target_branch = get_active_stock_branch_id($active_branch);

// --- Handle Add Ingredient ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_ingredient') {
    try {
        $name = $_POST['name'];
        $purchase_rate = $_POST['purchase_price'] ?? 0;
        $stock = $_POST['stock_level'] ?? 0;
        $alert = $_POST['alert_level'] ?? 5; // Add alert_level
        $unit_id = $_POST['unit_id'] ?: null;

        $stmt = $tenant_conn->prepare("INSERT INTO products (branch_id, name, price, stock_level, alert_level, unit_id, is_raw) VALUES (?, ?, ?, ?, ?, ?, 1)");
        $stmt->execute([$target_branch, $name, $purchase_rate, $stock, $alert, $unit_id]);

        $success_msg = "Ingredient added successfully!";
    } catch (Exception $e) {
        $error_msg = "Error: " . $e->getMessage();
    }
}

// --- Handle Delete ---
if (isset($_POST['action']) && $_POST['action'] === 'delete_ingredient') {
    $stmt = $tenant_conn->prepare("DELETE FROM products WHERE id = ? AND is_raw = 1");
    $stmt->execute([$_POST['id']]);
    $success_msg = "Ingredient removed.";
}

// --- Fetch Data ---
if (!isset($units_list)) $units_list = [];
try {
    $units_list = $tenant_conn->query("SELECT id, name FROM units ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
}
if (!$units_list) $units_list = [];

$is_all = ($active_branch === 'all');
$sql = "SELECT p.*, u.name as unit_name FROM products p LEFT JOIN units u ON p.unit_id = u.id WHERE p.is_raw = 1";
if (!$is_all) {
    $sql .= " AND p.branch_id = :branch_id";
}
$sql .= " ORDER BY p.id DESC";

$stmt = $tenant_conn->prepare($sql);
if (!$is_all) $stmt->bindValue(':branch_id', $target_branch);
$stmt->execute();
$ingredients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Manage Ingredients | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 min-h-screen flex">
    <?php include 'sidebar.php'; ?>

    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Ingredient Inventory</h1>
                <p class="text-xs text-orange-500 font-bold uppercase tracking-widest mt-1">Raw Materials & Stock</p>
            </div>
            <div class="flex items-center gap-3">
                <?php include 'topbar.php'; ?>
                <button onclick="document.getElementById('addModal').classList.remove('hidden'); document.getElementById('addModal').classList.add('flex')" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 hover:scale-105 transition-all">
                    <i data-lucide="plus" class="inline mr-1" size="16"></i> Add Ingredient
                </button>
            </div>
        </header>

        <?php if ($success_msg): ?>
            <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-2xl text-sm font-bold flex items-center gap-2">
                <i data-lucide="check-circle" size="18"></i> <?php echo $success_msg; ?>
            </div>
        <?php endif; ?>

        <div class="bg-white dark:bg-neutral-900 rounded-3xl border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                    <tr>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Ingredient Name</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-center">Unit</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-right">Purchase Price</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-center">Current Stock</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php if (empty($ingredients)): ?>
                        <tr><td colspan="5" class="p-12 text-center text-slate-400 italic">No ingredients found. Start by adding raw materials.</td></tr>
                    <?php endif; ?>
                    <?php foreach ($ingredients as $ing): ?>
                    <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors">
                        <td class="px-6 py-4 font-bold dark:text-white"><?php echo htmlspecialchars($ing['name']); ?></td>
                        <td class="px-6 py-4 text-center text-slate-500 text-sm"><?php echo htmlspecialchars($ing['unit_name'] ?? 'N/A'); ?></td>
                        <td class="px-6 py-4 text-right font-mono text-slate-700 dark:text-slate-300"><?php echo $currency_symbol . number_format($ing['price'], 2); ?></td>
                        <td class="px-6 py-4 text-center">
                            <?php 
                                $alert_level = $ing['alert_level'] ?? 5; // Default to 5 if not set
                            ?>
                            <span class="px-3 py-1 bg-slate-100 dark:bg-neutral-800 rounded-lg font-black text-xs <?php echo ($ing['stock_level'] <= $alert_level) ? 'text-rose-500' : 'text-slate-600 dark:text-slate-400'; ?>">
                                <?php echo $ing['stock_level']; ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-right">
                            <form method="POST" onsubmit="return confirm('Remove this ingredient?');" class="inline">
                                <input type="hidden" name="action" value="delete_ingredient">
                                <input type="hidden" name="id" value="<?php echo $ing['id']; ?>">
                                <button class="p-2 text-slate-400 hover:text-rose-600 transition-colors">
                                    <i data-lucide="trash-2" size="16"></i>
                                </button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </main>

    <!-- Add Ingredient Modal -->
    <div id="addModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('addModal').classList.add('hidden'); document.getElementById('addModal').classList.remove('flex')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500">
                <i data-lucide="x" size="24"></i>
            </button>
            
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Add Ingredient</h2>
            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mb-8">Register new raw material for recipes</p>
            
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add_ingredient">
                
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Ingredient Name</label>
                    <input type="text" name="name" required placeholder="e.g. Fresh Milk, Chicken Fillet" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Unit</label>
                        <select name="unit_id" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                            <?php foreach($units_list as $unit): ?>
                                <option value="<?php echo $unit['id']; ?>"><?php echo htmlspecialchars($unit['name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Purchase Price</label>
                        <input type="number" step="0.01" name="purchase_price" placeholder="0.00" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                    </div>
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Initial Stock</label>
                    <input type="number" step="0.01" name="stock_level" value="0" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Alert Level</label>
                    <input type="number" step="1" name="alert_level" value="5" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold">
                </div>


                <button type="submit" class="w-full py-5 bg-orange-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:bg-orange-700 transition-all mt-4">
                    Save Ingredient
                </button>
            </form>
        </div>
    </div>

    <script>lucide.createIcons();</script>
</body>
</html>