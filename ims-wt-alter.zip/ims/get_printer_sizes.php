<?php
require_once 'config/db_connect.php';
header("Content-Type: application/json");
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    $type_id = $_GET['type_id'] ?? 0;
    $stmt = $main_pdo->prepare("SELECT * FROM printer_sizes WHERE type_id = ?");
    $stmt->execute([$type_id]);
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
} catch (Exception $e) {
    echo json_encode([]);
}