<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

// Page Restriction Logic
if (!has_module('b2b_returns')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
$my_id = $_SESSION['tenant_id'];

// Self-healing for b2b_return_requests branch_id columns
try { $main_pdo->exec("ALTER TABLE b2b_return_requests ADD COLUMN sender_branch_id INT DEFAULT NULL AFTER subscriber_id"); } catch(Throwable $e) {}
try { $main_pdo->exec("ALTER TABLE b2b_return_requests ADD COLUMN receiver_branch_id INT DEFAULT NULL AFTER provider_id"); } catch(Throwable $e) {}

// Fetch Incoming Return Requests (where I am the Provider)
$active_branch = $_SESSION['active_branch_id'] ?? null;
$is_all = ($active_branch === 'all');
$stock_branch = get_active_stock_branch_id($active_branch);

// Get Main Branch ID for legacy data support
$stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
$main_id = $stmt_main->fetchColumn();
if (!$main_id) $main_id = 0;

// Construct Query with Multi-Branch Support
$query = "SELECT r.*, t.business_name as subscriber_name, o.payment_status 
          FROM b2b_return_requests r 
          JOIN tenants t ON r.subscriber_id = t.id 
          JOIN b2b_orders o ON r.order_id = o.id 
          WHERE r.provider_id = ?";
$params = [$my_id];

if (!$is_all) {
    if ($active_branch == $main_id) {
        $query .= " AND (r.receiver_branch_id = ? OR r.receiver_branch_id IS NULL)";
    } else {
        $query .= " AND r.receiver_branch_id = ?";
    }
    $params[] = $stock_branch;
}

$query .= " ORDER BY r.id DESC";
$stmt = $main_pdo->prepare($query);
$stmt->execute($params);
$returns = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Return Requests Management | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 p-8">
    <div class="max-w-6xl mx-auto">
        <div class="flex items-center gap-4 mb-8">
            <a href="b2b_orders.php" class="flex items-center gap-2 px-4 py-2 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl text-slate-400 hover:text-orange-500 transition-all shadow-sm">
                <i data-lucide="chevron-left" size="24"></i>
                <span class="text-xs font-black uppercase tracking-widest">Back to Orders</span>
            </a>
            <h1 class="text-3xl font-black dark:text-white">Customer Returns Manager</h1>
        </div>

        <div class="bg-white dark:bg-neutral-900 rounded-[32px] shadow-2xl border border-slate-200 dark:border-neutral-800 overflow-hidden">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                    <tr class="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <th class="px-8 py-5">Request Details</th>
                        <th class="px-8 py-5">Subscriber</th>
                        <th class="px-8 py-5 text-center">Qty</th>
                        <th class="px-8 py-5 text-right">Refund Estimate</th>
                        <th class="px-8 py-5 text-center">Status</th>
                        <th class="px-8 py-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach($returns as $r): ?>
                    <tr class="group hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors dark:text-white">
                        <td class="px-8 py-5">
                            <div class="text-xs font-black text-orange-500 uppercase">#RET-<?= $r['id'] ?> • Order #<?= $r['order_id'] ?></div>
                            <div class="text-sm font-bold mt-1 italic text-slate-500">"<?= htmlspecialchars($r['reason']) ?>"</div>
                            <?php if($r['status'] === 'received' && $r['is_damaged']): ?>
                                <div class="mt-1">
                                    <span class="text-[8px] font-black uppercase px-1.5 py-0.5 bg-rose-500 text-white rounded">Damaged / Non-Resalable</span>
                                </div>
                            <?php elseif($r['status'] === 'received'): ?>
                                <div class="mt-1 font-black text-[8px] text-emerald-500 uppercase italic tracking-tighter">Stock Restored (Resalable)</div>
                            <?php endif; ?>
                        </td>
                        <td class="px-8 py-5 font-bold text-sm"><?= htmlspecialchars($r['subscriber_name']) ?></td>
                        <td class="px-8 py-5 text-center font-mono font-bold"><?= $r['qty'] ?></td>
                        <td class="px-8 py-5 text-right font-black text-emerald-500">$<?= number_format($r['refund_amount'], 2) ?></td>
                        <td class="px-8 py-5 text-center">
                            <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase border border-slate-200 text-slate-400"><?= $r['status'] ?></span>
                        </td>
                        <td class="px-8 py-5 text-right flex justify-end gap-2">
                            <?php if($r['status'] === 'pending'): ?>
                                <button onclick="updateReturn(<?= $r['id'] ?>, 'accepted')" class="px-4 py-2 bg-indigo-600 text-white rounded-xl text-[10px] font-black uppercase">Accept Request</button>
                                <button onclick="cancelReturn(<?= $r['id'] ?>)" class="px-4 py-2 bg-rose-600/10 text-rose-500 rounded-xl text-[10px] font-black uppercase hover:bg-rose-500 hover:text-white transition-all">Reject/Cancel</button>
                            <?php elseif($r['status'] === 'accepted' || $r['status'] === 'shipped'): ?>
                                <button onclick="updateReturn(<?= $r['id'] ?>, 'received')" class="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase">Confirm Receipt & Sync</button>
                            <?php else: ?>
                                <span class="text-[10px] text-slate-400 font-bold uppercase italic">Processed</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script>
        lucide.createIcons();
        async function updateReturn(id, status) {
            let refund = 0; let damaged = 0;
            if(status === 'received') {
                refund = prompt("Enter final refund amount to deduct from subscriber balance:");
                if(refund === null) return;

                // Ask about condition
                damaged = confirm("Is this item DAMAGED or EXPIRED? \n\nOK = Damaged (No Stock In)\nCancel = Resalable (Add back to Stock)") ? 1 : 0;
            }
            
            try {
                const res = await fetch('./b2b_actions.php?action=update_return_status', {
                    method: 'POST',
                    body: JSON.stringify({ 
                        return_id: id, 
                        status: status, 
                        refund_amount: refund,
                        is_damaged: damaged
                    })
                });
                const data = await res.json();
                if(data.success) location.reload();
                else alert(data.message);
            } catch(e) { alert("Error updating return"); }
        }

        async function cancelReturn(id) {
            if(!confirm("Reject this return request? Stock will be released back to the subscriber.")) return;
            try {
                const res = await fetch('./b2b_actions.php?action=cancel_return', {
                    method: 'POST',
                    body: JSON.stringify({ return_id: id })
                });
                const data = await res.json();
                if(data.success) {
                    alert("Request rejected and cancelled.");
                    location.reload();
                } else alert(data.message);
            } catch(e) { alert("Error cancelling return"); }
        }
    </script>
</body>
</html>