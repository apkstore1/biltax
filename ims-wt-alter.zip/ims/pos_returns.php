<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

// Page Restriction Logic
if (!has_module('pos_returns')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

$sale_id = $_GET['sale_id'] ?? null;
$sale_details = null;
$sale_items = [];

if ($sale_id) {
    try {
        // Multi-Branch security filter
        $active_branch = $_SESSION['active_branch_id'] ?? null;
        $is_all = ($active_branch === 'all');

        $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
        $main_id = $stmt_main->fetchColumn();

        // Fetch Sale Details - Restricted to strictly the active branch
        $sql = "SELECT * FROM sales WHERE id = :id";
        if (!$is_all) {
            if ($active_branch == $main_id) {
                $sql .= " AND (branch_id = :branch_id OR branch_id IS NULL)";
            } else {
                $sql .= " AND branch_id = :branch_id";
            }
        }
        $stmt = $tenant_conn->prepare($sql);
        $stmt->bindValue(':id', $sale_id);
        if (!$is_all) $stmt->bindValue(':branch_id', $active_branch);
        $stmt->execute();
        $sale_details = $stmt->fetch(PDO::FETCH_ASSOC);

        // Fetch Sale Items with Product Names
        $stmt = $tenant_conn->prepare("SELECT si.*, p.name as product_name, p.sku FROM sale_items si JOIN products p ON si.product_id = p.id WHERE si.sale_id = ?");
        $stmt->execute([$sale_id]);
        $sale_items = $stmt->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        // Handle error, e.g., sale not found or DB issue
        $sale_id = null;
        $sale_details = null;
        $sale_items = [];
        error_log("POS Returns: Error fetching sale details - " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>POS Returns | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 p-8">
    <div class="max-w-4xl mx-auto">
        <div class="flex items-center gap-4 mb-8">
            <a href="pos.php" class="flex items-center gap-2 px-4 py-2 bg-slate-900 text-white rounded-xl hover:bg-black transition-all shadow-lg group">
                <i data-lucide="monitor" size="20"></i>
                <span class="text-xs font-black uppercase tracking-widest">Return to POS Terminal</span>
            </a>
            <h1 class="text-3xl font-black dark:text-white">POS Returns</h1>
        </div>

        <div class="bg-white dark:bg-neutral-900 rounded-[32px] shadow-xl border border-slate-200 dark:border-neutral-800 p-8 mb-8">
            <h2 class="text-xs font-black uppercase text-orange-500 mb-4 tracking-widest">Search Sale</h2>
            <form method="GET" class="flex gap-4">
                <input type="text" name="sale_id" placeholder="Enter Invoice ID (e.g., 123)" value="<?= htmlspecialchars($sale_id ?? '') ?>" 
                       class="flex-1 px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold focus:border-orange-500">
                <button type="submit" class="bg-orange-600 text-white px-6 py-3 rounded-xl font-black text-sm uppercase flex items-center gap-2 hover:bg-orange-700 transition-all">
                    <i data-lucide="search" size="18"></i> Search
                </button>
            </form>
        </div>

        <?php if ($sale_details): ?>
            <div class="bg-white dark:bg-neutral-900 rounded-[32px] shadow-xl border border-slate-200 dark:border-neutral-800 p-8 mb-8">
                <h2 class="text-xs font-black uppercase text-emerald-500 mb-4 tracking-widest">Sale #<?= $sale_details['id'] ?> Details</h2>
                <div class="grid grid-cols-2 gap-4 text-sm dark:text-white mb-6">
                    <div><span class="text-slate-500">Total Amount:</span> <span class="font-bold"><?= $currency_symbol ?><?= number_format($sale_details['total_amount'], 2) ?></span></div>
                    <div><span class="text-slate-500">Payment Method:</span> <span class="font-bold"><?= htmlspecialchars($sale_details['payment_method']) ?></span></div>
                    <div><span class="text-slate-500">Date:</span> <span class="font-bold"><?= date('M d, Y H:i', strtotime($sale_details['created_at'])) ?></span></div>
                </div>

                <form id="returnForm" onsubmit="processReturn(event)">
                    <input type="hidden" name="sale_id" value="<?= $sale_details['id'] ?>">
                    <table class="w-full text-left mb-6">
                        <thead class="text-[10px] uppercase text-slate-400 font-black border-b border-slate-100 dark:border-neutral-800">
                            <tr>
                                <th class="py-3">Product</th>
                                <th class="py-3 text-center">Sold / Rem.</th>
                                <th class="py-3 text-right">Price</th>
                                <th class="py-3 text-center">Return Qty</th>
                                <th class="py-3">Reason</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                            <?php if (empty($sale_items)): ?>
                                <tr><td colspan="5" class="py-4 text-center text-slate-400 italic">No items found for this sale.</td></tr>
                            <?php endif; ?>
                            <?php foreach($sale_items as $item): ?>
                                <?php $available = $item['quantity'] - ($item['returned_quantity'] ?? 0); ?>
                                <tr class="dark:text-white">
                                    <td class="py-4 font-bold text-sm"><?= htmlspecialchars($item['product_name']) ?></td>
                                    <td class="py-4 text-center text-xs">
                                        <?= (int)$item['quantity'] ?> / <span class="text-emerald-500 font-black"><?= (int)$available ?></span>
                                    </td>
                                    <td class="py-4 text-right"><?= $currency_symbol ?><?= number_format($item['price'], 2) ?></td>
                                    <td class="py-4">
                                        <input type="number" name="return_qty[<?= $item['product_id'] ?>]" min="0" max="<?= $available ?>" value="0"
                                               class="w-20 px-2 py-1 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none dark:text-white text-sm">
                                    </td>
                                    <td class="py-4">
                                        <input type="text" name="return_reason[<?= $item['product_id'] ?>]" placeholder="Reason (Optional)"
                                               class="w-full px-2 py-1 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none dark:text-white text-sm">
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <button type="submit" class="w-full bg-rose-600 text-white px-6 py-3 rounded-xl font-black text-sm uppercase flex items-center justify-center gap-2 hover:bg-rose-700 transition-all">
                        <i data-lucide="rotate-ccw" size="18"></i> Process Return
                    </button>
                </form>
            </div>
        <?php elseif ($sale_id): ?>
            <div class="bg-white dark:bg-neutral-900 rounded-[32px] shadow-xl border border-slate-200 dark:border-neutral-800 p-8 mb-8 text-center text-slate-500">
                <p class="text-lg font-bold">Sale #<?= htmlspecialchars($sale_id) ?> not found.</p>
                <p class="text-sm mt-2">Please check the Invoice ID and try again.</p>
            </div>
        <?php endif; ?>
    </div>
    <script>
        lucide.createIcons();
        const currencySymbol = '<?= $currency_symbol ?>';

        async function processReturn(event) {
            event.preventDefault();
            const form = event.target;
            const saleId = form.sale_id.value;
            const returnQuantities = {};
            const returnReasons = {};
            let hasReturns = false;

            form.querySelectorAll('input[name^="return_qty"]').forEach(input => {
                const productId = input.name.match(/\[(.*?)\]/)[1];
                const qty = parseInt(input.value);
                if (qty > 0) {
                    returnQuantities[productId] = qty;
                    hasReturns = true;
                }
            });

            form.querySelectorAll('input[name^="return_reason"]').forEach(input => {
                const productId = input.name.match(/\[(.*?)\]/)[1];
                if (returnQuantities[productId]) { // Only get reason if quantity is > 0
                    returnReasons[productId] = input.value;
                }
            });

            if (!hasReturns) {
                alert("Please enter a quantity for at least one item to return.");
                return;
            }

            if (!confirm("Are you sure you want to process this return? Stock will be updated.")) {
                return;
            }

            const returnItems = Object.keys(returnQuantities).map(productId => ({
                product_id: productId,
                quantity: returnQuantities[productId],
                reason: returnReasons[productId] || "No reason provided"
            }));

            try {
                const response = await fetch('api.php?route=pos/return', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ sale_id: saleId, items: returnItems })
                });
                const data = await response.json();

                if (data.success) {
                    alert("Return processed successfully! Refund amount: " + currencySymbol + parseFloat(data.refund_amount).toFixed(2));
                    window.location.reload();
                } else {
                    alert("Error processing return: " + data.message);
                }
            } catch (error) {
                console.error('Network or JSON error:', error);
                alert("A network error occurred or the server returned invalid data.");
            }
        }
    </script>
</body>
</html>