<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Industry-based logic
$industry = $_SESSION['industry_type'] ?? 'retail';
$available_types = [];

if ($industry === 'service') {
    $available_types['job'] = 'Service Job Invoice';
} else {
    $available_types['sale'] = 'Retail/POS Sale';
    $available_types['b2b'] = 'B2B Order';
    $available_types['purchase'] = 'Manual Purchase';
}

// Get parameters if redirected from Jobs/Orders
$pre_type = $_GET['type'] ?? '';
$pre_id = $_GET['job_id'] ?? $_GET['order_id'] ?? '';
$business_name = $_SESSION['business_name'] ?? 'Biltax';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Custom Invoice Builder | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@media print { .no-print { display: none !important; } .print-only { display: block !important; } body { background: white !important; } }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 no-print">
        <header class="mb-10">
            <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Invoice Builder</h1>
            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Generate custom invoices for any transaction</p>
        </header>

        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl max-w-2xl mx-auto">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Transaction Type</label>
                    <select id="inv-type" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none font-bold dark:text-white">
                        <?php foreach($available_types as $val => $label): ?>
                            <option value="<?= $val ?>" <?= $pre_type === $val ? 'selected' : '' ?>><?= $label ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Order/Invoice ID</label>
                    <input type="number" id="inv-id" value="<?= htmlspecialchars($pre_id) ?>" placeholder="e.g. 105" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none font-bold dark:text-white">
                </div>
            </div>
            <button onclick="fetchInvoice()" class="w-full py-5 bg-orange-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 transition-all active:scale-95">Generate Preview</button>
        </div>

        <!-- Preview Area -->
        <div id="preview-container" class="mt-12 hidden">
            <div class="max-w-3xl mx-auto bg-white p-12 rounded-[40px] shadow-2xl border border-slate-100 text-black">
                <div class="flex justify-between items-start mb-12">
                    <div>
                        <h2 class="text-4xl font-black uppercase tracking-tighter"><?= htmlspecialchars($business_name) ?></h2>
                        <p class="text-sm font-bold text-slate-500 uppercase mt-1">Official Invoice</p>
                    </div>
                    <div class="text-right">
                        <p class="text-xs font-black uppercase text-slate-400">Order Ref</p>
                        <p id="prev-id" class="text-2xl font-black"></p>
                    </div>
                </div>

                <?php if (has_module('whatsapp_email_sharing')): ?>
                <div class="mb-4 flex items-center gap-3 no-print">
                    <label for="toggleManualContact" class="relative inline-flex items-center cursor-pointer">
                        <input type="checkbox" id="toggleManualContact" class="sr-only peer" onchange="toggleManualContactFields()" checked>
                        <div class="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-orange-300 dark:peer-focus:ring-orange-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-orange-600"></div>
                        <span class="ml-3 text-sm font-bold text-slate-900">Use Custom Contact Details</span>
                    </label>
                </div>
                <!-- Manual Contact Input (If missing) -->
                <div id="manual-contact-area" class="hidden mb-8 grid grid-cols-1 md:grid-cols-2 gap-4 p-6 bg-orange-50/50 rounded-3xl border border-orange-100 no-print">
                    <div>
                        <label class="block text-[9px] font-black uppercase text-slate-400 mb-1">Receiver Phone (WhatsApp)</label>
                        <input type="text" id="manual-phone" onkeyup="updateShareLinks()" placeholder="e.g. 923001234567" class="w-full p-3 bg-white border border-slate-200 rounded-xl outline-none text-xs font-bold">
                    </div>
                    <div>
                        <label class="block text-[9px] font-black uppercase text-slate-400 mb-1">Receiver Email</label>
                        <input type="email" id="manual-email" onkeyup="updateShareLinks()" placeholder="e.g. customer@mail.com" class="w-full p-3 bg-white border border-slate-200 rounded-xl outline-none text-xs font-bold">
                    </div>
                </div>
                <?php endif; ?>

                <table class="w-full mb-12">
                    <thead class="border-b-2 border-black">
                        <tr class="text-[10px] font-black uppercase text-slate-400 text-left">
                            <th class="py-4">Item Description</th>
                            <th class="py-4 text-center">Qty</th>
                            <th class="py-4 text-right">Unit</th>
                            <th class="py-4 text-right">Total</th>
                        </tr>
                    </thead>
                    <tbody id="prev-items" class="divide-y divide-slate-100"></tbody>
                </table>
                <div class="flex justify-end">
                    <div class="w-64 space-y-2">
                        <div class="flex justify-between font-bold"><span>Subtotal</span><span id="prev-sub"></span></div>
                        <div class="flex justify-between text-2xl font-black border-t-2 border-black pt-2"><span>Total</span><span id="prev-total"></span></div>
                    </div>
                </div>
                <div class="mt-12 flex flex-col md:flex-row gap-4 no-print">
                    <button onclick="window.print()" class="flex-1 py-4 bg-black text-white rounded-2xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all active:scale-95 shadow-xl shadow-black/10">
                        <i data-lucide="printer" size="16"></i> Print Official Invoice
                    </button>
                    <?php if (has_module('whatsapp_email_sharing')): ?>
                    <a id="wa-btn" href="#" target="_blank" class="flex-1 py-4 bg-emerald-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all active:scale-95 shadow-xl shadow-emerald-600/20">
                        <i data-lucide="message-circle" size="16"></i> WhatsApp
                    </a>
                    <a id="mail-btn" href="#" class="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest flex items-center justify-center gap-2 transition-all active:scale-95 shadow-xl shadow-blue-600/20">
                        <i data-lucide="mail" size="16"></i> Email
                    </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </main>

    <script>
        lucide.createIcons();
        let currentOrderData = null;

        async function fetchInvoice() {
            const id = document.getElementById('inv-id').value;
            const type = document.getElementById('inv-type').value;
            if(!id) return alert("Enter ID");

            const res = await fetch(`api.php?route=invoice/fetch&order_id=${id}&type=${type}`);
            const result = await res.json();

            if(result.success) {
                currentOrderData = result.data;
                const order = currentOrderData.order;
                const items = result.data.items;
                const bizName = "<?= htmlspecialchars($business_name) ?>";

                document.getElementById('prev-id').innerText = '#' + (type.toUpperCase()) + '-' + order.id;
                document.getElementById('prev-items').innerHTML = items.map(i => `
                    <tr>
                        <td class="py-4 font-bold">${i.name || 'Product'}</td>
                        <td class="py-4 text-center font-mono">${i.quantity}</td>
                        <td class="py-4 text-right font-mono">${currencySymbol}${parseFloat(i.price).toFixed(2)}</td>
                        <td class="py-4 text-right font-black">${currencySymbol}${(i.price * i.quantity).toFixed(2)}</td>
                    </tr>
                `).join('');
                
                const total = parseFloat(order.total_amount);
                const discount = parseFloat(order.discount_amount || 0);
                document.getElementById('prev-sub').innerText = currencySymbol + (total + discount).toFixed(2);
                document.getElementById('prev-total').innerText = currencySymbol + total.toFixed(2);
                
                // Auto-toggle based on data availability
                const toggle = document.getElementById('toggleManualContact');
                if (toggle && (!order.customer_phone && !order.customer_email)) {
                    toggle.checked = false;
                    toggleManualContactFields();
                }

                updateShareLinks();

                document.getElementById('preview-container').classList.remove('hidden');
                lucide.createIcons();
            } else {
                alert(result.message);
            }
        }

        function toggleManualContactFields() {
            const toggle = document.getElementById('toggleManualContact');
            const manualArea = document.getElementById('manual-contact-area');
            if (manualArea) { // Check if manualArea exists (module might be disabled)
                if (toggle.checked) {
                    // Mode: Use Saved -> Hide Fields
                    manualArea.classList.add('hidden');
                } else {
                    // Mode: Custom -> Show Fields
                    manualArea.classList.remove('hidden');
                    // Clear manual inputs when hiding
                    const manualPhone = document.getElementById('manual-phone');
                    const manualEmail = document.getElementById('manual-email');
                    if (manualPhone) manualPhone.value = '';
                    if (manualEmail) manualEmail.value = '';
                }
                updateShareLinks(); // Update links based on new visibility
            }
        }

        function updateShareLinks() {
            if (!currentOrderData) return;
            const order = currentOrderData.order;
            const type = document.getElementById('inv-type').value;
            const waBtn = document.getElementById('wa-btn');
            const mailBtn = document.getElementById('mail-btn');
            const manualArea = document.getElementById('manual-contact-area');
            const toggleManualContact = document.getElementById('toggleManualContact');

            let effectivePhone = '';
            let effectiveEmail = '';

            if (toggleManualContact && toggleManualContact.checked) {
                // Option 1: Use Customer's Stored Info
                effectivePhone = order.customer_phone || '';
                effectiveEmail = order.customer_email || '';
            } else {
                // Option 2: Use Manual Overrides
                const manualPhoneInput = document.getElementById('manual-phone');
                const manualEmailInput = document.getElementById('manual-email');
                effectivePhone = (manualPhoneInput ? manualPhoneInput.value : '') || order.customer_phone || '';
                effectiveEmail = (manualEmailInput ? manualEmailInput.value : '') || order.customer_email || '';
            }
            
            const phone = effectivePhone;
            const email = effectiveEmail;
            const name = order.customer_name || 'Customer';
            const total = parseFloat(order.total_amount);
            const pdfUrl = `${window.location.origin}/ims/generate_pdf.php?type=${type}&order_id=${order.id}&print=true`;
            const bizName = "<?= htmlspecialchars($business_name) ?>";

            if (waBtn && phone) {
                const cleanPhone = phone.replace(/[^0-9]/g, '');
                const msg = encodeURIComponent(`Hi ${name}, here is your invoice for #${type.toUpperCase()}-${order.id}. Total: ${currencySymbol}${total.toFixed(2)}. View: ${pdfUrl} - ${bizName}`);
                waBtn.href = `https://wa.me/${cleanPhone}?text=${msg}`;
            } else if (waBtn) {
                waBtn.href = `https://wa.me/`; // Open WhatsApp without a specific number
            }

            if (mailBtn && email) {
                const subject = encodeURIComponent(`Invoice #${type.toUpperCase()}-${order.id}`);
                const body = encodeURIComponent(`Dear ${name},\n\nPlease find your invoice details for #${type.toUpperCase()}-${order.id}.\nTotal: ${currencySymbol}${total.toFixed(2)}\n\nPDF: ${pdfUrl}\n\nThank you, ${bizName}.`);
                mailBtn.href = `mailto:${email}?subject=${subject}&body=${body}`;
            } else if (mailBtn) {
                mailBtn.href = `mailto:`; // Open mail client without a specific recipient
            }
        }

        const currencySymbol = '<?= $currency_symbol ?>';

        // Auto-fetch if redirected with data
        if(document.getElementById('inv-id').value && document.getElementById('inv-type').value) {
            window.onload = fetchInvoice;
        }
    </script>
</body>
</html>