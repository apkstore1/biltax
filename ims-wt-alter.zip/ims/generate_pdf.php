<?php
require_once 'config/db_switch.php';

// PDF Library Requirement (Suggested: Dompdf)
// Agar aapke paas dompdf nahi hai, to ye HTML output dega jo Print-to-PDF ke liye ready hoga

$order_id = $_GET['order_id'] ?? null;
$type = $_GET['type'] ?? 'sale';

if (!$order_id) die("Invalid Request");

// Fetch Data directly from our existing API logic/DB
try {
    $data = [];
    if ($type === 'sale') {
        $stmt = $tenant_conn->prepare("SELECT s.*, c.name as customer_name, c.phone as customer_phone, c.address FROM sales s LEFT JOIN customers c ON s.customer_id = c.id WHERE s.id = ?");
        $stmt->execute([$order_id]);
        $data['order'] = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $stmt_items = $tenant_conn->prepare("SELECT si.*, p.name, u.name as unit_name FROM sale_items si JOIN products p ON si.product_id = p.id LEFT JOIN units u ON p.unit_id = u.id WHERE si.sale_id = ?");
        $stmt_items->execute([$order_id]);
        $data['items'] = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($type === 'job') {
        $stmt = $tenant_conn->prepare("SELECT j.*, c.name as customer_name, c.phone as customer_phone, c.address, s.service_name FROM job_cards j LEFT JOIN customers c ON j.customer_id = c.id LEFT JOIN services s ON j.service_id = s.id WHERE j.id = ?");
        $stmt->execute([$order_id]);
        $data['order'] = $stmt->fetch(PDO::FETCH_ASSOC);
        $price = ($data['order']['total_cost'] > 0) ? $data['order']['total_cost'] : $data['order']['estimated_cost'];
        $data['order']['total_amount'] = $price;
        $data['items'] = [['name' => $data['order']['service_name'], 'quantity' => 1, 'price' => $price]];
    }

    if (!$data['order']) die("Order not found");
} catch (Exception $e) { die($e->getMessage()); }

$biz_name = $_SESSION['business_name'] ?? 'Biltax';
?>
<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: 'Helvetica', sans-serif; color: #333; margin: 0; padding: 20px; }
        .header { border-bottom: 2px solid #000; padding-bottom: 20px; margin-bottom: 30px; }
        .biz-name { font-size: 24px; font-weight: bold; text-transform: uppercase; }
        .inv-title { float: right; text-align: right; }
        .details-table { width: 100%; border-collapse: collapse; margin-top: 30px; }
        .details-table th { background: #f8f9fa; text-align: left; padding: 12px; border-bottom: 1px solid #eee; font-size: 10px; text-transform: uppercase; }
        .details-table td { padding: 12px; border-bottom: 1px solid #eee; font-size: 12px; }
        .total-box { float: right; width: 250px; margin-top: 30px; }
        .total-row { display: flex; justify-content: space-between; padding: 5px 0; }
        .grand-total { font-size: 18px; font-weight: bold; border-top: 2px solid #000; padding-top: 10px; margin-top: 10px; }
        @media print { .no-print { display: none; } }
    </style>
</head>
<body onload="if(window.location.search.includes('print=true')) window.print()">
    <div class="header">
        <div class="inv-title">
            <h1 style="margin:0">INVOICE</h1>
            <p style="margin:0; color:#888">#<?= strtoupper($type) ?>-<?= $data['order']['id'] ?></p>
            <p style="margin:0; font-size:12px"><?= date('d M, Y') ?></p>
        </div>
        <div class="biz-name"><?= htmlspecialchars($biz_name) ?></div>
        <p style="margin:5px 0 0 0; font-size:12px; color:#666">Official Transaction Document</p>
    </div>

    <div style="margin-bottom:30px">
        <p style="font-size:10px; font-weight:bold; color:#888; text-transform:uppercase; margin-bottom:5px">Bill To:</p>
        <p style="margin:0; font-weight:bold"><?= htmlspecialchars($data['order']['customer_name']) ?></p>
        <p style="margin:0; font-size:12px"><?= htmlspecialchars($data['order']['customer_phone']) ?></p>
        <p style="margin:0; font-size:12px"><?= htmlspecialchars($data['order']['address'] ?? '') ?></p>
    </div>

    <table class="details-table">
        <thead>
            <tr>
                <th>Description</th>
                <th style="text-align:center">Qty</th>
                <th style="text-align:center">Unit</th>
                <th style="text-align:right">Price</th>
                <th style="text-align:right">Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach($data['items'] as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td style="text-align:center"><?= $item['quantity'] ?></td>
                <td style="text-align:center"><?= htmlspecialchars($item['unit_name'] ?? 'pcs') ?></td>
                <td style="text-align:right"><?= number_format($item['price'], 2) ?></td>
                <td style="text-align:right; font-weight:bold"><?= number_format($item['price'] * $item['quantity'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="total-box">
        <div style="text-align:right">
            <p style="margin:5px 0">Subtotal: <?= $currency_symbol ?><?= number_format($data['order']['total_amount'] + ($data['order']['discount_amount'] ?? 0), 2) ?></p>
            <?php if(($data['order']['discount_amount'] ?? 0) > 0): ?>
                <p style="margin:5px 0; color:red">Discount: -<?= $currency_symbol ?><?= number_format($data['order']['discount_amount'], 2) ?></p>
            <?php endif; ?>
            <div class="grand-total">
                Total: <?= $currency_symbol ?><?= number_format($data['order']['total_amount'], 2) ?>
            </div>
        </div>
    </div>

    <div style="margin-top:100px; font-size:10px; color:#888; text-align:center; border-top:1px solid #eee; padding-top:20px">
        This is a computer generated document. No signature required.
    </div>
    
    <div class="no-print" style="margin-top:20px; text-align:center">
        <button onclick="window.print()" style="padding:10px 20px; background:#000; color:#fff; border:none; border-radius:5px; cursor:pointer">Download as PDF / Print</button>
    </div>
</body>
</html>