// Global state for the application
const state = {
    activeTab: 'dashboard', // Default to dashboard
    // Check URL for initial tab, otherwise use default
    // This ensures direct links and reloads go to the correct tab
    get initialActiveTab() {
        return window.initialTab || new URLSearchParams(window.location.search).get('tab') || 'dashboard';
    },
    stats: null,
    products: [],
    suppliers: [],
    settings: {},
    cart: [],
};

// --- API Helper ---
async function api(route, options = {}) {
    try {
        const response = await fetch(`api.php?route=${route}`, options);
        if (!response.ok) throw new Error(`HTTP error! status: ${response.status}`);
        return await response.json();
    } catch (error) {
        console.error(`API call failed for ${route}:`, error);
        alert(`An error occurred: ${error.message}`);
        return null;
    }
}

// --- Main Render & Navigation ---
function setTab(tab, push = true) {
    state.activeTab = tab;
    if (push) {
        const newurl = window.location.protocol + "//" + window.location.host + window.location.pathname + '?tab=' + tab;
        window.history.pushState({ tab: tab }, '', newurl);
    }
    render();
}

function render() {
    const mainContent = document.getElementById('main-content');
    const headerTitle = document.getElementById('header-title');

    // Update sidebar active state
    document.querySelectorAll('.sidebar-item').forEach(item => {
        const isActive = item.dataset.tab === state.activeTab;
        // Remove all active classes first, then add if active
        item.classList.remove('bg-orange-50', 'dark:bg-orange-500/10', 'text-orange-600', 'dark:text-orange-500', 'border-orange-200', 'dark:border-orange-500/20');
        item.classList.add('text-slate-500', 'dark:text-neutral-400', 'hover:bg-orange-50', 'dark:hover:bg-neutral-800', 'hover:text-orange-600', 'dark:hover:text-white', 'border-transparent');
        if (isActive) {
            item.classList.add('bg-orange-50', 'dark:bg-orange-500/10', 'text-orange-600', 'dark:text-orange-500', 'border-orange-200', 'dark:border-orange-500/20');
            item.classList.remove('text-slate-500', 'dark:text-neutral-400', 'hover:bg-orange-50', 'dark:hover:bg-neutral-800', 'hover:text-orange-600', 'dark:hover:text-white', 'border-transparent');
        }
    });

    headerTitle.textContent = state.activeTab.replace('-', ' ');

    // Render view based on active tab
    mainContent.innerHTML = '<div class="p-8 text-center">Loading...</div>'; // Loading state
    switch (state.activeTab) {
        case 'dashboard': renderDashboard(mainContent); break;
        case 'pos': renderPOS(mainContent); break;
        case 'tables': renderTables(mainContent); break;
        case 'kot': renderKOT(mainContent); break;
        case 'inventory': renderInventory(mainContent); break;
        case 'suppliers': renderSuppliers(mainContent); break;
        case 'reports': renderReports(mainContent); break;
        case 'settings': renderSettings(mainContent); break;
    }

    // Re-initialize icons after every render
    lucide.createIcons();
}

// --- View Renderers ---

function renderDashboard(container) {
    if (!state.stats) {
        container.innerHTML = '<div class="p-8 text-center text-slate-500 font-bold uppercase tracking-widest text-xs">Loading Dashboard...</div>';
        return;
    }

    if (state.stats.industry && state.stats.industry.trim().toLowerCase() === 'restaurant') {
        renderRestaurantDashboard(container);
    } else {
        renderRetailDashboard(container);
    }
}

function renderRetailDashboard(container) {
    // Default values set ki hain taake agar data missing ho to crash na kare
    const { 
        revenue = 0, 
        productCount = 0, 
        lowStockCount = 0, 
        recentSales = [], 
        currency = '$',
        storageUsage = 0,
        storageLimit = 1
    } = state.stats || {};

    const storagePercent = Math.min(100, (storageUsage / storageLimit) * 100).toFixed(0);
    const storageRemaining = Math.max(0, storageLimit - storageUsage).toFixed(2);

    const statCard = (title, value, icon, color) => `
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-100 dark:border-neutral-800 shadow-sm transition-colors">
            <div class="flex justify-between items-start mb-4">
                <div class="p-3 rounded-xl ${color} text-white"><i data-lucide="${icon}"></i></div>
            </div>
            <h3 class="text-slate-500 dark:text-neutral-400 text-sm font-medium mb-1">${title}</h3>
            <p class="text-2xl font-bold text-slate-900 dark:text-white">${value}</p>
        </div>`;

    const storageUsageCard = `
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-100 dark:border-neutral-800 shadow-sm transition-colors">
            <div class="flex items-center justify-between mb-6">
                <h3 class="text-lg font-bold text-slate-900 dark:text-white">Storage Usage</h3>
                <i data-lucide="database" class="text-amber-500"></i>
            </div>
            <div class="flex items-end gap-2 mb-4">
                <div>
                    <p class="text-3xl font-black text-slate-900 dark:text-white leading-none">${storageUsage.toFixed(2)} MB <span class="text-sm font-medium text-slate-400">/ ${storageLimit} MB</span></p>
                    <p class="text-xs text-slate-500 dark:text-neutral-500 mt-2 font-bold uppercase tracking-wider">${storageRemaining} MB Remaining</p>
                </div>
            </div>
            <div class="w-full bg-slate-100 dark:bg-neutral-800 rounded-full h-4 mb-3 overflow-hidden">
                <div class="bg-amber-500 h-full rounded-full shadow-[0_0_10px_rgba(245,158,11,0.4)] transition-all duration-1000" style="width: ${storagePercent}%"></div>
            </div>
            <p class="text-[11px] text-slate-400 dark:text-neutral-600 italic">Usage is calculated based on database records and uploaded assets.</p>
        </div>`;

    const salesList = (recentSales || []).map(sale => `
        <div class="flex items-center justify-between p-3 rounded-xl hover:bg-slate-50 dark:hover:bg-neutral-800 transition-colors">
            <div class="flex items-center gap-3">
                <div class="p-2 bg-orange-100 rounded-lg text-orange-600"><i data-lucide="shopping-cart" size="18"></i></div>
                <div>
                    <p class="text-sm font-bold text-slate-900 dark:text-white">Order #${sale.id}</p>
                    <p class="text-xs text-slate-500 dark:text-neutral-400">${new Date(sale.created_at).toLocaleString()}</p>
                </div>
            </div>
            <p class="text-sm font-bold text-slate-900 dark:text-white">${currency || '$'}${parseFloat(sale.total_amount).toFixed(2)}</p>
        </div>`).join('');

    container.innerHTML = `
        <div class="space-y-8 animate-in">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                ${statCard('Total Revenue', `${currency || state.settings.currency || '$'}${parseFloat(revenue || 0).toLocaleString()}`, 'dollar-sign', 'bg-blue-500')}
                ${statCard('Total Products', productCount, 'box', 'bg-orange-500')}
                ${statCard('Low Stock Alerts', lowStockCount, 'alert-triangle', 'bg-rose-500')}
                ${statCard('Recent Sales', recentSales.length, 'trending-up', 'bg-emerald-500')}
            </div>
            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div class="lg:col-span-2 bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-100 dark:border-neutral-800 shadow-sm flex flex-col transition-colors">
                    <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-6">Revenue Overview</h3>
                    <div class="h-[300px]">
                        <canvas id="revenueChart"></canvas>
                    </div>
                </div>
                <div class="flex flex-col gap-8">
                    <div class="bg-white dark:bg-neutral-950 p-6 rounded-2xl border border-slate-100 dark:border-neutral-800 shadow-sm transition-colors">
                        <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-6">Recent Transactions</h3>
                        <div class="space-y-4">${salesList}</div>
                    </div>
                    ${storageUsageCard}
                </div>
            </div>
        </div>`;

    // Render Chart
    api('sales/report').then(data => {
        const ctx = document.getElementById('revenueChart');
        if (ctx && data) {
            new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.map(d => d.date),
                    datasets: [{
                        label: 'Revenue',
                        data: data.map(d => d.total),
                        borderColor: '#f97316',
                        backgroundColor: 'rgba(249, 115, 22, 0.1)',
                        fill: true,
                        tension: 0.4
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false, 
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { ticks: { color: '#737373' }, grid: { color: '#262626' } },
                        x: { ticks: { color: '#737373' }, grid: { color: '#262626' } }
                    }
                }
            });
        }
    });
}

function renderRestaurantDashboard(container) {
    // Default values for Restaurant context
    const { 
        revenue = 0, 
        activeTables = 0, 
        totalTables = 0, 
        pendingKots = 0, 
        lowStockCount = 0, 
        recentSales = [], 
        currency = '$' 
    } = state.stats || {};

    const statCard = (title, value, icon, color, subValue = '') => `
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm transition-all hover:scale-[1.02]">
            <div class="flex items-center gap-4 mb-4">
                <div class="p-3 ${color}/10 ${color.replace('bg-', 'text-')} rounded-2xl">
                    <i data-lucide="${icon}" size="24"></i>
                </div>
                <span class="text-[10px] font-black uppercase text-slate-400 tracking-widest">${title}</span>
            </div>
            <h3 class="text-3xl font-black dark:text-white">${value} ${subValue}</h3>
        </div>`;

    const ordersList = (recentSales || []).map(sale => `
        <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-900 rounded-2xl border border-slate-100 dark:border-neutral-800">
            <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-white dark:bg-neutral-800 flex items-center justify-center text-slate-400">
                    <i data-lucide="receipt" size="18"></i>
                </div>
                <div>
                    <p class="text-sm font-bold dark:text-white">Order #${sale.id}</p>
                    <p class="text-[10px] text-slate-500 font-mono uppercase">${sale.payment_method}</p>
                </div>
            </div>
            <p class="font-black text-orange-600">${currency || '$'}${parseFloat(sale.total_amount).toFixed(2)}</p>
        </div>`).join('');

    container.innerHTML = `
        <div class="space-y-8 animate-in">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                ${statCard('Active Tables', activeTables, 'layout-grid', 'bg-orange-500', `<span class="text-xs text-slate-400">/ ${totalTables}</span>`)}
                ${statCard('Kitchen Orders', pendingKots, 'chef-hat', 'bg-emerald-500', `<span class="text-xs text-slate-400 font-bold uppercase tracking-tighter">Pending</span>`)}
                ${statCard('Today\'s Sales', (currency || '$') + revenue.toLocaleString(), 'banknote', 'bg-blue-500')}
                ${statCard('Stock Alerts', lowStockCount, 'package-search', 'bg-rose-500', `<span class="text-xs text-slate-400 font-bold uppercase tracking-tighter">Low</span>`)}
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm transition-colors">
                    <div class="flex justify-between items-center mb-6">
                        <h4 class="font-black dark:text-white uppercase tracking-tight">Recent Restaurant Orders</h4>
                        <a href="pos.php" class="text-[10px] font-black uppercase text-orange-600 hover:underline">New Order</a>
                    </div>
                    <div class="space-y-4">
                        ${recentSales.length > 0 ? ordersList : '<p class="text-center text-slate-400 italic text-sm py-10">No recent orders found.</p>'}
                    </div>
                </div>

                <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm flex flex-col items-center justify-center border-dashed text-center">
                    <div class="w-16 h-16 bg-slate-50 dark:bg-neutral-900 rounded-3xl flex items-center justify-center text-slate-200 dark:text-neutral-800 mb-4">
                        <i data-lucide="layout-grid" size="32"></i>
                    </div>
                    <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-4">Table Status Overview</p>
                    <a href="tables.php" class="px-8 py-4 bg-slate-900 text-white dark:bg-white dark:text-black rounded-2xl text-[10px] font-black uppercase tracking-widest hover:scale-105 transition-all shadow-lg">
                        Go to Table Management
                    </a>
                </div>
            </div>

            <div class="bg-white dark:bg-neutral-950 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm transition-colors">
                <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-6 uppercase tracking-tight">Sales Performance</h3>
                <div class="h-[300px]">
                    <canvas id="restaurantRevenueChart"></canvas>
                </div>
            </div>
        </div>`;

    api('sales/report').then(data => {
        const ctx = document.getElementById('restaurantRevenueChart');
        if (ctx && data) {
            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.map(d => d.date),
                    datasets: [{
                        label: 'Revenue',
                        data: data.map(d => d.total),
                        backgroundColor: '#f97316',
                        borderRadius: 12
                    }]
                },
                options: { 
                    responsive: true, 
                    maintainAspectRatio: false, 
                    plugins: { legend: { display: false } },
                    scales: {
                        y: { 
                            beginAtZero: true,
                            ticks: { color: '#737373', font: { weight: 'bold' } }, 
                            grid: { color: 'rgba(115, 115, 115, 0.1)', drawBorder: false } 
                        },
                        x: { 
                            ticks: { color: '#737373', font: { weight: 'bold' } }, 
                            grid: { display: false } 
                        }
                    }
                }
            });
        }
    });
}

async function renderTables(container) {
    container.innerHTML = '<div class="p-8 text-center text-slate-500 font-bold uppercase tracking-widest text-xs">Loading Tables...</div>';
    
    const tables = await api('tables') || [];
    
    const tableGrid = tables.map(t => `
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-[32px] border ${t.status === 'occupied' ? 'border-orange-500 bg-orange-500/5' : 'border-slate-200 dark:border-neutral-800'} shadow-sm transition-all hover:scale-105">
            <div class="flex justify-between items-start mb-4">
                <div class="p-3 ${t.status === 'occupied' ? 'bg-orange-500 text-white' : 'bg-slate-100 dark:bg-neutral-900 text-slate-400'} rounded-2xl">
                    <i data-lucide="utensils" size="24"></i>
                </div>
                <span class="px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${t.status === 'available' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-orange-500/10 text-orange-500'}">
                    ${t.status}
                </span>
            </div>
            <h3 class="text-xl font-black dark:text-white mb-1">Table ${t.table_number}</h3>
            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Capacity: ${t.capacity} Persons</p>
            
            <div class="mt-6 pt-6 border-t border-slate-100 dark:border-neutral-800 grid grid-cols-2 gap-2">
                <button onclick="window.location.href='pos.php?table_id=${t.id}'" class="py-2.5 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[10px] font-black uppercase tracking-widest">Order</button>
                <button onclick="toggleTableStatus(${t.id}, '${t.status}')" class="py-2.5 bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-slate-400 rounded-xl text-[10px] font-black uppercase tracking-widest">Status</button>
            </div>
        </div>
    `).join('');

    container.innerHTML = `
        <div class="space-y-8 animate-in">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Floor Management</h2>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Live Table Status & Occupancy</p>
                </div>
                <button onclick="showAddTableModal()" class="px-6 py-3 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-orange-600/20 hover:scale-105 transition-all">
                    Add New Table
                </button>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                ${tables.length > 0 ? tableGrid : `
                    <div class="col-span-full py-20 bg-white dark:bg-neutral-950 rounded-[40px] border border-dashed border-slate-200 dark:border-neutral-800 text-center">
                        <i data-lucide="layout-grid" class="mx-auto text-slate-200 mb-4" size="48"></i>
                        <p class="text-slate-400 font-bold uppercase tracking-widest text-xs">No tables found on this floor.</p>
                    </div>
                `}
            </div>
        </div>

        <!-- Add Table Modal -->
        <div id="addTableModal" class="fixed inset-0 bg-black/80 hidden flex items-center justify-center backdrop-blur-sm z-[100] p-4">
            <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-sm shadow-2xl relative">
                <h3 class="text-xl font-black dark:text-white uppercase mb-6 tracking-tight">Add Restaurant Table</h3>
                <div class="space-y-4">
                    <div>
                        <label class="text-[10px] font-black uppercase text-slate-400 mb-2 block">Table Name / Number</label>
                        <input type="text" id="new_table_number" placeholder="e.g. T-01" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                    </div>
                    <div>
                        <label class="text-[10px] font-black uppercase text-slate-400 mb-2 block">Seating Capacity</label>
                        <input type="number" id="new_table_capacity" value="2" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                    </div>
                    <button onclick="submitNewTable()" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 mt-4">Save Table</button>
                    <button onclick="document.getElementById('addTableModal').classList.add('hidden')" class="w-full py-2 text-[10px] font-black uppercase text-slate-400">Cancel</button>
                </div>
            </div>
        </div>
    `;
    lucide.createIcons();
}

window.showAddTableModal = () => document.getElementById('addTableModal').classList.remove('hidden');

window.submitNewTable = async () => {
    const table_number = document.getElementById('new_table_number').value;
    const capacity = document.getElementById('new_table_capacity').value;
    
    const res = await api('tables/add', {
        method: 'POST',
        body: JSON.stringify({ table_number, capacity })
    });
    
    if (res && res.success) {
        document.getElementById('addTableModal').classList.add('hidden');
        renderTables(document.getElementById('main-content'));
    }
};

window.toggleTableStatus = async (id, currentStatus) => {
    const newStatus = currentStatus === 'available' ? 'occupied' : 'available';
    const res = await api('tables/update_status', { method: 'POST', body: JSON.stringify({ id, status: newStatus }) });
    if (res && res.success) renderTables(document.getElementById('main-content'));
};

async function renderKOT(container) {
    container.innerHTML = '<div class="p-8 text-center text-slate-500 font-bold uppercase tracking-widest text-xs">Loading Kitchen Orders...</div>';
    
    const kots = await api('kot') || [];
    
    const kotGrid = kots.map(k => `
        <div class="bg-white dark:bg-neutral-950 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm animate-in">
            <div class="flex justify-between items-start mb-4">
                <div>
                    <h3 class="text-xl font-black dark:text-white uppercase tracking-tight">Table ${k.table_number}</h3>
                    <p class="text-[10px] text-slate-400 font-mono">Order #KOT-${k.id}</p>
                </div>
                <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase tracking-widest ${k.status === 'pending' ? 'bg-rose-500/10 text-rose-500' : 'bg-orange-500/10 text-orange-500 animate-pulse'}">
                    ${k.status}
                </span>
            </div>
            
            <div class="space-y-2 mb-6 min-h-[100px]">
                ${k.items.map(item => `
                    <div class="flex justify-between items-center text-sm font-bold dark:text-neutral-300">
                        <span>${item.name}</span>
                        <span class="text-orange-600">x${parseFloat(item.quantity).toFixed(0)}</span>
                    </div>
                `).join('')}
            </div>
            
            <div class="pt-4 border-t border-slate-100 dark:border-neutral-800 flex gap-2">
                ${k.status === 'pending' ? `
                    <button onclick="updateKOTStatus(${k.id}, 'preparing')" class="flex-1 py-3 bg-orange-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all">Start Preparing</button>
                ` : `
                    <button onclick="updateKOTStatus(${k.id}, 'served')" class="flex-1 py-3 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-emerald-600/20 active:scale-95 transition-all">Mark as Served</button>
                `}
            </div>
        </div>
    `).join('');

    container.innerHTML = `
        <div class="space-y-8">
            <div class="flex justify-between items-center">
                <div>
                    <h2 class="text-2xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Kitchen Display (KDS)</h2>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Real-time incoming food orders</p>
                </div>
                <div class="p-3 bg-white dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800 flex items-center gap-3">
                    <div class="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                    <span class="text-[10px] font-black uppercase text-slate-400 tracking-widest">Live Connection</span>
                </div>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                ${kots.length > 0 ? kotGrid : `
                    <div class="col-span-full py-20 bg-white dark:bg-neutral-950 rounded-[40px] border border-dashed border-slate-200 dark:border-neutral-800 text-center">
                        <i data-lucide="chef-hat" class="mx-auto text-slate-200 mb-4 opacity-20" size="64"></i>
                        <p class="text-slate-400 font-bold uppercase tracking-widest text-xs">Kitchen is currently empty.</p>
                    </div>
                `}
            </div>
        </div>`;
    lucide.createIcons();
}

window.updateKOTStatus = async (id, status) => {
    const res = await api('kot/update_status', { method: 'POST', body: JSON.stringify({ id, status }) });
    if (res && res.success) renderKOT(document.getElementById('main-content'));
};

function renderPOS(container) {
    const globalTax = parseFloat(state.settings.global_tax_rate || 0);
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = state.cart.reduce((sum, item) => sum + (item.price * item.quantity * ((item.tax_rate > 0 ? item.tax_rate : globalTax) / 100)), 0);
    const total = subtotal + tax;

    const productList = state.products.map(p => `
        <div onclick="addToCart(${p.id})" class="bg-white dark:bg-neutral-950 p-4 rounded-xl border border-slate-100 dark:border-neutral-800 shadow-sm hover:border-orange-500 cursor-pointer flex items-center justify-between group transition-all">
            <div class="flex items-center gap-4">
                <div class="w-10 h-10 bg-slate-50 dark:bg-neutral-900 rounded-lg flex items-center justify-center text-slate-400 group-hover:text-orange-500 transition-colors">
                    <i data-lucide="package" size="20"></i>
                </div>
                <div>
                    <h4 class="font-bold text-slate-900 dark:text-white text-sm">${p.name}</h4>
                    <p class="text-[10px] text-slate-400 font-mono uppercase tracking-tighter">${p.sku || 'No SKU'}</p>
                </div>
            </div>
            <div class="text-right">
                <div class="text-orange-600 font-black text-sm">${p.currency || state.settings.currency || '$'}${parseFloat(p.price).toFixed(2)}</div>
                <div class="text-[10px] font-bold ${p.stock_level > p.reorder_point ? 'text-emerald-500' : 'text-rose-500'}">${p.stock_level} in stock</div>
            </div>
        </div>`).join('');

    const cartItems = state.cart.length === 0
        ? `<div class="h-full flex flex-col items-center justify-center text-slate-400"><i data-lucide="shopping-cart" size="48"></i><p>Cart is empty</p></div>`
        : state.cart.map(item => `
            <div class="flex items-center gap-4">
                <div class="flex-1"><h4 class="text-sm font-bold text-slate-900 dark:text-white">${item.name}</h4><p class="text-xs text-slate-500 dark:text-neutral-400">${item.currency || state.settings.currency || '$'}${parseFloat(item.price).toFixed(2)}</p></div>
                <div class="flex items-center gap-2">
                    <button onclick="updateQuantity(${item.id}, -1)" class="p-1 hover:bg-slate-100 dark:hover:bg-neutral-800 rounded"><i data-lucide="minus" size="14"></i></button>
                    <span class="text-sm font-black w-6 text-center text-slate-900 dark:text-white">${item.quantity}</span>
                    <button onclick="updateQuantity(${item.id}, 1)" class="p-1 hover:bg-slate-100 dark:hover:bg-neutral-800 rounded"><i data-lucide="plus" size="14"></i></button>
                </div>
                <button onclick="removeFromCart(${item.id})" class="p-1 text-rose-500 hover:bg-rose-50 rounded"><i data-lucide="trash-2" size="14"></i></button>
            </div>`).join('');

    container.innerHTML = `
        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 h-[calc(100vh-12rem)]">
            <div class="lg:col-span-2 flex flex-col gap-4">
                <input type="text" placeholder="Search products..." oninput="filterProducts(this.value)" class="w-full px-4 py-4 bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-sm focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-colors">
                <div class="flex flex-col gap-2 overflow-y-auto pr-2 h-full" id="pos-products">${productList}</div>
            </div>
            <div class="bg-white dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 shadow-sm flex flex-col transition-colors">
                <div class="p-6 border-b border-slate-100 dark:border-neutral-800"><h3 class="text-lg font-bold text-slate-900 dark:text-white">Current Order</h3></div>
                <div class="flex-1 overflow-y-auto p-6 space-y-4">${cartItems}</div>
                <div class="p-6 bg-slate-50 dark:bg-neutral-900 rounded-b-2xl space-y-3 transition-colors">
                    <div class="flex justify-between text-sm text-slate-500 dark:text-neutral-400"><span>Subtotal</span><span id="pos-subtotal-display">${state.settings.currency || '$'}${subtotal.toFixed(2)}</span></div>
                    <div class="flex justify-between text-sm text-slate-500 dark:text-neutral-400"><span>Tax</span><span id="pos-tax-display">${state.settings.currency || '$'}${tax.toFixed(2)}</span></div>
                    <div class="flex justify-between text-lg font-bold text-slate-900 dark:text-white pt-2 border-t border-slate-200 dark:border-neutral-800"><span>Total</span><span id="pos-total-display">${state.settings.currency || '$'}${total.toFixed(2)}</span></div>
                    <button onclick="checkout()" ${state.cart.length === 0 ? 'disabled' : ''} class="w-full bg-orange-500 text-white py-4 rounded-xl font-bold shadow-lg shadow-orange-200 hover:bg-orange-600 disabled:opacity-50">Complete Checkout</button>
                </div>
            </div>
        </div>`;
}

function renderInventory(container) {
    const rows = state.products.map(p => `
        <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800 transition-colors">
            <td class="px-6 py-4 font-bold text-slate-900 dark:text-white">${p.name}</td>
            <td class="px-6 py-4 text-sm text-slate-500 dark:text-neutral-400">${p.sku}</td>
            <td class="px-6 py-4 text-sm text-slate-500 dark:text-neutral-400">${p.category}</td>
            <td class="px-6 py-4 text-sm font-bold text-slate-900 dark:text-white">${p.currency || '$'}${p.price.toFixed(2)}</td>
            <td class="px-6 py-4 text-sm">${p.stock_level}</td>
            <td class="px-6 py-4"><span class="px-3 py-1 rounded-full text-xs font-bold ${p.stock_level > p.reorder_point ? 'bg-emerald-100 text-emerald-600' : 'bg-rose-100 text-rose-600'}">${p.stock_level > p.reorder_point ? 'In Stock' : 'Low Stock'}</span></td>
        </tr>`).join('');

    container.innerHTML = `
        <div class="space-y-6">
            <div class="flex justify-between items-center"><h2 class="text-2xl font-bold text-slate-900 dark:text-white">Inventory Management</h2></div>
            <div class="bg-white dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 shadow-sm overflow-hidden transition-colors">
                <table class="w-full text-left"><thead class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-100 dark:border-neutral-800 transition-colors"><tr>
                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Product</th><th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">SKU</th>
                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Category</th><th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Price</th>
                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Stock</th><th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Status</th>
                </tr></thead><tbody class="divide-y divide-slate-100 dark:divide-neutral-800 transition-colors">${rows}</tbody></table>
            </div>
        </div>`;
}

function renderSuppliers(container) {
    const rows = state.suppliers.map(s => `
        <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800 transition-colors"><td class="px-6 py-4 font-bold text-slate-900 dark:text-white">${s.name}</td><td class="px-6 py-4 text-sm text-slate-500 dark:text-neutral-400">${s.contact}</td><td class="px-6 py-4 text-sm text-slate-500 dark:text-neutral-400">${s.email}</td><td class="px-6 py-4 text-sm text-slate-500 dark:text-neutral-400">${s.phone}</td></tr>
    `).join('');
    container.innerHTML = `
        <div class="space-y-6"><h2 class="text-2xl font-bold text-slate-900 dark:text-white">Supplier Management</h2>
        <div class="bg-white dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 shadow-sm overflow-hidden transition-colors">
            <table class="w-full text-left"><thead class="bg-slate-50 dark:bg-neutral-900 border-b border-slate-100 dark:border-neutral-800 transition-colors"><tr>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Supplier</th><th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Contact</th>
                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Email</th><th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Phone</th>
            </tr></thead><tbody class="divide-y divide-slate-100 dark:divide-neutral-800 transition-colors">${rows}</tbody></table>
        </div></div>`;
}

function renderReports(container) {
    container.innerHTML = `<div class="bg-white dark:bg-neutral-950 p-12 rounded-3xl border border-slate-100 dark:border-neutral-800 shadow-sm text-center space-y-4 transition-colors">
        <i data-lucide="bar-chart-3" class="mx-auto text-slate-300 dark:text-neutral-700" size="64"></i>
        <h3 class="text-xl font-bold text-slate-900 dark:text-white">Reports & Analytics</h3>
        <p class="text-slate-500 dark:text-neutral-400">This section will contain detailed reports and analytics in the future.</p>
    </div>`;
}

function renderSettings(container) {
    const s = state.settings;
    const { 
        storageUsage = 0,
        storageLimit = 1 
    } = state.stats || {};
    const storagePercent = Math.min(100, (storageUsage / storageLimit) * 100).toFixed(0);
    const storageRemaining = Math.max(0, storageLimit - storageUsage).toFixed(2);

    container.innerHTML = `
        <div class="max-w-2xl mx-auto space-y-8 animate-in">
            <!-- Storage Monitor & Plan Management -->
            <div class="bg-white dark:bg-neutral-950 p-8 rounded-3xl border border-slate-100 dark:border-neutral-800 shadow-sm transition-colors">
                <div class="flex items-center justify-between mb-8">
                    <h3 class="text-xl font-bold text-slate-900 dark:text-white flex items-center gap-2">
                        <i data-lucide="database" class="text-amber-500"></i> Storage Monitor
                    </h3>
                    <button onclick="alert('Redirecting to upgrade page...')" class="text-xs font-black uppercase tracking-widest text-orange-500 hover:text-orange-600 transition-colors border-b-2 border-orange-500/20 pb-1">Upgrade Plan</button>
                </div>
                
                <div class="flex items-end gap-2 mb-4">
                    <div>
                        <p class="text-4xl font-black text-slate-900 dark:text-white leading-none">${storageUsage.toFixed(2)} MB <span class="text-sm font-medium text-slate-400">/ ${storageLimit} MB</span></p>
                        <p class="text-xs text-slate-500 dark:text-neutral-500 mt-2 font-bold uppercase tracking-wider">${storageRemaining} MB Space Remaining</p>
                    </div>
                </div>
                
                <div class="w-full bg-slate-100 dark:bg-neutral-800 rounded-full h-4 mb-4 overflow-hidden">
                    <div class="bg-amber-500 h-full rounded-full shadow-[0_0_15px_rgba(245,158,11,0.4)] transition-all duration-1000" style="width: ${storagePercent}%"></div>
                </div>
                <p class="text-xs text-slate-400 dark:text-neutral-600 italic">Your storage includes database records, product images, and generated reports.</p>
            </div>

            <!-- General Settings Form -->
            <div class="bg-white dark:bg-neutral-950 p-8 rounded-3xl border border-slate-100 dark:border-neutral-800 shadow-sm transition-colors">
                <h3 class="text-xl font-bold text-slate-900 dark:text-white mb-6 flex items-center gap-2"><i data-lucide="settings" class="text-orange-500"></i> General Settings</h3>
                <form onsubmit="saveSettings(event)" class="space-y-6">
                    <div><label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Business Name</label><input name="business_name" value="${s.business_name || ''}" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl transition-colors outline-none focus:border-orange-500"></div>
                    <div class="grid grid-cols-2 gap-4">
                        <div><label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Global Tax Rate (%)</label><input name="global_tax_rate" type="number" value="${s.global_tax_rate || ''}" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl transition-colors outline-none focus:border-orange-500"></div>
                        <div><label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Currency</label><input name="currency" value="${s.currency || ''}" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl transition-colors outline-none focus:border-orange-500"></div>
                    </div>
                    <button type="submit" class="w-full bg-orange-500 text-white py-4 rounded-xl font-bold shadow-lg shadow-orange-200 hover:shadow-orange-300 transition-all active:scale-[0.98]">Save Configuration</button>
                </form>
            </div>
        </div>`;
}

// --- POS & Cart Functions ---
function addToCart(id) {
    const product = state.products.find(p => p.id === id);
    const existing = state.cart.find(item => item.id === id);
    if (existing) {
        existing.quantity++;
    } else {
        state.cart.push({ ...product, quantity: 1 });
    }
    render();
}

function updateQuantity(id, delta) {
    const item = state.cart.find(i => i.id === id);
    if (item) {
        item.quantity += delta;
        if (item.quantity <= 0) {
            removeFromCart(id);
        } else {
            render();
        }
    }
}

function removeFromCart(id) {
    state.cart = state.cart.filter(i => i.id !== id);
    render();
}

async function checkout() {
    if (state.cart.length === 0) return;
    const globalTax = parseFloat(state.settings.global_tax_rate || 0);
    const subtotal = state.cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = state.cart.reduce((sum, item) => sum + (item.price * item.quantity * ((item.tax_rate > 0 ? item.tax_rate : globalTax) / 100)), 0);
    
    const result = await api('pos/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            items: state.cart,
            total_amount: subtotal + tax,
            tax_amount: tax,
            payment_method: 'Cash'
        })
    });

    if (result && result.success) {
        alert("Checkout successful!");
        state.cart = [];
        await initializeApp(); // Refresh all data
    }
}

function filterProducts(query) {
    const productContainer = document.getElementById('pos-products');
    if (!productContainer) return;
    const products = productContainer.children;
    for (const product of products) {
        const name = product.querySelector('h4').textContent.toLowerCase();
        product.style.display = name.includes(query.toLowerCase()) ? '' : 'none';
    }
}

// --- Settings Functions ---
async function saveSettings(event) {
    event.preventDefault();
    const formData = new FormData(event.target);
    const data = Object.fromEntries(formData.entries());
    
    const result = await api('settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
    });

    if (result && result.success) {
        alert("Settings saved!");
        await initializeApp();
    }
}

// --- Initialization ---
async function initializeApp() {
    // Fetch all initial data in parallel
    const [stats, products, settings, suppliers] = await Promise.all([
        api('dashboard/stats'),
        api('products'),
        api('settings'),
        api('suppliers')
    ]);

    // Update state
    state.stats = stats;
    state.products = products || [];
    state.settings = settings;
    state.suppliers = suppliers || [];

    // Set the active tab based on URL or default
    state.activeTab = state.initialActiveTab;
    // Set date in header
    document.getElementById('current-date').textContent = new Date().toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric' });

    // Initial render
    render();
}

// Start the app when the DOM is ready
document.addEventListener('DOMContentLoaded', initializeApp);
