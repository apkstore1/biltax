<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Self-healing: Table for QR Configs
try {
    $tenant_conn->exec("CREATE TABLE IF NOT EXISTS payment_qr_configs (
        id INT PRIMARY KEY AUTO_INCREMENT,
        method_name VARCHAR(100),
        account_title VARCHAR(255),
        account_no VARCHAR(100),
        payment_url TEXT,
        is_active TINYINT(1) DEFAULT 1
    )");
} catch(Exception $e) {}

// Handle Save
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'save_qr') {
    $stmt = $tenant_conn->prepare("INSERT INTO payment_qr_configs (method_name, account_title, account_no, payment_url) VALUES (?, ?, ?, ?)");
    $stmt->execute([$_POST['method'], $_POST['title'], $_POST['no'], $_POST['url']]);
    header("Location: payment_qr.php?msg=saved"); exit;
}

$methods = $tenant_conn->query("SELECT * FROM payment_qr_configs WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Payment QR Generator | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/qrcodejs@1.0.0/qrcode.min.js"></script>
    <script src="theme.js"></script>
    <style>@media print { .no-print { display: none !important; } .print-area { display: block !important; } body { background: white !important; } }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 no-print">
        <header class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Payment QR Generator</h1>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Create QR codes for your customers to pay online</p>
            </div>
            <button onclick="document.getElementById('addQrModal').classList.remove('hidden')" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-orange-600/20">Add New Method</button>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <?php foreach($methods as $m): ?>
            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl text-center group">
                <div id="qr-<?= $m['id'] ?>" class="flex justify-center mb-6 p-4 bg-white rounded-3xl"></div>
                <h3 class="text-xl font-black dark:text-white uppercase"><?= htmlspecialchars($m['method_name']) ?></h3>
                <p class="text-sm font-bold text-orange-600"><?= htmlspecialchars($m['account_title']) ?></p>
                <p class="text-xs text-slate-500 font-mono mt-1"><?= htmlspecialchars($m['account_no']) ?></p>
                <button onclick="printQr('qr-<?= $m['id'] ?>', '<?= $m['method_name'] ?>', '<?= $m['account_title'] ?>')" class="mt-6 w-full py-3 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl text-[10px] font-black uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-all">Print QR Card</button>
                <script>new QRCode(document.getElementById("qr-<?= $m['id'] ?>"), { text: "<?= $m['payment_url'] ?: $m['account_no'] ?>", width: 150, height: 150 });</script>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <div id="addQrModal" class="fixed inset-0 bg-black/80 flex hidden items-center justify-center p-4 z-50">
        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] w-full max-w-md border border-slate-200 dark:border-neutral-800">
            <h2 class="text-2xl font-black dark:text-white uppercase mb-6 text-center">Payment Details</h2>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="save_qr">
                <input type="text" name="method" placeholder="Bank Name / Wallet (e.g. EasyPaisa)" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                <input type="text" name="title" placeholder="Account Title" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                <input type="text" name="no" placeholder="Account / IBAN Number" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                <input type="text" name="url" placeholder="Payment URL (Optional)" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl">Generate & Save</button>
                <button type="button" onclick="this.closest('#addQrModal').classList.add('hidden')" class="w-full text-slate-400 text-xs font-bold uppercase mt-2">Cancel</button>
            </form>
        </div>
    </div>

    <div id="print-view" class="hidden fixed inset-0 bg-white items-center justify-center p-20 flex-col text-center print-area">
        <h1 class="text-4xl font-black uppercase mb-2"><?= htmlspecialchars($business_name) ?></h1>
        <p class="text-xl font-bold text-orange-600 mb-10">Scan to Pay Online</p>
        <div id="print-qr-target" class="mb-10 flex justify-center scale-150"></div>
        <h2 id="print-method" class="text-3xl font-black uppercase"></h2>
        <p id="print-title" class="text-xl font-bold text-slate-500"></p>
    </div>

    <script>
        lucide.createIcons();
        function printQr(divId, method, title) {
            document.getElementById('print-method').innerText = method;
            document.getElementById('print-title').innerText = title;
            document.getElementById('print-qr-target').innerHTML = document.getElementById(divId).innerHTML;
            window.print();
        }
    </script>
</body>
</html>