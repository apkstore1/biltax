<?php
require_once 'config/db_switch.php';

if (!$tenant_conn || !isset($_GET['sale_id'])) {
    die("Unauthorized or Invalid Request");
}

$sale_id = (int)$_GET['sale_id'];

// 1. Fetch KOT Details
$stmt = $tenant_conn->prepare("SELECT k.*, t.table_number 
                               FROM kot k 
                               LEFT JOIN restaurant_tables t ON k.table_id = t.id 
                               WHERE k.sale_id = ?");
$stmt->execute([$sale_id]);
$kot = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$kot) die("KOT record not found.");

// 2. Fetch Items
$stmt_items = $tenant_conn->prepare("SELECT si.quantity, p.name 
                                     FROM sale_items si 
                                     JOIN products p ON si.product_id = p.id 
                                     WHERE si.sale_id = ?");
$stmt_items->execute([$sale_id]);
$items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head>
    <title>KOT #<?= $kot['id'] ?></title>
    <style>
        body { font-family: 'Courier New', Courier, monospace; width: 80mm; margin: 0 auto; padding: 10px; color: #000; }
        .text-center { text-align: center; }
        .bold { font-weight: bold; }
        .divider { border-top: 2px solid #000; margin: 10px 0; }
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; }
        .item-row td { padding: 5px 0; font-size: 18px; font-weight: bold; }
        .header { margin-bottom: 10px; }
        @media print {
            @page { margin: 0; }
            body { margin: 0; padding: 5mm; }
        }
    </style>
</head>
<body onload="window.print(); setTimeout(() => window.close(), 1000);">
    <div class="header text-center">
        <h1 style="margin: 0; font-size: 24px;">KITCHEN TOKEN</h1>
        <div class="bold" style="font-size: 28px;"><?= $kot['table_number'] ? 'Table: ' . htmlspecialchars($kot['table_number']) : 'TAKEAWAY / NO TABLE' ?></div>
    </div>

    <div class="divider"></div>
    
    <div style="font-size: 14px;">
        <span>KOT ID: #<?= $kot['id'] ?></span><br>
        <span>Time: <?= date('H:i:s', strtotime($kot['created_at'])) ?></span>
    </div>

    <div class="divider"></div>

    <table>
        <thead>
            <tr>
                <th style="font-size: 14px;">ITEM</th>
                <th style="font-size: 14px; text-align: right;">QTY</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
            <tr class="item-row">
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td style="text-align: right;">x<?= (int)$item['quantity'] ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="divider"></div>
    
    <div class="text-center bold" style="font-size: 12px;">
        *** End of KOT ***
    </div>
</body>
</html>