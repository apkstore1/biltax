<?php
/**
 * Biltax Manual Cron Trigger Wrapper
 * Used to test background tasks via browser.
 */

define('CRON_RUNNING', true);

// 1. Security Check
$secret_key = 'biltax_test_786';
if (!isset($_GET['key']) || $_GET['key'] !== $secret_key) {
    http_response_code(403);
    die("<div style='font-family:sans-serif; padding:50px; text-align:center;'>
            <h1 style='color:red;'>🛑 Access Denied</h1>
            <p>Invalid Security Key.</p>
         </div>");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Biltax Cron Monitor</title>
    <style>
        body { background: #0a0a0a; color: #d4d4d4; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 40px; }
        .container { max-width: 800px; margin: 0 auto; }
        .card { background: #1a1a1a; border: 1px solid #333; padding: 25px; border-radius: 20px; margin-bottom: 20px; }
        .log-box { background: #000; padding: 15px; border-radius: 10px; font-family: monospace; font-size: 12px; color: #4ade80; border-left: 4px solid #f97316; margin-top: 10px; }
        .success-badge { color: #22c55e; font-weight: bold; }
        .title { color: #f97316; text-transform: uppercase; letter-spacing: 2px; font-size: 14px; margin-bottom: 15px; display: block; }
        .timestamp { color: #666; font-size: 11px; float: right; }
    </style>
</head>
<body>
    <div class="container">
        <h1 style="color:white; margin-bottom:30px;">🚀 Biltax Cron Engine <span style="font-size:12px; font-weight:normal; color:#666;">(Manual Trigger Mode)</span></h1>

        <?php
        // Files to execute
        $cron_files = [
            'Storage Update'    => ['path' => 'config/cron_storage_update.php', 'type' => 'cli'],
            'Billing Engine'    => ['path' => 'config/universal_cron.php', 'type' => 'cli'],
            'Service Reminders' => ['path' => 'universal_cron.php', 'type' => 'http', 'secret' => 'BILTAX_SECRET_786']
        ];

        // Solve hostname resolution issues by using local loopback with a Host header
        $host = $_SERVER['HTTP_HOST'];
        $base_http_url = "http://127.0.0.1/ims/";

        /**
         * Advanced PHP CLI Resolver
         * Securely resolves the absolute path to the PHP CLI binary.
         */
        $php_path = PHP_BINDIR . '/php'; // Method 1: Use PHP's internal bin directory
        if (!@is_executable($php_path)) {
            // Method 2: Strip web suffixes from current binary
            $php_path = preg_replace('/-(fpm|cgi|lsphp|apache2).*/i', '', PHP_BINARY);
        }
        
        // Final validation: Ensure it's not a directory and is executable
        if (!@is_executable($php_path) || @is_dir($php_path)) {
            if (@is_executable("/usr/bin/php")) $php_path = "/usr/bin/php";
            else $php_path = 'php'; // System PATH fallback
        }

        foreach ($cron_files as $name => $details) {
            $full_path = __DIR__ . '/' . $details['path'];
            $timestamp = date('H:i:s');

            echo "<div class='card'>";
            echo "<span class='timestamp'>Triggered at $timestamp</span>";
            echo "<span class='title'>Task: $name</span>";

            $output = "";
            if ($details['type'] === 'cli') {
                if (file_exists($full_path)) {
                    // Use dynamically discovered PHP path to solve "not found" error
                    $cmd = "$php_path " . escapeshellarg($full_path);
                    $output = shell_exec($cmd . " 2>&1");

                    if (strpos($output, 'not found') !== false || strpos($output, 'Permission denied') !== false) {
                        echo "<div style='color:#e11d48; font-weight:bold;'>❌ " . htmlspecialchars($name) . " failed to launch.</div>";
                    } else {
                        echo "<div class='success-badge'>✅ " . htmlspecialchars($name) . " executed successfully.</div>";
                    }
                    echo "<div class='log-box'>" . nl2br(htmlspecialchars($output ?: "Process finished with no output (Success).")) . "</div>";
                } else {
                    echo "<div style='color:red;'>❌ Error: File not found at " . htmlspecialchars($details['path']) . "</div>";
                }
            } elseif ($details['type'] === 'http') {
                $http_url = $base_http_url . $details['path'] . "?key=" . $details['secret'];
                
                // Use stream_context_create for better error handling with file_get_contents
                $context_options = stream_context_create([
                    'http' => [
                        'method' => 'GET',
                        'header' => "Host: $host\r\nUser-Agent: Biltax Cron Wrapper (HTTP Call)\r\n",
                        'ignore_errors' => true // Capture HTTP errors in output
                    ]
                ]);
                $output = @file_get_contents($http_url, false, $context_options); // @ to suppress PHP warnings
                
                if ($output === false) {
                    $output = "Failed to fetch HTTP URL: " . htmlspecialchars($http_url) . ". Check if web server is running and URL is correct.";
                    echo "<div style='color:red;'>❌ Error: " . htmlspecialchars($name) . " execution failed.</div>";
                    echo "<div class='log-box'>" . nl2br(htmlspecialchars($output)) . "</div>";
                } else {
                    echo "<div class='success-badge'>✅ " . htmlspecialchars($name) . " executed successfully (via HTTP).</div>";
                    echo "<div class='log-box'>" . nl2br(htmlspecialchars($output)) . "</div>";
                }
            } else {
                echo "<div style='color:red;'>❌ Error: File not found at $path</div>";
            }
            echo "</div>";
            
            // Small pause between executions to prevent race conditions
            usleep(500000); 
        }
        ?>

        <footer style="text-align:center; margin-top:50px; color:#444; font-size:11px;">
            Biltax Automated Systems &bull; Temporary Testing Utility
        </footer>
    </div>
</body>
</html>