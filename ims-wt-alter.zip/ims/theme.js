/**
 * Biltax Theme Manager
 * Handles Dark/Light mode toggling and persistence.
 */

// Configure Tailwind to use class-based dark mode
if (typeof tailwind !== 'undefined') {
    tailwind.config = {
        darkMode: 'class',
        theme: {
            extend: {
                colors: {
                    // Ensure Biltax Orange is available (matches Tailwind orange-500/600)
                    primary: {
                        500: '#f97316',
                        600: '#ea580c',
                    }
                }
            }
        }
    };
}

const ThemeManager = {
    init() {
        this.apply();
        window.addEventListener('DOMContentLoaded', () => this.apply());
    },

    apply() {
        const savedTheme = localStorage.getItem('theme');
        const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
        const isDark = savedTheme === 'dark' || (!savedTheme && systemDark);

        if (isDark) {
            document.documentElement.classList.add('dark');
            document.body?.classList.remove('light-theme');
        } else {
            document.documentElement.classList.remove('dark');
            document.body?.classList.add('light-theme');
        }

        // Update the icon in the sidebar
        const themeIcon = document.getElementById('theme-icon');
        if (themeIcon) {
            const newIcon = isDark ? 'sun' : 'moon';
            themeIcon.setAttribute('data-lucide', newIcon);
            if (typeof lucide !== 'undefined') lucide.createIcons();
        }

        // Update the text next to the theme icon
        const themeText = document.getElementById('theme-text');
        if (themeText) {
            themeText.textContent = isDark ? 'Light Mode' : 'Dark Mode';
        }
    },

    toggle() {
        const currentlyDark = document.documentElement.classList.contains('dark');
        localStorage.setItem('theme', currentlyDark ? 'light' : 'dark');
        this.apply();
    }
};

// Initialize Theme on Load
ThemeManager.init();

// Expose toggle function globally for UI buttons
window.toggleTheme = () => ThemeManager.toggle();
