<?php
require_once 'config/db_switch.php';
require_once 'config/currency_helper.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

try {
    $stmt = $m_pdo->query("SELECT * FROM packages ORDER BY price ASC");
    $plans = $stmt->fetchAll(PDO::FETCH_ASSOC);
    $rates = getExchangeRates();
    $current_status = $_SESSION['subscription_status'] ?? 'inactive';

    // Get current currency rate for initial PHP rendering
    $curr_code = (isset($t_conf['currency_code']) && !empty($t_conf['currency_code'])) ? $t_conf['currency_code'] : 'USD';
    $current_rate = $rates[$curr_code] ?? 1.0;
    $currency_symbol = $t_conf['currency_symbol'] ?? '$';

    // Fetch detailed current subscription info for the info bar
    $sub_details = null;
    $stmt_sub = $m_pdo->prepare("SELECT s.*, p.package_name, p.price, p.yearly_price 
                                FROM subscriptions s 
                                JOIN packages p ON s.plan_id = p.id 
                                WHERE s.tenant_id = ? 
                                ORDER BY s.id DESC LIMIT 1");
    $stmt_sub->execute([$t_conf['id'] ?? 0]);
    $sub_details = $stmt_sub->fetch(PDO::FETCH_ASSOC);

    $current_active_plan_id = ($sub_details && isset($sub_details['plan_id'])) ? $sub_details['plan_id'] : null;

    $days_left = 0;
    if ($sub_details && $sub_details['expiry_date']) {
        $today = new DateTime();
        $expiry = new DateTime($sub_details['expiry_date']);
        if ($expiry > $today) {
            $interval = $today->diff($expiry);
            $days_left = (int)$interval->format('%a');
        }
    }

    // Fetch pending billing requests for this tenant
    $stmt_pending = $m_pdo->prepare("SELECT package_id FROM billing WHERE tenant_id = ? AND status = 'pending'");
    $stmt_pending->execute([$t_conf['id'] ?? 0]); // Use null-coalescing for safety
    $pending_plans = $stmt_pending->fetchAll(PDO::FETCH_COLUMN);

    // Fetch Billing Adjustments for current tenant to calculate renewal amount
    $adjustments = [];
    $adj_sum = 0;
    if (isset($t_conf['id'])) { // Check if $t_conf['id'] is set before using
        $stmt_adj = $m_pdo->prepare("SELECT * FROM billing_adjustments WHERE tenant_id = ?");
        $stmt_adj->execute([$t_conf['id']]);
        $adjustments = $stmt_adj->fetchAll(PDO::FETCH_ASSOC);
        foreach ($adjustments as $adj) { $adj_sum += ($adj['type'] === 'discount') ? -(float)$adj['amount'] : (float)$adj['amount']; }
    }
} catch (Exception $e) { $plans = []; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Subscription Plans | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
        .plan-card:hover { transform: translateY(-5px); border-color: #f97316; }
        .switch-input:checked + .switch-label { background-color: #f97316; }
        .switch-input:checked + .switch-label .switch-dot { transform: translateX(20px); }
    </style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 overflow-y-auto">
        <?php include 'topbar.php'; ?>
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black dark:text-white tracking-tight uppercase">Billing Center</h1>
                <p class="text-sm text-slate-500 dark:text-neutral-400 font-medium">Manage your subscription, plans and billing history.</p>
            </div>
        </header>

        <!-- Currency Selector -->
        <div class="max-w-6xl mx-auto flex justify-end mb-4">
            <div class="flex items-center gap-2 bg-white dark:bg-neutral-900 px-4 py-2 rounded-2xl border border-slate-200 dark:border-neutral-800 shadow-sm">
                <i data-lucide="globe" size="14" class="text-slate-400"></i>
                <select id="currency-selector" onchange="updateCurrency(this.value)" class="bg-transparent text-xs font-black uppercase outline-none text-orange-600 dark:text-orange-500 cursor-pointer">
                    <option value="USD" data-symbol="$" <?= (($t_conf['currency_code'] ?? 'USD') === 'USD') ? 'selected' : '' ?>>USD ($)</option>
                    <option value="PKR" data-symbol="Rs" <?= (($t_conf['currency_code'] ?? '') === 'PKR') ? 'selected' : '' ?>>PKR (Rs)</option>
                    <option value="AED" data-symbol="د.إ" <?= (($t_conf['currency_code'] ?? '') === 'AED') ? 'selected' : '' ?>>AED (د.إ)</option>
                    <option value="SAR" data-symbol="ر.س" <?= (($t_conf['currency_code'] ?? '') === 'SAR') ? 'selected' : '' ?>>SAR (ر.س)</option>
                </select>
            </div>
            <a href="billing_history.php" class="px-5 py-2.5 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl text-[10px] font-black uppercase tracking-widest text-slate-600 dark:text-slate-300 hover:text-orange-500 transition-all flex items-center gap-2 shadow-sm">
                <i data-lucide="history" size="14"></i> Billing History
            </a>
        </div>

        <?php
        if (isset($_GET['lock']) && $_GET['lock'] === 'true') {
            $lock_message = "Your account is currently locked. Please upgrade your plan to regain full access.";
            $alert_class = "bg-rose-500/10 text-rose-500 border-rose-500/20";
            $icon = "lock";

            if (isset($_GET['reason'])) {
                if ($_GET['reason'] === 'storage_full') {
                    $lock_message = "Your account has reached its storage limit. Please upgrade your plan to continue using all features.";
                    $icon = "database";
                } elseif ($_GET['reason'] === 'subscription_expired') {
                    $lock_message = "Your subscription has expired. Please renew or upgrade your plan to regain full access.";
                    $icon = "calendar-x";
                }
            }
        ?>
            <div class="mb-6 p-4 <?= $alert_class ?> rounded-2xl text-sm font-bold animate-in fade-in duration-300 flex items-center gap-3">
                <i data-lucide="<?= $icon ?>" size="20"></i>
                <span><?= htmlspecialchars($lock_message) ?></span>
            </div>
        <?php } ?>
        <!-- Current Subscription Bar -->
        <?php if ($sub_details): ?>
        <div class="mb-12 p-6 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[32px] shadow-sm flex flex-col md:flex-row items-center justify-between gap-6 max-w-6xl mx-auto">
            <div class="flex items-center gap-4">
                <div class="w-14 h-14 bg-orange-600/10 text-orange-600 rounded-2xl flex items-center justify-center">
                    <i data-lucide="shield-check" size="28"></i>
                </div>
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">Active Plan</p>
                    <h3 class="text-xl font-black dark:text-white uppercase"><?= htmlspecialchars($sub_details['package_name']) ?></h3>
                </div>
            </div>
            
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 flex-1 px-0 md:px-10 border-t md:border-t-0 md:border-l border-slate-100 dark:border-neutral-800 pt-6 md:pt-0">
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Activated On</p>
                    <p class="text-xs font-bold dark:text-white"><?= date('M d, Y', strtotime($sub_details['start_date'])) ?></p>
                </div>
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Expiry Date</p>
                    <p class="text-xs font-bold dark:text-white"><?= date('M d, Y', strtotime($sub_details['expiry_date'])) ?></p>
                </div>
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Remaining Time</p>
                    <p class="text-xs font-black <?= $days_left <= 5 ? 'text-rose-500' : 'text-emerald-500' ?>">
                        <?= ($sub_details['status'] === 'expired') ? 'Expired' : $days_left . ' Days Left' ?>
                    </p>
                </div>
                <div>
                    <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Quotas</p>
                    <p class="text-[10px] font-bold text-slate-500"><?= $t_conf['staff_limit'] ?> Staff / <?= $t_conf['branch_limit'] ?> Branch</p>
                </div>
            </div>

            <div class="flex items-center gap-3">
                <span class="px-4 py-2 rounded-xl text-[10px] font-black uppercase border <?= $sub_details['status'] === 'active' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20' ?>">
                    <?= $sub_details['status'] ?>
                </span>
                <?php
                    // Calculate total amount for renewal including adjustments
                    $renewal_base_price = ($sub_details && isset($sub_details['billing_cycle']) && $sub_details['billing_cycle'] === 'secondary') ? ((float)($sub_details['yearly_price'] ?? 0) ?? (float)($sub_details['price'] ?? 0)) : ((float)($sub_details['price'] ?? 0) ?? 0);
                    $renewal_amount_converted = ($renewal_base_price * $current_rate) + $adj_sum; // $adj_sum is already in local currency
                ?>
                <?php if ($sub_details && $days_left <= 1 && ($sub_details['status'] === 'active' || $sub_details['status'] === 'expired') && $renewal_amount_converted > 0): ?>
                    <button onclick="renewSubscription(<?= (int)$sub_details['plan_id'] ?>, <?= (float)$renewal_amount_converted ?>, '<?= htmlspecialchars($sub_details['billing_cycle'] ?? '1_month') ?>', '<?= (int)$sub_details['plan_id'] ?>', '<?= htmlspecialchars($sub_details['expiry_date'] ?? 'null') ?>')" class="px-5 py-2.5 bg-orange-600 text-white rounded-xl text-[10px] font-black uppercase shadow-lg shadow-orange-600/20 active:scale-95 transition-all">Renew Now</button>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>

        <!-- Global Billing Cycle Toggle -->
        <div class="max-w-6xl mx-auto flex items-center justify-center gap-4 mb-12">
            <span class="text-xs font-black uppercase transition-colors duration-300 text-orange-600" id="monthly-label">Monthly</span>
            <label class="relative inline-flex items-center cursor-pointer">
                <input type="checkbox" id="global-cycle-toggle" class="sr-only peer">
                <div class="w-14 h-7 bg-slate-200 dark:bg-neutral-800 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[4px] after:left-[4px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600 shadow-inner"></div>
            </label>
            <span class="text-xs font-black uppercase transition-colors duration-300 text-slate-400" id="yearly-label">Yearly <span class="text-[10px] text-emerald-500 ml-1 font-black tracking-tighter">(Save Big)</span></span>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <?php foreach($plans as $plan): 
                $price_val = (float)($plan['price'] ?? 0);
                $yearly_price = (float)($plan['yearly_price'] ?? 0);
                
                if ($price_val == 0 && $current_status !== 'trial') continue;
                
                $is_active = (isset($t_conf['package_id']) && $plan['id'] == $t_conf['package_id']);
                $is_pending = in_array($plan['id'], $pending_plans);
            ?>
            <div class="plan-card bg-white dark:bg-neutral-900 p-8 rounded-[48px] border <?= $is_active ? 'border-orange-500 ring-4 ring-orange-500/10' : 'border-slate-200 dark:border-neutral-800' ?> shadow-xl flex flex-col transition-all relative">
                <h3 class="text-xl font-black dark:text-white uppercase mb-2"><?= htmlspecialchars($plan['package_name'] ?? 'Custom Plan') ?></h3>
                <div class="flex items-baseline gap-1 mb-8 price-container">
                    <span class="text-5xl font-black text-orange-600"><span class="currency-symbol"><?= $currency_symbol ?></span><span class="price-display" 
                        data-base="<?= $price_val ?>" 
                        data-secondary="<?= $yearly_price ?>"
                        data-p-cycle="<?= str_replace('_', ' ', $plan['primary_cycle']) ?>"
                        data-s-cycle="<?= str_replace('_', ' ', $plan['secondary_cycle']) ?>"
                    ><?= number_format($price_val * $current_rate, 0) ?></span></span>
                    <span class="text-xs font-bold text-slate-500 uppercase cycle-label">/ <?= str_replace('_', ' ', $plan['primary_cycle'] ?? 'month') ?></span>
                </div>

                <div class="space-y-4 mb-10 flex-1">
                    <div class="flex items-center gap-3 text-xs font-bold dark:text-neutral-300"><i data-lucide="check-circle" class="text-emerald-500" size="16"></i> <?= $plan['staff_limit'] ?> Staff Members</div>
                    <div class="flex items-center gap-3 text-xs font-bold dark:text-neutral-300"><i data-lucide="check-circle" class="text-emerald-500" size="16"></i> <?= $plan['storage_limit'] ?> MB Storage</div>
                </div>

                <?php if ($is_active): ?>
                    <button disabled class="w-full py-5 bg-slate-100 dark:bg-neutral-800 text-slate-400 rounded-3xl font-black uppercase text-xs cursor-not-allowed">Active Plan</button>
                <?php elseif ($is_pending): ?>
                    <button disabled class="w-full py-5 bg-amber-100 dark:bg-amber-900/20 text-amber-600 rounded-3xl font-black uppercase text-xs cursor-not-allowed border border-amber-200 dark:border-amber-500/30">Pending Approval</button>
                <?php else: ?>
                    <button onclick="requestActivation(<?= $plan['id'] ?>, this)" class="w-full py-5 bg-orange-600 text-white rounded-3xl font-black uppercase text-xs hover:scale-105 transition-all">Select & Pay</button>
                <?php endif; ?>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <script>
        lucide.createIcons();

        const exchangeRates = <?= json_encode($rates) ?>;
        let currentCurrencySymbol = '<?= $currency_symbol ?>'; 
        let currentCurrencyCode = '<?= $curr_code ?>'; 

        // Function to update all package prices based on selected currency and cycle
        function updateAllPackagePrices() {
            const rate = parseFloat(exchangeRates[currentCurrencyCode] || 1);
            const isYearlySelected = document.getElementById('global-cycle-toggle').checked;

            document.querySelectorAll('.plan-card').forEach(card => {
                const priceEl = card.querySelector('.price-display');
                const cycleEl = card.querySelector('.cycle-label');
                const currencySymbolEl = card.querySelector('.currency-symbol');
                
                if(!priceEl) return;

                const basePriceUSD = parseFloat(priceEl.dataset.base || 0);
                const secondaryPriceUSD = parseFloat(priceEl.dataset.secondary || 0);

                let priceToDisplay = 0;
                let cycleText = '';

                if (isYearlySelected && secondaryPriceUSD > 0) {
                    priceToDisplay = secondaryPriceUSD * rate;
                    cycleText = priceEl.dataset.sCycle || 'year';
                    card.dataset.selectedCycle = 'secondary';
                } else {
                    priceToDisplay = basePriceUSD * rate;
                    cycleText = priceEl.dataset.pCycle || 'month';
                    card.dataset.selectedCycle = 'primary';
                }
                
                if(currencySymbolEl) currencySymbolEl.innerText = currentCurrencySymbol;
                priceEl.innerText = Math.round(priceToDisplay).toLocaleString();
                priceEl.dataset.current = priceToDisplay; 
                if(cycleEl) cycleEl.innerText = '/ ' + cycleText;
            });
        }

        async function updateCurrency(code) {
            const select = document.getElementById('currency-selector');
            const symbol = select.options[select.selectedIndex].dataset.symbol;
            
            currentCurrencyCode = code; // Update global variable
            currentCurrencySymbol = symbol; // Update global variable

            // Update UI immediately
            updateAllPackagePrices();

            // Persist to database via API
            const res = await fetch('api.php?route=billing/update_currency', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ currency_code: code, currency_symbol: symbol })
            });

            const data = await res.json();
            if(!data.success) {
                alert("Error saving currency preference: " + data.message);
            }
            // No page reload needed, UI is already updated
        }

        // Global Cycle Toggle Logic
        document.getElementById('global-cycle-toggle').addEventListener('change', function() {
            updateAllPackagePrices(); // Re-calculate prices based on new cycle and current currency

            // Update Labels UI
            const isYearly = this.checked;
            document.getElementById('monthly-label').classList.toggle('text-orange-600', !isYearly);
            document.getElementById('monthly-label').classList.toggle('text-slate-400', isYearly);
            document.getElementById('yearly-label').classList.toggle('text-orange-600', isYearly);
            document.getElementById('yearly-label').classList.toggle('text-slate-400', !isYearly);
        });

        function requestActivation(id, btn) {
            const card = btn.closest('.plan-card');
            const priceDisplay = card.querySelector('.price-display');
            const price = priceDisplay.dataset.current || parseFloat(priceDisplay.dataset.base) * (exchangeRates[currentCurrencyCode] || 1); // Use converted price
            const cycle = card.dataset.selectedCycle || '1_month'; // Default to '1_month' if not set
            const currentPlanId = '<?= $current_active_plan_id ?? 'null' ?>'; // Pass 'null' string if not set
            const currentExpiryDate = '<?= ($sub_details && isset($sub_details['expiry_date'])) ? $sub_details['expiry_date'] : 'null' ?>'; // Pass 'null' string if not set

            // New Redirect Logic
            window.location.href = `pay_now.php?plan_id=${id}&amount=${price}&cycle=${cycle}&current_plan_id=${currentPlanId}&current_expiry_date=${currentExpiryDate}`;
        }

        function renewSubscription(planId, amount, cycle) {
            const currentPlanId = '<?= $current_active_plan_id ?? 'null' ?>';
            const currentExpiryDate = '<?= ($sub_details && isset($sub_details['expiry_date'])) ? $sub_details['expiry_date'] : 'null' ?>';
            window.location.href = `pay_now.php?plan_id=${planId}&amount=${amount}&cycle=${cycle}&current_plan_id=${currentPlanId}&current_expiry_date=${currentExpiryDate}`;
        }
    </script>
</body>
</html>