<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Module Restriction
if (!has_module('jobs')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

// AJAX Handler: Fetch Service Checklist
if (isset($_GET['ajax_action']) && $_GET['ajax_action'] === 'get_service_checklist') {
    $sid = (int)$_GET['service_id'];
    $stmt = $tenant_conn->prepare("SELECT checklists FROM services WHERE id = ?");
    $stmt->execute([$sid]);
    $checklists = $stmt->fetchColumn();
    echo $checklists ?: json_encode([]);
    exit;
}

// Handle Status Update via POST (Background Fetch)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_job_status') {
    header('Content-Type: application/json');
    try {
        $jid = (int)$_POST['id'];
        $status = $_POST['status'];
        
        // If marking delivered, update customer's last service date
        if ($status === 'delivered') {
            $stmt_info = $tenant_conn->prepare("SELECT customer_id FROM job_cards WHERE id = ?");
            $stmt_info->execute([$jid]);
            $cid = $stmt_info->fetchColumn();
            if ($cid) {
                $tenant_conn->prepare("UPDATE customers SET last_service_date = CURRENT_DATE WHERE id = ?")->execute([$cid]);
            }
        }

        $stmt = $tenant_conn->prepare("UPDATE job_cards SET status = ? WHERE id = ?");
        $stmt->execute([$status, $jid]);
        echo json_encode(['success' => true]);
    } catch(Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
    exit;
}

// Self-healing: Job Cards Table (Service Industry Specific)
try {
    // Ensure columns for the ecosystem exist
    try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN customer_id INT"); } catch(Exception $e) {}
    try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN service_id INT"); } catch(Exception $e) {}
    try { $tenant_conn->exec("ALTER TABLE job_cards MODIFY COLUMN customer_name VARCHAR(255) NULL, MODIFY COLUMN customer_phone VARCHAR(50) NULL"); } catch(Exception $e) {}
    try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN task_completion_data JSON DEFAULT NULL"); } catch(Exception $e) {}
    try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN products_used_data JSON DEFAULT NULL"); } catch(Exception $e) {}
} catch(Exception $e) {}

// Handle Status Update (Quick Actions)
if (isset($_GET['update_id']) && isset($_GET['status'])) {
    try {
        $status = $_GET['status'];
        $jid = (int)$_GET['update_id'];
        
        // If marking delivered, update customer's last service date
        if ($status === 'delivered') {
            $stmt_info = $tenant_conn->prepare("SELECT customer_id FROM job_cards WHERE id = ?");
            $stmt_info->execute([$jid]);
            $cid = $stmt_info->fetchColumn();
            if ($cid) {
                $tenant_conn->prepare("UPDATE customers SET last_service_date = CURRENT_DATE WHERE id = ?")->execute([$cid]);
            }
        }

        $stmt = $tenant_conn->prepare("UPDATE job_cards SET status = ? WHERE id = ?");
        $stmt->execute([$status, $jid]);
        header("Location: jobs.php"); exit;
    } catch(Exception $e) { die("Error updating status: " . $e->getMessage()); }
}

// Handle Save New Job Action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_job') {
    try {
        // Prepare task completion data from checklist selection
        $tasks = $_POST['tasks'] ?? [];
        $completion_data = [];
        foreach($tasks as $t) { $completion_data[] = ['label' => $t, 'completed' => false]; }

        // Prepare products used data
        $products_used_json = $_POST['products_used_json'] ?? '[]';
        $products_used_data = json_decode($products_used_json, true);

        $tenant_conn->beginTransaction();

        $stmt = $tenant_conn->prepare("INSERT INTO job_cards (customer_id, service_id, assigned_to, device_model, serial_no, problem_description, estimated_cost, advance_paid, status, task_completion_data, products_used_data) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, ?)");
        $stmt->execute([
            (int)$_POST['customer_id'],
            (int)$_POST['service_id'],
            (int)($_POST['assigned_to'] ?? 0) ?: null,
            $_POST['device_model'] ?? '',
            $_POST['serial_no'] ?? '',
            $_POST['problem_description'] ?? '',
            (float)($_POST['estimated_cost'] ?? 0),
            (float)($_POST['advance_paid'] ?? 0),
            json_encode($completion_data),
            json_encode($products_used_data)
        ]);
        $job_id = $tenant_conn->lastInsertId();

        // Deduct products from stock
        if (has_module('inventory') && !empty($products_used_data)) {
            $stockCol = 'stock_level'; // Default for retail/service
            $checkCol = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'stock_quantity'")->fetch();
            if ($checkCol) $stockCol = 'stock_quantity'; // For wholesale

            foreach ($products_used_data as $product) {
                $qty_to_deduct = (float)$product['qty'];
                $product_id = (int)$product['id'];

                $stmt_deduct = $tenant_conn->prepare("UPDATE products SET $stockCol = $stockCol - ? WHERE id = ?");
                $stmt_deduct->execute([$qty_to_deduct, $product_id]);
                
                // Log stock movement
                $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")->execute([$product_id, -$qty_to_deduct, "Job Card #$job_id"]);
            }
        }
        $tenant_conn->commit();
        header("Location: jobs.php?msg=success"); exit;
    } catch(Exception $e) {
        die("Database Error while saving job: " . $e->getMessage());
    }
}

// Fetch All Jobs
try { // Fetch All Jobs
    $jobs = $tenant_conn->query("SELECT j.*, u.name as staff_name, c.name as customer_name, c.phone as customer_phone, c.email as customer_email, s.service_name 
                                 FROM job_cards j 
                                 LEFT JOIN users u ON j.assigned_to = u.id 
                                 LEFT JOIN customers c ON j.customer_id = c.id
                                 LEFT JOIN services s ON j.service_id = s.id
                                 ORDER BY j.created_at DESC")->fetchAll(PDO::FETCH_ASSOC);
    $staff = $tenant_conn->query("SELECT id, name FROM users")->fetchAll(PDO::FETCH_ASSOC);
    $customers = $tenant_conn->query("SELECT id, name, phone FROM customers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    $services_list = $tenant_conn->query("SELECT id, service_name FROM services WHERE is_active = 1 ORDER BY service_name ASC")->fetchAll(PDO::FETCH_ASSOC);

    // Fetch all products for the product search modal
    if (has_module('inventory')) {
        // Removing is_raw dependency for service panel to prevent 500 errors
        $all_products_for_job = $tenant_conn->query("SELECT id, name, sku, stock_level, price FROM products WHERE is_active = 1 ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $all_products_for_job = [];
    }

} catch(Exception $e) {
    die("Data Fetch Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Job Cards | Biltax Service</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Service Job Cards</h1>
                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Manage repair requests and status</p>
            </div>
            <button onclick="document.getElementById('addJobModal').classList.remove('hidden')" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all">Add New Job Card</button>
        </header>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach($jobs as $j): 
                $cleanStatus = str_replace('_', ' ', $j['status']);
                $statusColor = 'bg-slate-500/10 text-slate-500';
                switch($j['status']) {
                    case 'pending': $statusColor = 'bg-amber-500/10 text-amber-500'; break;
                    case 'in_progress': $statusColor = 'bg-blue-500/10 text-blue-500'; break;
                    case 'completed': $statusColor = 'bg-emerald-500/10 text-emerald-500'; break;
                    case 'delivered': $statusColor = 'bg-indigo-500/10 text-indigo-500'; break;
                }

                // Communication Links
                $wa_msg = urlencode("Hello " . $j['customer_name'] . ", this is a status update for your " . ($j['service_name'] ?: 'service') . " for " . $j['device_model'] . ". Current Status: " . strtoupper($cleanStatus));
                $wa_link = "https://wa.me/" . preg_replace('/[^0-9]/', '', $j['customer_phone']) . "?text=" . $wa_msg;
                
                $email_subject = urlencode("Status Update: " . ($j['service_name'] ?: 'Service') . " #" . $j['id']);
                $email_body = urlencode("Dear " . $j['customer_name'] . ",\n\nYour job card #" . $j['id'] . " for " . $j['device_model'] . " is currently " . $cleanStatus . ".\n\nThank you for choosing Biltax.");
                $email_link = "mailto:" . $j['customer_email'] . "?subject=" . $email_subject . "&body=" . $email_body;
            ?>
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm flex flex-col group">
                <div class="flex justify-between items-start mb-4">
                    <span class="text-[9px] font-black uppercase px-3 py-1 rounded-full <?= $statusColor ?>"><?= str_replace('_', ' ', $j['status']) ?></span>
                    <p class="text-[10px] text-slate-400 font-mono">#JOB-<?= $j['id'] ?></p>
                </div>

                <div class="flex justify-between items-start mb-4">
                    <div>
                        <h3 class="text-lg font-black dark:text-white uppercase line-clamp-1"><?= htmlspecialchars($j['device_model']) ?></h3>
                        <p class="text-[10px] font-black text-orange-600 uppercase"><?= htmlspecialchars($j['service_name'] ?: 'General Service') ?></p>
                        <p class="text-xs text-slate-500 font-bold uppercase mt-1"><?= htmlspecialchars($j['customer_name']) ?></p>
                    </div>
                    <?php if (has_module('whatsapp_email_sharing')): ?>
                        <div class="flex gap-2">
                            <a href="<?= $wa_link ?>" target="_blank" class="p-2 bg-emerald-500/10 text-emerald-500 rounded-xl hover:bg-emerald-500 hover:text-white transition-all"><i data-lucide="message-circle" size="14"></i></a>
                            <a href="<?= $email_link ?>" class="p-2 bg-blue-500/10 text-blue-500 rounded-xl hover:bg-blue-50 hover:text-white transition-all"><i data-lucide="mail" size="14"></i></a>
                        </div>
                    <?php endif; ?>
                </div>

                <div class="mb-4 flex items-center justify-between">
                    <div class="flex items-center gap-2">
                        <i data-lucide="user-cog" size="14" class="text-orange-500"></i>
                        <p class="text-[10px] font-black uppercase text-slate-500"><?= $j['staff_name'] ?: 'Unassigned' ?></p>
                    </div>
                    <p class="text-[10px] font-mono text-slate-400"><?= htmlspecialchars($j['customer_phone']) ?></p>
                </div>

                <div class="p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 mb-4 flex-1">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-1">Problem Description:</p>
                    <p class="text-xs dark:text-slate-300 italic">"<?= htmlspecialchars($j['problem_description']) ?>"</p>
                </div>

                <div class="flex justify-between items-center mb-6">
                    <div>
                        <p class="text-[9px] font-black uppercase text-slate-400">Estimated Cost</p>
                        <p class="text-sm font-black text-orange-600"><?= $currency_symbol ?><?= number_format($j['estimated_cost'], 2) ?></p>
                    </div>
                    <div class="text-right">
                        <p class="text-[9px] font-black uppercase text-slate-400">Advance Paid</p>
                        <p class="text-sm font-black text-emerald-500"><?= $currency_symbol ?><?= number_format($j['advance_paid'], 2) ?></p>
                    </div>
                </div>

                <?php 
                $used_products = has_module('inventory') ? json_decode($j['products_used_data'], true) : [];
                if (!empty($used_products)): ?>
                <div class="p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 mb-4">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-2">Products Used:</p>
                    <ul class="list-disc list-inside text-xs dark:text-slate-300">
                        <?php foreach($used_products as $prod): ?>
                            <li><?= htmlspecialchars($prod['name']) ?> (x<?= $prod['qty'] ?>)</li>
                        <?php endforeach; ?>
                    </ul>
                </div>
                <?php endif; ?>

                <div class="pt-4 border-t border-slate-100 dark:border-neutral-800 flex gap-2 overflow-x-auto no-scrollbar">
                    <?php if($j['status'] === 'pending'): ?>
                        <a href="?update_id=<?= $j['id'] ?>&status=in_progress" class="flex-1 text-center px-4 py-3 bg-blue-600 text-white rounded-xl text-[8px] font-black uppercase tracking-widest whitespace-nowrap">Start Work</a>
                    <?php elseif($j['status'] === 'in_progress'): ?>
                        <a href="?update_id=<?= $j['id'] ?>&status=completed" class="flex-1 text-center px-4 py-3 bg-emerald-600 text-white rounded-xl text-[8px] font-black uppercase tracking-widest whitespace-nowrap">Complete Job</a>
                    <?php elseif($j['status'] === 'completed'): ?>
                        <button onclick="markAsDelivered(<?= $j['id'] ?>)" class="flex-1 text-center px-4 py-3 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[8px] font-black uppercase tracking-widest whitespace-nowrap">Deliver to Client</button>
                    <?php elseif($j['status'] === 'delivered'): ?>
                        <a href="invoice_builder.php?type=job&job_id=<?= $j['id'] ?>&customer_id=<?= $j['customer_id'] ?>&total_cost=<?= ($j['total_cost'] > 0 ? $j['total_cost'] : $j['estimated_cost']) ?>" class="flex-1 text-center px-4 py-3 bg-orange-600 text-white rounded-xl text-[8px] font-black uppercase tracking-widest whitespace-nowrap">Generate Invoice</a>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <!-- Add Job Modal -->
    <div id="addJobModal" class="fixed inset-0 bg-black/80 hidden flex items-center justify-center p-4 z-50 backdrop-blur-sm overflow-y-auto">
        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] w-full max-w-xl border border-slate-200 dark:border-neutral-800 shadow-2xl my-8">
            <h2 class="text-2xl font-black dark:text-white uppercase mb-6 text-center">New Job Details</h2>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add_job">
                
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div class="w-full">
                        <label class="text-[9px] font-black uppercase text-slate-400 ml-2 mb-1 block">Select Customer</label>
                        <select name="customer_id" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                            <option value="">-- Search Customer --</option>
                            <?php foreach($customers as $c): ?><option value="<?= $c['id'] ?>"><?= htmlspecialchars($c['name']) ?> (<?= $c['phone'] ?>)</option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="w-full">
                        <label class="text-[9px] font-black uppercase text-slate-400 ml-2 mb-1 block">Service Type</label>
                        <select name="service_id" id="serviceSelector" required onchange="fetchChecklist(this.value)" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                            <option value="">-- Choose Service --</option>
                            <?php foreach($services_list as $sl): ?><option value="<?= $sl['id'] ?>"><?= htmlspecialchars($sl['service_name']) ?></option><?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="w-full">
                    <label class="text-[9px] font-black uppercase text-slate-400 ml-2 mb-1 block">Staff Assignment</label>
                    <select name="assigned_to" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                        <option value="">Assign Technician (Optional)</option>
                        <?php foreach($staff as $s): ?><option value="<?= $s['id'] ?>"><?= htmlspecialchars($s['name']) ?></option><?php endforeach; ?>
                    </select>
                </div>

                <!-- Checklist Container -->
                <div id="checklistDisplay" class="hidden p-5 bg-orange-500/5 border border-orange-500/10 rounded-[32px]">
                    <p class="text-[10px] font-black uppercase text-orange-600 mb-3 flex items-center gap-2"><i data-lucide="check-square" size="14"></i> Standard Checklist Items</p>
                    <div id="checklistItems" class="grid grid-cols-1 md:grid-cols-2 gap-3"></div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <input type="text" name="device_model" placeholder="Device / Vehicle Model" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                    <input type="text" name="serial_no" placeholder="Serial / Plate Number" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                </div>
                <textarea name="problem_description" placeholder="Describe the problem..." required rows="3" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold"></textarea>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="text-[9px] font-black uppercase text-slate-400 ml-2 mb-1 block">Est. Cost (<?= $currency_symbol ?>)</label>
                        <input type="number" step="0.01" name="estimated_cost" placeholder="0.00" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                    </div>
                    <div>
                        <label class="text-[9px] font-black uppercase text-slate-400 ml-2 mb-1 block">Advance Paid (<?= $currency_symbol ?>)</label>
                        <input type="number" step="0.01" name="advance_paid" placeholder="0.00" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                    </div>
                </div>
                <div class="pt-4 space-y-3">
                    <!-- Products Used Section -->
                    <?php if (has_module('inventory')): ?>
                    <div class="pt-4 border-t border-slate-100 dark:border-neutral-800">
                        <div class="flex justify-between items-center mb-4">
                            <label class="text-[10px] font-black uppercase text-slate-400">Products Used (Optional)</label>
                            <button type="button" onclick="openProductSearchModal()" class="text-[10px] font-black uppercase text-orange-600 flex items-center gap-1 hover:underline">
                                <i data-lucide="plus-circle" size="14"></i> Add Product
                            </button>
                        </div>
                        <div id="productsUsedContainer" class="space-y-3">
                            <!-- Selected products will be listed here -->
                        </div>
                        <input type="hidden" name="products_used_json" id="productsUsedJson">
                    </div>
                    <?php endif; ?>

                    <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 active:scale-95 transition-all">Create Job Card</button>
                    <button type="button" onclick="document.getElementById('addJobModal').classList.add('hidden')" class="w-full text-slate-400 text-[10px] font-black uppercase tracking-widest">Cancel</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Product Search Modal -->
    <?php if (has_module('inventory')): ?>
    <div id="productSearchModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[70] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-xl shadow-2xl relative">
            <button onclick="closeProductSearchModal()" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Add Products to Job</h2>
            <p class="text-xs text-orange-500 font-bold uppercase tracking-widest mb-6">Search and select inventory items</p>

            <div class="space-y-4">
                <div class="relative">
                    <i data-lucide="search" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="16"></i>
                    <input type="text" id="jobProductSearch" onkeyup="filterAvailableJobProducts(this.value)" placeholder="Search products by name or SKU..." class="w-full pl-12 pr-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm focus:border-orange-500 transition-all">
                </div>

                <p class="text-[10px] font-black uppercase text-slate-400 tracking-widest ml-1">Available Products (Click to add)</p>
                <div id="availableJobProductsList" class="flex flex-wrap gap-2 max-h-40 overflow-y-auto p-1 custom-scrollbar"></div>

                <div class="max-h-60 overflow-y-auto custom-scrollbar">
                    <table class="w-full text-left">
                        <thead class="text-[10px] font-black uppercase text-slate-400 border-b border-slate-100 dark:border-neutral-800">
                            <tr>
                                <th class="py-2">Product</th>
                                <th class="py-2 text-center">Qty</th>
                                <th class="py-2 text-right"></th>
                            </tr>
                        </thead>
                        <tbody id="selectedJobProductsListBody" class="divide-y divide-slate-50 dark:divide-neutral-800"></tbody>
                    </table>
                </div>
            </div>

            <button onclick="confirmProductsUsed()" class="w-full py-4 bg-orange-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 mt-8">Confirm Products</button>
        </div>
    </div>
    <?php endif; ?>

    <script>
        lucide.createIcons();

        let allAvailableProducts = <?= json_encode($all_products_for_job) ?>;
        let selectedJobProducts = [];

        // Function to render available products in the search modal
        function renderAvailableJobProducts(filter = '') {
            const container = document.getElementById('availableJobProductsList');
            const query = filter.toLowerCase();
            
            const filtered = allAvailableProducts.filter(p => 
                (p.name.toLowerCase().includes(query) || (p.sku && p.sku.toLowerCase().includes(query))) &&
                !selectedJobProducts.some(sp => sp.id === p.id) // Don't show already selected products
            );
            
            container.innerHTML = filtered.map(p => `
                <button type="button" onclick="addJobProduct(${p.id})" 
                    class="px-3 py-2 rounded-xl border transition-all text-[10px] font-black uppercase tracking-tight
                    bg-white dark:bg-neutral-800 text-slate-600 dark:text-slate-400 border-slate-200 dark:border-neutral-700 hover:border-orange-500">
                    ${p.name} (${p.stock_level} in stock)
                </button>
            `).join('');
        }

        function filterAvailableJobProducts(query) {
            renderAvailableJobProducts(query);
        }

        function openProductSearchModal() {
            renderAvailableJobProducts();
            const modal = document.getElementById('productSearchModal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function closeProductSearchModal() {
            const modal = document.getElementById('productSearchModal');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }

        function addJobProduct(id) {
            const product = allAvailableProducts.find(p => p.id === id);
            if (product && !selectedJobProducts.some(p => p.id === id)) {
                selectedJobProducts.push({ ...product, qty: 1 });
                renderAvailableJobProducts(document.getElementById('jobProductSearch').value);
                renderSelectedJobProducts();
            }
        }

        function renderSelectedJobProducts() {
            const body = document.getElementById('selectedJobProductsListBody');
            body.innerHTML = selectedJobProducts.map(p => `
                <tr class="text-sm dark:text-white">
                    <td class="py-2 font-bold">${p.name}</td>
                    <td class="py-2 text-center">
                        <input type="number" min="1" value="${p.qty}" onchange="updateJobProductQty(${p.id}, this.value)" class="w-16 bg-slate-50 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded text-center text-xs outline-none">
                    </td>
                    <td class="py-2 text-right">
                        <button type="button" onclick="removeJobProduct(${p.id})" class="text-rose-500 hover:text-rose-700 transition-colors"><i data-lucide="trash-2" size="14"></i></button>
                    </td>
                </tr>
            `).join('');
            lucide.createIcons();
        }

        function updateJobProductQty(id, qty) {
            const prod = selectedJobProducts.find(p => p.id === id);
            if (prod) prod.qty = parseFloat(qty) || 1;
        }

        function removeJobProduct(id) {
            selectedJobProducts = selectedJobProducts.filter(p => p.id !== id);
            renderAvailableJobProducts(document.getElementById('jobProductSearch').value);
            renderSelectedJobProducts();
        }

        function confirmProductsUsed() {
            const container = document.getElementById('productsUsedContainer');
            const jsonInput = document.getElementById('productsUsedJson');
            
            jsonInput.value = JSON.stringify(selectedJobProducts);
            container.innerHTML = selectedJobProducts.map(p => `
                <div class="flex justify-between items-center p-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl">
                    <span class="text-xs font-bold dark:text-white">${p.name} (x${p.qty})</span>
                    <span class="text-[10px] font-black text-orange-600 uppercase"><?= $currency_symbol ?>${p.price}</span>
                </div>
            `).join('');
            
            closeProductSearchModal();
        }

        async function fetchChecklist(serviceId) {
            const display = document.getElementById('checklistDisplay');
            const itemsContainer = document.getElementById('checklistItems');
            
            if (!serviceId) {
                display.classList.add('hidden');
                return;
            }

            const res = await fetch(`jobs.php?ajax_action=get_service_checklist&service_id=${serviceId}`);
            const data = await res.json();

            if (data && data.length > 0) {
                itemsContainer.innerHTML = data.map(task => `
                    <label class="flex items-center gap-2 cursor-pointer group">
                        <input type="checkbox" name="tasks[]" value="${task}" checked class="w-4 h-4 rounded border-slate-300 text-orange-600 focus:ring-orange-500">
                        <span class="text-xs font-bold text-slate-600 dark:text-slate-300 group-hover:text-orange-600">${task}</span>
                    </label>
                `).join('');
                display.classList.remove('hidden');
                lucide.createIcons();
            } else {
                display.classList.add('hidden');
            }
        }

        async function markAsDelivered(id) {
            if(!confirm("Are you sure you want to mark this job as Delivered?")) return;
            
            const formData = new FormData();
            formData.append('action', 'update_job_status');
            formData.append('id', id);
            formData.append('status', 'delivered');

            try {
                const res = await fetch('jobs.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await res.json();
                if (result.success) {
                    location.reload();
                } else {
                    alert("Error: " + result.message);
                }
            } catch (e) { alert("System Error occurred."); }
        }
    </script>
</body>
</html>