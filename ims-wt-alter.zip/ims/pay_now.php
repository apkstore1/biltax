<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

$plan_id = $_GET['plan_id'] ?? null;
$amount = $_GET['amount'] ?? 0;
$cycle = $_GET['cycle'] ?? '1_month'; // Default to 1_month
$current_plan_id = $_GET['current_plan_id'] ?? null;
$current_expiry_date = $_GET['current_expiry_date'] ?? null;

if (!$plan_id) { header("Location: billing_plans_view.php"); exit; }

try {
    $stmt = $m_pdo->prepare("SELECT package_name, primary_cycle, secondary_cycle FROM packages WHERE id = ?");
    $stmt->execute([$plan_id]);
    $pkg_info = $stmt->fetch(PDO::FETCH_ASSOC);
    $plan_name = $pkg_info['package_name'] ?? "Selected Plan";
    $actual_cycle = ($cycle === 'secondary') ? ($pkg_info['secondary_cycle'] ?? '1_year') : ($pkg_info['primary_cycle'] ?? '1_month');
} catch (Exception $e) { $plan_name = "Selected Plan"; $actual_cycle = $cycle; }

// Fetch Dynamic Bank Details from Payment Settings in main DB
try {
    $res_settings = $m_pdo->query("SELECT setting_key, setting_value FROM payment_settings WHERE setting_key LIKE 'bank_details_%'")->fetchAll(PDO::FETCH_KEY_PAIR);
    $bank_name = $res_settings['bank_details_name'] ?? 'Meezan Bank / HBL';
    $account_title = $res_settings['bank_details_title'] ?? 'Biltax Solutions';
    $account_no = $res_settings['bank_details_no'] ?? 'PK00 MZN 0012 3456 7890';
    $instructions = $res_settings['bank_details_instructions'] ?? 'Paise transfer karne ke baad baraye meharbani Transaction ID aur apna naam submit karein taake hum foran aapka plan activate kar sakein.';
} catch (Exception $e) {
    $bank_name = 'Meezan Bank / HBL'; $account_title = 'Biltax Solutions'; $account_no = 'PK00 MZN 0012 3456 7890';
    $instructions = 'Paise transfer karne ke baad baraye meharbani Transaction ID aur apna naam submit karein taake hum foran aapka plan activate kar sakein.';
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Pay Now | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-10">
            <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Complete Payment</h1>
            <?php include 'topbar.php'; ?>
        </header>

        <div class="max-w-4xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-10">
            <!-- Bank Details -->
            <div class="bg-white dark:bg-neutral-900 p-10 rounded-[48px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                <h2 class="text-xl font-black dark:text-white uppercase mb-6 flex items-center gap-3"><i data-lucide="landmark" class="text-orange-600"></i> Bank Transfer</h2>
                <div class="p-6 bg-slate-50 dark:bg-neutral-950 rounded-3xl border border-slate-100 dark:border-neutral-800 space-y-4 mb-8">
                    <div><p class="text-[10px] font-black text-slate-400 uppercase">Bank Name</p><p class="text-sm font-bold dark:text-white"><?= htmlspecialchars($bank_name) ?></p></div>
                    <div><p class="text-[10px] font-black text-slate-400 uppercase">Account Title</p><p class="text-sm font-bold dark:text-white"><?= htmlspecialchars($account_title) ?></p></div>
                    <div><p class="text-[10px] font-black text-slate-400 uppercase">IBAN / Account Number</p><p class="text-lg font-black text-orange-600 tracking-tighter"><?= htmlspecialchars($account_no) ?></p></div>
                </div>
                <div class="p-4 bg-orange-500/5 rounded-2xl border border-orange-500/10">
                    <p class="text-xs text-slate-500 dark:text-slate-400 font-medium italic"><?= htmlspecialchars($instructions) ?></p>
                </div>
            </div>

            <!-- Verification Form -->
            <div class="bg-indigo-600 p-10 rounded-[48px] text-white shadow-2xl shadow-indigo-600/20">
                <div class="mb-8">
                    <p class="text-[10px] font-black uppercase tracking-widest opacity-70">Checkout Summary</p>
                    <h3 class="text-2xl font-black"><?= htmlspecialchars($plan_name) ?></h3>
                    <p class="text-sm font-bold mt-1 opacity-90"><?= $currency_symbol ?><?= number_format($amount, 2) ?> / <?= ucwords(str_replace('_', ' ', $actual_cycle)) ?></p>
                </div>

                <form id="paymentForm" class="space-y-4">
                    <input type="hidden" name="package_id" value="<?= $plan_id ?>">
                    <input type="hidden" name="amount" value="<?= $amount ?>">
                    <input type="hidden" name="billing_cycle" value="<?= $cycle ?>">
                    <input type="hidden" name="current_plan_id" value="<?= $current_plan_id ?>">
                    <input type="hidden" name="current_expiry_date" value="<?= $current_expiry_date ?>">

                    <div>
                        <label class="block text-[10px] font-black uppercase mb-2 opacity-70 tracking-widest">Account Holder Name</label>
                        <input type="text" name="account_name" required placeholder="Name on receipt" class="w-full px-5 py-4 bg-white/10 border border-white/20 rounded-2xl outline-none focus:bg-white/20 transition-all font-bold placeholder:text-white/40">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-2 opacity-70 tracking-widest">Transaction ID (TID)</label>
                        <input type="text" name="transaction_id" required placeholder="Enter TID number" class="w-full px-5 py-4 bg-white/10 border border-white/20 rounded-2xl outline-none focus:bg-white/20 transition-all font-black tracking-widest placeholder:text-white/40">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-2 opacity-70 tracking-widest">Additional Notes</label>
                        <textarea name="description" placeholder="Optional notes..." class="w-full p-5 bg-white/10 border border-white/20 rounded-2xl outline-none focus:bg-white/20 transition-all font-bold h-24 placeholder:text-white/40"></textarea>
                    </div>
                    <button type="submit" id="submitBtn" class="w-full py-4 bg-white text-indigo-600 rounded-2xl font-black uppercase tracking-widest shadow-xl hover:scale-105 active:scale-95 transition-all mt-4">Submit Payment Details</button>
                </form>
            </div>
        </div>
    </main>
    <script>
        lucide.createIcons();

        document.getElementById('paymentForm').addEventListener('submit', async function(e) {
            e.preventDefault();
            const btn = document.getElementById('submitBtn');
            const originalText = btn.innerText;
            btn.disabled = true; btn.innerText = 'Processing...';

            const payload = Object.fromEntries(new FormData(this).entries());

            try {
                const res = await fetch('api.php?route=payment/verify', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(payload)
                });
                const result = await res.json();
                if(result.success) {
                    alert("Details Submitted! Redirecting to history...");
                    window.location.href = 'billing_history.php';
                } else {
                    alert(result.message);
                    btn.disabled = false; btn.innerText = originalText;
                }
            } catch (err) {
                alert("Network error occurred.");
                btn.disabled = false; btn.innerText = originalText;
            }
        });
    </script>
</body>
</html>