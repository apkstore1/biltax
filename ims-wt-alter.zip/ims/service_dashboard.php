<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// 1. Fetch Stats
try {
    // Total Active Jobs
    $active_jobs = $tenant_conn->query("SELECT COUNT(*) FROM job_cards WHERE status IN ('pending', 'in_progress')")->fetchColumn() ?: 0;

    // Monthly Revenue (Delivered/Completed jobs this month)
    $monthly_rev = $tenant_conn->query("SELECT SUM(total_cost) FROM job_cards WHERE status IN ('completed', 'delivered') AND MONTH(created_at) = MONTH(CURRENT_DATE()) AND YEAR(created_at) = YEAR(CURRENT_DATE())")->fetchColumn() ?: 0;

    // Pending Payments (Total Cost - Advance Paid for all non-delivered jobs)
    $pending_payments = $tenant_conn->query("SELECT SUM(total_cost - advance_paid) FROM job_cards WHERE status != 'delivered'")->fetchColumn() ?: 0;

    // Jobs Due Today (Based on next_recurring_date)
    $due_today = $tenant_conn->query("SELECT COUNT(*) FROM job_cards WHERE DATE(next_recurring_date) = CURRENT_DATE()")->fetchColumn() ?: 0;

    // Recent Activity (Last 5 jobs)
    $recent_jobs = $tenant_conn->query("SELECT j.*, c.name as customer_name, s.service_name 
                                        FROM job_cards j 
                                        LEFT JOIN customers c ON j.customer_id = c.id 
                                        LEFT JOIN services s ON j.service_id = s.id 
                                        ORDER BY j.created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

    // Chart Data: Status Distribution
    $chart_stats = $tenant_conn->query("SELECT status, COUNT(*) as count FROM job_cards GROUP BY status")->fetchAll(PDO::FETCH_KEY_PAIR);
    $statuses = ['pending', 'in_progress', 'completed', 'delivered'];
    $chart_counts = [];
    foreach($statuses as $s) { $chart_counts[] = $chart_stats[$s] ?? 0; }

} catch (Exception $e) { $error = $e->getMessage(); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Service Dashboard | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8">
        <header class="mb-10 flex justify-between items-end">
            <div>
                <h1 class="text-4xl font-black dark:text-white uppercase tracking-tighter">Service Overview</h1>
                <p class="text-[10px] text-orange-500 font-bold uppercase tracking-widest mt-1">Real-time performance analytics</p>
            </div>
            <div class="flex gap-3">
                <a href="jobs.php" class="px-6 py-3 bg-orange-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-orange-600/20 active:scale-95 transition-all">Quick Create Job</a>
                <a href="reminders.php" class="px-6 py-3 bg-white dark:bg-neutral-900 dark:text-white border border-slate-200 dark:border-neutral-800 rounded-2xl font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all">Check Reminders</a>
            </div>
        </header>

        <!-- Stat Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
            <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm group">
                <div class="w-10 h-10 bg-blue-500/10 text-blue-500 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><i data-lucide="activity" size="20"></i></div>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Active Jobs</p>
                <h2 class="text-3xl font-black dark:text-white"><?= $active_jobs ?></h2>
            </div>

            <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm group">
                <div class="w-10 h-10 bg-emerald-500/10 text-emerald-500 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><i data-lucide="trending-up" size="20"></i></div>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Monthly Revenue</p>
                <h2 class="text-3xl font-black dark:text-white"><?= $currency_symbol ?><?= number_format($monthly_rev, 0) ?></h2>
            </div>

            <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm group">
                <div class="w-10 h-10 bg-rose-500/10 text-rose-500 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><i data-lucide="wallet" size="20"></i></div>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Pending Payments</p>
                <h2 class="text-3xl font-black dark:text-white"><?= $currency_symbol ?><?= number_format($pending_payments, 0) ?></h2>
            </div>

            <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm group">
                <div class="w-10 h-10 bg-orange-500/10 text-orange-500 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform"><i data-lucide="calendar-check" size="20"></i></div>
                <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest">Due Today</p>
                <h2 class="text-3xl font-black dark:text-white"><?= $due_today ?></h2>
            </div>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <!-- Chart Section -->
            <div class="lg:col-span-1 bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                <h3 class="text-lg font-black dark:text-white uppercase mb-6 tracking-tight">Status Distribution</h3>
                <div class="aspect-square relative">
                    <canvas id="statusChart"></canvas>
                </div>
                <div class="mt-8 space-y-3">
                    <a href="services.php" class="block w-full py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-100 dark:border-neutral-800 rounded-2xl text-[10px] font-black uppercase text-center text-slate-500 hover:text-orange-600 transition-colors tracking-widest">View Service Catalog</a>
                </div>
            </div>

            <!-- Recent Jobs -->
            <div class="lg:col-span-2 bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
                <div class="flex justify-between items-center mb-8">
                    <h3 class="text-lg font-black dark:text-white uppercase tracking-tight">Recent Activity</h3>
                    <a href="jobs.php" class="text-[10px] font-black uppercase text-orange-600 hover:underline">View All Jobs</a>
                </div>
                <div class="space-y-4">
                    <?php if (empty($recent_jobs)): ?>
                        <p class="text-center py-10 text-slate-400 italic">No job cards found.</p>
                    <?php endif; ?>
                    <?php foreach($recent_jobs as $j): 
                        $color = match($j['status']) {
                            'pending' => 'text-amber-500',
                            'in_progress' => 'text-blue-500',
                            'completed' => 'text-emerald-500',
                            'delivered' => 'text-slate-400',
                            default => 'text-slate-500'
                        };
                    ?>
                    <div class="flex items-center justify-between p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-100 dark:border-neutral-800 rounded-3xl">
                        <div class="flex items-center gap-4">
                            <div class="w-12 h-12 bg-white dark:bg-neutral-900 rounded-2xl flex items-center justify-center border border-slate-100 dark:border-neutral-800">
                                <i data-lucide="wrench" class="text-slate-400" size="18"></i>
                            </div>
                            <div>
                                <p class="text-sm font-black dark:text-white uppercase"><?= htmlspecialchars($j['device_model'] ?: 'General') ?></p>
                                <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest"><?= htmlspecialchars($j['customer_name'] ?: 'Walk-in') ?> • #JOB-<?= $j['id'] ?></p>
                            </div>
                        </div>
                        <div class="text-right">
                            <p class="text-[9px] font-black uppercase <?= $color ?>"><?= str_replace('_', ' ', $j['status']) ?></p>
                            <p class="text-[10px] font-mono text-slate-400 mt-1"><?= date('d M, H:i', strtotime($j['created_at'])) ?></p>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </main>

    <script>
        lucide.createIcons();

        // Chart Initialization
        const ctx = document.getElementById('statusChart').getContext('2d');
        const isDark = document.documentElement.classList.contains('dark');
        
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: ['Pending', 'In Progress', 'Completed', 'Delivered'],
                datasets: [{
                    data: <?= json_encode($chart_counts) ?>,
                    backgroundColor: [
                        '#f59e0b', // Amber
                        '#3b82f6', // Blue
                        '#10b981', // Emerald
                        '#64748b'  // Slate
                    ],
                    borderWidth: 0,
                    hoverOffset: 10
                }]
            },
            options: {
                cutout: '70%',
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            padding: 20,
                            usePointStyle: true,
                            font: {
                                size: 10,
                                weight: '900',
                                family: 'Inter'
                            },
                            color: isDark ? '#a3a3a3' : '#64748b'
                        }
                    }
                }
            }
        });
    </script>
</body>
</html>