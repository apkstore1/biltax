<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

// Initialize connection to Main DB using variables from db_connect.php
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Self-healing: Ensure Support tables exist in main database
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS support_tickets (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tenant_id INT NOT NULL,
        subject VARCHAR(255) NOT NULL,
        category ENUM('technical', 'billing', 'feature', 'other') DEFAULT 'technical',
        priority ENUM('low', 'medium', 'high', 'urgent') DEFAULT 'medium',
        status ENUM('open', 'in_progress', 'resolved', 'closed') DEFAULT 'open',
        last_reply_by ENUM('tenant', 'admin') DEFAULT 'tenant',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB");

    $main_pdo->exec("CREATE TABLE IF NOT EXISTS ticket_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        ticket_id INT NOT NULL,
        sender_role ENUM('tenant', 'admin') NOT NULL,
        message TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE
    ) ENGINE=InnoDB");
} catch (Exception $e) { die("Database Error: " . $e->getMessage()); }

// Ensure we have the correct tenant ID from session or database
$my_tenant_id = $_SESSION['tenant_id'] ?? null;
if (!$my_tenant_id) {
    $stmt_t = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
    $stmt_t->execute([$_SESSION['db_name']]);
    $my_tenant_id = $stmt_t->fetchColumn();
    $_SESSION['tenant_id'] = $my_tenant_id;
}

// Handle New Ticket
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_ticket') {
    $subject = $_POST['subject'];
    $cat = $_POST['category'];
    $msg = $_POST['message'];
    $priority = $_POST['priority'];

    $main_pdo->beginTransaction();
    $stmt = $main_pdo->prepare("INSERT INTO support_tickets (tenant_id, subject, category, priority, status) VALUES (?, ?, ?, ?, 'open')");
    $stmt->execute([$my_tenant_id, $subject, $cat, $priority]);
    $ticket_id = $main_pdo->lastInsertId();

    $stmt_msg = $main_pdo->prepare("INSERT INTO ticket_messages (ticket_id, sender_role, message) VALUES (?, 'tenant', ?)");
    $stmt_msg->execute([$ticket_id, $msg]);
    $main_pdo->commit();

    header("Location: support_tickets.php?msg=created"); exit;
}

// Handle Reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reply_ticket') {
    $tid = $_POST['ticket_id'];
    $msg = $_POST['message'];

    $stmt = $main_pdo->prepare("INSERT INTO ticket_messages (ticket_id, sender_role, message) VALUES (?, 'tenant', ?)");
    $stmt->execute([$tid, $msg]);

    $main_pdo->prepare("UPDATE support_tickets SET status = 'open', last_reply_by = 'tenant' WHERE id = ?")->execute([$tid]);
    header("Location: support_tickets.php?id=$tid&msg=replied"); exit;
}

// Fetch Tickets
$tickets = $main_pdo->prepare("SELECT * FROM support_tickets WHERE tenant_id = ? ORDER BY updated_at DESC");
$tickets->execute([$my_tenant_id]);
$my_tickets = $tickets->fetchAll(PDO::FETCH_ASSOC);

// View Specific Ticket
$active_ticket = null;
$messages = [];
if (isset($_GET['id'])) {
    $stmt = $main_pdo->prepare("SELECT * FROM support_tickets WHERE id = ? AND tenant_id = ?");
    $stmt->execute([$_GET['id'], $my_tenant_id]);
    $active_ticket = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($active_ticket) {
        $stmt_m = $main_pdo->prepare("SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC");
        $stmt_m->execute([$active_ticket['id']]);
        $messages = $stmt_m->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Support Center | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 flex flex-col h-screen">
        <header class="mb-10 flex justify-between items-center shrink-0">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Support Tickets</h1>
                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Get help from Biltax experts</p>
            </div>
            <button onclick="document.getElementById('newTicketModal').classList.remove('hidden')" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-orange-600/20">Open New Ticket</button>
        </header>

        <div class="flex-1 flex gap-8 overflow-hidden">
            <!-- Ticket List -->
            <div class="w-1/3 bg-white dark:bg-neutral-900 rounded-[32px] border border-slate-200 dark:border-neutral-800 overflow-y-auto custom-scrollbar shadow-sm">
                <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                    <h3 class="text-xs font-black uppercase text-slate-400">Your Tickets</h3>
                </div>
                <div class="divide-y divide-slate-50 dark:divide-neutral-800">
                    <?php foreach($my_tickets as $t): ?>
                    <a href="?id=<?= $t['id'] ?>" class="block p-5 hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-all <?= ($active_ticket && $active_ticket['id'] == $t['id']) ? 'bg-orange-50/50 dark:bg-orange-600/5 border-l-4 border-orange-600' : '' ?>">
                        <div class="flex justify-between items-start mb-2">
                            <span class="text-[9px] font-black uppercase px-2 py-0.5 rounded bg-slate-100 dark:bg-neutral-800 text-slate-500"><?= $t['category'] ?></span>
                            <span class="text-[9px] font-black uppercase <?= $t['status'] === 'open' ? 'text-emerald-500' : 'text-slate-400' ?>"><?= $t['status'] ?></span>
                        </div>
                        <h4 class="font-bold text-sm dark:text-white line-clamp-1"><?= htmlspecialchars($t['subject']) ?></h4>
                        <p class="text-[10px] text-slate-400 mt-1 font-mono">#TKT-<?= $t['id'] ?> • <?= date('d M', strtotime($t['updated_at'])) ?></p>
                    </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Conversation -->
            <div class="flex-1 bg-white dark:bg-neutral-900 rounded-[32px] border border-slate-200 dark:border-neutral-800 flex flex-col shadow-sm">
                <?php if ($active_ticket): ?>
                    <div class="p-6 border-b border-slate-100 dark:border-neutral-800 flex justify-between items-center shrink-0">
                        <div>
                            <h2 class="text-lg font-black dark:text-white uppercase"><?= htmlspecialchars($active_ticket['subject']) ?></h2>
                            <p class="text-[10px] font-bold text-orange-600 uppercase">Priority: <?= $active_ticket['priority'] ?></p>
                        </div>
                        <span class="px-3 py-1 bg-slate-100 dark:bg-neutral-800 rounded-lg text-[10px] font-black uppercase text-slate-500 italic"><?= $active_ticket['status'] ?></span>
                    </div>
                    
                    <div class="flex-1 overflow-y-auto p-6 space-y-6 custom-scrollbar">
                        <?php foreach($messages as $m): ?>
                            <div class="flex <?= $m['sender_role'] === 'tenant' ? 'justify-end' : 'justify-start' ?>">
                                <div class="max-w-[80%] <?= $m['sender_role'] === 'tenant' ? 'bg-orange-600 text-white rounded-l-2xl rounded-tr-2xl' : 'bg-slate-100 dark:bg-neutral-800 text-slate-900 dark:text-white rounded-r-2xl rounded-tl-2xl' ?> p-4 shadow-sm">
                                    <p class="text-sm font-medium leading-relaxed"><?= nl2br(htmlspecialchars($m['message'])) ?></p>
                                    <p class="text-[9px] mt-2 opacity-60 font-bold uppercase"><?= $m['sender_role'] === 'admin' ? 'Biltax Support' : 'You' ?> • <?= date('H:i', strtotime($m['created_at'])) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <?php if ($active_ticket['status'] !== 'closed'): ?>
                    <form method="POST" class="p-6 border-t border-slate-100 dark:border-neutral-800 shrink-0">
                        <input type="hidden" name="action" value="reply_ticket">
                        <input type="hidden" name="ticket_id" value="<?= $active_ticket['id'] ?>">
                        <div class="flex gap-4">
                            <textarea name="message" required placeholder="Type your message here..." rows="1" class="flex-1 p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white text-sm font-medium resize-none"></textarea>
                            <button type="submit" class="bg-slate-900 dark:bg-white text-white dark:text-black p-4 rounded-2xl hover:scale-105 transition-all"><i data-lucide="send" size="20"></i></button>
                        </div>
                    </form>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="flex-1 flex flex-col items-center justify-center text-slate-300 opacity-50">
                        <i data-lucide="message-square" size="64" class="mb-4"></i>
                        <p class="text-sm font-black uppercase tracking-widest">Select a ticket to view conversation</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- New Ticket Modal -->
    <div id="newTicketModal" class="fixed inset-0 bg-black/80 hidden flex items-center justify-center p-4 z-50 backdrop-blur-sm">
        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] w-full max-w-lg border border-slate-200 dark:border-neutral-800">
            <h2 class="text-2xl font-black dark:text-white uppercase mb-6 text-center">New Support Ticket</h2>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="create_ticket">
                <input type="text" name="subject" placeholder="What do you need help with?" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                
                <div class="grid grid-cols-2 gap-4">
                    <select name="category" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                        <option value="technical">Technical Issue</option>
                        <option value="billing">Billing/Payment</option>
                        <option value="feature">Feature Request</option>
                        <option value="other">General Inquiry</option>
                    </select>
                    <select name="priority" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm text-orange-600">
                        <option value="low">Low</option>
                        <option value="medium" selected>Medium</option>
                        <option value="high">High</option>
                        <option value="urgent">Urgent</option>
                    </select>
                </div>

                <textarea name="message" rows="5" placeholder="Describe your issue in detail..." required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm"></textarea>
                
                <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 active:scale-95 transition-all">Submit Ticket</button>
                <button type="button" onclick="document.getElementById('newTicketModal').classList.add('hidden')" class="w-full text-slate-400 text-[10px] font-black uppercase mt-2">Cancel</button>
            </form>
        </div>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>