<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

if (!has_module('rider_tracking')) {
    header("Location: dashboard.php?error=access_denied");
    exit;
}

// Handle AJAX for Rider Details
if (isset($_GET['get_rider_details'])) {
    header('Content-Type: application/json');
    $rider_id = (int)$_GET['get_rider_details'];
    try {
        $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
        $stmt = $main_pdo->prepare("
            SELECT o.id, o.delivery_status, o.total_amount, o.created_at, t.business_name as customer
            FROM b2b_orders o
            JOIN tenants t ON o.sender_tenant_id = t.id
            WHERE o.rider_id = ? AND o.receiver_tenant_id = ?
            ORDER BY o.id DESC LIMIT 10");
        $stmt->execute([$rider_id, $_SESSION['tenant_id']]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    } catch (Exception $e) { echo json_encode([]); }
    exit;
}

// Handle Custom Ride Assignment
if (isset($_POST['action']) && $_POST['action'] === 'assign_custom_ride') {
    try {
        $rider_id = (int)$_POST['rider_id'];
        $customer_name = trim($_POST['customer_name']);
        $customer_phone = trim($_POST['customer_phone']);
        $delivery_address = trim($_POST['delivery_address']);
        $item_description = trim($_POST['item_description']);
        $total_amount = (float)$_POST['total_amount'];

        // Insert into b2b_orders table (using current tenant as both sender and receiver for internal custom rides)
        $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
        $stmt = $main_pdo->prepare("
            INSERT INTO b2b_orders (
                sender_tenant_id, receiver_tenant_id, rider_id,
                delivery_status, status, total_amount,
                customer_name, customer_phone, delivery_address, item_description
            ) VALUES (?, ?, ?, 'dispatched', 'shipped', ?, ?, ?, ?, ?)
        ");
        $stmt->execute([
            $_SESSION['tenant_id'], $_SESSION['tenant_id'], $rider_id,
            $total_amount, $customer_name, $customer_phone, $delivery_address, $item_description
        ]);
        header("Location: riders_management.php?msg=custom_ride_assigned"); exit;
    } catch (Exception $e) { $error_msg = "Error assigning custom ride: " . $e->getMessage(); }
}

$success_msg = $error_msg = '';

// Handle Toggle Status
if (isset($_GET['toggle_id'])) {
    try {
        $rid = (int)$_GET['toggle_id'];
        $tenant_conn->prepare("UPDATE riders SET is_active = NOT is_active WHERE id = ?")->execute([$rid]);
        header("Location: riders_management.php?msg=updated"); exit;
    } catch (Exception $e) { $error_msg = $e->getMessage(); }
}

// Handle Delete
if (isset($_POST['action']) && $_POST['action'] === 'delete_rider') {
    try {
        $rid = (int)$_POST['id'];
        $tenant_conn->prepare("DELETE FROM riders WHERE id = ?")->execute([$rid]);
        header("Location: riders_management.php?msg=deleted"); exit;
    } catch (Exception $e) { $error_msg = $e->getMessage(); }
}

if (isset($_GET['msg'])) {
    if ($_GET['msg'] === 'updated') $success_msg = "Rider status changed.";
    if ($_GET['msg'] === 'deleted') $success_msg = "Rider deleted.";
    if ($_GET['msg'] === 'added') $success_msg = "New rider added successfully.";
    if ($_GET['msg'] === 'custom_ride_assigned') $success_msg = "Custom ride assigned successfully.";
}

$riders = $tenant_conn->query("SELECT * FROM riders ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch active tracking stats from Main DB for each rider
$rider_tracking = [];
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $stmt_tracking = $main_pdo->prepare("
        SELECT rider_id, 
               SUM(CASE WHEN delivery_status = 'dispatched' THEN 1 ELSE 0 END) as dispatched,
               SUM(CASE WHEN delivery_status = 'picked_up' THEN 1 ELSE 0 END) as on_way,
               SUM(CASE WHEN delivery_status = 'delivered' THEN 1 ELSE 0 END) as delivered
        FROM b2b_orders 
        WHERE receiver_tenant_id = ? AND rider_id IS NOT NULL
        GROUP BY rider_id");
    $stmt_tracking->execute([$_SESSION['tenant_id']]);
    while($row = $stmt_tracking->fetch(PDO::FETCH_ASSOC)) {
        $rider_tracking[$row['rider_id']] = $row;
    }
} catch(Exception $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Rider Management | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Rider Fleet</h1>
                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Manage delivery personnel and dispatchers</p>
            </div>
            <div class="flex gap-3">
                <button onclick="openAssignCustomRideModal()" class="bg-orange-600 text-white px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg active:scale-95 transition-all flex items-center gap-2">
                    <i data-lucide="plus" size="14"></i> Assign Custom Ride
                </button>
                <a href="staff_add.php" class="bg-slate-900 dark:bg-white text-white dark:text-black px-6 py-3 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg active:scale-95 transition-all">
                    Register New Personnel
                </a>
            </div>
        </header>

        <?php if($success_msg || $error_msg): ?>
            <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 rounded-2xl text-xs font-bold flex items-center gap-2 animate-pulse">
                <i data-lucide="<?= $success_msg ? 'check-circle' : 'alert-circle' ?>" size="16"></i> <?= $success_msg ?: $error_msg ?>
            </div>
        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php foreach($riders as $r): 
                $stats = $rider_tracking[$r['id']] ?? ['dispatched' => 0, 'on_way' => 0, 'delivered' => 0];
                $is_on_delivery = $stats['on_way'] > 0;
            ?>
            <div onclick="openRiderTracking(<?= $r['id'] ?>, '<?= htmlspecialchars($r['name']) ?>')" class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm group cursor-pointer hover:border-orange-500/50 transition-all flex flex-col">
                <div class="flex justify-between items-start mb-4">
                    <div class="w-12 h-12 bg-slate-50 dark:bg-neutral-950 rounded-2xl flex items-center justify-center text-orange-600 border border-slate-100 dark:border-neutral-800">
                        <i data-lucide="bike" size="24"></i>
                    </div>
                    <a href="?toggle_id=<?= $r['id'] ?>" class="px-3 py-1 rounded-full text-[8px] font-black uppercase border <?= $r['is_active'] ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20' ?>">
                        <?= $r['is_active'] ? 'Active' : 'Inactive' ?>
                    </a>
                </div>
                <h3 class="text-lg font-black dark:text-white uppercase"><?= htmlspecialchars($r['name']) ?></h3>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1 mb-auto"><?= htmlspecialchars($r['phone']) ?></p>

                <!-- Rider Tracking Stats -->
                <div class="grid grid-cols-3 gap-2 mt-6">
                    <div class="bg-slate-50 dark:bg-neutral-950 p-3 rounded-2xl border border-slate-100 dark:border-neutral-800 text-center">
                        <p class="text-[8px] font-black text-slate-400 uppercase tracking-tighter">Pending</p>
                        <p class="text-sm font-black dark:text-white"><?= $stats['dispatched'] ?></p>
                    </div>
                    <div class="bg-orange-500/5 p-3 rounded-2xl border border-orange-500/10 text-center relative">
                        <?php if($is_on_delivery): ?>
                            <span class="absolute -top-1 -right-1 flex h-2 w-2">
                                <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                                <span class="relative inline-flex rounded-full h-2 w-2 bg-orange-500"></span>
                            </span>
                        <?php endif; ?>
                        <p class="text-[8px] font-black text-orange-500 uppercase tracking-tighter">On Way</p>
                        <p class="text-sm font-black dark:text-orange-500"><?= $stats['on_way'] ?></p>
                    </div>
                    <div class="bg-emerald-500/5 p-3 rounded-2xl border border-emerald-500/10 text-center">
                        <p class="text-[8px] font-black text-emerald-500 uppercase tracking-tighter">Success</p>
                        <p class="text-sm font-black dark:text-emerald-500"><?= $stats['delivered'] ?></p>
                    </div>
                </div>

                <div class="mt-4 pt-4 border-t border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                    <span class="text-[9px] font-black uppercase tracking-widest <?= $is_on_delivery ? 'text-orange-500' : 'text-slate-400' ?>">
                        <?= $is_on_delivery ? 'Currently Delivering' : 'Idle / No Active Trips' ?>
                    </span>
                    <button class="text-slate-400 hover:text-orange-600 transition-colors"><i data-lucide="more-horizontal" size="16"></i></button>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Rider Tracking Modal -->
        <div id="trackingModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm hidden items-center justify-center z-[100] p-4">
            <div class="bg-white dark:bg-neutral-950 w-full max-w-2xl rounded-[40px] border border-slate-200 dark:border-neutral-800 overflow-hidden shadow-2xl">
                <div class="p-8 border-b border-slate-100 dark:border-neutral-900 flex justify-between items-center">
                    <div>
                        <h2 id="modalRiderName" class="text-2xl font-black dark:text-white uppercase tracking-tight">Rider Name</h2>
                        <p class="text-[10px] text-orange-500 font-bold uppercase tracking-widest">Live Delivery Journey</p>
                    </div>
                    <button onclick="closeTrackingModal()" class="w-10 h-10 bg-slate-50 dark:bg-neutral-900 rounded-full flex items-center justify-center text-slate-400 hover:text-rose-500 transition-colors">
                        <i data-lucide="x" size="20"></i>
                    </button>
                </div>

                <div class="p-8">
                    <!-- Courier Style Progress Bar -->
                    <div class="relative flex justify-between mb-12">
                        <div class="absolute top-5 left-0 w-full h-1 bg-slate-100 dark:bg-neutral-800 -z-10"></div>
                        <div id="progressBar" class="absolute top-5 left-0 h-1 bg-orange-500 transition-all duration-700 -z-10" style="width: 0%"></div>
                        
                        <div class="flex flex-col items-center gap-2">
                            <div id="step1" class="w-10 h-10 rounded-full bg-slate-100 dark:bg-neutral-800 flex items-center justify-center text-slate-400 transition-colors border-4 border-white dark:border-neutral-950">
                                <i data-lucide="package" size="16"></i>
                            </div>
                            <span class="text-[9px] font-black uppercase tracking-tighter text-slate-400">Assigned</span>
                        </div>
                        <div class="flex flex-col items-center gap-2">
                            <div id="step2" class="w-10 h-10 rounded-full bg-slate-100 dark:bg-neutral-800 flex items-center justify-center text-slate-400 transition-colors border-4 border-white dark:border-neutral-950">
                                <i data-lucide="truck" size="16"></i>
                            </div>
                            <span class="text-[9px] font-black uppercase tracking-tighter text-slate-400">Picked Up</span>
                        </div>
                        <div class="flex flex-col items-center gap-2">
                            <div id="step3" class="w-10 h-10 rounded-full bg-slate-100 dark:bg-neutral-950 flex items-center justify-center text-slate-400 transition-colors border-4 border-white dark:border-neutral-950">
                                <i data-lucide="check-circle" size="16"></i>
                            </div>
                            <span class="text-[9px] font-black uppercase tracking-tighter text-slate-400">Delivered</span>
                        </div>
                    </div>

                    <h4 class="text-xs font-black text-slate-500 uppercase tracking-widest mb-4">Recent Activity Logs</h4>
                    <div id="deliveryLogs" class="space-y-3 max-h-[300px] overflow-y-auto pr-2 custom-scrollbar">
                        <!-- Logs injected by JS -->
                    </div>
                </div>
            </div>
        </div>

        <!-- Assign Custom Ride Modal -->
        <div id="assignCustomRideModal" class="fixed inset-0 bg-black/80 backdrop-blur-sm hidden items-center justify-center z-[110] p-4">
            <div class="bg-white dark:bg-neutral-950 w-full max-w-md rounded-[40px] border border-slate-200 dark:border-neutral-800 p-8 shadow-2xl relative">
                <button onclick="closeAssignCustomRideModal()" class="absolute top-6 right-6 text-slate-400 hover:text-rose-500 transition-colors">
                    <i data-lucide="x" size="24"></i>
                </button>
                <h2 class="text-2xl font-black dark:text-white uppercase tracking-tight mb-1">Assign Custom Ride</h2>
                <p class="text-[10px] text-orange-500 font-bold uppercase tracking-widest mb-8">Manually dispatch a delivery</p>
                
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="action" value="assign_custom_ride">
                    <div>
                        <label class="block text-[9px] font-black uppercase text-slate-400 mb-2 ml-1">Select Rider</label>
                        <select name="rider_id" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold dark:text-white">
                            <option value="">-- Select Rider --</option>
                            <?php foreach($riders as $r): ?>
                                <option value="<?= $r['id'] ?>"><?= htmlspecialchars($r['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[9px] font-black uppercase text-slate-400 mb-2 ml-1">Customer Name</label>
                        <input type="text" name="customer_name" required placeholder="e.g. John Doe" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold dark:text-white">
                    </div>
                    <div>
                        <label class="block text-[9px] font-black uppercase text-slate-400 mb-2 ml-1">Customer Phone</label>
                        <input type="text" name="customer_phone" required placeholder="e.g. 03XXXXXXXXX" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold dark:text-white">
                    </div>
                    <div>
                        <label class="block text-[9px] font-black uppercase text-slate-400 mb-2 ml-1">Delivery Address</label>
                        <textarea name="delivery_address" required placeholder="e.g. 123 Main St, City" rows="3" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold dark:text-white"></textarea>
                    </div>
                    <div>
                        <label class="block text-[9px] font-black uppercase text-slate-400 mb-2 ml-1">Item Description</label>
                        <input type="text" name="item_description" required placeholder="e.g. 1x Pizza, 2x Cold Drink" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold dark:text-white">
                    </div>
                    <div>
                        <label class="block text-[9px] font-black uppercase text-slate-400 mb-2 ml-1">Total Amount</label>
                        <input type="number" step="0.01" name="total_amount" required value="0.00" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-100 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold dark:text-white">
                    </div>
                    
                    <div class="pt-4">
                        <button type="submit" class="w-full py-5 bg-orange-600 text-white rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-orange-600/20 active:scale-95 transition-all">
                            Assign Ride
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <script>
        lucide.createIcons();

        async function openRiderTracking(riderId, name) {
            document.getElementById('modalRiderName').innerText = name;
            const modal = document.getElementById('trackingModal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');

            const res = await fetch(`riders_management.php?get_rider_details=${riderId}`);
            const orders = await res.json();
            
            const logsContainer = document.getElementById('deliveryLogs');
            logsContainer.innerHTML = '';

            if (orders.length > 0) {
                const latest = orders[0];
                updateProgressBar(latest.delivery_status);
                
                orders.forEach(o => {
                    const div = document.createElement('div');
                    div.className = "p-4 bg-slate-50 dark:bg-neutral-900/50 rounded-2xl border border-slate-100 dark:border-neutral-800 flex justify-between items-center";
                    div.innerHTML = `
                        <div>
                            <p class="text-[10px] font-black text-orange-500 uppercase tracking-tighter">Order #${o.id}</p>
                            <p class="text-sm font-bold dark:text-white">${o.customer}</p>
                        </div>
                        <div class="text-right">
                            <p class="text-[9px] font-black uppercase text-slate-400">${o.created_at}</p>
                            <p class="text-[10px] font-black ${o.delivery_status === 'delivered' ? 'text-emerald-500' : 'text-orange-500'} uppercase">${o.delivery_status}</p>
                        </div>`;
                    logsContainer.appendChild(div);
                });
            }
        }

        function updateProgressBar(status) {
            const steps = { 'dispatched': 1, 'picked_up': 2, 'delivered': 3 };
            const currentStep = steps[status] || 1;
            document.getElementById('progressBar').style.width = ((currentStep - 1) / 2 * 100) + '%';
            
            for(let i=1; i<=3; i++) {
                const el = document.getElementById('step' + i);
                if(i <= currentStep) el.classList.replace('bg-slate-100', 'bg-orange-500'), el.classList.replace('text-slate-400', 'text-white'), el.classList.replace('dark:bg-neutral-800', 'bg-orange-500');
                else el.classList.add('bg-slate-100', 'dark:bg-neutral-800'), el.classList.add('text-slate-400'), el.classList.remove('bg-orange-500', 'text-white');
            }
        }

        function closeTrackingModal() {
            document.getElementById('trackingModal').classList.add('hidden');
            document.getElementById('trackingModal').classList.remove('flex');
        }

        function openAssignCustomRideModal() {
            document.getElementById('assignCustomRideModal').classList.remove('hidden');
            document.getElementById('assignCustomRideModal').classList.add('flex');
        }

        function closeAssignCustomRideModal() {
            document.getElementById('assignCustomRideModal').classList.add('hidden');
            document.getElementById('assignCustomRideModal').classList.remove('flex');
        }
    </script>
</body>
</html>