<?php
/**
 * Cloudinary Storage Helper
 * Direct implementation using cURL to avoid external SDK dependencies.
 */

// Placeholder Credentials - Replace these with your actual details from Cloudinary Dashboard
define('CLOUDINARY_CLOUD_NAME', 'dumptsnaj');
define('CLOUDINARY_API_KEY', '171527256957788');
define('CLOUDINARY_API_SECRET', 'fAVYcRCssn5Np9WvRMoQTa2B5oM');

/**
 * Uploads an image to Cloudinary and returns the secure URL.
 * 
 * @param string $fileTempPath The temporary path of the uploaded file ($_FILES['tmp_name'])
 * @param string $folderName Target folder path in Cloudinary (e.g., 'biltax_tenants/logos')
 * @param string|null $publicId Optional custom public ID (filename) for the image
 * @return string|false The Secure URL of the uploaded image or false on failure
 */
function uploadToCloud($fileTempPath, $folderName, $publicId = null) {
    if (empty($fileTempPath) || !file_exists($fileTempPath)) return false;

    $timestamp = time();
    
    // 1. Prepare parameters for signature (must be sorted alphabetically)
    $params = [
        'folder'    => $folderName,
        'timestamp' => $timestamp
    ];

    if ($publicId) {
        $params['public_id'] = $publicId;
    }
    
    ksort($params);
    
    // 2. Create signature string: sorted_params_joined_by_& + API_SECRET
    $sign_parts = [];
    foreach($params as $key => $value) { $sign_parts[] = "$key=$value"; }
    $to_sign = implode('&', $sign_parts) . CLOUDINARY_API_SECRET;
    $signature = sha1($to_sign);
    
    // 3. Prepare cURL Request
    $url = "https://api.cloudinary.com/v1_1/" . CLOUDINARY_CLOUD_NAME . "/image/upload";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $post_fields = array_merge($params, [
        'file'      => new CURLFile($fileTempPath),
        'api_key'   => CLOUDINARY_API_KEY,
        'signature' => $signature
    ]);
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $data = json_decode($response, true);
    return $data['secure_url'] ?? false;
}

/**
 * Deletes an image from Cloudinary.
 * 
 * @param string $publicId The public ID of the image to delete
 * @return bool True on success, false on failure
 */
function deleteFromCloud($publicId) {
    if (empty($publicId)) return false;

    $timestamp = time();
    
    $params = [
        'public_id' => $publicId,
        'timestamp' => $timestamp
    ];
    
    ksort($params);
    
    // Create signature
    $sign_parts = [];
    foreach($params as $key => $value) { $sign_parts[] = "$key=$value"; }
    $to_sign = implode('&', $sign_parts) . CLOUDINARY_API_SECRET;
    $signature = sha1($to_sign);
    
    $url = "https://api.cloudinary.com/v1_1/" . CLOUDINARY_CLOUD_NAME . "/image/destroy";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    
    $post_fields = array_merge($params, [
        'api_key'   => CLOUDINARY_API_KEY,
        'signature' => $signature
    ]);
    
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_fields);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $data = json_decode($response, true);
    return (isset($data['result']) && $data['result'] === 'ok');
}

/**
 * Gets the total size (in bytes) of all resources within a specific Cloudinary folder.
 * Requires Cloudinary Admin API credentials.
 *
 * @param string $folderName The folder path in Cloudinary (e.g., 'biltax_verifications/123')
 * @return int|false Total size in bytes, or false on failure.
 */
function getCloudinaryFolderSize($folderName) {
    if (empty($folderName)) return false;

    $url = "https://api.cloudinary.com/v1_1/" . CLOUDINARY_CLOUD_NAME . "/resources/search";
    
    // Build query for search API to get all resources in the folder
    $query = "folder:\"$folderName\"";
    
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        "Authorization: Basic " . base64_encode(CLOUDINARY_API_KEY . ":" . CLOUDINARY_API_SECRET)
    ]);
    curl_setopt($ch, CURLOPT_POSTFIELDS, "expression=" . urlencode($query)); // Use POST for search API
    
    $response = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    
    $data = json_decode($response, true);

    if ($http_code === 200 && isset($data['resources'])) {
        $total_size = 0;
        foreach ($data['resources'] as $resource) {
            $total_size += (int)($resource['bytes'] ?? 0);
        }
        return $total_size;
    } else {
        error_log("Cloudinary API Error (getCloudinaryFolderSize): HTTP $http_code - " . ($data['error']['message'] ?? 'Unknown error'));
        return false;
    }
}