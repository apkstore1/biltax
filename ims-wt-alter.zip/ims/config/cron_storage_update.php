<?php
/**
 * Biltax Cron Job: Daily Storage Usage Update for All Tenants
 * This script is designed to be run by a system cron scheduler (e.g., Linux cron).
 * It calculates and updates the storage usage for all active tenants.
 *
 * Usage: php /path/to/your/ims/config/cron_storage_update.php
 */

// Ensure script is run from CLI and not directly via web
if (php_sapi_name() !== 'cli') {
    die("This script can only be accessed via CLI.");
}

// Include necessary files
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/storage_manager.php';

// Log file path
$log_file = __DIR__ . '/cron_storage_update.log';

function log_message($message) {
    global $log_file;
    file_put_contents($log_file, date('[Y-m-d H:i:s] ') . $message . PHP_EOL, FILE_APPEND);
}

log_message("Starting daily storage update cron job.");

try {
    // Establish main database connection (from db_connect.php)
    // $pdo global variable is available from db_connect.php
    if (!isset($pdo)) {
        $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }

    // Fetch all active tenants
    $stmt = $pdo->query("SELECT id, business_name FROM tenants WHERE status = 'active'");
    $tenants = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($tenants as $tenant) {
        log_message("Processing tenant: " . $tenant['business_name'] . " (ID: " . $tenant['id'] . ")");
        $result = calculateTenantStorage($tenant['id']);
        log_message("Tenant " . $tenant['id'] . " storage update result: " . ($result !== false ? $result . " MB" : "Failed"));
    }
    log_message("Daily storage update cron job finished successfully.");
} catch (Exception $e) {
    log_message("CRITICAL ERROR: " . $e->getMessage());
}