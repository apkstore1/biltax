<?php
/**
 * Tenant Database Switcher
 *
 * This script starts a session, reads the tenant's database name ('db_name'),
 * and establishes a PDO connection to that specific database.
 * The resulting connection object is stored in $tenant_conn.
 *
 * This file should be included at the top of any page that needs to
 * interact with a logged-in tenant's data.
 */

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// --- Include Central Database Connection ---
require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/../mailer/email_helper.php';

$tenant_conn = null; // Initialize connection variable
$active_modules = []; // Global modules array
$m_pdo = null; // Share main DB connection
$role_allowed_modules = null; // Global role permissions cache
$logo_url = null; // Global logo variable
$currency_symbol = '$'; // Global fallback
$global_tax_rate = 0;
$max_discount_limit = 100;
$discount_limit_type = 'percentage';
$staff_limit = 5; // Global fallback
$is_super_admin_impersonating = false; // Flag to indicate if Super Admin is viewing tenant panel
$is_system_inactive = false; // Status 'inactive': visible but blurred/locked
$is_system_locked = false;   // Status 'locked' or Expired: Hidden except whitelist

// Clear any previous lock reason
unset($_SESSION['lock_reason']);

if (isset($_SESSION['super_admin_backup'])) {
    $is_super_admin_impersonating = true;
}
$branch_limit = 1; // Global fallback
$has_critical_verification = false; // Flag for Red Alert Bar

// Check if a tenant is logged in (i.e., db_name is in the session)
if (isset($_SESSION['db_name']) && !empty($_SESSION['db_name'])) {
    $tenant_db_name = $_SESSION['db_name'];
    $industry_type = strtolower(trim($_SESSION['industry_type'] ?? 'retail'));

    try {
        // Establish connection to the specific tenant's database
        $tenant_conn = new PDO("mysql:host=" . DB_HOST . ";dbname=$tenant_db_name", DB_USER, DB_PASS);
        $tenant_conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Connect to Main DB to fetch Tenant Config & Modules
        $m_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
        $m_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // --- Package Features Self-Healing ---
        try {
            $m_pdo->exec("CREATE TABLE IF NOT EXISTS package_features (id INT PRIMARY KEY AUTO_INCREMENT, package_id INT NOT NULL, module_id INT NOT NULL)");
        } catch(Exception $e) {}


        // --- CRITICAL SELF-HEALING (Must run before SELECT query) ---
        // Using SHOW COLUMNS for universal MySQL compatibility to prevent 500 errors
        $t_cols = $m_pdo->query("SHOW COLUMNS FROM tenants")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('branch_limit', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN branch_limit INT DEFAULT 1");
        if (!in_array('package_id', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN package_id INT DEFAULT 1");
        if (!in_array('staff_limit', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN staff_limit INT DEFAULT 5");
        if (!in_array('currency_code', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN currency_code VARCHAR(10) DEFAULT 'USD'");
        if (!in_array('currency_symbol', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN currency_symbol VARCHAR(10) DEFAULT '$'");
        if (!in_array('tax_rate', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN tax_rate DECIMAL(5,2) DEFAULT 0.00");
        if (!in_array('max_discount_limit', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN max_discount_limit DECIMAL(15,2) DEFAULT 100.00");
        if (!in_array('allow_receipt_reprint', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN allow_receipt_reprint TINYINT(1) DEFAULT 0");
        if (!in_array('current_storage_usage', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN current_storage_usage DECIMAL(10,2) DEFAULT 0.00");
        if (!in_array('storage_limit', $t_cols)) $m_pdo->exec("ALTER TABLE tenants ADD COLUMN storage_limit INT DEFAULT 1");
        
        try { $m_pdo->exec("ALTER TABLE tenants MODIFY COLUMN discount_limit_type ENUM('percentage', 'fixed', 'disabled') DEFAULT 'fixed'"); } catch(Exception $e) {}

        // Update notification types
        try {
            $m_pdo->exec("ALTER TABLE notifications MODIFY COLUMN type ENUM('announcement', 'system', 'alert', 'verification_task', 'expiry_alert', 'service_reminder', 'b2b_order') DEFAULT 'announcement'");
        } catch(Exception $e) {}

        // Ensure role_permissions table exists in main DB to prevent has_module crash
        try { $m_pdo->exec("CREATE TABLE IF NOT EXISTS role_permissions (id INT PRIMARY KEY AUTO_INCREMENT, role_key VARCHAR(50), module_key VARCHAR(50), is_allowed TINYINT(1) DEFAULT 1, UNIQUE KEY unique_role_mod (role_key, module_key))"); } catch(Exception $e) {}


    // --- Subscription & Expiry Logic ---
    $sub_status = 'inactive';
    $sub_expiry = 'N/A';

    // 1. Fetch Global Settings & Tenant Status
    $stmt_conf = $m_pdo->prepare("SELECT id, status, email, logo_url, package_id, business_category_id, currency_code, currency_symbol, tax_rate, max_discount_limit, discount_limit_type, staff_limit, branch_limit, allow_receipt_reprint, current_storage_usage, storage_limit 
                                     FROM tenants 
                                     WHERE db_name = ?");
        $stmt_conf->execute([$tenant_db_name]);
        $t_conf = $stmt_conf->fetch(PDO::FETCH_ASSOC);

    if ($t_conf) {
        $tenant_status = $t_conf['status'] ?? 'active';
        $_SESSION['tenant_status'] = $tenant_status;

        // --- Storage Limit Check ---
        $current_storage_usage = (float)($t_conf['current_storage_usage'] ?? 0);
        $storage_limit = (int)($t_conf['storage_limit'] ?? 1);

        // If storage is full and tenant is not already locked or suspended
        if ($current_storage_usage >= $storage_limit && $tenant_status !== 'locked' && $tenant_status !== 'suspended') {
            // Update tenant status to 'locked' in the main database
            $m_pdo->prepare("UPDATE tenants SET status = 'locked' WHERE id = ?")->execute([$t_conf['id']]);
            $tenant_status = 'locked'; // Update current status for this request
            $_SESSION['tenant_status'] = 'locked';
            $_SESSION['lock_reason'] = 'storage_full'; // Set lock reason

            // Add a notification for storage full
            $title = "Storage Limit Reached";
            $msg = "Your account has reached its storage limit of {$storage_limit} MB. Please upgrade your plan to continue using all features.";
            $check = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND DATE(created_at) = CURDATE()");
            $check->execute([$t_conf['id'], $title]);
            if ($check->fetchColumn() == 0) {
                $m_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'alert')")->execute([$t_conf['id'], $title, $msg]);
            }
        }

        // --- ACTION 1: SUSPENDED CHECK ---
        if ($tenant_status === 'suspended' && !$is_super_admin_impersonating) {
            http_response_code(403);
            echo "<style>
                body { background: #0a0a0a; color: white; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
                .box { text-align: center; border: 1px solid #333; padding: 40px; border-radius: 24px; background: #111; max-width: 400px; }
                h1 { color: #e11d48; margin-bottom: 10px; text-transform: uppercase; letter-spacing: 2px; }
                p { color: #888; line-height: 1.6; }
            </style>
            <div class='box'>
                <h1>Account Suspended</h1>
                <p>Your business access has been suspended by the administrator. Please contact Biltax Support for further details.</p>
                <a href='login.php' style='color: white; text-decoration: underline; font-size: 12px; margin-top: 20px; display: block;'>Back to Login</a>
            </div>";
            exit;
        }

        try {
            $stmt_sub = $m_pdo->prepare("SELECT status, expiry_date FROM subscriptions WHERE tenant_id = ? ORDER BY id DESC LIMIT 1");
            $stmt_sub->execute([$t_conf['id']]);
            $sub_info = $stmt_sub->fetch(PDO::FETCH_ASSOC);

            if ($sub_info) {
                $sub_status = $sub_info['status'];
                $sub_expiry = $sub_info['expiry_date'];

                // Fetch Actual Plan Name
                $stmt_pn = $m_pdo->prepare("SELECT package_name FROM packages WHERE id = ?");
                $stmt_pn->execute([$t_conf['package_id']]);
                $_SESSION['subscription_plan_name'] = $stmt_pn->fetchColumn() ?: 'Starter';

                // Auto-Expiry (Safe Check)
                if ($m_pdo && ($sub_status === 'active' || $sub_status === 'trial') && $sub_expiry && $sub_expiry < date('Y-m-d')) {
                    $m_pdo->prepare("UPDATE subscriptions SET status = 'expired' WHERE tenant_id = ?")->execute([$t_conf['id']]);
                    $sub_status = 'expired';

                    // Real-time notification for expiry
                    $title = "Subscription Expired";
                    $msg = "Your subscription has expired. Please renew now to avoid service interruption.";
                    $check = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND DATE(created_at) = CURDATE()");
                    $check->execute([$t_conf['id'], $title]);
                    if ($check->fetchColumn() == 0) {
                        // Only add notification if not already added today
                        $m_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'alert')")
                            ->execute([$t_conf['id'], $title, $msg]);
                        
                        // Send Expiry Email
                        sendBiltaxEmail($t_conf['email'] ?? '', 'Subscription Expired', [
                            'days_left' => '0', 
                            'plan_name' => $_SESSION['subscription_plan_name'] ?? 'Plan'
                        ], 'expiry');
                    }
                }
            }
        } catch (Exception $e) {
            // Billing tables not ready, fail silently to keep dashboard alive
        }
        $_SESSION['subscription_status'] = $sub_status;
        $_SESSION['subscription_expiry'] = $sub_expiry;

        // --- ACTION 2: STATE DETECTION ---
        $valid_subs = ['active', 'trial'];
        
        // State 1: Inactive (Blurred/Locked)
        if ($tenant_status === 'inactive') {
            $is_system_inactive = true;
        }
        // State 2: Locked (Hidden except whitelist) - also triggered by expiry
        if ($tenant_status === 'locked' || !in_array($sub_status, $valid_subs)) {
            $is_system_locked = true;
            // If lock_reason is not already set by storage full, set it to subscription_expired
            if (!isset($_SESSION['lock_reason']) && $tenant_status !== 'suspended') { // Don't overwrite if already suspended
                $_SESSION['lock_reason'] = 'subscription_expired';
            }
        }
    }

        if ($t_conf) { // Ensure $t_conf is not false
            $currency_symbol = $t_conf['currency_symbol'] ?: '$';
            $logo_url = $t_conf['logo_url'];
            $global_tax_rate = (float)($t_conf['tax_rate'] ?? 0);
            $max_discount_limit = (float)($t_conf['max_discount_limit'] ?? 100);
            $discount_limit_type = $t_conf['discount_limit_type'] ?? 'percentage';
            $allow_receipt_reprint = (bool)($t_conf['allow_receipt_reprint'] ?? 0);
            $staff_limit = (int)($t_conf['staff_limit'] ?? 5);
            $branch_limit = (int)($t_conf['branch_limit'] ?? 1);
            $current_storage_usage = (float)($t_conf['current_storage_usage'] ?? 0);
            $storage_limit = (int)($t_conf['storage_limit'] ?? 1);
            
            // 2. Fetch Modules (Only if $t_conf['id'] is valid)
            // Combined Logic: Manual Enabled + Industry Defaults + Package Features
            $stmt_mod = $m_pdo->prepare("
                SELECT module_key FROM enabled_modules WHERE tenant_id = ? AND is_active = 1
                UNION
                SELECT module_key FROM category_modules WHERE category_id = ?
                UNION
                SELECT m.module_key FROM package_features pf JOIN modules m ON pf.module_id = m.id WHERE pf.package_id = ?
            ");
            $stmt_mod->execute([$t_conf['id'], $t_conf['business_category_id'], $t_conf['package_id']]);
            $active_modules = $stmt_mod->fetchAll(PDO::FETCH_COLUMN);
        }

        // Self-healing: Ensure core 'users' table exists for staff management and payroll
        try {
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS users (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                role VARCHAR(50) NOT NULL,
                password VARCHAR(255) NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            $tenant_conn->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS assigned_branch_id INT DEFAULT NULL");
        } catch(Exception $e) {}
        // Self-healing for users table: assigned_branch_id
        try {
            // Basic products table for all industries to prevent dashboard crashes
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS products (id INT PRIMARY KEY AUTO_INCREMENT, branch_id INT, name VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
        } catch(Exception $e) {}

        try {
            // Ensure sales table exists
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS sales (
                id INT PRIMARY KEY AUTO_INCREMENT,
                branch_id INT DEFAULT NULL,
                customer_id INT DEFAULT NULL,
                total_amount DECIMAL(15,2) NOT NULL,
                payment_method VARCHAR(50) DEFAULT 'Cash',
                discount_amount DECIMAL(10,2) DEFAULT 0.00,
                tax_amount DECIMAL(10,2) DEFAULT 0.00,
                return_status ENUM('no_returns', 'partial_return', 'full_return') DEFAULT 'no_returns',
                status ENUM('pending', 'completed', 'cancelled') DEFAULT 'completed',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
        } catch(Exception $e) {}

        try {
            // Ensure sale_items table exists
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS sale_items (
                id INT PRIMARY KEY AUTO_INCREMENT,
                sale_id INT NOT NULL,
                product_id INT NOT NULL,
                quantity DECIMAL(10,2) NOT NULL,
                price DECIMAL(15,2) NOT NULL,
                returned_quantity DECIMAL(10,2) DEFAULT 0,
                FOREIGN KEY (sale_id) REFERENCES sales(id) ON DELETE CASCADE
            )");
        } catch(Exception $e) {}

        try {
            // Ensure stock table exists
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS stock (
                id INT PRIMARY KEY AUTO_INCREMENT,
                product_id INT NOT NULL,
                quantity_change DECIMAL(10,2) NOT NULL,
                reason TEXT,
                expiry_date DATE DEFAULT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
            )");

            // Ensure customers table exists for sales/ledgers
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS customers (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(255) NOT NULL,
                phone VARCHAR(50),
                email VARCHAR(255),
                address TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            $tenant_conn->exec("ALTER TABLE customers ADD COLUMN IF NOT EXISTS address TEXT");
        } catch(Exception $e) {}

        // Self-healing: Ensure restaurant_tables exists with correct schema
        try {
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS restaurant_tables (
                id INT PRIMARY KEY AUTO_INCREMENT,
                branch_id INT,
                table_number VARCHAR(50) NOT NULL,
                capacity INT DEFAULT 2,
                status ENUM('available', 'occupied', 'reserved') DEFAULT 'available',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
        } catch(Exception $e) {}

        try { $tenant_conn->exec("ALTER TABLE users ADD COLUMN assigned_branch_id INT DEFAULT NULL"); } catch(Exception $e) {}

        // --- Service Industry Self-Healing ---
        try {
            // 1. Service Catalog (What you offer)
            // Self-healing: Ensure table and new columns like checklists (JSON) exist
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS services (
                id INT PRIMARY KEY AUTO_INCREMENT,
                service_name VARCHAR(255) NOT NULL,
                description TEXT,
                base_price DECIMAL(15,2) DEFAULT 0,
                category VARCHAR(100),
                is_active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");

            try { $tenant_conn->exec("ALTER TABLE services ADD COLUMN tenant_id INT"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE services ADD COLUMN checklists JSON DEFAULT NULL"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE services ADD COLUMN price DECIMAL(15,2) DEFAULT 0.00"); } catch(Exception $e) {}

            // 2. Expand Job Cards for Universal Tracking
            // Adding JSON field for checklists and customer_id for deep CRM integration
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN assigned_to INT"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN tenant_id INT"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards MODIFY COLUMN status VARCHAR(50) DEFAULT 'pending'"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards MODIFY COLUMN customer_name VARCHAR(255) NULL, MODIFY COLUMN customer_phone VARCHAR(50) NULL"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN customer_id INT"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN technician_id INT"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards MODIFY COLUMN estimated_cost DECIMAL(15,2) DEFAULT 0.00"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN service_id INT"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN priority ENUM('low', 'medium', 'high') DEFAULT 'medium'"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN task_completion_data JSON DEFAULT NULL"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN total_cost DECIMAL(15,2) DEFAULT 0"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE job_cards ADD COLUMN next_recurring_date DATE DEFAULT NULL"); } catch(Exception $e) {}
            
            // 3. Global Tenant Settings (Key-Value Pair)
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS tenant_settings (
                setting_key VARCHAR(100) PRIMARY KEY,
                setting_value TEXT,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )");

            // 3. Universal Cron Management Table
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS universal_cron_configs (
                id INT PRIMARY KEY AUTO_INCREMENT,
                tenant_id INT NOT NULL,
                job_name VARCHAR(100) NOT NULL,
                frequency_minutes INT DEFAULT 60,
                last_run DATETIME DEFAULT NULL,
                is_active TINYINT(1) DEFAULT 1,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            
            // 4. Universal Cron Logs
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS universal_cron_logs (
                id INT PRIMARY KEY AUTO_INCREMENT,
                job_name VARCHAR(100),
                status ENUM('success', 'failed') DEFAULT 'success',
                message TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");

            // 5. Tenant Notifications
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS notifications (
                id INT PRIMARY KEY AUTO_INCREMENT,
                title VARCHAR(255),
                message TEXT,
                is_read TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");

            // Ensure customers table has recurring type for contracts
            try { $tenant_conn->exec("ALTER TABLE customers ADD COLUMN recurring_type ENUM('none', 'monthly', 'quarterly', 'yearly') DEFAULT 'none'"); } catch(Exception $e) {}
            try { $tenant_conn->exec("ALTER TABLE customers ADD COLUMN last_service_date DATE DEFAULT NULL"); } catch(Exception $e) {}
        } catch (Exception $e) {}

        // --- Multi-Branch Self-Healing ---
        try {
            // 1. Create Branches Table in Tenant DB
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS branches (
                id INT PRIMARY KEY AUTO_INCREMENT,
                branch_name VARCHAR(255) NOT NULL,
                address TEXT,
                has_own_stock TINYINT(1) DEFAULT 1,
                is_main TINYINT(1) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");

            // 2. Add branch_id to products if not exists
            try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN branch_id INT AFTER id"); } catch(Exception $e) {}
            
            // 2a. Ensure purchases table has branch_id support
            try { $tenant_conn->exec("ALTER TABLE purchases ADD COLUMN branch_id INT AFTER id"); } catch(Exception $e) {}
            
            // 3. Ensure at least one Main branch exists and link existing products to it
            $bc = $tenant_conn->query("SELECT COUNT(*) FROM branches WHERE is_main = 1")->fetchColumn();
            if ($bc == 0) {
                $tenant_conn->exec("INSERT INTO branches (branch_name, is_main, has_own_stock) VALUES ('Main Account', 1, 1)");
                $main_id = $tenant_conn->lastInsertId();
                $tenant_conn->exec("UPDATE sales SET branch_id = $main_id WHERE branch_id IS NULL"); // Fix legacy sales
            } else {
                $main_id = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1")->fetchColumn();
            }

            // --- Multi-Branch Data Consolidation (Self-Healing) ---
            // Ensure legacy data (NULL branch_id) is linked to the Main Account so it shows up in history
            if ($main_id) {
                $tenant_conn->exec("UPDATE products SET branch_id = $main_id WHERE branch_id IS NULL");
                $tenant_conn->exec("UPDATE sales SET branch_id = $main_id WHERE branch_id IS NULL");
                try { $tenant_conn->exec("UPDATE purchases SET branch_id = $main_id WHERE branch_id IS NULL"); } catch(Exception $e) {}
                
                // Fix legacy B2B orders in Main DB for the current tenant
                if (isset($t_conf['id'])) {
                    $m_pdo->prepare("UPDATE b2b_orders SET sender_branch_id = ? WHERE sender_tenant_id = ? AND sender_branch_id IS NULL")->execute([$main_id, $t_conf['id']]);
                    $m_pdo->prepare("UPDATE b2b_orders SET receiver_branch_id = ? WHERE receiver_tenant_id = ? AND receiver_branch_id IS NULL")->execute([$main_id, $t_conf['id']]);
                }
            }
        } catch (Exception $e) { /* Fail silently */ }

        // --- Global Tables for all Industries (Units & Categories) ---
        try {
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS categories (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL, is_allowed TINYINT(1) DEFAULT 1)");
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS units (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50) NOT NULL, is_allowed TINYINT(1) DEFAULT 1)");
        } catch (Exception $e) {}

        // --- Individual Column Self-Healing (Safer for MySQL) ---
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN is_b2b_public TINYINT(1) DEFAULT 0"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN is_expirable TINYINT(1) DEFAULT 0"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN is_active TINYINT(1) DEFAULT 1"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN allow_partner_view TINYINT(1) DEFAULT 0"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN is_raw TINYINT(1) DEFAULT 0"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN category VARCHAR(255) DEFAULT NULL"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN description TEXT DEFAULT NULL"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN sku VARCHAR(100) DEFAULT NULL"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN sale_price DECIMAL(15,2) DEFAULT 0.00"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN purchase_price DECIMAL(15,2) DEFAULT 0.00"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN stock_level DECIMAL(10,2) DEFAULT 0"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN alert_level INT DEFAULT 10"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN unit_id INT DEFAULT NULL"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN category_id INT DEFAULT NULL"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN has_stock TINYINT(1) DEFAULT 0"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN price DECIMAL(15,2) DEFAULT 0.00"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN is_raw_component TINYINT(1) DEFAULT 0"); } catch (Exception $e) {}
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN is_sellable TINYINT(1) DEFAULT 1"); } catch (Exception $e) {}

        // Setup Raw Material Components Table (Alternative to Recipes for Retail)
        try {
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS product_components (id INT PRIMARY KEY AUTO_INCREMENT, product_id INT NOT NULL, component_id INT NOT NULL, quantity DECIMAL(10,3) NOT NULL, FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE)");
        } catch(Exception $e) {}

        
        // --- Finance & Accounts System Self-Healing ---
        try {
            // 1. Expense Categories (Electricity, Rent, Fuel, etc.)
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS expense_categories (
                id INT PRIMARY KEY AUTO_INCREMENT,
                name VARCHAR(100) NOT NULL,
                description TEXT
            )");

            // 2. Expenses Table
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS expenses (
                id INT PRIMARY KEY AUTO_INCREMENT,
                branch_id INT,
                category_id INT,
                amount DECIMAL(15,2) NOT NULL,
                payment_method VARCHAR(50) DEFAULT 'Cash',
                description TEXT,
                receipt_url VARCHAR(255) DEFAULT NULL,
                expense_date DATE,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (category_id) REFERENCES expense_categories(id) ON DELETE SET NULL
            )");

            // 3. Payroll Settings (Per Staff)
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS payroll_configs (
                id INT PRIMARY KEY AUTO_INCREMENT,
                user_id INT UNIQUE,
                base_salary DECIMAL(15,2) DEFAULT 0,
                allowances DECIMAL(15,2) DEFAULT 0,
                deductions DECIMAL(15,2) DEFAULT 0,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            )");

            // 4. Salary Payments (History)
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS salary_payments (
                id INT PRIMARY KEY AUTO_INCREMENT,
                branch_id INT,
                user_id INT,
                amount_paid DECIMAL(15,2) NOT NULL,
                payment_date DATE,
                month_year VARCHAR(20), -- e.g., 'March 2024'
                payment_method VARCHAR(50) DEFAULT 'Cash',
                reference_no VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            try { $tenant_conn->exec("ALTER TABLE expenses ADD COLUMN receipt_url VARCHAR(255) DEFAULT NULL AFTER description"); } catch(Exception $e) {}
        } catch (Exception $e) {}

        // --- Self-healing: Ensure ledgers table exists for financial transactions ---
        try {
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS ledgers (
                id INT PRIMARY KEY AUTO_INCREMENT,
                branch_id INT,
                party_name VARCHAR(255) NOT NULL,
                party_type ENUM('customer', 'supplier') NOT NULL,
                description TEXT,
                debit DECIMAL(15,2) DEFAULT 0,
                credit DECIMAL(15,2) DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )");
            try { $tenant_conn->exec("ALTER TABLE ledgers ADD COLUMN branch_id INT AFTER id"); } catch(Exception $e) {}
        } catch (Exception $e) { /* Silent fail if table exists or other issue */ }

        // --- Rider Tracking System Module ---
        if (in_array('rider_tracking', $active_modules)) {
            try {
                $tenant_conn->exec("CREATE TABLE IF NOT EXISTS riders (
                    id INT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(255) NOT NULL,
                    phone VARCHAR(50) UNIQUE,
                    password VARCHAR(255) DEFAULT NULL,
                    is_active TINYINT(1) DEFAULT 1,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                )");
                try { $tenant_conn->exec("ALTER TABLE riders ADD COLUMN password VARCHAR(255) DEFAULT NULL"); } catch(Exception $e) {}
                try { $m_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN rider_id INT DEFAULT NULL"); } catch(Throwable $e) {}
                try { $m_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN delivery_status VARCHAR(50) DEFAULT 'pending'"); } catch(Throwable $e) {}
                try { $m_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN customer_name VARCHAR(255) DEFAULT NULL"); } catch(Throwable $e) {}
                try { $m_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN customer_phone VARCHAR(50) DEFAULT NULL"); } catch(Throwable $e) {}
                try { $m_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN delivery_address TEXT DEFAULT NULL"); } catch(Throwable $e) {}
                try { $m_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN item_description TEXT DEFAULT NULL"); } catch(Throwable $e) {}
            } catch(Exception $e) {}
        }

        // --- Recipe Management Table ---
        try {
            $tenant_conn->exec("CREATE TABLE IF NOT EXISTS recipes (
                id INT PRIMARY KEY AUTO_INCREMENT,
                product_id INT NOT NULL,
                ingredient_id INT NOT NULL,
                quantity DECIMAL(10,3) NOT NULL DEFAULT 1.00
            )");
            // Ensure ingredient_id exists (fixes legacy table structure from older versions)
            try { $tenant_conn->exec("ALTER TABLE recipes ADD COLUMN ingredient_id INT NOT NULL AFTER product_id"); } catch(Exception $e) {}
            // Ensure quantity is DECIMAL type for precise measurement
            try { $tenant_conn->exec("ALTER TABLE recipes MODIFY COLUMN quantity DECIMAL(10,3) NOT NULL DEFAULT 1.00"); } catch(Exception $e) {}
        } catch (Exception $e) {}
        
        try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP"); } catch (Exception $e) {}

        // --- Restaurant Specific Price Column Fix ---
        try {
            if ($industry_type === 'restaurant') {
                $stmt_p = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'price'");
                $price_exists = $stmt_p->fetch();

                $stmt_sp = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'sale_price'");
                $sale_price_exists = $stmt_sp->fetch();

                if (!$price_exists) {
                    if ($sale_price_exists) {
                        $tenant_conn->exec("ALTER TABLE products CHANGE COLUMN sale_price price DECIMAL(15,2) NOT NULL DEFAULT 0.00");
                    } else {
                        $tenant_conn->exec("ALTER TABLE products ADD COLUMN price DECIMAL(15,2) NOT NULL DEFAULT 0.00 AFTER name");
                    }
                } elseif ($price_exists && $sale_price_exists) {
                    $tenant_conn->exec("ALTER TABLE products DROP COLUMN sale_price");
                }
            }
        } catch (Exception $e) { /* Column check failed or table doesn't exist */ }

        // Self-healing: Ensure verification_tasks table exists in main database
        try {
            $m_pdo->exec("CREATE TABLE IF NOT EXISTS verification_tasks (
                id INT PRIMARY KEY AUTO_INCREMENT,
                tenant_id INT NOT NULL,
                task_title VARCHAR(255) NOT NULL,
                task_description TEXT,
                required_docs TEXT, 
                submitted_docs TEXT,
                priority ENUM('low', 'medium', 'high') DEFAULT 'low',
                status ENUM('not_started', 'pending_review', 'approved', 'rejected') DEFAULT 'not_started',
                admin_reason TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
            )");
        } catch (Exception $e) { /* Table creation failed or already exists */ }

        // 3. Check for High Priority Verification Tasks
        if (isset($t_conf['id']) && in_array('verification_center', $active_modules)) {
            $stmt_v = $m_pdo->prepare("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id = ? AND priority = 'high' AND status IN ('not_started', 'rejected')");
            $stmt_v->execute([$t_conf['id']]);
            $has_critical_verification = ($stmt_v->fetchColumn() > 0);
        }

        // --- Initialize Active Branch Session ---
        $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
        $main_branch_id = $stmt_main->fetchColumn();

        // Force Main Branch if module is disabled or session not set
        if (!isset($_SESSION['active_branch_id']) || !in_array('manage_branches', $active_modules)) {
            if ($main_branch_id) $_SESSION['active_branch_id'] = $main_branch_id;
        }

        // --- Branch Switching Handler ---
        if (isset($_GET['switch_branch_id'])) {
            $sid_raw = $_GET['switch_branch_id'];

            // Lock Down: Staff with assignment cannot switch
            $can_switch = true;
            if (isset($_SESSION['staff_id']) && isset($_SESSION['staff_restricted']) && $_SESSION['staff_restricted'] === true) {
                $can_switch = false;
            }

            if ($can_switch && $sid_raw === 'all') {
                $_SESSION['active_branch_id'] = 'all';
                header("Location: " . strtok($_SERVER["REQUEST_URI"], '?'));
                exit;
            } elseif ($can_switch) {
                $sid = (int)$_GET['switch_branch_id'];
                // Verify branch belongs to tenant
                $stmt_v = $tenant_conn->prepare("SELECT COUNT(*) FROM branches WHERE id = ?");
                $stmt_v->execute([$sid]);
                if ($stmt_v->fetchColumn() > 0) {
                    $_SESSION['active_branch_id'] = $sid;
                    header("Location: " . strtok($_SERVER["REQUEST_URI"], '?')); // Redirect back to same page without param
                    exit;
                }
            }
        }

        // Fallback defaults if no modules are explicitly enabled in DB
        if (empty($active_modules)) {
            $active_modules = ['dashboard', 'reports', 'settings', 'manage_branches', 'inventory', 'support_tickets', 'documentation', 'knowledge_base', 'biltax_hub', 'marketplace_main']; 
            switch ($industry_type) {
                case 'restaurant':
                    $active_modules = array_merge($active_modules, ['food_pos', 'tables', 'kot', 'recipes', 'staff', 'receipt_reprint']);
                    break;
                case 'wholesale':
                    $active_modules = array_merge($active_modules, ['bulk_sales', 'inventory', 'ledgers', 'purchases', 'staff', 'partner_network', 'b2b_returns', 'b2b_orders', 'receipt_reprint']);
                    break;
                case 'service':
                    $active_modules = array_merge($active_modules, ['jobs', 'customers', 'reminders', 'receipt_reprint']);
                    break;
                default: // Retail
                    $active_modules = array_merge($active_modules, ['retail_pos', 'inventory', 'suppliers', 'barcodes', 'sales_reports', 'staff', 'purchases', 'whatsapp_email_sharing', 'receipt_reprint']);
                    break;
            }
        }

        /**
         * Background sync calls removed from here to prevent 500 errors on every page load.
         * Syncing is now handled exclusively by the notification API.
         */

    } catch (PDOException $e) {
        // If connection fails, stop everything and show an error.
        http_response_code(503); // Service Unavailable
        die("FATAL ERROR: Could not connect to database. Error: " . $e->getMessage());
    }
}

// --- ACTION 3: ACCESS REDIRECTION LOGIC ---
$current_script = basename($_SERVER['PHP_SELF']);
$current_slug = basename($_SERVER['PHP_SELF'], '.php');

// Whitelisted pages in Locked state
$whitelisted_pages = [
    'billing_plans_view.php', 'billing_history.php', 'setting.php', 
    'support_tickets.php', 'documentation.php', 'knowledge_base.php', 
    'pay_now.php', 'logout.php', 'locked_feature.php', 'login.php',
    'api.php', 'api_notifications.php', 'api_mark_read.php'
];

// Both Inactive and Locked states redirect non-whitelisted pages
if (($is_system_locked || $is_system_inactive) && !in_array($current_script, $whitelisted_pages) && !$is_super_admin_page) {
    $redirect_url = "billing_plans_view.php?lock=true";
    if (isset($_SESSION['lock_reason'])) { $redirect_url .= "&reason=" . $_SESSION['lock_reason']; }
    header("Location: " . $redirect_url);
    exit;
}

/**
 * World-class Module Access Helper
 */
if (!function_exists('has_module')) {
    function has_module($key) {
        global $active_modules, $role_allowed_modules, $m_pdo;
        
        // 1. Tenant-Level Check
        // Core support and hub modules bypass the tenant-enabled check so Role Permissions can control them globally.
        $global_bypass_keys = ['documentation', 'knowledge_base', 'support_tickets', 'biltax_hub', 'marketplace_main', 'live_chat', 'notifications'];
        
        if (!in_array($key, $active_modules) && !in_array($key, $global_bypass_keys)) return false;

        // 2. Role Check: Admin always has full access
        $user_role = strtolower(trim($_SESSION['role'] ?? 'admin'));
        if ($user_role === 'admin') return true;

        // 3. Check Role-based permissions from main DB
        if ($role_allowed_modules === null) {
            try {
                if (!$m_pdo) {
                    $m_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
                    $m_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                }
                $stmt_perm = $m_pdo->prepare("SELECT module_key FROM role_permissions WHERE role_key = ? AND is_allowed = 1");
                $stmt_perm->execute([$user_role]);
                $role_allowed_modules = $stmt_perm->fetchAll(PDO::FETCH_COLUMN);
            } catch (Exception $e) {
                $role_allowed_modules = []; // Fallback empty if table missing
            }
        }

        return in_array($key, $role_allowed_modules);
    }
}

/**
 * Background helper to detect low stock and notify the main dashboard
 */
function syncLowStockAlerts($host, $user, $pass, $tenant_pdo, $db_name) {
    try {
        // Connect to Main DB for notifications
        $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
        
        // 1. Get Tenant ID and Email from main database
        $stmt = $main_pdo->prepare("SELECT id, email FROM tenants WHERE db_name = ?");
        $stmt->execute([$db_name]);
        $t_data = $stmt->fetch(PDO::FETCH_ASSOC);
        $tenant_id = $t_data['id'] ?? null;
        $tenant_email = $t_data['email'] ?? '';
        
        if (!$tenant_id) return;

        // 2. Safe check for columns before query to prevent 500 error
        $stmt_cols = $tenant_pdo->query("SHOW COLUMNS FROM products");
        $cols = $stmt_cols->fetchAll(PDO::FETCH_COLUMN);
        
        if (!in_array('stock_level', $cols) || !in_array('alert_level', $cols)) return;

        $stmt_low = $tenant_pdo->query("SELECT name, sku, stock_level, alert_level FROM products WHERE stock_level <= alert_level");
        $low_stock_items = $stmt_low ? $stmt_low->fetchAll(PDO::FETCH_ASSOC) : [];

        foreach ($low_stock_items as $item) {
            $title = "Low Stock Alert";
            $msg = "Warning: Product '" . $item['name'] . "' (" . $item['sku'] . ") has reached critical level. Current: " . $item['stock_level'];

            // 3. Prevent Duplicate Spam (Check if a similar alert was sent in the last 24 hours)
            $check = $main_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND message = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
            $check->execute([$tenant_id, $title, $msg]);

            if ($check->fetchColumn() == 0) {
                // 4. Insert System Notification
                $ins = $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'system')");
                $ins->execute([$tenant_id, $title, $msg]);

                // 5. Send Stock Alert Email
                sendBiltaxEmail($tenant_email, 'Low Stock Alert', ['items' => [['name' => $item['name'], 'stock' => $item['stock_level']]]], 'stock_alert');
            }
        }
    } catch (Exception $e) {
        // Silently fail to ensure the main application logic remains uninterrupted
    }
}

/**
 * Background helper to detect subscription expiry and notify
 */
if (!function_exists('syncSubscriptionExpiryNotifications')) {
    function syncSubscriptionExpiryNotifications($m_pdo, $tenant_id) {
        try {
            // Get Email for the tenant
            $stmt_e = $m_pdo->prepare("SELECT email FROM tenants WHERE id = ?");
            $stmt_e->execute([$tenant_id]);
            $t_email = $stmt_e->fetchColumn() ?: '';

            // 1. Check for Expiry Tomorrow (1 Day Before)
            $tomorrow = date('Y-m-d', strtotime('+1 day'));
            $stmt = $m_pdo->prepare("SELECT s.expiry_date, p.package_name FROM subscriptions s JOIN packages p ON s.plan_id = p.id WHERE s.tenant_id = ? AND s.status IN ('active', 'trial') AND s.expiry_date = ?");
            $stmt->execute([$tenant_id, $tomorrow]);
            $sub = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($sub) {
                $title = "Subscription Expiring Tomorrow";
                $msg = "Your subscription for " . $sub['package_name'] . " will expire tomorrow. Please renew to avoid interruption.";
                
                $check = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND DATE(created_at) = CURDATE()");
                $check->execute([$tenant_id, $title]);

                if ($check->fetchColumn() == 0) {
                    $m_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'alert')")
                        ->execute([$tenant_id, $title, $msg]);

                    // Send 1-Day Warning Email
                    sendBiltaxEmail($t_email, 'Plan Expiring Tomorrow', [
                        'days_left' => '1', 
                        'plan_name' => $sub['package_name']
                    ], 'expiry');
                }
            }

            // Note: "Expired" notification is handled in the main db_switch loop above 
            // when status transition happens.

        } catch (Exception $e) {
            error_log("Subscription Sync Error: " . $e->getMessage());
        }
    }
}

/**
 * Background helper to detect expiring stock and notify the main dashboard
 */
if (!function_exists('syncExpiringStockAlerts')) {
    function syncExpiringStockAlerts($host, $user, $pass, $tenant_pdo, $db_name) {
        try {
            $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
            $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
            $stmt->execute([$db_name]);
            $tenant_id = $stmt->fetchColumn();
            if (!$tenant_id) return;

            // Fetch products expiring within the next 30 days
            $expiring_items = $tenant_pdo->query("SELECT name, sku, (SELECT expiry_date FROM stock WHERE product_id = products.id AND expiry_date IS NOT NULL ORDER BY expiry_date ASC LIMIT 1) as expiry_date FROM products WHERE is_expirable = 1 HAVING expiry_date IS NOT NULL AND expiry_date <= DATE_ADD(CURDATE(), INTERVAL 30 DAY)")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($expiring_items as $item) {
                $title = "Stock Expiry Alert";
                $msg = "Warning: Product '" . $item['name'] . "' (" . $item['sku'] . ") is expiring soon on " . $item['expiry_date'] . ".";

                $check = $main_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND message = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
                $check->execute([$tenant_id, $title, $msg]);

                if ($check->fetchColumn() == 0) {
                    $ins = $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'expiry_alert')");
                    $ins->execute([$tenant_id, $title, $msg]);
                }
            }
        } catch (Exception $e) {
            error_log("Expiring Stock Sync Error: " . $e->getMessage());
        }
    }
}

/**
 * Background helper to detect due service reminders and notify the main dashboard
 */
if (!function_exists('syncServiceRemindersAlerts')) {
    function syncServiceRemindersAlerts($host, $user, $pass, $tenant_pdo, $db_name) {
        try {
            $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
            $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
            $stmt->execute([$db_name]);
            $tenant_id = $stmt->fetchColumn();
            if (!$tenant_id) return;

            // Fetch reminders due today or in the past that are still pending
            $due_reminders = $tenant_pdo->query("SELECT r.id, r.message, c.name as customer_name FROM reminders r JOIN customers c ON r.customer_id = c.id WHERE r.status = 'pending' AND r.due_date <= CURDATE()")->fetchAll(PDO::FETCH_ASSOC);

            foreach ($due_reminders as $reminder) {
                $title = "Service Reminder Due";
                $msg = "Reminder for " . $reminder['customer_name'] . ": " . $reminder['message'];

                $check = $main_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND message = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 DAY)");
                $check->execute([$tenant_id, $title, $msg]);

                if ($check->fetchColumn() == 0) {
                    $ins = $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'service_reminder')");
                    $ins->execute([$tenant_id, $title, $msg]);
                }
            }
        } catch (Exception $e) {
            error_log("Service Reminders Sync Error: " . $e->getMessage());
        }
    }
}

/**
 * Background helper to detect new B2B orders and notify the main dashboard
 */
if (!function_exists('syncB2BAlerts')) {
    function syncB2BAlerts($host, $user, $pass, $tenant_pdo, $db_name) {
        try {
            $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
            $stmt = $main_pdo->prepare("SELECT id FROM tenants WHERE db_name = ?");
            $stmt->execute([$db_name]);
            $tenant_id = $stmt->fetchColumn();
            if (!$tenant_id) return;

            // Fetch new B2B orders for this tenant that are still pending
            $new_b2b_orders = $main_pdo->prepare("SELECT id, sender_tenant_id FROM b2b_orders WHERE receiver_tenant_id = ? AND status = 'pending' AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)"); // Check for orders in last hour to avoid old ones
            $new_b2b_orders->execute([$tenant_id]);
            $orders = $new_b2b_orders->fetchAll(PDO::FETCH_ASSOC);

            foreach ($orders as $order) {
                $title = "New B2B Order Received";
                $msg = "You have received a new B2B order (ID: " . $order['id'] . ") from Sender ID: " . $order['sender_tenant_id'];

                $check = $main_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND message = ? AND created_at >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
                $check->execute([$tenant_id, $title, $msg]);

                if ($check->fetchColumn() == 0) {
                    $ins = $main_pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'b2b_order')");
                    $ins->execute([$tenant_id, $title, $msg]);
                }
            }
        } catch (Exception $e) {
            error_log("B2B Alerts Sync Error: " . $e->getMessage());
        }
    }
}

/**
 * Resolves the branch ID from which stock should be pulled.
 * 
 * @param int $session_branch_id The branch ID currently active in user's session.
 * @return int|null The branch ID to use for stock queries.
 */
if (!function_exists('get_active_stock_branch_id')) {
    function get_active_stock_branch_id($session_branch_id) {
        global $tenant_conn;
        
        if (!$tenant_conn || empty($session_branch_id) || $session_branch_id === 'all') {
            // Fallback to Main Branch if 'all' or empty
            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $main_id = $stmt_main->fetchColumn();
            return $main_id ? (int)$main_id : null;
        }

        try {
            // 1. Check if the current branch has its own stock
            $stmt = $tenant_conn->prepare("SELECT has_own_stock FROM branches WHERE id = ?");
            $stmt->execute([$session_branch_id]);
            $branch = $stmt->fetch(PDO::FETCH_ASSOC);

            if ($branch && (int)$branch['has_own_stock'] === 1) {
                return (int)$session_branch_id;
            }

            // 2. If not, fallback to the Main branch ID
            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $main_id = $stmt_main->fetchColumn();
            
            return $main_id ? (int)$main_id : null;
        } catch (Exception $e) {
            error_log("Gatekeeper Error (Branch Resolution): " . $e->getMessage());
            return null;
        }
    }
}

/**
 * Helper function to check page access based on page_access_controls.
 * Redirects if access is denied.
 *
 * @param string $current_page_slug The slug of the current page (e.g., 'dashboard', 'b2b_connect').
 */
if (!function_exists('gatekeeper_check')) {
    function gatekeeper_check($current_page_slug) {
        global $m_pdo, $t_conf; // Access global main PDO and tenant config

        // If tenant is not logged in, let the regular authentication handle redirection
        if (!isset($t_conf['id'])) {
            return; 
        }

        $tenant_id = $t_conf['id'];
        $tenant_package_id = $t_conf['package_id'];

        try {
            // 1. Fetch Rules for the current page slug
            // Using trim and lowercase for foolproof slug matching
            $stmt = $m_pdo->prepare("SELECT * FROM page_access_controls WHERE LOWER(TRIM(page_slug)) = LOWER(TRIM(?))");
            $stmt->execute([$current_page_slug]);
            $rule = $stmt->fetch(PDO::FETCH_ASSOC);

            // If no rule exists at all in the gatekeeper table, allow access
            if (!$rule) { 
                error_log("GATEKEEPER_DEBUG: No active rule found for page slug: '$current_page_slug'. Allowing access."); //
                return;
            }

            // NEW: If status is 'inactive', it means the page is MANUALLY DISABLED by Super Admin
            if (trim($rule['status']) === 'inactive') {
                error_log("GATEKEEPER_DEBUG: Page '$current_page_slug' is INACTIVE. Denying access.");
                header("Location: locked_feature.php?msg=" . urlencode("This feature is currently disabled by the system administrator."));
                exit();
            }

            error_log("GATEKEEPER_DEBUG: Rule found for '$current_page_slug'. Details: " . json_encode($rule)); //

            switch ($rule['restriction_type']) {
                case 'none':
                    // No restriction, allow access
                    break;

                case 'request_based':
                    error_log("GATEKEEPER_DEBUG: Checking Request Status for '$current_page_slug'."); 
                    if (!empty($rule['required_verification_task_id'])) {
                        $stmt_template_task = $m_pdo->prepare("SELECT task_title FROM verification_tasks WHERE id = ? AND tenant_id IS NULL");
                        $stmt_template_task->execute([$rule['required_verification_task_id']]);
                        $template_task_title = $stmt_template_task->fetchColumn();

                        if ($template_task_title) {
                            $stmt_tenant_task = $m_pdo->prepare("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id = ? AND task_title = ? AND status = 'approved'");
                            $stmt_tenant_task->execute([$tenant_id, $template_task_title]);
                            $is_approved = $stmt_tenant_task->fetchColumn() > 0;

                            if (!$is_approved) {
                                // Check if user has already submitted a request
                                $stmt_pending = $m_pdo->prepare("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id = ? AND task_title = ? AND status = 'pending_review'");
                                $stmt_pending->execute([$tenant_id, $template_task_title]);
                                $is_pending = $stmt_pending->fetchColumn() > 0;

                                if ($is_pending) {
                                    header("Location: locked_feature.php?type=request_based&msg=" . urlencode("Your request for this feature is currently under review. Please wait for admin approval."));
                                } else {
                                    header("Location: locked_feature.php?type=request_based&msg=" . urlencode("This feature requires a special access request."));
                                }
                                exit();
                            }
                        } else {
                            error_log("GATEKEEPER_ERROR: Restriction set to 'request_based' but template task ID " . $rule['required_verification_task_id'] . " not found for '$current_page_slug'.");
                            header("Location: locked_feature.php?msg=" . urlencode("Feature configuration error: No request task linked. Please contact support."));
                            exit();
                        }
                    } else {
                        error_log("GATEKEEPER_ERROR: Restriction set to 'request_based' but no task linked for '$current_page_slug'.");
                        header("Location: locked_feature.php?msg=" . urlencode("Feature configuration error: No request task linked. Please contact support."));
                        exit();
                    }
                    break;

                case 'verification_required':
                    error_log("GATEKEEPER_DEBUG: Checking Verification for '$current_page_slug'. Required Task ID: " . $rule['required_verification_task_id']); //
                    // Check if a specific verification task is required and approved
                    if (!empty($rule['required_verification_task_id'])) {
                        // Get the task_title of the template task (assuming tenant_id IS NULL for templates)
                        $stmt_template_task = $m_pdo->prepare("SELECT task_title FROM verification_tasks WHERE id = ? AND tenant_id IS NULL");
                        $stmt_template_task->execute([$rule['required_verification_task_id']]);
                        $template_task_title = $stmt_template_task->fetchColumn();

                        if ($template_task_title) {
                            error_log("GATEKEEPER_DEBUG: Template task title found: '$template_task_title'. Checking tenant tasks."); //
                            // Check if the current tenant has an APPROVED task with this title
                            $stmt_tenant_task = $m_pdo->prepare("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id = ? AND task_title = ? AND status = 'approved'");
                            $stmt_tenant_task->execute([$tenant_id, $template_task_title]);
                            $is_approved = $stmt_tenant_task->fetchColumn() > 0;

                            error_log("GATEKEEPER_DEBUG: Tenant $tenant_id has approved task '$template_task_title': " . ($is_approved ? 'YES' : 'NO')); //
                            if (!$is_approved) {
                                // Access denied: Redirect to Verification Center
                                error_log("GATEKEEPER_DEBUG: Access DENIED for '$current_page_slug' (Verification/Request). Redirecting."); //
                                header("Location: verification_center.php?feature_locked=" . urlencode($current_page_slug)); //
                                exit();
                            }
                        } else {
                            // Configuration error: Template task not found, deny access for safety
                            error_log("GATEKEEPER_ERROR: Template task ID {$rule['required_verification_task_id']} not found in main DB for '$current_page_slug'."); //
                            header("Location: locked_feature.php?msg=" . urlencode("Configuration Error: Verification task template not found for this feature. Please contact support.")); //
                            exit();
                        }
                    } else {
                        // Configuration error: Restriction type set but no task linked, deny access for safety
                        error_log("GATEKEEPER_ERROR: Restriction type '{$rule['restriction_type']}' set but no task linked for '$current_page_slug'."); //
                        header("Location: locked_feature.php?msg=" . urlencode("Configuration Error: No verification task linked for this feature. Please contact support.")); //
                        exit();
                    }
                    break;

                case 'upgrade_required':
                    // Check if tenant's package meets the requirement
                    if (!empty($rule['required_package_id'])) {
                        $req_pkg = (int)$rule['required_package_id'];
                        $cur_pkg = (int)$tenant_package_id;
                        
                        // Assuming higher package_id means a better package
                        if ($cur_pkg < $req_pkg) {
                            error_log("GATEKEEPER_DEBUG: Access DENIED for '$current_page_slug'. Tenant Pkg: $cur_pkg < Required: $req_pkg"); 
                            header("Location: locked_feature.php?type=upgrade_required&msg=" . urlencode("This feature requires a higher subscription plan.")); 
                            exit();
                        }
                    } else {
                        // Configuration error: Restriction type set but no package linked, deny access for safety
                        error_log("GATEKEEPER_ERROR: Restriction type 'upgrade_required' set but no package linked for '$current_page_slug'."); //
                        header("Location: locked_feature.php?msg=" . urlencode("Configuration Error: No package linked for this feature. Please contact support.")); //
                        exit();
                    }
                    break;
            }
        } catch (Exception $e) {
            error_log("GATEKEEPER_RUNTIME_ERROR for '$current_page_slug' (Tenant ID: $tenant_id): " . $e->getMessage()); //
            header("Location: locked_feature.php?msg=" . urlencode("An unexpected error occurred while checking access to this feature. Please try again or contact support.")); //
            exit();
        }
    }
}

// Automatically call gatekeeper_check for tenant-facing pages
// Exclude login.php, register_tenant.php, locked_feature.php, and super_admin pages
$current_script_name = basename($_SERVER['PHP_SELF']);
$current_page_slug = basename($_SERVER['PHP_SELF'], '.php');

$excluded_pages = ['login.php', 'register_tenant.php', 'locked_feature.php', 'auth/register_tenant.php', 'api.php', 'api_notifications.php', 'api_mark_read.php']; // Exclude APIs from gatekeeper
$is_super_admin_page = strpos($_SERVER['PHP_SELF'], '/super_admin/') !== false;

if (isset($_SESSION['db_name']) && !empty($_SESSION['db_name']) && !in_array($current_script_name, $excluded_pages) && !$is_super_admin_page) {
    // Enforce Module-level security for Branch related pages
    if (($current_page_slug === 'manage_branches' || $current_page_slug === 'stock_transfer') && !has_module('manage_branches')) {
        header("Location: dashboard.php");
        exit();
    }
    gatekeeper_check($current_page_slug);
}