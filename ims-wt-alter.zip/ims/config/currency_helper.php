<?php
/**
 * Biltax Currency Helper
 * Manual rates for stability (Can be updated to ExchangeRate-API later)
 */
function getExchangeRates() {
    return [
        'USD' => 1.0,       // Base Currency
        'PKR' => 278.50,    // Pakistani Rupee
        'AED' => 3.67,      // UAE Dirham
        'SAR' => 3.75,      // Saudi Riyal
        'INR' => 83.30,     // Indian Rupee
        'GBP' => 0.79       // British Pound
    ];
}
?>