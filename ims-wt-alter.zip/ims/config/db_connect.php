<?php
// Central Database Configuration for Biltax IMS
if (!defined('DB_HOST')) define('DB_HOST', 'localhost');
if (!defined('DB_USER')) define('DB_USER', 'root');
if (!defined('DB_PASS')) define('DB_PASS', '');
if (!defined('DB_MAIN')) define('DB_MAIN', 'biltax_main');

/**
 * Global Variables for legacy script compatibility
 */
$host = DB_HOST;
$user = DB_USER;
$pass = DB_PASS;