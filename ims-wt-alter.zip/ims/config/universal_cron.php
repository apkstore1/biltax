<?php
/**
 * Biltax Billing Engine Cron - Execute at 12:00 AM
 */
require_once __DIR__ . '/db_connect.php';

try {
    $pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    
    // 1. Process Auto-Expiry
    $pdo->exec("UPDATE subscriptions SET status = 'expired' WHERE status IN ('active', 'trial') AND expiry_date < CURDATE()");

    // 1.1 Notify about Expiry Tomorrow (1 Day Before)
    $tomorrow = date('Y-m-d', strtotime('+1 day'));
    $stmt_remind = $pdo->prepare("SELECT s.tenant_id, p.package_name FROM subscriptions s JOIN packages p ON s.plan_id = p.id WHERE s.status IN ('active', 'trial') AND s.expiry_date = ?");
    $stmt_remind->execute([$tomorrow]);
    $to_remind = $stmt_remind->fetchAll(PDO::FETCH_ASSOC);

    foreach($to_remind as $rem) {
        $title = "Subscription Expiring Tomorrow";
        $msg = "Your subscription for " . $rem['package_name'] . " will expire tomorrow. Please renew now to avoid service interruption.";
        
        // Duplicate check (Prevent multiple alerts for the same thing today)
        $check = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND title = ? AND DATE(created_at) = CURDATE()");
        $check->execute([$rem['tenant_id'], $title]);
        
        if ($check->fetchColumn() == 0) {
            $pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'alert')")
                ->execute([$rem['tenant_id'], $title, $msg]);
        }
    }

    // 2. Process Today's Invoicing
    $stmt = $pdo->query("SELECT s.*, p.price, p.package_name FROM subscriptions s JOIN packages p ON s.plan_id = p.id WHERE s.status = 'expired' AND s.expiry_date = DATE_SUB(CURDATE(), INTERVAL 1 DAY)");
    $to_invoice = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach($to_invoice as $sub) {
        $inv_num = "INV-" . date('Ymd') . "-" . $sub['tenant_id'];
        
        // Check if invoice already exists
        $check = $pdo->prepare("SELECT COUNT(*) FROM invoices_master WHERE invoice_number = ?");
        $check->execute([$inv_num]);
        
        if ($check->fetchColumn() == 0) {
            $stmt_inv = $pdo->prepare("INSERT INTO invoices_master (tenant_id, invoice_number, base_amount, net_payable, due_date, status) VALUES (?, ?, ?, ?, DATE_ADD(CURDATE(), INTERVAL 7 DAY), 'unpaid')");
            $stmt_inv->execute([$sub['tenant_id'], $inv_num, $sub['price'], $sub['price']]);
            
            // Notify Tenant
            $msg = "Your subscription for " . $sub['package_name'] . " has expired. A new invoice " . $inv_num . " has been generated.";
            $pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, 'Subscription Expired', ?, 'alert')")
                ->execute([$sub['tenant_id'], $msg]);
        }
    }
    echo "Engine: " . count($to_invoice) . " accounts processed.";
} catch (Exception $e) { error_log("CRON ERROR: " . $e->getMessage()); }
?>