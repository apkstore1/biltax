<?php
/**
 * Storage Manager Helper
 * Calculates and updates a tenant's total storage usage across various platforms.
 */

require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/CloudinaryStorage.php'; // For Cloudinary API calls

// --- Firebase Realtime Database Configuration ---
// IMPORTANT: Replace with your actual Firebase project ID and, if necessary, a secret.
// For production, consider using a Firebase Admin SDK for PHP or a serverless function
// for secure and efficient data access. Make sure your Firebase rules allow read access for this estimation.
define('FIREBASE_DATABASE_URL', 'https://your-firebase-project-id-default-rtdb.firebaseio.com/');
// If your Firebase rules require authentication, you'll need a service account key or a database secret.
// For a simple GET estimation, we'll assume public read or an API key is configured in Firebase rules.

/**
 * Calculates the total storage usage for a given tenant across their dedicated DB,
 * main DB records, Cloudinary assets, and Firebase chat data.
 *
 * @param int $tenant_id The ID of the tenant.
 * @return float|false Total storage in MB, or false on failure.
 */
function calculateTenantStorage(int $tenant_id) {
    global $pdo; // Use the main PDO connection from db_connect.php

    $total_storage_mb = 0.0; // Initialize total storage in MB

    try {
        // 1. Fetch Tenant Details (db_name, business_name)
        $stmt = $pdo->prepare("SELECT id, db_name, business_name FROM tenants WHERE id = ?");
        $stmt->execute([$tenant_id]);
        $tenant_info = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$tenant_info) {
            error_log("Storage Manager: Tenant ID $tenant_id not found.");
            return false;
        }

        $tenant_db_name = $tenant_info['db_name'];

        // --- 2. Calculate Tenant's Dedicated Database Size ---
        try {
            $tenant_db_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$tenant_db_name", DB_USER, DB_PASS);
            $tenant_db_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

            $stmt_db_size = $tenant_db_pdo->query("SELECT SUM(data_length + index_length) FROM information_schema.tables WHERE table_schema = '$tenant_db_name'");
            $tenant_db_size_bytes = $stmt_db_size->fetchColumn() ?: 0;
            $total_storage_mb += ($tenant_db_size_bytes / (1024 * 1024));
        } catch (Exception $e) {
            error_log("Storage Manager: Error calculating tenant dedicated DB size for $tenant_db_name: " . $e->getMessage());
        }

        // --- 3. Calculate Tenant's Records Size in Main Database ---
        // This is an estimate based on row count and average row length for relevant tables.
        $main_db_tenant_usage_bytes = 0;
        $main_db_tables_with_tenant_id = [
            'subscriptions', 'billing', 'notifications', 'feature_requests', 'verification_tasks'
        ];
        $main_db_tables_with_sender_receiver_id = [
            'b2b_orders', 'b2b_return_requests', 'tenant_connections'
        ];

        // For tables with direct tenant_id
        foreach ($main_db_tables_with_tenant_id as $table) {
            try {
                $stmt_avg_row = $pdo->query("SELECT AVG_ROW_LENGTH FROM information_schema.tables WHERE table_schema = '" . DB_MAIN . "' AND table_name = '$table'");
                $avg_row_length = $stmt_avg_row->fetchColumn() ?: 100; // Default estimate

                $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM $table WHERE tenant_id = ?");
                $stmt_count->execute([$tenant_id]);
                $tenant_row_count = $stmt_count->fetchColumn();
                $main_db_tenant_usage_bytes += ($tenant_row_count * $avg_row_length);
            } catch (Exception $e) {
                error_log("Storage Manager: Error calculating main DB usage for table $table: " . $e->getMessage());
            }
        }

        // For tables with sender_id or receiver_id
        foreach ($main_db_tables_with_sender_receiver_id as $table) {
            try {
                $stmt_avg_row = $pdo->query("SELECT AVG_ROW_LENGTH FROM information_schema.tables WHERE table_schema = '" . DB_MAIN . "' AND table_name = '$table'");
                $avg_row_length = $stmt_avg_row->fetchColumn() ?: 100;

                $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM $table WHERE sender_id = ? OR receiver_id = ?");
                $stmt_count->execute([$tenant_id, $tenant_id]);
                $tenant_row_count = $stmt_count->fetchColumn();
                $main_db_tenant_usage_bytes += ($tenant_row_count * $avg_row_length);
            } catch (Exception $e) {
                error_log("Storage Manager: Error calculating main DB usage for table $table (sender/receiver): " . $e->getMessage());
            }
        }
        $total_storage_mb += ($main_db_tenant_usage_bytes / (1024 * 1024));

        // --- 4. Cloudinary Integration: Total Size of Assets in Tenant's Folders ---
        // Cloudinary folders are now standardized to use tenant_id for easier tracking.
        $cloudinary_folders = [
            "biltax_verifications/$tenant_id",
            "biltax_tenants/logos/$tenant_id",
            "biltax_tenants/shop_images/$tenant_id",
            "biltax_shop_custom/$tenant_id"
        ];
        $cloudinary_total_bytes = 0;
        foreach ($cloudinary_folders as $folder) {
            try {
                $folder_size = getCloudinaryFolderSize($folder); // Function from CloudinaryStorage.php
                if ($folder_size !== false) {
                    $cloudinary_total_bytes += $folder_size;
                }
            } catch (Exception $e) {
                error_log("Storage Manager: Error calculating Cloudinary folder size for $folder: " . $e->getMessage());
            }
        }
        $total_storage_mb += ($cloudinary_total_bytes / (1024 * 1024));

        // --- 5. Firebase Chat: Estimate Chat Data Size ---
        // This is a simplified estimation. For accurate, real-time data,
        // a dedicated Firebase Admin SDK for PHP or a serverless function is recommended.
        // We assume chat data for a tenant can be aggregated under a specific node or by querying.
        // For this implementation, we'll fetch all chat rooms where this tenant is involved
        // and sum the JSON string lengths of their messages. This can be heavy.
        $firebase_chat_size_bytes = 0;
        try {
            // Fetch all chat rooms where this tenant is either sender or receiver
            // This is a complex query for Firebase REST API.
            // For a practical estimate, we'll fetch the entire 'chats' node and filter client-side (not ideal for large data).
            // A better approach would be to query Firebase for specific chat rooms related to this tenant.
            // For now, we'll make a direct fetch of a hypothetical tenant-specific chat node if it existed.
            // Given the current chat structure `chats/room_{subscriber_id}_{branch_id}/messages`,
            // a direct "JSON tree for that tenant" is not easily available without iterating through all rooms.
            // As a placeholder, we'll fetch a limited set of data or assume a direct tenant node for estimation.
            $firebase_tenant_chat_node_url = FIREBASE_DATABASE_URL . "chats.json?orderBy=\"sender_id\"&equalTo=\"{$tenant_id}\""; // Simplified query
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $firebase_tenant_chat_node_url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            $response = curl_exec($ch);
            $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);

            if ($http_code === 200 && $response !== 'null') {
                $firebase_chat_size_bytes = strlen($response); // Estimate size by JSON string length
                $total_storage_mb += ($firebase_chat_size_bytes / (1024 * 1024));
            } else {
                error_log("Storage Manager: Firebase chat data not found or error for tenant $tenant_id (HTTP $http_code).");
            }
        } catch (Exception $e) {
            error_log("Storage Manager: Error estimating Firebase chat size for tenant $tenant_id: " . $e->getMessage());
        }

        // --- 6. Update current_storage_usage in tenants table ---
        $stmt_update = $pdo->prepare("UPDATE tenants SET current_storage_usage = ? WHERE id = ?");
        $stmt_update->execute([$total_storage_mb, $tenant_id]);

        return $total_storage_mb;

    } catch (Exception $e) {
        error_log("Storage Manager: Global error for tenant $tenant_id: " . $e->getMessage());
        return false;
    }
}