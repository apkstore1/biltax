<?php
require_once 'config/db_switch.php';

// Check login
if (!$tenant_conn) {
    header("Location: login.php");
    exit;
}

// Self-healing for Service Panel & others: Ensure columns exist before insertion
try {
    $tenant_conn->exec("CREATE TABLE IF NOT EXISTS users (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, role VARCHAR(50) NOT NULL, password VARCHAR(255) NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)");
    $tenant_conn->exec("ALTER TABLE users ADD COLUMN IF NOT EXISTS assigned_branch_id INT DEFAULT NULL");
} catch(Exception $e) {}

$error_msg = '';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_staff') {
    try {
        // SERVER-SIDE SECURITY: Enforce Personnel Limit (Security against console/hack bypass)
        $u_count = (int)$tenant_conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
        $r_count = 0;
        if (has_module('rider_tracking')) {
            try { $r_count = (int)$tenant_conn->query("SELECT COUNT(*) FROM riders")->fetchColumn(); } catch(Exception $e) {}
        }
        $total_active = $u_count + $r_count;
        if ($total_active >= $staff_limit) {
            throw new Exception("Registration Failed: You have reached your personnel limit of $staff_limit. Please upgrade your package or remove existing staff.");
        }

        $name = $_POST['name'];
        $role = $_POST['role'];
        $branch_id = !empty($_POST['branch_id']) ? (int)$_POST['branch_id'] : null;

        if ($role === 'rider' && has_module('rider_tracking')) {
            // Insert into 'riders' table for tracking system
            $phone = $_POST['phone'] ?? '';
            $password = $_POST['password'] ?? '';
            if (empty($phone)) throw new Exception("Phone number is required.");
            if (empty($password)) throw new Exception("Password is required.");
            
            $check = $tenant_conn->prepare("SELECT COUNT(*) FROM riders WHERE phone = ?");
            $check->execute([$phone]);
            if ($check->fetchColumn() > 0) throw new Exception("A rider with this phone number already exists.");

            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $tenant_conn->prepare("INSERT INTO riders (name, phone, password, is_active) VALUES (?, ?, ?, 1)");
            $stmt->execute([$name, $phone, $hashed_password]);
            header("Location: staff_list.php?msg=added");
        } else {
            // Insert into 'users' table for dashboard access
            $password = $_POST['password'] ?? '';
            if (empty($password)) throw new Exception("Password is required for Dashboard Staff.");
            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $tenant_conn->prepare("INSERT INTO users (name, role, password, assigned_branch_id) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $role, $hashed_password, $branch_id]);
            header("Location: staff_list.php?msg=added");
        }
        exit;
    } catch (Exception $e) {
        $error_msg = $e->getMessage();
    }
}

$branches = $tenant_conn->query("SELECT id, branch_name FROM branches")->fetchAll(PDO::FETCH_ASSOC);
$u_total = (int)$tenant_conn->query("SELECT COUNT(*) FROM users")->fetchColumn();
$r_total = 0;
if (has_module('rider_tracking')) {
    try { $r_total = (int)$tenant_conn->query("SELECT COUNT(*) FROM riders")->fetchColumn(); } catch(Exception $e) {}
}
$current_staff_count = $u_total + $r_total;
$is_limit_reached = ($current_staff_count >= $staff_limit);

$industry = strtolower(trim($_SESSION['industry_type'] ?? 'retail'));

// Define Roles based on Industry
$roles_config = [
    'retail' => [
        ['val' => 'admin', 'label' => 'Administrator'],
        ['val' => 'manager', 'label' => 'Store Manager'],
        ['val' => 'cashier', 'label' => 'Cashier'],
        ['val' => 'salesman', 'label' => 'Sales Person']
    ],
    'wholesale' => [
        ['val' => 'admin', 'label' => 'Administrator'],
        ['val' => 'manager', 'label' => 'Warehouse Manager'],
        ['val' => 'cashier', 'label' => 'Accounts / Cashier']
    ],
    'restaurant' => [
        ['val' => 'admin', 'label' => 'Owner / Admin'],
        ['val' => 'chef', 'label' => 'Head Chef'],
        ['val' => 'waiter', 'label' => 'Service Waiter'],
        ['val' => 'cashier', 'label' => 'Cashier']
    ],
    'service' => [
        ['val' => 'admin', 'label' => 'Administrator'],
        ['val' => 'manager', 'label' => 'Service Manager'],
        ['val' => 'technician', 'label' => 'Lead Technician'],
        ['val' => 'cashier', 'label' => 'Cashier']
    ]
];

$current_roles = $roles_config[$industry] ?? $roles_config['retail'];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Add Staff | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 flex min-h-screen transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 overflow-y-auto">
        <header class="mb-10 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Register New Personnel</h1>
                <p class="text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-1">Add staff members or riders to your fleet</p>
            </div>
            <?php include 'topbar.php'; ?>
        </header>

        <?php if($error_msg): ?>
            <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-2xl text-xs font-bold flex items-center gap-2">
                <i data-lucide="alert-circle" size="16"></i> <?= $error_msg ?>
            </div>
        <?php endif; ?>

        <?php if($is_limit_reached): ?>
            <div class="mb-6 p-6 bg-orange-500/10 border border-orange-500/20 text-orange-600 rounded-[32px] text-xs font-bold flex flex-col gap-2">
                <div class="flex items-center gap-2 font-black uppercase"><i data-lucide="shield-alert" size="18"></i> Personnel Limit Reached</div>
                <p class="opacity-80">You have reached the maximum staff limit (<?= $staff_limit ?>) allowed in your current plan. You cannot add more members without upgrading or deleting old ones.</p>
            </div>
        <?php endif; ?>

        <div class="max-w-2xl mx-auto bg-white dark:bg-neutral-900 p-10 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
            <form method="POST" class="space-y-6 <?= $is_limit_reached ? 'opacity-50 pointer-events-none' : '' ?>">
                <input type="hidden" name="action" value="add_staff">
                
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Full Name</label>
                    <input type="text" name="name" required placeholder="Enter name" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                </div>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Role / Designation</label>
                        <select name="role" id="roleSelector" onchange="toggleRoleFields()" required class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                            <?php foreach($current_roles as $role): ?>
                                <option value="<?= $role['val'] ?>"><?= $role['label'] ?></option>
                            <?php endforeach; ?>
                            
                            <?php if(has_module('rider_tracking')): ?>
                                <option value="rider" class="text-orange-600">
                                    <?= ($industry === 'service') ? 'Service Man (Field/Tracking) 🛠️' : 'Delivery Rider 🚲' ?>
                                </option>
                            <?php endif; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Branch Assignment</label>
                        <select name="branch_id" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                            <option value="">Global (All Branches)</option>
                            <?php foreach($branches as $b): ?>
                                <option value="<?= $b['id'] ?>"><?= htmlspecialchars($b['branch_name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div id="passwordField">
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Login Password</label>
                    <input type="password" name="password" required placeholder="••••••••" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                </div>

                <div id="phoneField" class="hidden">
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Phone Number (for WhatsApp/Tracking)</label>
                    <input type="text" name="phone" placeholder="e.g. 923001234567" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm">
                </div>

                <button type="submit" <?= $is_limit_reached ? 'disabled' : '' ?> class="w-full py-5 <?= $is_limit_reached ? 'bg-slate-300 dark:bg-neutral-800 cursor-not-allowed' : 'bg-orange-600 shadow-orange-600/20 active:scale-95 shadow-xl' ?> text-white rounded-3xl font-black uppercase tracking-widest transition-all mt-6">Register Personnel</button>
            </form>
        </div>
    </main>

    <script>
        lucide.createIcons();
        function toggleRoleFields() {
            const role = document.getElementById('roleSelector').value;
            const phoneField = document.getElementById('phoneField');

            if (role === 'rider') {
                phoneField.classList.remove('hidden');
            } else {
                phoneField.classList.add('hidden');
            }
        }
    </script>
</body>
</html>