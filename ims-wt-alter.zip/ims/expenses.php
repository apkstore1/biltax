<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }
if (!has_module('expense_tracker')) { header("Location: dashboard.php?error=module_disabled"); exit; }

$currency = $currency_symbol ?? '$';

// Fetch Quick Stats
try {
    $today_total = $tenant_conn->query("SELECT SUM(amount) FROM expenses WHERE expense_date = CURRENT_DATE()")->fetchColumn() ?: 0;
    $month_total = $tenant_conn->query("SELECT SUM(amount) FROM expenses WHERE MONTH(expense_date) = MONTH(CURRENT_DATE()) AND YEAR(expense_date) = YEAR(CURRENT_DATE())")->fetchColumn() ?: 0;
} catch(Exception $e) { $today_total = $month_total = 0; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Expense Tracker | Biltax Finance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    
    <main class="flex-1 p-8">
        <header class="flex justify-between items-center mb-8">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Expense Tracker</h1>
                <p class="text-xs text-slate-500 uppercase tracking-widest font-bold mt-1">Financials Sub-Module</p>
            </div>
            <div class="flex items-center gap-3">
                <?php include 'topbar.php'; ?>
                <button onclick="openAddModal()" class="px-6 py-3 bg-rose-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-lg shadow-rose-600/20 hover:scale-105 transition-all">
                    <i data-lucide="plus-circle" class="inline mr-2" size="16"></i> Add Expense
                </button>
            </div>
        </header>

        <!-- Stats Row -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                <p class="text-[10px] font-black uppercase text-slate-400 mb-1 tracking-widest">Total Spent Today</p>
                <h3 class="text-4xl font-black text-rose-500"><?= $currency . number_format($today_total, 2) ?></h3>
            </div>
            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                <p class="text-[10px] font-black uppercase text-slate-400 mb-1 tracking-widest">This Month Expenses</p>
                <h3 class="text-4xl font-black dark:text-white"><?= $currency . number_format($month_total, 2) ?></h3>
            </div>
        </div>

        <!-- Expense List -->
        <div class="bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
            <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                <h2 class="text-sm font-black dark:text-white uppercase tracking-widest">Recent Transactions</h2>
            </div>
            <div class="overflow-x-auto">
                <table class="w-full text-left">
                    <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <tr>
                            <th class="px-8 py-4">Date</th>
                            <th class="px-8 py-4">Category</th>
                            <th class="px-8 py-4">Description</th>
                            <th class="px-8 py-4">Payment</th>
                            <th class="px-8 py-4 text-right">Amount</th>
                        </tr>
                    </thead>
                    <tbody id="expenseBody" class="divide-y divide-slate-100 dark:divide-neutral-800">
                        <!-- Loaded via JS -->
                    </tbody>
                </table>
            </div>
        </div>
    </main>

    <!-- Add Expense Modal -->
    <div id="addModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('addModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-6 tracking-tight">Record New Expense</h2>
            
            <form id="expenseForm" class="space-y-4">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Category</label>
                        <select id="catSelect" required class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm focus:border-rose-500">
                            <option value="">Select Category</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Amount (<?= $currency ?>)</label>
                        <input type="number" id="expAmount" step="0.01" required class="w-full px-4 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white font-black text-xl">
                    </div>
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Date</label>
                    <input type="date" id="expDate" value="<?= date('Y-m-d') ?>" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Description</label>
                    <input type="text" id="expDesc" placeholder="e.g. Electricity bill for March" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Attach Receipt (Image)</label>
                    <input type="file" id="expReceipt" accept="image/*" class="w-full text-xs text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-[10px] file:font-black file:bg-orange-600 file:text-white">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Payment Method</label>
                    <select id="expMethod" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                        <option value="Cash">Cash</option>
                        <option value="Bank Transfer">Bank Transfer</option>
                        <option value="Credit Card">Credit Card</option>
                    </select>
                </div>
                <button type="submit" class="w-full py-5 bg-rose-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-rose-600/20 hover:bg-rose-700 transition-all mt-4">Confirm Expense</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        const currency = '<?= $currency ?>';

        async function fetchExpenses() {
            const res = await fetch('api.php?route=finance/expenses/get');
            const data = await res.json();
            const body = document.getElementById('expenseBody');
            
            if (data.length === 0) {
                body.innerHTML = `<tr><td colspan="5" class="p-20 text-center text-slate-400 italic font-bold">No expenses recorded yet.</td></tr>`;
                return;
            }

            body.innerHTML = data.map(e => `
                <tr class="hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                    <td class="px-8 py-5 text-xs text-slate-500 font-bold uppercase">${e.expense_date}</td>
                    <td class="px-8 py-5">
                        <span class="px-3 py-1 bg-slate-100 dark:bg-neutral-800 rounded-full text-[10px] font-black uppercase text-slate-600 dark:text-slate-400 border border-slate-200 dark:border-neutral-700">${e.category_name || 'Others'}</span>
                    </td>
                    <td class="px-8 py-5 text-sm font-bold dark:text-white">${e.description || '-'}</td>
                    <td class="px-8 py-5 text-[10px] font-black uppercase text-slate-400">${e.payment_method}</td>
                    <td class="px-8 py-5 text-right text-lg font-black text-rose-500">${currency}${parseFloat(e.amount).toLocaleString()}</td>
                </tr>
            `).join('');
        }

        async function openAddModal() {
            const res = await fetch('api.php?route=finance/categories/get');
            const cats = await res.json();
            const select = document.getElementById('catSelect');
            
            // Populate categories
            select.innerHTML = '<option value="">Select Category</option>' + 
                cats.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
            
            document.getElementById('addModal').classList.replace('hidden', 'flex');
        }

        document.getElementById('expenseForm').onsubmit = async (e) => {
            e.preventDefault();
            const btn = e.target.querySelector('button');
            btn.disabled = true;
            btn.innerText = "Processing...";

            const data = {
                category_id: document.getElementById('catSelect').value,
                amount: document.getElementById('expAmount').value,
                expense_date: document.getElementById('expDate').value,
                description: document.getElementById('expDesc').value,
                payment_method: document.getElementById('expMethod').value
            };

            try {
                const res = await fetch('api.php?route=finance/expenses/add', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify(data)
                });
                const result = await res.json();
                if (result.success) {
                    location.reload();
                } else {
                    alert("Error: " + result.message);
                }
            } catch (err) { alert("System Error."); }
            btn.disabled = false; btn.innerText = "Confirm Expense";
        };

        document.addEventListener('DOMContentLoaded', fetchExpenses);
    </script>
</body>
</html>