<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Check if super admin is logged in
if (!isset($_SESSION['super_admin_logged_in']) || $_SESSION['super_admin_logged_in'] !== true) {
    // Redirect to login page if not authenticated
    header("Location: login.php");
    exit;
}

/**
 * Check if the logged-in admin has a specific permission
 * @param string $permission The permission key (e.g. 'manage_tenants', 'billing')
 * @return bool
 */
function has_admin_permission($permission) {
    // Super Admin bypasses all checks
    if (isset($_SESSION['super_admin_role']) && $_SESSION['super_admin_role'] === 'Super Admin') {
        return true;
    }
    
    $perms = $_SESSION['super_admin_permissions'] ?? [];
    return in_array($permission, $perms) || in_array('all', $perms);
}
?>