<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard
if (!has_admin_permission('manage_tenants')) {
    die("Access Denied: You do not have permission to view tenant instances.");
}

require_once 'config.php'; // For Super Admin DB connection
require_once '../config/db_connect.php'; // For DB_HOST, DB_USER, DB_PASS

// Handle "Login as Tenant" action
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'login_as_tenant') {
    $tenant_id = (int)$_POST['tenant_id'];

    try {
        // Fetch tenant details from main DB
        $stmt = $pdo->prepare("SELECT * FROM tenants WHERE id = ?");
        $stmt->execute([$tenant_id]);
        $tenant_data = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($tenant_data) {
            // Backup entire Super Admin session state before switching context
            $admin_backup = $_SESSION;

            // Overwrite session with tenant's data
            $_SESSION['tenant_id'] = $tenant_data['id'];
            $_SESSION['db_name'] = $tenant_data['db_name'];
            $_SESSION['business_name'] = $tenant_data['business_name'];
            $_SESSION['owner_name'] = $tenant_data['owner_name'];
            $_SESSION['email'] = $tenant_data['email'];
            $_SESSION['industry_type'] = $tenant_data['industry_type'];
            $_SESSION['active_branch_id'] = null; // Let tenant's db_switch handle this

            // Re-inject the backup into the new context
            $_SESSION['super_admin_backup'] = $admin_backup;

            // Redirect to tenant's dashboard
            header("Location: ../dashboard.php");
            exit;
        } else {
            $error_message = "Tenant not found.";
        }
    } catch (Exception $e) {
        $error_message = "Error logging in as tenant: " . $e->getMessage();
    }
}

// Fetch all tenants
try {
    $stmt = $pdo->query("SELECT t.*, p.package_name FROM tenants t LEFT JOIN packages p ON t.package_id = p.id ORDER BY t.business_name ASC");
    $tenants = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $tenants = [];
    $error_message = "Error fetching tenants: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tenant Views - Biltax Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #171717; }
        ::-webkit-scrollbar-thumb { background: #404040; border-radius: 10px; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>

        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-7xl mx-auto">
                <header class="flex justify-between items-start mb-10">
                    <div>
                        <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Tenant Views</h1>
                        <p class="text-sm text-slate-500 dark:text-neutral-400">Monitor and access tenant panels.</p>
                        <?php if (isset($error_message)): ?>
                            <p class="text-red-500 text-sm mt-2"><?php echo htmlspecialchars($error_message); ?></p>
                        <?php endif; ?>
                    </div>
                    <div class="text-right">
                        <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo count($tenants); ?></p>
                        <p class="text-xs text-slate-500 dark:text-neutral-500 uppercase tracking-wider">Total Tenants</p>
                    </div>
                </header>

                <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-2xl relative">
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800 rounded-t-2xl">
                            <tr>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Business Name</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Owner</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Industry</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Package</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                            <?php if (empty($tenants)): ?>
                                <tr><td colspan="5" class="px-6 py-8 text-center text-slate-400">No tenants found.</td></tr>
                            <?php else: ?>
                                <?php foreach ($tenants as $t): ?>
                                <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors">
                                    <td class="px-6 py-4">
                                        <p class="font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($t['business_name']); ?></p>
                                        <p class="text-xs text-slate-500 dark:text-neutral-500 font-mono mt-1"><?php echo htmlspecialchars($t['db_name']); ?></p>
                                    </td>
                                    <td class="px-6 py-4">
                                        <p class="text-sm text-slate-700 dark:text-neutral-300"><?php echo htmlspecialchars($t['owner_name']); ?></p>
                                        <p class="text-xs text-slate-500 dark:text-neutral-500"><?php echo htmlspecialchars($t['email']); ?></p>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-neutral-300 border border-slate-200 dark:border-neutral-700 capitalize">
                                            <?php echo htmlspecialchars($t['industry_type']); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 dark:bg-blue-500/10 text-blue-600 dark:text-blue-500 border border-blue-200 dark:border-blue-500/20 capitalize">
                                            <?php echo htmlspecialchars($t['package_name'] ?? 'N/A'); ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <a href="tenant_monitor.php?id=<?php echo $t['id']; ?>" class="inline-flex items-center px-4 py-2 bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-neutral-300 rounded-xl text-xs font-bold hover:bg-indigo-600 hover:text-white transition-all mr-2">
                                            <i data-lucide="activity" size="14" class="inline mr-1"></i> Monitor
                                        </a>
                                        <form method="POST" class="inline-block">
                                            <input type="hidden" name="action" value="login_as_tenant">
                                            <input type="hidden" name="tenant_id" value="<?php echo $t['id']; ?>">
                                            <button type="submit" class="px-4 py-2 bg-orange-600 text-white rounded-xl text-xs font-bold hover:bg-orange-700 transition-all shadow-lg shadow-orange-600/20">
                                                <i data-lucide="log-in" size="14" class="inline mr-1"></i> Login as Tenant
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>
    <script>
        lucide.createIcons();
    </script>
</body>
</html>