<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard
if (!has_admin_permission('billing')) {
    die("Access Denied: You do not have permission to view billing reports.");
}

require_once 'config.php';
require_once '../config/currency_helper.php';

// Fetch Global Admin Settings
$global_currency = 'USD';
$global_symbol = '$';
try {
    $stmt_admin = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
    $admin_settings = $stmt_admin->fetchAll(PDO::FETCH_KEY_PAIR);
    $global_currency = $admin_settings['global_currency'] ?? 'USD';
    $global_symbol = $admin_settings['global_currency_symbol'] ?? '$';
} catch (Exception $e) {}

$rates = getExchangeRates();
$global_rate = $rates[$global_currency] ?? 1.0;

// Fetch Summary Stats
try {
    // Monthly recurring revenue (Sum of all active tenant package prices)
    $mrr_stmt = $pdo->query("SELECT SUM(p.monthly_price) FROM tenants t JOIN packages p ON t.package_id = p.id WHERE t.status = 'active'");
    $total_mrr = ($mrr_stmt->fetchColumn() ?: 0) * $global_rate;

    // Active Subscriptions
    $active_subs = $pdo->query("SELECT COUNT(*) FROM tenants WHERE status = 'active'")->fetchColumn();
    
    // Plan distribution
    $plan_stats = $pdo->query("SELECT p.package_name, COUNT(t.id) as count FROM packages p LEFT JOIN tenants t ON p.id = t.package_id GROUP BY p.id")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { $db_error = $e->getMessage(); }

// Fetch Tenant Billing Details
$query = "SELECT t.id, t.business_name, t.unique_id, p.package_name, p.monthly_price, t.status, t.created_at, t.currency_symbol 
          FROM tenants t 
          LEFT JOIN packages p ON t.package_id = p.id 
          ORDER BY t.created_at DESC";
$billing_list = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Billing Center | Biltax Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>

        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-7xl mx-auto">
                <header class="mb-10">
                    <h1 class="text-3xl font-black uppercase tracking-tight">Revenue & Billing</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Global subscription and monetization control</p>
                </header>

                <!-- Analytics Grid -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Estimated MRR</p>
                        <h3 class="text-4xl font-black text-emerald-500"><?= $global_symbol ?><?= number_format($total_mrr, 2) ?></h3>
                        <p class="text-[9px] text-slate-500 mt-2 italic">Monthly Recurring Revenue</p>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Active Accounts</p>
                        <h3 class="text-4xl font-black dark:text-white"><?= $active_subs ?></h3>
                        <p class="text-[9px] text-slate-500 mt-2 italic">Active business environments</p>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4">Plan Distribution</p>
                        <div class="flex gap-2">
                            <?php foreach($plan_stats as $ps): ?>
                                <div class="flex-1 text-center">
                                    <p class="text-lg font-black dark:text-white"><?= $ps['count'] ?></p>
                                    <p class="text-[8px] font-bold text-slate-400 uppercase truncate"><?= $ps['package_name'] ?></p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- Billing Table -->
                <div class="bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
                    <div class="p-6 border-b border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                        <h2 class="text-sm font-black dark:text-white uppercase tracking-widest">Subscription Manifest</h2>
                        <button class="px-4 py-2 bg-slate-100 dark:bg-neutral-800 text-[10px] font-black uppercase rounded-xl hover:bg-orange-600 hover:text-white transition-all">Download Report</button>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                <tr>
                                    <th class="px-8 py-5">Client / Business</th>
                                    <th class="px-8 py-5">Current Plan</th>
                                    <th class="px-8 py-5">Value</th>
                                    <th class="px-8 py-5">Join Date</th>
                                    <th class="px-8 py-5">Status</th>
                                    <th class="px-8 py-5 text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                                <?php foreach($billing_list as $b): ?>
                                <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors">
                                    <td class="px-8 py-5">
                                        <p class="font-bold text-sm dark:text-white"><?= htmlspecialchars($b['business_name']) ?></p>
                                        <p class="text-[10px] font-mono text-slate-400">ID: <?= $b['unique_id'] ?></p>
                                    </td>
                                    <td class="px-8 py-5">
                                        <span class="px-3 py-1 bg-indigo-500/10 text-indigo-500 rounded-lg text-[10px] font-black uppercase border border-indigo-500/20">
                                            <?= htmlspecialchars($b['package_name'] ?: 'Custom') ?>
                                        </span>
                                    </td>
                                    <td class="px-8 py-5">
                                        <p class="font-black text-sm text-emerald-500"><?= $global_symbol ?><?= number_format(($b['monthly_price'] ?: 0) * $global_rate, 2) ?></p>
                                        <p class="text-[8px] text-slate-400 uppercase font-bold">Per Month</p>
                                    </td>
                                    <td class="px-8 py-5 text-xs text-slate-500 font-medium">
                                        <?= date('M d, Y', strtotime($b['created_at'])) ?>
                                    </td>
                                    <td class="px-8 py-5">
                                        <?php if($b['status'] === 'active'): ?>
                                            <span class="flex items-center gap-1.5 text-xs font-black text-emerald-500 uppercase">
                                                <span class="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span> Active
                                            </span>
                                        <?php else: ?>
                                            <span class="flex items-center gap-1.5 text-xs font-black text-slate-400 uppercase">
                                                <span class="w-1.5 h-1.5 bg-slate-400 rounded-full"></span> Suspended
                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-8 py-5 text-right">
                                        <button onclick="alert('Invoicing history coming soon!')" class="p-2 text-slate-400 hover:text-orange-600 transition-colors">
                                            <i data-lucide="history" size="18"></i>
                                        </button>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($billing_list)): ?>
                                    <tr><td colspan="6" class="p-20 text-center text-slate-400 italic font-bold">No billing records found.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Info Footer -->
                <div class="mt-8 p-6 bg-blue-500/5 border border-blue-500/10 rounded-3xl flex items-start gap-4">
                    <div class="p-2 bg-blue-500 text-white rounded-lg"><i data-lucide="info" size="16"></i></div>
                    <p class="text-xs text-slate-500 leading-relaxed">
                        This panel shows active subscriptions. In the next phase, we will implement **manual invoice overrides**, **payment proofs**, and **automatic expiration logic**.
                    </p>
                </div>
            </div>
        </main>
    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>