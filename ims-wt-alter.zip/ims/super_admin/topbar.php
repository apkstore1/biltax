<header class="h-20 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-md border-b border-slate-200 dark:border-neutral-800 flex items-center justify-between px-8 sticky top-0 z-10 transition-colors duration-300">
    <div>
        <h2 class="text-xl font-bold text-slate-900 dark:text-white">Welcome, Super Admin</h2>
        <p class="text-xs text-slate-500 dark:text-neutral-400">Manage your multi-tenant environment</p>
    </div>
    <div class="flex items-center gap-4">
        <!-- Theme Toggle -->
        <button onclick="toggleTheme()" class="p-2.5 rounded-xl bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-neutral-400 hover:text-orange-500 transition-colors">
            <i data-lucide="moon" size="20" class="hidden dark:block"></i>
            <i data-lucide="sun" size="20" class="block dark:hidden"></i>
        </button>
        
        <!-- Quick Action -->
        <?php if (basename($_SERVER['PHP_SELF']) == 'manage_tenants.php'): ?>
        <button onclick="document.getElementById('addTenantModal').classList.remove('hidden'); document.getElementById('addTenantModal').classList.add('flex')" class="bg-slate-900 dark:bg-white text-white dark:text-black hover:opacity-90 px-4 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 transition-all shadow-lg shadow-slate-200 dark:shadow-none">
            <i data-lucide="plus" size="16"></i> Add New Tenant
        </button>
        <?php endif; ?>
    </div>
</header>