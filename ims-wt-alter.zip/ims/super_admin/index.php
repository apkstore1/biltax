<?php
// Redirect to the main dashboard page
header("Location: dashboard.php");
exit;
?>