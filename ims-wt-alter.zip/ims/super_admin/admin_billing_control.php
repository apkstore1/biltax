<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard: Only allowed if has 'billing' permission
if (!has_admin_permission('billing')) {
    die("Access Denied: You do not have permission to control billing.");
}

require_once 'config.php'; // connects to biltax_main ($pdo)
require_once '../config/currency_helper.php';

$msg = '';
$error = '';

// --- 0. FETCH GLOBAL ADMIN SETTINGS ---
$global_currency = 'USD';
$global_symbol = '$';
try {
    $stmt_admin = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
    $admin_settings = $stmt_admin->fetchAll(PDO::FETCH_KEY_PAIR);
    $global_currency = $admin_settings['global_currency'] ?? 'USD';
    $global_symbol = $admin_settings['global_currency_symbol'] ?? '$';
} catch (Exception $e) {}

$rates = getExchangeRates();
$global_rate = $rates[$global_currency] ?? 1.0;

// --- 1. SELF-HEALING: Ensure Billing Tables & Columns Exist ---
try {
    // Create packages table if missing to prevent ALTER crashes
    $pdo->exec("CREATE TABLE IF NOT EXISTS packages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        package_name VARCHAR(100) NOT NULL,
        price DECIMAL(10,2) DEFAULT 0.00,
        yearly_price DECIMAL(10,2) DEFAULT 0.00,
        staff_limit INT DEFAULT 5,
        branch_limit INT DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Ensure packages table has the new cycle columns
    $pdo->exec("ALTER TABLE packages ADD COLUMN IF NOT EXISTS primary_cycle VARCHAR(50) DEFAULT '1_month'");
    $pdo->exec("ALTER TABLE packages ADD COLUMN IF NOT EXISTS secondary_cycle VARCHAR(50) DEFAULT '1_year'");
    $pdo->exec("ALTER TABLE packages ADD COLUMN IF NOT EXISTS has_secondary TINYINT(1) DEFAULT 0");
    $pdo->exec("ALTER TABLE packages ADD COLUMN IF NOT EXISTS yearly_price DECIMAL(10,2) DEFAULT 0.00");

    // Subscriptions Table (Linked to packages)
    $pdo->exec("CREATE TABLE IF NOT EXISTS subscriptions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        plan_id INT NOT NULL,
        billing_cycle ENUM('primary', 'secondary') DEFAULT 'primary',
        start_date DATE NOT NULL,
        expiry_date DATE NOT NULL,
        status ENUM('active', 'expired', 'cancelled', 'trial', 'pending_activation') DEFAULT 'active',
        transaction_id VARCHAR(100) DEFAULT NULL,
        pending_plan_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");

    // Adjustments Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS billing_adjustments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        type ENUM('discount', 'additional_charge') NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        reason TEXT,
        applied_on_date DATE NOT NULL,
        is_recurring TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");

    // Invoices Master
    $pdo->exec("CREATE TABLE IF NOT EXISTS invoices_master (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        invoice_number VARCHAR(50) UNIQUE NOT NULL,
        base_amount DECIMAL(15,2) NOT NULL,
        adjustment_total DECIMAL(15,2) DEFAULT 0,
        net_payable DECIMAL(15,2) NOT NULL,
        due_date DATE NOT NULL,
        status ENUM('unpaid', 'paid', 'overdue') DEFAULT 'unpaid',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");
} catch (Exception $e) { $error = "DB Setup Error: " . $e->getMessage(); }

// --- 2. HELPERS ---
/**
 * Returns the relative date interval for PHP strtotime
 * @param string $cycle The cycle key from DB
 * @return string
 */
function getCycleInterval($cycle) {
    switch ($cycle) {
        case '15_days': return '+15 days';
        case '1_month': return '+1 month';
        case '3_months': return '+3 months';
        case '6_months': return '+6 months';
        case '1_year': return '+1 year';
        case '5_years': return '+5 years';
        default: return '+1 month';
    }
}

// --- 3. POST ACTIONS ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $tid = $_POST['tenant_id'] ?? null;

    // Add Adjustment
    if ($_POST['action'] === 'add_adjustment') {
        $pdo->prepare("INSERT INTO billing_adjustments (tenant_id, type, amount, reason, applied_on_date, is_recurring) VALUES (?, ?, ?, ?, CURDATE(), ?)")
            ->execute([$tid, $_POST['adj_type'], $_POST['adj_amount'], $_POST['adj_reason'], isset($_POST['is_recurring']) ? 1 : 0]);
        $msg = "Adjustment saved.";
    }

    // Delete Adjustment
    if ($_POST['action'] === 'delete_adjustment') {
        $pdo->prepare("DELETE FROM billing_adjustments WHERE id = ?")->execute([$_POST['adj_id']]);
        $msg = "Adjustment removed.";
    }

    // Approve Activation Request
    if ($_POST['action'] === 'approve_activation') {
        $sub_id = $_POST['sub_id'];
        $stmt = $pdo->prepare("SELECT s.*, p.primary_cycle, p.secondary_cycle FROM subscriptions s JOIN packages p ON s.pending_plan_id = p.id WHERE s.id = ?");
        $stmt->execute([$sub_id]);
        $sub = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($sub) {
            $cycle_key = ($sub['billing_cycle'] === 'secondary') ? $sub['secondary_cycle'] : $sub['primary_cycle'];
            $new_expiry = date('Y-m-d', strtotime(getCycleInterval($cycle_key)));
            $pdo->prepare("UPDATE subscriptions SET plan_id = pending_plan_id, status = 'active', start_date = CURDATE(), expiry_date = ?, pending_plan_id = NULL, transaction_id = NULL WHERE id = ?")
                ->execute([$new_expiry, $sub_id]);
            $msg = "Subscription activated!";
        }
    }

    // Generate Manual Invoice
    if ($_POST['action'] === 'generate_invoice') {
        try {
            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT s.*, p.price as p_price, p.yearly_price as s_price, p.primary_cycle, p.secondary_cycle FROM subscriptions s JOIN packages p ON s.plan_id = p.id WHERE s.tenant_id = ? AND s.status = 'active'");
            $stmt->execute([$tid]);
            $sub = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if (!$sub) throw new Exception("No active plan found.");

            $base_amount = ($sub['billing_cycle'] === 'secondary') ? $sub['s_price'] : $sub['p_price'];
            $cycle_key = ($sub['billing_cycle'] === 'secondary') ? $sub['secondary_cycle'] : $sub['primary_cycle'];            
            $adj_total = $pdo->query("SELECT SUM(CASE WHEN type='additional_charge' THEN amount ELSE -amount END) FROM billing_adjustments WHERE tenant_id = " . (int)$tid)->fetchColumn() ?: 0;
            $inv_num = "INV-" . date('Ymd') . "-" . strtoupper(bin2hex(random_bytes(2)));
            $pdo->prepare("INSERT INTO invoices_master (tenant_id, invoice_number, base_amount, adjustment_total, net_payable, due_date) VALUES (?, ?, ?, ?, ?, DATE_ADD(CURDATE(), INTERVAL 7 DAY))")->execute([$tid, $inv_num, $base_amount, $adj_total, ($base_amount + $adj_total)]);

            $new_expiry = date('Y-m-d', strtotime(getCycleInterval($cycle_key), strtotime($sub['expiry_date'])));
            $pdo->prepare("UPDATE subscriptions SET expiry_date = ? WHERE id = ?")->execute([$new_expiry, $sub['id']]);
            $pdo->prepare("DELETE FROM billing_adjustments WHERE tenant_id = ? AND is_recurring = 0")->execute([$tid]);

            $pdo->commit();
            $msg = "Invoice #$inv_num generated and expiry extended.";
        } catch (Exception $e) { if($pdo->inTransaction()) $pdo->rollBack(); $error = $e->getMessage(); }
    }

    // 4. Approve Activation Request
    if ($_POST['action'] === 'approve_activation') {
        $stmt = $pdo->prepare("SELECT s.*, p.primary_cycle, p.secondary_cycle FROM subscriptions s JOIN packages p ON s.pending_plan_id = p.id WHERE s.id = ?");
        $stmt->execute([$_POST['sub_id']]);
        $sub = $stmt->fetch(PDO::FETCH_ASSOC);
        
        $cycle_key = ($sub['billing_cycle'] === 'secondary') ? $sub['secondary_cycle'] : $sub['primary_cycle'];
        $new_expiry = date('Y-m-d', strtotime(getCycleInterval($cycle_key)));

        // Activate and link to tenant
        $pdo->prepare("UPDATE subscriptions SET plan_id = pending_plan_id, status = 'active', start_date = CURDATE(), expiry_date = ?, pending_plan_id = NULL, transaction_id = NULL WHERE id = ?")
            ->execute([$new_expiry, $_POST['sub_id']]);
        
        $pdo->prepare("UPDATE tenants SET package_id = (SELECT plan_id FROM subscriptions WHERE id = ?) WHERE id = (SELECT tenant_id FROM subscriptions WHERE id = ?)")
            ->execute([$_POST['sub_id'], $_POST['sub_id']]);
        $msg = "Subscription activated!";
    }
}

// --- 4. DATA FETCHING ---
$tenants = [];
$pending_activations = [];
$subscription = null;
$adjustments_list = [];
$selected_tid = $_GET['tenant_id'] ?? null;

try {
    // All fetch queries wrapped in try-catch to prevent page crashes
    $tenants = $pdo->query("SELECT id, business_name, unique_id FROM tenants WHERE status = 'active' ORDER BY business_name ASC")->fetchAll(PDO::FETCH_ASSOC);
    
    // Check if column pending_plan_id exists before joining
    $check_col = $pdo->query("SHOW COLUMNS FROM subscriptions LIKE 'pending_plan_id'")->fetch();
    if ($check_col) {
        $pending_activations = $pdo->query("SELECT s.*, t.business_name, p.package_name as plan_name, p.primary_cycle, p.secondary_cycle 
                                            FROM subscriptions s 
                                            JOIN tenants t ON s.tenant_id = t.id 
                                            JOIN packages p ON s.pending_plan_id = p.id 
                                            WHERE s.status = 'pending_activation'")->fetchAll(PDO::FETCH_ASSOC);
    }

    if ($selected_tid) {
        $stmt = $pdo->prepare("SELECT s.*, p.package_name, p.primary_cycle, p.secondary_cycle 
                               FROM subscriptions s 
                               JOIN packages p ON s.plan_id = p.id 
                               WHERE s.tenant_id = ? AND s.status = 'active'");
        $stmt->execute([$selected_tid]);
        $subscription = $stmt->fetch(PDO::FETCH_ASSOC);

        // Fetch Adjustments
        $stmt_adj = $pdo->prepare("SELECT * FROM billing_adjustments WHERE tenant_id = ? ORDER BY created_at DESC");
        $stmt_adj->execute([$selected_tid]);
        $adjustments_list = $stmt_adj->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $error = "Data Fetch Error: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Billing Control | Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>
        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-5xl mx-auto">
                <header class="mb-10">
                    <h1 class="text-3xl font-black uppercase tracking-tight">Billing Control</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Manage tenant subscriptions and invoices</p>
                </header>

                <?php if($msg): ?><div class="p-4 bg-emerald-500/10 text-emerald-500 rounded-2xl mb-6 font-bold text-sm border border-emerald-500/20"><i data-lucide="check-circle" class="inline mr-2"></i><?= $msg ?></div><?php endif; ?>
                <?php if($error): ?><div class="p-4 bg-rose-500/10 text-rose-500 rounded-2xl mb-6 font-bold text-sm border border-rose-500/20"><?= $error ?></div><?php endif; ?>

                <!-- Tenant Selector -->
                <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm mb-10">
                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">Target Business</label>
                    <select onchange="window.location.href='?tenant_id='+this.value" class="w-full px-6 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-black text-lg appearance-none">
                        <option value="">-- Choose Business --</option>
                        <?php foreach($tenants as $t): ?>
                            <option value="<?= $t['id'] ?>" <?= $selected_tid == $t['id'] ? 'selected' : '' ?>><?= htmlspecialchars($t['business_name']) ?> (<?= $t['unique_id'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <!-- Pending Activations -->
                <?php if(!empty($pending_activations)): ?>
                <div class="bg-white dark:bg-neutral-900 border-2 border-orange-500 rounded-[40px] p-8 mb-10 shadow-xl">
                    <h3 class="text-xl font-black text-orange-500 uppercase mb-6 flex items-center gap-2"><i data-lucide="clock"></i> Pending Activations</h3>
                    <div class="grid grid-cols-1 gap-4">
                        <?php foreach($pending_activations as $req): ?>
                        <div class="p-5 bg-slate-50 dark:bg-neutral-950 rounded-3xl border border-slate-200 dark:border-neutral-800 flex justify-between items-center">
                            <div>
                                <p class="text-sm font-black dark:text-white"><?= htmlspecialchars($req['business_name']) ?></p>
                                <?php 
                                    $p_cycle_text = ($req['billing_cycle'] === 'secondary') ? ($req['secondary_cycle'] ?? 'N/A') : ($req['primary_cycle'] ?? 'N/A');
                                ?>
                                <p class="text-[10px] font-black uppercase text-orange-600">Plan: <?= $req['plan_name'] ?> (<?= str_replace('_', ' ', strtoupper($p_cycle_text)) ?>)</p>
                                <p class="text-[10px] font-mono text-slate-400 mt-1 uppercase">TID: <?= htmlspecialchars($req['transaction_id']) ?></p>
                            </div>
                            <form method="POST">
                                <input type="hidden" name="action" value="approve_activation">
                                <input type="hidden" name="sub_id" value="<?= $req['id'] ?>">
                                <button type="submit" class="px-6 py-3 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase shadow-lg shadow-emerald-600/20 active:scale-95">Verify & Activate</button>
                            </form>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endif; ?>

                <?php if($selected_tid && $subscription): ?>
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Adjustments -->
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                        <h3 class="text-xl font-black mb-6 uppercase"><i data-lucide="calculator" class="inline mr-2 text-orange-600"></i> Adjustments</h3>
                        <form method="POST" class="space-y-4">
                            <input type="hidden" name="action" value="add_adjustment">
                            <input type="hidden" name="tenant_id" value="<?= $selected_tid ?>">
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-400 mb-1">Type</label>
                                <select name="adj_type" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                                    <option value="additional_charge">Charge (+)</option>
                                    <option value="discount">Discount (-)</option>
                                </select>
                            </div>
                            <div class="grid grid-cols-2 gap-4">
                                <div>
                                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-1">Amount</label>
                                    <input type="number" step="0.01" name="adj_amount" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                                </div>
                                <div class="flex items-center gap-2 pt-5">
                                    <input type="checkbox" name="is_recurring" class="w-4 h-4 accent-orange-600">
                                    <span class="text-[10px] font-black uppercase text-slate-500">Recurring</span>
                                </div>
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-400 mb-1">Reason</label>
                                <input type="text" name="adj_reason" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white font-bold">
                            </div>
                            <button type="submit" class="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase text-[10px] tracking-widest shadow-lg">Apply Adjustment</button>
                        </form>
                    </div>

                    <!-- Current Status -->
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl flex flex-col">
                        <h3 class="text-xl font-black mb-6 uppercase"><i data-lucide="activity" class="inline mr-2 text-orange-600"></i> Active Status</h3>
                        <div class="space-y-6 flex-1">
                            <div class="p-5 bg-orange-500/5 rounded-3xl border border-orange-500/10">
                                <p class="text-[9px] font-black uppercase text-orange-500 mb-1">Current Plan</p>
                                <p class="text-lg font-black dark:text-white"><?= $subscription['package_name'] ?></p>
                                <?php 
                                    $display_cycle = ($subscription['billing_cycle'] === 'secondary') ? ($subscription['secondary_cycle'] ?? 'N/A') : ($subscription['primary_cycle'] ?? 'N/A');
                                ?>
                                <p class="text-[10px] font-bold text-slate-500 uppercase mt-1">Cycle: <?= str_replace('_', ' ', strtoupper($display_cycle)) ?></p>
                            </div>
                            <div>
                                <p class="text-[10px] font-black uppercase text-slate-400 mb-1">Plan Expiry</p>
                                <p class="text-2xl font-black dark:text-white"><?= date('M d, Y', strtotime($subscription['expiry_date'])) ?></p>
                            </div>

                            <!-- Adjustment List -->
                            <?php if(!empty($adjustments_list)): ?>
                            <div class="pt-6 border-t border-slate-100 dark:border-neutral-800">
                                <p class="text-[10px] font-black uppercase text-orange-500 mb-3 tracking-widest">Active Adjustments</p>
                                <div class="space-y-2">
                                    <?php foreach($adjustments_list as $al): 
                                        $is_disc = ($al['type'] === 'discount');
                                    ?>
                                    <div class="flex justify-between items-center p-3 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800">
                                        <div>
                                            <p class="text-[10px] font-bold dark:text-white"><?= htmlspecialchars($al['reason']) ?></p>
                                            <p class="text-[9px] font-black uppercase <?= $is_disc ? 'text-emerald-500' : 'text-rose-500' ?>">
                                                <?= $is_disc ? '-' : '+' ?><?= $global_symbol ?><?= number_format($al['amount'] * $global_rate, 2) ?> (<?= $al['is_recurring'] ? 'REC' : 'ONCE' ?>)
                                            </p>
                                        </div>
                                        <form method="POST" onsubmit="return confirm('Remove this adjustment?')">
                                            <input type="hidden" name="action" value="delete_adjustment">
                                            <input type="hidden" name="tenant_id" value="<?= $selected_tid ?>">
                                            <input type="hidden" name="adj_id" value="<?= $al['id'] ?>">
                                            <button type="submit" class="p-2 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="14"></i></button>
                                        </form>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <!-- Invoice Action -->
                    <div class="md:col-span-2 bg-indigo-600 p-10 rounded-[48px] text-white flex flex-col md:flex-row items-center justify-between shadow-2xl shadow-indigo-600/20">
                        <div class="text-center md:text-left mb-6 md:mb-0">
                            <h2 class="text-3xl font-black uppercase tracking-tight">Manual Renewal</h2>
                            <p class="text-xs font-bold opacity-80 mt-1 uppercase tracking-widest">Generate Invoice & Extend Expiry</p>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="action" value="generate_invoice">
                            <input type="hidden" name="tenant_id" value="<?= $selected_tid ?>">
                            <button type="submit" class="px-10 py-5 bg-white text-indigo-600 rounded-[24px] font-black uppercase text-sm tracking-widest shadow-xl hover:scale-105 active:scale-95 transition-all">
                                <i data-lucide="file-text" class="inline mr-2"></i> Generate Now
                            </button>
                        </form>
                    </div>
                </div>
                <?php elseif($selected_tid): ?>
                    <div class="p-20 text-center bg-white dark:bg-neutral-900 rounded-[40px] border border-dashed border-slate-200 dark:border-neutral-800">
                        <i data-lucide="alert-circle" class="mx-auto text-slate-300 mb-4" size="48"></i>
                        <p class="text-slate-400 font-bold uppercase tracking-widest text-xs">No active subscription found for this tenant.</p>
                    </div>
                <?php else: ?>
                    <div class="p-20 text-center bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm opacity-50 italic">Select a tenant to begin management.</div>
                <?php endif; ?>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>