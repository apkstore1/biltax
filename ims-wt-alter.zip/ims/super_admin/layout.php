<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
// Basic Auth Check for Super Admin (To be implemented or assumed)
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Biltax Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Theme Logic -->
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #171717; }
        ::-webkit-scrollbar-thumb { background: #404040; border-radius: 10px; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content Wrapper -->
    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        
        <!-- Top Bar -->
        <?php include 'topbar.php'; ?>

        <!-- Dynamic Content Area -->
        <main class="p-8 flex-1 overflow-y-auto">
            <?php
            // Dynamic Include Logic
            if (isset($content_view) && file_exists($content_view)) {
                include $content_view;
            } else {
                echo '<div class="p-4 bg-yellow-100 dark:bg-yellow-900/20 text-yellow-700 dark:text-yellow-500 rounded-lg">No content view defined.</div>';
            }
            ?>
        </main>

    </div>

    <script>
        lucide.createIcons();
    </script>
</body>
</html>