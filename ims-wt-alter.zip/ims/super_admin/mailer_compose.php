<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';
require_once '../mailer/email_helper.php';

$msg = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $to = $_POST['to'];
    $subject = $_POST['subject'];
    $body = $_POST['message'];
    $type = $_POST['template_type'] ?? 'general';

    // Prepare dummy data for templates if not general
    $data = $body;
    if ($type === 'activation') $data = ['name' => 'Valued Partner', 'message' => $body];
    elseif ($type === 'expiry') $data = ['days_left' => '3', 'plan_name' => 'Current Plan', 'message' => $body];
    
    if (sendBiltaxEmail($to, $subject, $data, $type)) {
        $msg = "Email successfully dispatched to $to";
    } else {
        $error = "Mailer Error: Please check your SMTP settings in mailer/email_helper.php";
    }
}

$tenants = $pdo->query("SELECT email, business_name FROM tenants WHERE status = 'active' ORDER BY business_name ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Compose Email | Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64 flex flex-col">
        <?php include 'topbar.php'; ?>
        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-4xl mx-auto">
                <header class="mb-10">
                    <h1 class="text-3xl font-black uppercase tracking-tight">Mail Sender</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Broadcast professional emails to your network</p>
                </header>

                <?php if($msg): ?><div class="p-4 bg-emerald-500/10 text-emerald-500 rounded-2xl mb-6 font-bold text-sm border border-emerald-500/20"><?= $msg ?></div><?php endif; ?>
                <?php if($error): ?><div class="p-4 bg-rose-500/10 text-rose-500 rounded-2xl mb-6 font-bold text-sm border border-rose-500/20"><?= $error ?></div><?php endif; ?>

                <div class="bg-white dark:bg-neutral-900 p-10 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                    <form method="POST" class="space-y-6">
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Recipient</label>
                                <input type="text" name="to" list="tenant_list" required placeholder="email@example.com" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all text-sm">
                                <datalist id="tenant_list">
                                    <?php foreach($tenants as $t): ?>
                                        <option value="<?= $t['email'] ?>"><?= $t['business_name'] ?></option>
                                    <?php endforeach; ?>
                                </datalist>
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Template Theme</label>
                                <select name="template_type" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all text-sm">
                                    <option value="general">General (Standard Blue)</option>
                                    <option value="activation">Account Activation (Welcome)</option>
                                    <option value="expiry">Urgent Expiry (Red Alert)</option>
                                </select>
                            </div>
                        </div>

                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Subject</label>
                            <input type="text" name="subject" required placeholder="e.g. Important Update regarding your account" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all text-sm">
                        </div>

                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Message Body</label>
                            <textarea name="message" rows="6" required placeholder="Type your message here..." class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all text-sm"></textarea>
                        </div>

                        <button type="submit" class="w-full py-5 bg-orange-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-900/20 hover:scale-[1.01] active:scale-95 transition-all flex items-center justify-center gap-3">
                            <i data-lucide="send" size="20"></i> Dispatch Branded Email
                        </button>
                    </form>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>