-- Create modules table if not exists
CREATE TABLE IF NOT EXISTS modules (
    id INT PRIMARY KEY AUTO_INCREMENT,
    module_name VARCHAR(50) NOT NULL UNIQUE,
    module_key VARCHAR(50) NOT NULL UNIQUE, -- Added module_key
    status ENUM('active', 'inactive') DEFAULT 'active'
);
-- 1. Pehle table ka structure theek karein (module_key add karein)
ALTER TABLE modules 
ADD COLUMN IF NOT EXISTS module_key VARCHAR(50) NOT NULL AFTER module_name,
ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;

-- 2. Module Key par Unique index lagayein taake duplicate na ho
ALTER TABLE modules ADD UNIQUE INDEX IF NOT EXISTS (module_key);

-- 3. Status column ko ENUM banayein agar wo simple text hai
ALTER TABLE modules MODIFY COLUMN status ENUM('active', 'inactive') DEFAULT 'active';

-- 4. Default Modules insert karein (Sahi keys ke sath)
TRUNCATE TABLE modules; -- Purana khali data khatam karein

INSERT INTO modules (module_name, module_key, status) VALUES 
('Dashboard', 'dashboard', 'active'),
('Food POS Terminal', 'food_pos', 'active'),
('Retail POS Terminal', 'retail_pos', 'active'),
('Wholesale POS Terminal', 'wholesale_pos', 'active'),
('Service POS Terminal', 'service_pos', 'active'),
('Custom POS Terminal', 'custom_pos', 'active'),
('Inventory Management', 'inventory', 'active'),
('Staff Management', 'staff', 'active'),
('Suppliers', 'suppliers', 'active'),
('Purchases', 'purchases', 'active'),
('B2B Orders', 'b2b_orders', 'active'),
('POS Returns', 'pos_returns', 'active'),
('Business Logo', 'business_logo', 'active'),
('Shop Image Upload', 'shop_image_upload', 'active'),
('Biltax Hub', 'marketplace_main', 'active'),
('Marketplace', 'biltax_hub', 'active'),
('Shop', 'shop_module', 'active'),
('Marketplace Listing Visibility', 'marketplace_listing_visibility', 'active'), -- New module for the second slider
('B2B Returns', 'b2b_returns', 'active'),
('Vendors Management', 'vendors', 'active'),
('Vendor Order History', 'vendor_orders', 'active'),
('Marketplace Listing', 'marketplace', 'active'),
('Sales Reports', 'sales_reports', 'active'),
('Barcode Engine', 'barcodes', 'active'),
('Table Management', 'tables', 'active'),
('Kitchen Orders (KOT)', 'kot', 'active'),
('Menu & Recipes', 'recipes', 'active'),
('Bulk Sales', 'bulk_sales', 'active'),
('Party Ledgers (Udhaar)', 'ledgers', 'active'),
('Service Jobs', 'jobs', 'active'),
('Partner Network (B2B)', 'partner_network', 'active'),
('Customers (CRM)', 'customers', 'active'),
('Reminders', 'reminders', 'active'),
('Advanced Reports', 'reports', 'active'),
('WhatsApp & Email Sharing', 'whatsapp_email_sharing', 'active'), -- Unified module for sharing invoices/jobs
('Rider Tracking System', 'rider_tracking', 'active'), -- New module for delivery management
('Verification Center', 'verification_center', 'active'),
('System Settings', 'settings', 'active'),
('Store & Branches', 'manage_branches', 'active'),
('Bulk Sales', 'bulk_sales', 'active'),
('B2B Chat System', 'b2b_chat', 'active'),
('Chat Image Sharing', 'chat_images', 'active'),
('Live Chat Support', 'live_chat', 'active'),
('Payment QR Generator', 'payment_qr', 'active'),
('Custom Invoice Builder', 'invoice_builder', 'active'),
('Raw Material System', 'raw_material_system', 'active'),
('Financials', 'finance_management', 'active'),
('Payroll System', 'payroll_system', 'active'),
('Expense Tracker', 'expense_tracker', 'active'),
('Accounts Payable', 'accounts_payable', 'active'),
('Finance Reports', 'finance_reports', 'active'),
('Receipt Reprint', 'receipt_reprint', 'active') -- New module for reprinting old receipts
ON DUPLICATE KEY UPDATE status='active';

-- Create Page Access Controls Table
CREATE TABLE IF NOT EXISTS page_access_controls (
    id INT PRIMARY KEY AUTO_INCREMENT,
    page_slug VARCHAR(100) NOT NULL UNIQUE,
    page_title VARCHAR(255) NOT NULL,
    restriction_type ENUM('none', 'verification_required', 'request_based', 'upgrade_required') DEFAULT 'none',
    required_verification_task_id INT DEFAULT NULL,
    required_package_id INT DEFAULT NULL,
    status ENUM('active', 'inactive') DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Seed Initial Page Access Data
INSERT IGNORE INTO page_access_controls (page_slug, page_title, restriction_type, required_package_id) VALUES 
('dashboard', 'Main Dashboard', 'none', 1),
('inventory_list', 'Inventory Management', 'none', 1),
('pos_retail', 'Retail POS Terminal', 'none', 1),
('pos_food', 'Food POS Terminal', 'none', 1), 
('connect_partner', 'Partner Network (B2B)', 'verification_required', 1),
('b2b_orders', 'B2B Trade Orders', 'verification_required', 1),
('marketplace_hub', 'Biltax Hub Listing', 'verification_required', 2),
('staff_management', 'Staff & Permissions', 'upgrade_required', 2),
('advanced_reports', 'Financial Analytics', 'upgrade_required', 3),
('party_ledgers', 'Party Ledgers (Udhaar)', 'none', 1),
('suppliers', 'Supplier Management', 'none', 1),
('verification_center', 'Compliance Center', 'none', 1),
('manage_branches', 'Store & Branches', 'none', 1),
('stock_transfer', 'Stock Transfer', 'none', 1),
('api_access', 'Developer API Keys', 'request_based', 3),
('bulk_import', 'Bulk Data Import', 'upgrade_required', 2);