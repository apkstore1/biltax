<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';

// --- Self-healing: Ensure payment_settings table exists in biltax_main ---
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS payment_settings (
        setting_key VARCHAR(100) PRIMARY KEY,
        setting_value TEXT,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
} catch (Exception $e) {}

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_bank_details') {
    try {
        $settings = [
            'bank_details_name' => $_POST['bank_name'],
            'bank_details_title' => $_POST['account_title'],
            'bank_details_no' => $_POST['account_no'],
            'bank_details_instructions' => $_POST['instructions']
        ];

        foreach ($settings as $key => $val) {
            $stmt = $pdo->prepare("INSERT INTO payment_settings (setting_key, setting_value) VALUES (?, ?) ON DUPLICATE KEY UPDATE setting_value = ?");
            $stmt->execute([$key, $val, $val]);
        }
        $msg = "Bank details updated successfully!";
    } catch (Exception $e) {
        $error_msg = "Update failed: " . $e->getMessage();
    }
}

// Fetch current settings
$stmt_fetch = $pdo->query("SELECT setting_key, setting_value FROM payment_settings");
// Failsafe: query might return false if table is missing, prevent 500 error
$res = $stmt_fetch ? $stmt_fetch->fetchAll(PDO::FETCH_KEY_PAIR) : [];

$bank_name = $res['bank_details_name'] ?? 'Meezan Bank / HBL';
$account_title = $res['bank_details_title'] ?? 'Biltax Solutions';
$account_no = $res['bank_details_no'] ?? 'PK00 MZN 0012 3456 7890';
$instructions = $res['bank_details_instructions'] ?? 'Paise transfer karne ke baad baraye meharbani Transaction ID aur apna naam submit karein taake hum foran aapka plan activate kar sakein.';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Payment Options | Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>
        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-4xl mx-auto">
                <header class="mb-10">
                    <h1 class="text-3xl font-black uppercase tracking-tight">Payment Options</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Configure Bank details and future Payment Gateways</p>
                </header>

                <?php if(isset($msg)): ?><div class="p-4 bg-emerald-500/10 text-emerald-500 rounded-2xl mb-6 font-bold text-sm border border-emerald-500/20"><i data-lucide="check-circle" class="inline mr-2"></i><?= $msg ?></div><?php endif; ?>
                <?php if(isset($error_msg)): ?><div class="p-4 bg-rose-500/10 text-rose-500 rounded-2xl mb-6 font-bold text-sm border border-rose-500/20"><i data-lucide="alert-circle" class="inline mr-2"></i><?= $error_msg ?></div><?php endif; ?>

                <div class="grid grid-cols-1 gap-8">
                    <!-- Manual Bank Transfer Config -->
                    <div class="bg-white dark:bg-neutral-900 p-10 rounded-[48px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                        <h2 class="text-xl font-black dark:text-white uppercase mb-6 flex items-center gap-3"><i data-lucide="landmark" class="text-orange-600"></i> Bank Transfer Details</h2>
                        <form method="POST" class="space-y-6">
                            <input type="hidden" name="action" value="update_bank_details">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Bank Name</label>
                                    <input type="text" name="bank_name" value="<?= htmlspecialchars($bank_name) ?>" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all font-bold">
                                </div>
                                <div>
                                    <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Account Title</label>
                                    <input type="text" name="account_title" value="<?= htmlspecialchars($account_title) ?>" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all font-bold">
                                </div>
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">IBAN / Account Number</label>
                                <input type="text" name="account_no" value="<?= htmlspecialchars($account_no) ?>" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all font-black text-lg tracking-tighter text-orange-600">
                            </div>
                            <div>
                                <label class="block text-[10px] font-black uppercase text-slate-400 mb-2 ml-1">Customer Instructions</label>
                                <textarea name="instructions" rows="3" class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all font-medium text-sm"><?= htmlspecialchars($instructions) ?></textarea>
                            </div>
                            <button type="submit" class="w-full py-5 bg-orange-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:scale-[1.02] active:scale-95 transition-all mt-4">Save Bank Configuration</button>
                        </form>
                    </div>

                    <!-- Future Gateways Placeholder -->
                    <div class="bg-white dark:bg-neutral-900 p-10 rounded-[48px] border border-slate-200 dark:border-neutral-800 shadow-xl opacity-60">
                        <h2 class="text-xl font-black dark:text-white uppercase mb-6 flex items-center gap-3"><i data-lucide="credit-card" class="text-indigo-600"></i> Online Payment Gateways</h2>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div class="p-6 bg-slate-50 dark:bg-neutral-950 rounded-3xl border border-dashed border-slate-200 dark:border-neutral-800 flex flex-col items-center justify-center text-center">
                                <i data-lucide="shield-check" class="text-slate-300 mb-2"></i>
                                <h4 class="font-bold text-sm uppercase">Stripe / Credit Card</h4>
                                <p class="text-[10px] text-slate-400 mt-1 uppercase font-black tracking-widest">Coming Soon</p>
                            </div>
                            <div class="p-6 bg-slate-50 dark:bg-neutral-950 rounded-3xl border border-dashed border-slate-200 dark:border-neutral-800 flex flex-col items-center justify-center text-center">
                                <i data-lucide="wallet" class="text-slate-300 mb-2"></i>
                                <h4 class="font-bold text-sm uppercase">JazzCash / EasyPaisa</h4>
                                <p class="text-[10px] text-slate-400 mt-1 uppercase font-black tracking-widest">Planned</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>