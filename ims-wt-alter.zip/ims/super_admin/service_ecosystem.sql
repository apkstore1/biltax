-- Universal Service Management Ecosystem - Central Schema
-- This handles cross-tenant service data for the Biltax Hub

CREATE TABLE IF NOT EXISTS services (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tenant_id INT NOT NULL,
    service_name VARCHAR(255) NOT NULL,
    base_price DECIMAL(15,2) DEFAULT 0,
    checklists JSON DEFAULT NULL, -- Stores dynamic task points
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (tenant_id)
);

CREATE TABLE IF NOT EXISTS job_cards (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tenant_id INT NOT NULL,
    customer_id INT DEFAULT NULL,
    service_id INT DEFAULT NULL,
    technician_id INT DEFAULT NULL,
    status ENUM('pending', 'in-progress', 'completed', 'delivered') DEFAULT 'pending',
    task_completion_data JSON DEFAULT NULL, -- Track checklist progress
    total_cost DECIMAL(15,2) DEFAULT 0,
    advance_paid DECIMAL(15,2) DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (tenant_id),
    INDEX (status)
);

CREATE TABLE IF NOT EXISTS universal_cron_configs (
    id INT PRIMARY KEY AUTO_INCREMENT,
    tenant_id INT NOT NULL,
    job_name VARCHAR(100) NOT NULL,
    frequency_minutes INT DEFAULT 60,
    last_run DATETIME DEFAULT NULL,
    is_active TINYINT(1) DEFAULT 1,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX (tenant_id),
    INDEX (is_active)
);