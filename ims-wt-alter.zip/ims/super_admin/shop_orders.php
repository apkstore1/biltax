<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';

// Handle Status Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    $stmt = $pdo->prepare("UPDATE shop_orders SET status = ? WHERE id = ?");
    $stmt->execute([$new_status, $order_id]);
    header("Location: shop_orders.php?msg=updated"); exit;
}

// Fetch Orders with Tenant Details
$orders = $pdo->query("
    SELECT o.*, t.business_name, t.email as tenant_email, t.currency_symbol 
    FROM shop_orders o 
    JOIN tenants t ON o.tenant_id = t.id 
    ORDER BY o.created_at DESC
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Shop Orders - Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white flex min-h-screen">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 ml-64 p-8">
        <header class="mb-8">
            <h1 class="text-2xl font-black uppercase tracking-tight">Biltax Shop Orders</h1>
            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Manage incoming product requests from tenants</p>
        </header>

        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[32px] overflow-hidden shadow-sm">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                    <tr>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Order ID</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Business</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Amount</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Status</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest">Date</th>
                        <th class="px-6 py-4 text-[10px] font-black uppercase text-slate-500 tracking-widest text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach($orders as $o): ?>
                    <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors">
                        <td class="px-6 py-4 font-mono text-xs font-bold text-slate-400">#ORD-<?= $o['id'] ?></td>
                        <td class="px-6 py-4">
                            <p class="text-sm font-black dark:text-white"><?= htmlspecialchars($o['business_name']) ?></p>
                            <p class="text-[10px] text-slate-400 font-bold uppercase"><?= htmlspecialchars($o['tenant_email']) ?></p>
                        </td>
                        <td class="px-6 py-4 font-black text-orange-600 text-sm"><?= htmlspecialchars($o['currency_symbol']) ?><?= number_format($o['total_amount'], 2) ?></td>
                        <td class="px-6 py-4">
                            <?php 
                                $color = 'bg-amber-500';
                                if($o['status'] == 'fulfilled') $color = 'bg-emerald-500';
                                if($o['status'] == 'cancelled') $color = 'bg-rose-500';
                                if($o['status'] == 'processing') $color = 'bg-blue-500';
                            ?>
                            <span class="<?= $color ?> text-white text-[9px] font-black uppercase px-2 py-1 rounded-lg">
                                <?= $o['status'] ?>
                            </span>
                        </td>
                        <td class="px-6 py-4 text-xs font-bold text-slate-500"><?= date('M d, Y', strtotime($o['created_at'])) ?></td>
                        <td class="px-6 py-4 text-right">
                            <form method="POST" class="inline-flex gap-2">
                                <input type="hidden" name="order_id" value="<?= $o['id'] ?>">
                                <input type="hidden" name="action" value="update_status">
                                <select name="status" onchange="this.form.submit()" class="bg-slate-50 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-lg text-[10px] font-black uppercase px-2 py-1 outline-none">
                                    <option value="pending" <?= $o['status'] == 'pending' ? 'selected' : '' ?>>Pending</option>
                                    <option value="processing" <?= $o['status'] == 'processing' ? 'selected' : '' ?>>Processing</option>
                                    <option value="fulfilled" <?= $o['status'] == 'fulfilled' ? 'selected' : '' ?>>Fulfilled</option>
                                    <option value="cancelled" <?= $o['status'] == 'cancelled' ? 'selected' : '' ?>>Cancelled</option>
                                </select>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($orders)): ?>
                        <tr>
                            <td colspan="6" class="px-6 py-12 text-center">
                                <div class="w-16 h-16 bg-slate-100 dark:bg-neutral-800 rounded-full flex items-center justify-center mx-auto mb-4">
                                    <i data-lucide="inbox" class="text-slate-300"></i>
                                </div>
                                <p class="text-xs font-bold text-slate-400 uppercase tracking-widest">No orders received yet</p>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>