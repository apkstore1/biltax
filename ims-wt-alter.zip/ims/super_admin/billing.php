<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';
require_once '../config/currency_helper.php';

// Fetch Global Admin Settings
$global_currency = 'USD';
$global_symbol = '$';
try {
    $stmt_admin = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
    $admin_settings = $stmt_admin->fetchAll(PDO::FETCH_KEY_PAIR);
    $global_currency = $admin_settings['global_currency'] ?? 'USD';
    $global_symbol = $admin_settings['global_currency_symbol'] ?? '$';
} catch (Exception $e) {}

$rates = getExchangeRates();
$global_rate = $rates[$global_currency] ?? 1.0;

// --- SELF-HEALING: Billing Engine Setup ---
try {
    // 2. Subscriptions (Linked to Tenants)
    $pdo->exec("CREATE TABLE IF NOT EXISTS subscriptions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        plan_id INT NOT NULL, -- This should link to packages table
        billing_cycle ENUM('monthly', 'yearly') DEFAULT 'monthly',
        start_date DATE NOT NULL,
        expiry_date DATE NOT NULL,
        status ENUM('active', 'expired', 'cancelled', 'trial') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
        FOREIGN KEY (plan_id) REFERENCES packages(id) ON DELETE CASCADE
    )");

    // 3. Billing Adjustments (Discounts or Charges)
    $pdo->exec("CREATE TABLE IF NOT EXISTS billing_adjustments (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        type ENUM('discount', 'additional_charge') NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        reason TEXT,
        applied_on_date DATE NOT NULL,
        is_recurring TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");

    // 4. Invoices Master (The Billing History)
    $pdo->exec("CREATE TABLE IF NOT EXISTS invoices_master (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        invoice_number VARCHAR(50) UNIQUE NOT NULL,
        base_amount DECIMAL(15,2) NOT NULL,
        adjustment_total DECIMAL(15,2) DEFAULT 0,
        net_payable DECIMAL(15,2) NOT NULL,
        due_date DATE NOT NULL,
        status ENUM('unpaid', 'paid', 'overdue') DEFAULT 'unpaid',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");

} catch (Exception $e) { $db_error = $e->getMessage(); }

// --- Filter & Search Logic ---
$adj_search = $_GET['adj_search'] ?? '';
$adj_type = $_GET['adj_type'] ?? 'all';

$inv_search = $_GET['inv_search'] ?? '';
$inv_status = $_GET['inv_status'] ?? 'all';

// Fetch Summary Data
// Updated to use 'packages' table instead of 'billing_plans'
$total_mrr = $pdo->query("SELECT SUM(p.price) FROM subscriptions s 
                          JOIN packages p ON s.plan_id = p.id 
                          WHERE s.status = 'active' AND s.billing_cycle = 'monthly'")->fetchColumn() ?: 0;
$total_mrr *= $global_rate;
$active_subs = $pdo->query("SELECT COUNT(*) FROM subscriptions WHERE status = 'active'")->fetchColumn() ?: 0;

// Fetch Active Billing Adjustments (Discounts & Extra Charges)
$adj_query = "SELECT a.*, t.business_name, t.unique_id FROM billing_adjustments a JOIN tenants t ON a.tenant_id = t.id";
$adj_where = [];
$adj_params = [];
if ($adj_type !== 'all') {
    $adj_where[] = "a.type = ?";
    $adj_params[] = $adj_type;
}
if ($adj_search) {
    $adj_where[] = "(t.business_name LIKE ? OR t.unique_id LIKE ? OR a.reason LIKE ?)";
    $p = "%$adj_search%";
    array_push($adj_params, $p, $p, $p);
}
if ($adj_where) $adj_query .= " WHERE " . implode(" AND ", $adj_where);
$adj_query .= " ORDER BY a.created_at DESC";
$stmt_adj = $pdo->prepare($adj_query);
$stmt_adj->execute($adj_params);
$adjustments = $stmt_adj->fetchAll(PDO::FETCH_ASSOC);

// Fetch Recent Invoices
$inv_query = "SELECT i.*, t.business_name FROM invoices_master i JOIN tenants t ON i.tenant_id = t.id";
$inv_where = [];
$inv_params = [];
if ($inv_status !== 'all') {
    $inv_where[] = "i.status = ?";
    $inv_params[] = $inv_status;
}
if ($inv_search) {
    $inv_where[] = "(i.invoice_number LIKE ? OR t.business_name LIKE ?)";
    $p = "%$inv_search%";
    array_push($inv_params, $p, $p);
}
if ($inv_where) $inv_query .= " WHERE " . implode(" AND ", $inv_where);
$inv_query .= " ORDER BY i.created_at DESC LIMIT 50";
$stmt_inv = $pdo->prepare($inv_query);
$stmt_inv->execute($inv_params);
$invoices = $stmt_inv->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Billing Center | Biltax Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>
        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-7xl mx-auto">
                <header class="mb-10">
                    <h1 class="text-3xl font-black uppercase tracking-tight">Billing & Subscriptions</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Global Billing Engine Control</p>
                </header>

                <?php if(isset($db_error)): ?>
                    <div class="p-4 bg-rose-500/10 text-rose-500 rounded-2xl mb-6 font-bold text-xs">DB Sync Error: <?= $db_error ?></div>
                <?php elseif(isset($msg)): ?>
                    <div class="p-4 bg-emerald-500/10 text-emerald-500 rounded-2xl mb-6 font-bold text-xs"><?= $msg ?></div>
                <?php endif; ?>

                <!-- Stats Row -->
                <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase mb-1">Estimated MRR</p>
                        <h3 class="text-4xl font-black text-emerald-500"><?= $global_symbol ?><?= number_format($total_mrr, 2) ?></h3>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase mb-1">Active Subscriptions</p>
                        <h3 class="text-4xl font-black dark:text-white"><?= $active_subs ?></h3>
                    </div>
                    <div class="bg-indigo-600 p-8 rounded-[40px] text-white shadow-xl shadow-indigo-600/20">
                        <p class="text-[10px] font-black uppercase opacity-70 mb-1">Billing System Status</p>
                        <h3 class="text-xl font-black uppercase tracking-tight">Engine Online</h3>
                        <p class="text-xs mt-2 font-bold opacity-80 italic">Tables isolated per tenant</p>
                    </div>
                </div>

                <!-- Billing Adjustments Section -->
                <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[40px] overflow-hidden shadow-xl mb-10">
                    <div class="p-8 border-b border-slate-100 dark:border-neutral-800 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
                        <div>
                            <h2 class="text-sm font-black dark:text-white uppercase tracking-widest">Active Billing Adjustments</h2>
                            <p class="text-[10px] text-slate-500 font-bold uppercase mt-1">Global discounts and manual charges applied to tenants</p>
                        </div>
                        <form method="GET" class="flex items-center gap-2 w-full md:w-auto">
                            <input type="hidden" name="inv_search" value="<?= htmlspecialchars($inv_search) ?>">
                            <input type="hidden" name="inv_status" value="<?= htmlspecialchars($inv_status) ?>">
                            <select name="adj_type" onchange="this.form.submit()" class="px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl text-[10px] font-black uppercase outline-none focus:border-orange-500 dark:text-white">
                                <option value="all" <?= $adj_type === 'all' ? 'selected' : '' ?>>All Types</option>
                                <option value="discount" <?= $adj_type === 'discount' ? 'selected' : '' ?>>Discounts</option>
                                <option value="additional_charge" <?= $adj_type === 'additional_charge' ? 'selected' : '' ?>>Charges</option>
                            </select>
                            <input type="text" name="adj_search" value="<?= htmlspecialchars($adj_search) ?>" placeholder="Search business or reason..." class="flex-1 md:w-48 px-4 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl text-[10px] font-bold outline-none focus:border-orange-500 dark:text-white">
                        </form>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                <tr>
                                    <th class="px-8 py-5">Tenant</th>
                                    <th class="px-8 py-5">Adjustment Type</th>
                                    <th class="px-8 py-5">Amount</th>
                                    <th class="px-8 py-5">Reason</th>
                                    <th class="px-8 py-5 text-center">Recurrence</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                                <?php foreach($adjustments as $adj): 
                                    $is_disc = ($adj['type'] === 'discount');
                                ?>
                                <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors">
                                    <td class="px-8 py-5">
                                        <p class="font-bold text-sm dark:text-white"><?= htmlspecialchars($adj['business_name']) ?></p>
                                        <p class="text-[10px] text-slate-500 font-mono"><?= $adj['unique_id'] ?></p>
                                    </td>
                                    <td class="px-8 py-5">
                                        <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase border <?= $is_disc ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20' ?>">
                                            <?= str_replace('_', ' ', $adj['type']) ?>
                                        </span>
                                    </td>
                                    <td class="px-8 py-5 font-black <?= $is_disc ? 'text-emerald-500' : 'text-rose-500' ?>"><?= $is_disc ? '-' : '+' ?><?= $global_symbol ?><?= number_format($adj['amount'] * $global_rate, 2) ?></td>
                                    <td class="px-8 py-5 text-xs text-slate-500 italic"><?= htmlspecialchars($adj['reason']) ?></td>
                                    <td class="px-8 py-5 text-center">
                                        <span class="text-[10px] font-bold uppercase <?= $adj['is_recurring'] ? 'text-orange-500' : 'text-slate-400' ?>"><?= $adj['is_recurring'] ? 'Recurring' : 'One-time' ?></span>
                                    </td>
                                </tr>
                                <?php endforeach; if(empty($adjustments)): ?>
                                    <tr><td colspan="5" class="p-16 text-center text-slate-400 italic font-bold">No adjustments or discounts set for any tenant.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

                <!-- Invoice Manifest -->
                <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[40px] overflow-hidden shadow-xl">
                    <div class="p-8 border-b border-slate-100 dark:border-neutral-800 flex flex-col lg:flex-row justify-between items-start lg:items-center gap-4">
                        <div>
                            <h2 class="text-sm font-black dark:text-white uppercase tracking-widest">Recent System Invoices</h2>
                        </div>
                        <div class="flex flex-wrap items-center gap-2 w-full lg:w-auto justify-end">
                            <form method="GET" class="flex items-center gap-2 flex-1 lg:flex-none">
                                <input type="hidden" name="adj_search" value="<?= htmlspecialchars($adj_search) ?>">
                                <input type="hidden" name="adj_type" value="<?= htmlspecialchars($adj_type) ?>">
                                <select name="inv_status" onchange="this.form.submit()" class="px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl text-[10px] font-black uppercase outline-none focus:border-orange-500 dark:text-white">
                                    <option value="all" <?= $inv_status === 'all' ? 'selected' : '' ?>>All Status</option>
                                    <option value="paid" <?= $inv_status === 'paid' ? 'selected' : '' ?>>Paid</option>
                                    <option value="unpaid" <?= $inv_status === 'unpaid' ? 'selected' : '' ?>>Unpaid</option>
                                    <option value="overdue" <?= $inv_status === 'overdue' ? 'selected' : '' ?>>Overdue</option>
                                </select>
                                <input type="text" name="inv_search" value="<?= htmlspecialchars($inv_search) ?>" placeholder="Invoice # or business..." class="flex-1 md:w-48 px-4 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl text-[10px] font-bold outline-none focus:border-orange-500 dark:text-white">
                            </form>
                            <a href="admin_billing_control.php" class="px-5 py-2.5 bg-slate-100 dark:bg-neutral-800 text-[10px] font-black uppercase rounded-xl hover:bg-orange-600 hover:text-white transition-all whitespace-nowrap">Manual Generation</a>
                        </div>
                    </div>
                    <div class="overflow-x-auto">
                        <table class="w-full text-left">
                            <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                                <tr>
                                    <th class="px-8 py-5">Invoice #</th>
                                    <th class="px-8 py-5">Tenant / Business</th>
                                    <th class="px-8 py-5">Due Date</th>
                                    <th class="px-8 py-5 text-right">Net Payable</th>
                                    <th class="px-8 py-5 text-center">Status</th>
                                    <th class="px-8 py-5"></th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                                <?php foreach($invoices as $inv): ?>
                                <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors">
                                    <td class="px-8 py-5 font-mono text-xs font-bold text-slate-400"><?= $inv['invoice_number'] ?></td>
                                    <td class="px-8 py-5">
                                        <p class="font-bold text-sm dark:text-white"><?= htmlspecialchars($inv['business_name']) ?></p>
                                    </td>
                                    <td class="px-8 py-5 text-xs text-slate-500"><?= date('M d, Y', strtotime($inv['due_date'])) ?></td>
                                    <td class="px-8 py-5 text-right font-black text-slate-900 dark:text-white"><?= $global_symbol ?><?= number_format($inv['net_payable'] * $global_rate, 2) ?></td>
                                    <td class="px-8 py-5 text-center">
                                        <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase border <?= $inv['status'] === 'paid' ? 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20' : 'bg-rose-500/10 text-rose-500 border-rose-500/20' ?>">
                                            <?= $inv['status'] ?>
                                        </span>
                                    </td>
                                    <td class="px-8 py-5 text-right">
                                        <a href="tenant_monitor.php?id=<?= $inv['tenant_id'] ?>" class="p-2 text-slate-400 hover:text-orange-600 transition-colors inline-block"><i data-lucide="external-link" size="16"></i></a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if(empty($invoices)): ?>
                                    <tr><td colspan="6" class="p-20 text-center text-slate-400 italic font-bold">No invoices generated by the engine yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>