<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';
require_once '../config/db_connect.php';
require_once '../config/currency_helper.php';

$tenant_id = $_GET['id'] ?? null;
if (!$tenant_id) die("Invalid Tenant ID");

try {
    // 1. Fetch Tenant Profile & Package from Main DB
    $stmt = $pdo->prepare("SELECT t.*, p.package_name, p.monthly_price,
                           (SELECT COUNT(*) FROM enabled_modules WHERE tenant_id = t.id AND is_active = 1) as module_count
                           FROM tenants t 
                           LEFT JOIN packages p ON t.package_id = p.id 
                           WHERE t.id = ?");
    $stmt->execute([$tenant_id]);
    $tenant = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$tenant) die("Tenant not found.");

    // 2. Fetch Active Modules List
    $stmt_mod = $pdo->prepare("SELECT m.module_name, m.module_key FROM enabled_modules em JOIN modules m ON em.module_key = m.module_key WHERE em.tenant_id = ? AND em.is_active = 1");
    $stmt_mod->execute([$tenant_id]);
    $active_modules = $stmt_mod->fetchAll(PDO::FETCH_ASSOC);

    // 2.2 Fetch Global Admin Settings
    $global_currency = 'USD';
    $global_symbol = '$';
    try {
        $stmt_admin_settings = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
        $admin_settings = $stmt_admin_settings->fetchAll(PDO::FETCH_KEY_PAIR);
        if ($admin_settings) {
            $global_currency = $admin_settings['global_currency'] ?? 'USD';
            $global_symbol = $admin_settings['global_currency_symbol'] ?? '$';
        }
    } catch (Exception $e) { /* Table or column might not exist yet, using defaults */ }
    
    // Prepare Exchange Rates for conversion (Tenant -> Global Admin Currency)
    $rates = getExchangeRates();
    $global_rate = $rates[$global_currency] ?? 1.0;
    $tenant_rate = $rates[$tenant['currency_code'] ?? 'USD'] ?? 1.0;

    // 2.5 Prepare Chart Data (Last 7 Days Revenue)
    $chartLabels = [];
    $chartData = [];
    $revenue_map = [];
    for ($i = 6; $i >= 0; $i--) {
        $d = date('Y-m-d', strtotime("-$i days"));
        $day_name = date('D', strtotime($d));
        $chartLabels[] = $day_name;
        $revenue_map[$d] = 0;
    }

    $chartLabelsJson = json_encode($chartLabels);
    // Default chart data if DB fails
    $chartDataJson = json_encode(array_values($revenue_map));

    // 3. Connect to Tenant DB for Live Analytics
    $stats = ['products' => 0, 'sales' => 0, 'revenue' => 0, 'staff' => 0, 'recent_sales' => [], 'staff_list' => [], 'rider_list' => [], 'branch_list' => [], 'products_list' => [], 'purchase_history' => [], 'expenses' => [], 'ledger' => [], 'salaries' => [], 'jobs' => [], 'suppliers' => []];
    try {
        $t_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . $tenant['db_name'], DB_USER, DB_PASS);
        $t_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        $stats['products'] = $t_pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
        $stats['sales'] = $t_pdo->query("SELECT COUNT(*) FROM sales")->fetchColumn();
        
        $rev_col = (strtolower($tenant['industry_type']) == 'retail' || strtolower($tenant['industry_type']) == 'wholesale') ? 'total_amount' : 'total_amount';
        $stats['revenue'] = $t_pdo->query("SELECT SUM($rev_col) FROM sales")->fetchColumn() ?: 0;
        
        // Fetch Staff
        $stats['staff_list'] = $t_pdo->query("SELECT name, role FROM users ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
        
        // Fetch Riders if table exists
        $check_riders = $t_pdo->query("SHOW TABLES LIKE 'riders'")->fetch();
        if ($check_riders) {
            $stats['rider_list'] = $t_pdo->query("SELECT name, phone FROM riders ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
        }
        
        $stats['staff'] = count($stats['staff_list']) + count($stats['rider_list']);
        
        // Fetch last 5 transactions
        $stmt_rec = $t_pdo->query("SELECT * FROM sales ORDER BY created_at DESC LIMIT 5");
        $stats['recent_sales'] = $stmt_rec->fetchAll(PDO::FETCH_ASSOC);

        // Fetch last 7 days for Chart
        $stmt_chart = $t_pdo->query("SELECT DATE(created_at) as date, SUM($rev_col) as total FROM sales WHERE created_at >= DATE_SUB(NOW(), INTERVAL 7 DAY) GROUP BY DATE(created_at)");
        while($row = $stmt_chart->fetch(PDO::FETCH_ASSOC)) {
            $revenue_map[$row['date']] = (float)$row['total'];
        }
        $chartDataJson = json_encode(array_values($revenue_map));
        
        // 4. Comprehensive Data Fetching
        // Products Detailed List
        $stats['products_list'] = $t_pdo->query("SELECT p.name, p.sku, p.stock_level, p.sale_price, p.purchase_price, s.name as supplier_name FROM products p LEFT JOIN suppliers s ON p.supplier_id = s.id ORDER BY p.stock_level ASC LIMIT 50")->fetchAll(PDO::FETCH_ASSOC);

        // Purchase History & Pending Orders
        $check_purchases = $t_pdo->query("SHOW TABLES LIKE 'purchases'")->fetch();
        if ($check_purchases) {
            $stats['purchase_history'] = $t_pdo->query("SELECT p.*, s.name as supplier_name FROM purchases p LEFT JOIN suppliers s ON p.supplier_id = s.id ORDER BY p.created_at DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
        }

        // Expenses
        $check_expenses = $t_pdo->query("SHOW TABLES LIKE 'expenses'")->fetch();
        if ($check_expenses) {
            $stats['expenses'] = $t_pdo->query("SELECT e.*, c.name as cat_name FROM expenses e LEFT JOIN expense_categories c ON e.category_id = c.id ORDER BY expense_date DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
        }

        // Party Ledger (Udhaar)
        $check_ledgers = $t_pdo->query("SHOW TABLES LIKE 'ledgers'")->fetch();
        if ($check_ledgers) {
            $stats['ledger'] = $t_pdo->query("SELECT party_name, party_type, SUM(debit) as total_debit, SUM(credit) as total_credit FROM ledgers GROUP BY party_name, party_type HAVING (SUM(debit) - SUM(credit)) != 0")->fetchAll(PDO::FETCH_ASSOC);
        }

        // Staff Salaries
        $check_salaries = $t_pdo->query("SHOW TABLES LIKE 'salary_payments'")->fetch();
        if ($check_salaries) {
            $stats['salaries'] = $t_pdo->query("SELECT sp.*, u.name as staff_name FROM salary_payments sp JOIN users u ON sp.user_id = u.id ORDER BY payment_date DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
        }

        // Job Cards (Services)
        $check_jobs = $t_pdo->query("SHOW TABLES LIKE 'job_cards'")->fetch();
        if ($check_jobs) {
            $stats['jobs'] = $t_pdo->query("SELECT j.*, c.name as customer_name FROM job_cards j LEFT JOIN customers c ON j.customer_id = c.id ORDER BY created_at DESC LIMIT 20")->fetchAll(PDO::FETCH_ASSOC);
        }

        // Suppliers (Manual)
        $check_suppliers = $t_pdo->query("SHOW TABLES LIKE 'suppliers'")->fetch();
        if ($check_suppliers) {
            $stats['suppliers'] = $t_pdo->query("SELECT * FROM suppliers ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
        }

        // Fetch Branches
        $check_branches = $t_pdo->query("SHOW TABLES LIKE 'branches'")->fetch();
        if ($check_branches) {
            $stats['branch_list'] = $t_pdo->query("SELECT branch_name, address, is_main FROM branches ORDER BY is_main DESC, branch_name ASC")->fetchAll(PDO::FETCH_ASSOC);
        }
        
        // 5. B2B Orders (from Main DB)
        $stmt_b2b = $pdo->prepare("SELECT o.*, t.business_name as partner_name FROM b2b_orders o JOIN tenants t ON o.receiver_tenant_id = t.id WHERE o.sender_tenant_id = ? ORDER BY o.created_at DESC LIMIT 20");
        $stmt_b2b->execute([$tenant_id]);
        $stats['b2b_orders'] = $stmt_b2b->fetchAll(PDO::FETCH_ASSOC);

    } catch (Exception $e) {
        $db_error = "Could not connect to tenant database: " . $e->getMessage();
    }

} catch (Exception $e) {
    die("Critical Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Monitor: <?= htmlspecialchars($tenant['business_name']) ?> | Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>

        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-7xl mx-auto">
                <!-- Breadcrumb & Header -->
                <div class="flex items-center gap-2 text-xs font-bold text-slate-400 uppercase tracking-widest mb-4">
                    <a href="tenant_views_manager.php" class="hover:text-orange-500 transition-colors">Tenants</a>
                    <i data-lucide="chevron-right" size="12"></i>
                    <span class="text-slate-600 dark:text-slate-300">Detailed Monitor</span>
                </div>

                <header class="flex justify-between items-end mb-10">
                    <div>
                        <h1 class="text-4xl font-black tracking-tight text-slate-900 dark:text-white"><?= htmlspecialchars($tenant['business_name']) ?></h1>
                        <div class="flex items-center gap-3 mt-2">
                            <span class="px-3 py-1 bg-indigo-500/10 text-indigo-500 rounded-full text-[10px] font-black uppercase tracking-widest border border-indigo-500/20">ID: <?= $tenant['unique_id'] ?></span>
                            <span class="px-3 py-1 bg-emerald-500/10 text-emerald-500 rounded-full text-[10px] font-black uppercase tracking-widest border border-emerald-500/20"><?= ucfirst($tenant['industry_type']) ?></span>
                            <?php if($tenant['is_verified']): ?>
                                <span class="flex items-center gap-1 text-[10px] font-black uppercase text-blue-500"><i data-lucide="badge-check" size="14"></i> Trusted</span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <form action="tenant_views_manager.php" method="POST">
                        <input type="hidden" name="action" value="login_as_tenant">
                        <input type="hidden" name="tenant_id" value="<?= $tenant['id'] ?>">
                        <button type="submit" class="px-6 py-3 bg-orange-600 text-white rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-orange-600/20 hover:scale-105 transition-all">
                            <i data-lucide="external-link" class="inline mr-2" size="16"></i> Access Panel
                        </button>
                    </form>
                </header>

                <!-- Floating Shortcut for Admin -->
                <div class="fixed bottom-10 right-10 z-[60] flex flex-col gap-3">
                    <form action="tenant_views_manager.php" method="POST">
                        <input type="hidden" name="action" value="login_as_tenant">
                        <input type="hidden" name="tenant_id" value="<?= $tenant['id'] ?>">
                        <button type="submit" class="w-14 h-14 bg-orange-600 text-white rounded-full flex items-center justify-center shadow-2xl hover:scale-110 transition-transform" title="Login as Tenant">
                            <i data-lucide="log-in" size="24"></i>
                        </button>
                    </form>
                </div>

                <!-- Tab Navigation -->
                <div class="flex gap-2 p-1 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl mb-10 overflow-x-auto no-scrollbar">
                    <button onclick="switchTab('overview')" class="tab-btn px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all bg-orange-600 text-white" data-tab="overview">Overview</button>
                    <button onclick="switchTab('inventory')" class="tab-btn px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="inventory">Stock & Products</button>
                    <button onclick="switchTab('financials')" class="tab-btn px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="financials">Financials</button>
                    <button onclick="switchTab('operations')" class="tab-btn px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="operations">Operations & B2B</button>
                    <?php if(!empty($stats['jobs']) || strtolower($tenant['industry_type']) == 'service'): ?>
                        <button onclick="switchTab('services')" class="tab-btn px-6 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all text-slate-400 hover:text-orange-500" data-tab="services">Jobs & CRM</button>
                    <?php endif; ?>
                </div>

                <?php if(isset($db_error)): ?>
                    <div class="mb-8 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-2xl text-xs font-bold">
                        ⚠️ <?= $db_error ?>
                    </div>
                <?php endif; ?>

                <div id="overview" class="tab-pane animate-in fade-in duration-300">
                <!-- Stats Grid -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                    <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Revenue</p>
                        <h3 class="text-3xl font-black text-slate-900 dark:text-white"><?= $global_symbol ?><?= number_format(($stats['revenue'] / $tenant_rate) * $global_rate, 2) ?></h3>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Transactions</p>
                        <h3 class="text-3xl font-black text-slate-900 dark:text-white"><?= number_format($stats['sales']) ?></h3>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Stock Items</p>
                        <h3 class="text-3xl font-black text-slate-900 dark:text-white"><?= number_format($stats['products']) ?></h3>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Active Staff</p>
                        <h3 class="text-3xl font-black text-slate-900 dark:text-white"><?= number_format($stats['staff']) ?> / <?= $tenant['staff_limit'] ?></h3>
                    </div>
                </div>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
                    <!-- Sales Trend Chart -->
                    <div class="lg:col-span-2 bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <h4 class="text-xs font-black uppercase text-orange-500 tracking-widest mb-6">Revenue Trend (Last 7 Days)</h4>
                        <div class="h-64"><canvas id="revenueTrend"></canvas></div>
                    </div>

                    <!-- Left: Profile & Plan -->
                    <div class="lg:col-span-1 space-y-6">
                        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                            <h4 class="text-xs font-black uppercase text-orange-500 tracking-widest mb-6">Subscription Details</h4>
                            <div class="space-y-4">
                                <div class="flex justify-between items-center">
                                    <span class="text-xs font-bold text-slate-400">Current Plan</span>
                                    <span class="text-sm font-black dark:text-white"><?= htmlspecialchars($tenant['package_name'] ?? 'Custom') ?></span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-xs font-bold text-slate-400">Monthly Billing</span>
                                    <span class="text-sm font-black text-emerald-500"><?= $global_symbol ?><?= number_format(($tenant['monthly_price'] ?? 0) * $global_rate, 2) ?></span>
                                </div>
                                <div class="flex justify-between items-center">
                                    <span class="text-xs font-bold text-slate-400">Status</span>
                                    <span class="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-500 text-[10px] font-black uppercase"><?= $tenant['status'] ?></span>
                                </div>
                            </div>
                            <hr class="my-6 border-slate-100 dark:border-neutral-800">
                            <h4 class="text-[10px] font-black uppercase text-slate-400 tracking-widest mb-4">Contact Information</h4>
                            <div class="space-y-3">
                                <p class="text-sm font-bold dark:text-white"><?= htmlspecialchars($tenant['owner_name']) ?></p>
                                <p class="text-xs text-slate-500"><?= htmlspecialchars($tenant['email']) ?></p>
                                <p class="text-xs text-slate-500"><?= htmlspecialchars($tenant['phone']) ?></p>
                            </div>
                        </div>

                        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                            <h4 class="text-xs font-black uppercase text-indigo-500 tracking-widest mb-6">Active Modules (<?= count($active_modules) ?>)</h4>
                            <div class="flex flex-wrap gap-2">
                                <?php foreach($active_modules as $mod): ?>
                                    <span class="px-3 py-1.5 bg-slate-50 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-xl text-[10px] font-bold dark:text-slate-300">
                                        <?= htmlspecialchars($mod['module_name']) ?>
                                    </span>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Right: Activity & Live DB View -->
                    <div class="lg:col-span-2 space-y-6">
                        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
                            <div class="flex justify-between items-center mb-6">
                                <h4 class="text-xs font-black uppercase text-slate-400 tracking-widest">Recent Live Activity</h4>
                                <span class="flex items-center gap-1 text-[9px] font-black text-emerald-500 animate-pulse uppercase"><i data-lucide="circle" size="8" class="fill-current"></i> Live Feed</span>
                            </div>
                            
                            <div class="overflow-x-auto">
                                <table class="w-full text-left">
                                    <thead class="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-neutral-800">
                                        <tr>
                                            <th class="pb-4">Trans ID</th>
                                            <th class="pb-4">Date & Time</th>
                                            <th class="pb-4">Method</th>
                                            <th class="pb-4 text-right">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                                        <?php if(empty($stats['recent_sales'])): ?>
                                            <tr><td colspan="4" class="py-8 text-center text-xs text-slate-400 italic">No recent transactions found.</td></tr>
                                        <?php else: ?>
                                            <?php foreach($stats['recent_sales'] as $sale): ?>
                                            <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors">
                                                <td class="py-4 text-xs font-black text-indigo-500">#<?= $sale['id'] ?></td>
                                                <td class="py-4 text-xs text-slate-500"><?= date('M d, H:i', strtotime($sale['created_at'])) ?></td>
                                                <td class="py-4"><span class="px-2 py-0.5 bg-slate-100 dark:bg-neutral-800 rounded text-[9px] font-black uppercase text-slate-600 dark:text-slate-400"><?= $sale['payment_method'] ?></span></td>
                                                <td class="py-4 text-right text-sm font-black dark:text-white"><?= $global_symbol ?><?= number_format(($sale['total_amount'] / $tenant_rate) * $global_rate, 2) ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>

                        <!-- Staff & Branches Row -->
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                            <!-- Staff List Card -->
                            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
                                <h4 class="text-xs font-black uppercase text-orange-500 tracking-widest mb-6 flex items-center gap-2"><i data-lucide="users" size="14"></i> Staff & Team</h4>
                                <div class="space-y-3 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                                    <?php foreach($stats['staff_list'] as $s): ?>
                                    <div class="p-3 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                                        <span class="text-xs font-bold dark:text-white"><?= htmlspecialchars($s['name']) ?></span>
                                        <span class="text-[9px] font-black uppercase bg-slate-100 dark:bg-neutral-800 text-slate-500 px-2 py-0.5 rounded-lg"><?= htmlspecialchars($s['role']) ?></span>
                                    </div>
                                    <?php endforeach; ?>
                                    <?php foreach($stats['rider_list'] as $r): ?>
                                    <div class="p-3 bg-orange-500/5 rounded-2xl border border-orange-500/10 flex justify-between items-center">
                                        <div class="flex items-center gap-2">
                                            <i data-lucide="bike" size="12" class="text-orange-500"></i>
                                            <span class="text-xs font-bold dark:text-white"><?= htmlspecialchars($r['name']) ?></span>
                                        </div>
                                        <span class="text-[9px] font-black uppercase text-orange-600">Rider</span>
                                    </div>
                                    <?php endforeach; ?>
                                    <?php if(empty($stats['staff_list']) && empty($stats['rider_list'])): ?>
                                        <p class="text-center text-xs text-slate-400 italic">No staff records found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Branches Card -->
                            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
                                <h4 class="text-xs font-black uppercase text-indigo-500 tracking-widest mb-6 flex items-center gap-2"><i data-lucide="map-pin" size="14"></i> Registered Branches</h4>
                                <div class="space-y-3 max-h-60 overflow-y-auto pr-2 custom-scrollbar">
                                    <?php foreach($stats['branch_list'] as $b): ?>
                                    <div class="p-3 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800">
                                        <div class="flex justify-between items-center mb-1">
                                            <span class="text-xs font-black dark:text-white uppercase tracking-tight"><?= htmlspecialchars($b['branch_name']) ?></span>
                                            <?php if($b['is_main']): ?><span class="text-[8px] font-black uppercase bg-indigo-500 text-white px-2 py-0.5 rounded">Main Branch</span><?php endif; ?>
                                        </div>
                                        <p class="text-[10px] text-slate-500 truncate"><?= htmlspecialchars($b['address'] ?: 'No address set') ?></p>
                                    </div>
                                    <?php endforeach; ?>
                                    <?php if(empty($stats['branch_list'])): ?>
                                        <p class="text-center text-xs text-slate-400 italic">No branch records found.</p>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- Database Context -->
                        <div class="bg-indigo-600 p-8 rounded-[40px] text-white flex justify-between items-center shadow-xl shadow-indigo-600/20">
                            <div>
                                <p class="text-[10px] font-black uppercase opacity-70 mb-1">Backend Infrastructure</p>
                                <div class="flex items-center gap-2">
                                    <i data-lucide="shield-check" class="text-emerald-400" size="20"></i>
                                    <h4 class="text-xl font-black">Dedicated Instance Active</h4>
                                </div>
                                <p class="text-xs mt-2 font-mono opacity-80"><?= $tenant['db_name'] ?> @ Localhost</p>
                            </div>
                            <div class="text-right">
                                <div class="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center mb-2">
                                    <i data-lucide="database" size="24"></i>
                                </div>
                                <span class="text-[9px] font-black uppercase px-2 py-1 bg-white/20 rounded">Health: 100%</span>
                            </div>
                        </div>
                    </div>
                </div>
                </div>

                <!-- Inventory Tab -->
                <div id="inventory" class="tab-pane hidden animate-in fade-in duration-300">
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm mb-10">
                        <h4 class="text-xs font-black uppercase text-orange-500 tracking-widest mb-6">Product Catalog & Live Stock</h4>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left">
                                <thead class="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-neutral-800">
                                    <tr>
                                        <th class="pb-4">Product Name</th>
                                        <th class="pb-4">SKU</th>
                                        <th class="pb-4">Supplier</th>
                                        <th class="pb-4">Price</th>
                                        <th class="pb-4 text-right">Stock</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                                    <?php foreach($stats['products_list'] as $p): ?>
                                    <tr class="text-sm">
                                        <td class="py-4 font-bold dark:text-white"><?= htmlspecialchars($p['name']) ?></td>
                                        <td class="py-4 font-mono text-xs text-slate-500"><?= htmlspecialchars($p['sku'] ?: 'N/A') ?></td>
                                        <td class="py-4 text-xs text-slate-500"><?= htmlspecialchars($p['supplier_name'] ?: 'Internal') ?></td>
                                        <td class="py-4 text-xs font-bold dark:text-slate-300"><?= $global_symbol ?><?= number_format(($p['sale_price'] / $tenant_rate) * $global_rate, 2) ?></td>
                                        <td class="py-4 text-right">
                                            <span class="px-2 py-1 rounded-lg text-[10px] font-black <?= $p['stock_level'] <= 10 ? 'bg-rose-500/10 text-rose-500' : 'bg-emerald-500/10 text-emerald-500' ?>">
                                                <?= $p['stock_level'] ?>
                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <!-- Financials Tab -->
                <div id="financials" class="tab-pane hidden animate-in fade-in duration-300">
                    <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                        <!-- Expenses -->
                        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                            <h4 class="text-xs font-black uppercase text-rose-500 tracking-widest mb-6">Expense History</h4>
                            <div class="space-y-4">
                                <?php foreach($stats['expenses'] as $e): ?>
                                <div class="p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                                    <div>
                                        <p class="text-xs font-black dark:text-white uppercase tracking-tight"><?= htmlspecialchars($e['cat_name']) ?></p>
                                        <p class="text-[10px] text-slate-500"><?= date('M d, Y', strtotime($e['expense_date'])) ?></p>
                                    </div>
                                    <p class="text-sm font-black text-rose-500">-<?= $global_symbol ?><?= number_format(($e['amount'] / $tenant_rate) * $global_rate, 2) ?></p>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <!-- Party Ledger Summary -->
                        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                            <h4 class="text-xs font-black uppercase text-orange-500 tracking-widest mb-6">Party Ledger (Udhaar)</h4>
                            <div class="space-y-4">
                                <?php foreach($stats['ledger'] as $l): 
                                    $balance = ($l['party_type'] == 'supplier') ? ($l['total_credit'] - $l['total_debit']) : ($l['total_debit'] - $l['total_credit']);
                                ?>
                                <div class="p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800 flex justify-between items-center">
                                    <div>
                                        <p class="text-xs font-black dark:text-white uppercase tracking-tight"><?= htmlspecialchars($l['party_name']) ?></p>
                                        <p class="text-[9px] font-black uppercase <?= $l['party_type'] == 'supplier' ? 'text-rose-500' : 'text-emerald-500' ?>"><?= $l['party_type'] ?></p>
                                    </div>
                                    <div class="text-right">
                                        <p class="text-sm font-black <?= $balance > 0 ? 'text-orange-500' : 'text-slate-400' ?>"><?= $global_symbol ?><?= number_format((abs($balance) / $tenant_rate) * $global_rate, 2) ?></p>
                                        <p class="text-[9px] text-slate-400 font-bold uppercase"><?= $balance >= 0 ? ($l['party_type'] == 'supplier' ? 'Payable' : 'Receivable') : 'Advance' ?></p>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <!-- Salaries -->
                        <div class="lg:col-span-2 bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                            <h4 class="text-xs font-black uppercase text-indigo-500 tracking-widest mb-6">Recent Salary Payouts</h4>
                            <div class="overflow-x-auto">
                                <table class="w-full text-left">
                                    <thead class="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-neutral-800">
                                        <tr>
                                            <th class="pb-4">Staff Member</th>
                                            <th class="pb-4">Month/Year</th>
                                            <th class="pb-4">Method</th>
                                            <th class="pb-4 text-right">Amount Paid</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                                        <?php foreach($stats['salaries'] as $sal): ?>
                                        <tr class="text-sm">
                                            <td class="py-4 font-bold dark:text-white"><?= htmlspecialchars($sal['staff_name']) ?></td>
                                            <td class="py-4 text-xs text-slate-500"><?= $sal['month_year'] ?></td>
                                            <td class="py-4"><span class="px-2 py-0.5 bg-slate-100 dark:bg-neutral-800 rounded text-[9px] font-black uppercase"><?= $sal['payment_method'] ?></span></td>
                                            <td class="py-4 text-right font-black text-emerald-500"><?= $global_symbol ?><?= number_format(($sal['amount_paid'] / $tenant_rate) * $global_rate, 2) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Operations Tab -->
                <div id="operations" class="tab-pane hidden animate-in fade-in duration-300">
                    <div class="grid grid-cols-1 gap-8">
                        <!-- Purchases -->
                        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                            <h4 class="text-xs font-black uppercase text-orange-500 tracking-widest mb-6">Manual Purchase History</h4>
                            <div class="overflow-x-auto">
                                <table class="w-full text-left">
                                    <thead class="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-neutral-800">
                                        <tr>
                                            <th class="pb-4">ID</th>
                                            <th class="pb-4">Supplier</th>
                                            <th class="pb-4">Date</th>
                                            <th class="pb-4">Status</th>
                                            <th class="pb-4 text-right">Total Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                                        <?php foreach($stats['purchase_history'] as $pur): ?>
                                        <tr class="text-sm">
                                            <td class="py-4 font-black text-indigo-500">#<?= $pur['id'] ?></td>
                                            <td class="py-4 font-bold dark:text-white"><?= htmlspecialchars($pur['supplier_name']) ?></td>
                                            <td class="py-4 text-xs text-slate-500"><?= date('M d, Y', strtotime($pur['created_at'])) ?></td>
                                            <td class="py-4"><span class="px-2 py-0.5 rounded text-[9px] font-black uppercase <?= $pur['status'] == 'pending' ? 'bg-amber-500/10 text-amber-500' : 'bg-emerald-500/10 text-emerald-500' ?>"><?= $pur['status'] ?></span></td>
                                            <td class="py-4 text-right font-black"><?= $global_symbol ?><?= number_format(($pur['total_amount'] / $tenant_rate) * $global_rate, 2) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- B2B Connect Orders -->
                        <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                            <h4 class="text-xs font-black uppercase text-indigo-500 tracking-widest mb-6">Partner Connect (B2B) Orders</h4>
                            <div class="overflow-x-auto">
                                <table class="w-full text-left">
                                    <thead class="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-neutral-800">
                                        <tr>
                                            <th class="pb-4">ID</th>
                                            <th class="pb-4">Partner Business</th>
                                            <th class="pb-4">Status</th>
                                            <th class="pb-4">Payment</th>
                                            <th class="pb-4 text-right">Amount</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                                        <?php foreach($stats['b2b_orders'] as $b2b): ?>
                                        <tr class="text-sm">
                                            <td class="py-4 font-black text-indigo-500">#B2B-<?= $b2b['id'] ?></td>
                                            <td class="py-4 font-bold dark:text-white"><?= htmlspecialchars($b2b['partner_name']) ?></td>
                                            <td class="py-4"><span class="px-2 py-0.5 bg-indigo-500/10 text-indigo-500 rounded text-[9px] font-black uppercase"><?= $b2b['status'] ?></span></td>
                                            <td class="py-4"><span class="px-2 py-0.5 <?= $b2b['payment_status'] == 'Paid' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500' ?> rounded text-[9px] font-black uppercase"><?= $b2b['payment_status'] ?></span></td>
                                            <td class="py-4 text-right font-black"><?= $global_symbol ?><?= number_format(($b2b['total_amount'] / $tenant_rate) * $global_rate, 2) ?></td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Services Tab -->
                <div id="services" class="tab-pane hidden animate-in fade-in duration-300">
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm mb-10">
                        <h4 class="text-xs font-black uppercase text-purple-500 tracking-widest mb-6">Service Job Cards & CRM</h4>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left">
                                <thead class="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-neutral-800">
                                    <tr>
                                        <th class="pb-4">Job ID</th>
                                        <th class="pb-4">Customer</th>
                                        <th class="pb-4">Description</th>
                                        <th class="pb-4">Status</th>
                                        <th class="pb-4 text-right">Est. Cost</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                                    <?php foreach($stats['jobs'] as $j): ?>
                                    <tr class="text-sm">
                                        <td class="py-4 font-black text-purple-500">#JOB-<?= $j['id'] ?></td>
                                        <td class="py-4 font-bold dark:text-white"><?= htmlspecialchars($j['customer_name'] ?: 'Guest') ?></td>
                                        <td class="py-4 text-xs text-slate-500 truncate max-w-xs"><?= htmlspecialchars($j['description']) ?></td>
                                        <td class="py-4">
                                            <span class="px-2 py-0.5 rounded text-[9px] font-black uppercase 
                                                <?= $j['status'] == 'delivered' ? 'bg-emerald-500/10 text-emerald-500' : 
                                                   ($j['status'] == 'received' ? 'bg-indigo-500/10 text-indigo-500' : 'bg-amber-500/10 text-amber-500') ?>">
                                                <?= $j['status'] ?>
                                            </span>
                                        </td>
                                        <td class="py-4 text-right font-black"><?= $global_symbol ?><?= number_format(($j['estimated_cost'] / $tenant_rate) * $global_rate, 2) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

            </div>
        </main>
    </div>
    <script>
        // Global functions definition
        function switchTab(tabId) {
            document.querySelectorAll('.tab-pane').forEach(p => p.classList.add('hidden')); 
            document.getElementById(tabId).classList.remove('hidden');

            document.querySelectorAll('.tab-btn').forEach(btn => {
                btn.classList.remove('bg-orange-600', 'text-white');
                btn.classList.add('text-slate-400');
            });

            const activeBtn = document.querySelector(`[onclick="switchTab('${tabId}')"]`);
            if(activeBtn) {
                activeBtn.classList.add('bg-orange-600', 'text-white');
                activeBtn.classList.remove('text-slate-400');
            }
        }

        // Init on DOM Load
        document.addEventListener('DOMContentLoaded', () => {
            lucide.createIcons();

            const chartCtx = document.getElementById('revenueTrend');
            if (chartCtx) {
                new Chart(chartCtx.getContext('2d'), {
                    type: 'line',
                    data: {
                        labels: <?= $chartLabelsJson ?>,
                        datasets: [{
                            label: 'Revenue',
                            data: <?= $chartDataJson ?>,
                            borderColor: '#f97316',
                            backgroundColor: 'rgba(249, 115, 22, 0.1)',
                            borderWidth: 4,
                            fill: true,
                            tension: 0.4
                        }]
                    },
                    options: {
                        responsive: true,
                        maintainAspectRatio: false,
                        plugins: { legend: { display: false } },
                        scales: {
                            y: { beginAtZero: true, grid: { color: 'rgba(0,0,0,0.05)' } },
                            x: { grid: { display: false } }
                        }
                    }
                });
            }
        });
    </script>
</body>
</html>