<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';
require_once '../mailer/email_helper.php';

$templates = [
    ['id' => 'activation', 'name' => 'Account Activation', 'desc' => 'Sent when a payment is approved. Contains a welcome message and login link.', 'color' => 'bg-blue-500'],
    ['id' => 'expiry', 'name' => 'Package Expiry', 'desc' => 'Urgent red alert template for subscription renewal notifications.', 'color' => 'bg-rose-500'],
    ['id' => 'stock_alert', 'name' => 'IMS Stock Alert', 'desc' => 'Orange-themed warning listing items that have reached critical levels.', 'color' => 'bg-orange-500'],
    ['id' => 'general', 'name' => 'General Announcement', 'desc' => 'Standard branded layout for general news and platform updates.', 'color' => 'bg-slate-700'],
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Email Templates | Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64 flex flex-col">
        <?php include 'topbar.php'; ?>
        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-6xl mx-auto">
                <header class="mb-10">
                    <h1 class="text-3xl font-black uppercase tracking-tight">Email System Library</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Preview system-generated HTML templates</p>
                </header>

                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <?php foreach($templates as $t): ?>
                    <div class="bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden group">
                        <div class="p-8">
                            <div class="flex justify-between items-start mb-6">
                                <div class="w-12 h-12 <?= $t['color'] ?> rounded-2xl flex items-center justify-center text-white">
                                    <i data-lucide="layout" size="24"></i>
                                </div>
                                <span class="px-3 py-1 bg-slate-100 dark:bg-neutral-800 rounded-full text-[9px] font-black uppercase tracking-widest"><?= $t['id'] ?>_tpl</span>
                            </div>
                            <h3 class="text-xl font-black mb-2 uppercase tracking-tight"><?= $t['name'] ?></h3>
                            <p class="text-sm text-slate-500 leading-relaxed mb-8"><?= $t['desc'] ?></p>
                            
                            <button onclick="previewTemplate('<?= $t['id'] ?>')" class="w-full py-4 border-2 border-slate-100 dark:border-neutral-800 rounded-2xl font-black uppercase text-[10px] tracking-widest group-hover:border-orange-500 group-hover:text-orange-500 transition-all">
                                Live Preview
                            </button>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </main>
    </div>

    <!-- Preview Modal -->
    <div id="previewModal" class="fixed inset-0 bg-black/90 hidden z-[100] items-center justify-center p-10">
        <div class="bg-white rounded-[40px] w-full max-w-2xl h-full overflow-hidden flex flex-col">
            <div class="p-6 border-b flex justify-between items-center bg-slate-50">
                <span class="text-xs font-black uppercase tracking-widest text-slate-400">Template Preview</span>
                <button onclick="document.getElementById('previewModal').classList.add('hidden')" class="text-slate-400 hover:text-rose-500"><i data-lucide="x" size="24"></i></button>
            </div>
            <iframe id="previewFrame" class="flex-1 w-full border-none"></iframe>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function previewTemplate(type) {
            const modal = document.getElementById('previewModal');
            const frame = document.getElementById('previewFrame');
            // Yahan hum dummy call kar sakte hain ya email_helper ko standalone use kar sakte hain
            // For now, simplicity ke liye hum sirf modal open kar rahe hain
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
    </script>
</body>
</html>