<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';

// --- Self-Healing: Create Admin Users Table ---
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS admin_users (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL,
        permissions TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Seed Default Super Admin if empty
    $count = $pdo->query("SELECT COUNT(*) FROM admin_users")->fetchColumn();
    if ($count == 0) {
        $pass = password_hash('admin123', PASSWORD_DEFAULT);
        $pdo->prepare("INSERT INTO admin_users (name, email, password, role, permissions) VALUES (?, ?, ?, ?, ?)")
            ->execute(['Super Admin', 'admin@biltax.com', $pass, 'Super Admin', '["all"]']);
    }
} catch (PDOException $e) {
    die("DB Setup Error: " . $e->getMessage());
}

// --- Handle Form Submission ---
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        
        // Add New Team Member
        if ($_POST['action'] === 'add_user') {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            $role = $_POST['role'];
            
            // If Super Admin, give all permissions, else take selected
            if ($role === 'Super Admin') {
                $permissions = json_encode(['all']);
            } else {
                $permissions = json_encode($_POST['permissions'] ?? []);
            }

            try {
                $stmt = $pdo->prepare("INSERT INTO admin_users (name, email, password, role, permissions) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$name, $email, $password, $role, $permissions]);
                $success_msg = "Team member added successfully.";
            } catch (PDOException $e) {
                $error_msg = "Error: " . $e->getMessage();
            }
        }

        // Delete User
        if ($_POST['action'] === 'delete_user') {
            $id = $_POST['id'];
            $stmt = $pdo->prepare("DELETE FROM admin_users WHERE id = ? AND role != 'Super Admin'"); // Prevent deleting all Super Admins check ideally
            $stmt->execute([$id]);
        }
        
        // Redirect to avoid resubmission
        header("Location: manage_team.php");
        exit;
    }
}

// --- Fetch Users ---
$users = $pdo->query("SELECT * FROM admin_users ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Team Management - Biltax Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Theme Logic -->
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #171717; }
        ::-webkit-scrollbar-thumb { background: #404040; border-radius: 10px; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>

        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-7xl mx-auto">
                <header class="flex justify-between items-center mb-10">
                    <div>
                        <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Team Management</h1>
                        <p class="text-sm text-slate-500 dark:text-neutral-400">Manage internal users and access controls.</p>
                    </div>
                <button onclick="document.getElementById('addTeamModal').classList.replace('hidden', 'flex')" class="bg-slate-900 dark:bg-white text-white dark:text-black hover:opacity-90 px-4 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 transition-all shadow-lg">
                        <i data-lucide="user-plus" size="16"></i> Add Member
                    </button>
                </header>

                <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-sm">
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                            <tr>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Name</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Role</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Permissions</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Action</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                            <?php foreach ($users as $user): ?>
                            <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors">
                                <td class="px-6 py-4">
                                    <div class="font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($user['name']); ?></div>
                                    <div class="text-xs text-slate-500 dark:text-neutral-500"><?php echo htmlspecialchars($user['email']); ?></div>
                                </td>
                                <td class="px-6 py-4"><span class="bg-slate-100 dark:bg-neutral-800 text-slate-700 dark:text-white px-3 py-1 rounded-full text-xs font-bold"><?php echo htmlspecialchars($user['role']); ?></span></td>
                                <td class="px-6 py-4 text-xs text-slate-500 dark:text-neutral-400 font-mono max-w-xs truncate"><?php echo $user['role'] == 'Super Admin' ? 'All Access' : htmlspecialchars($user['permissions']); ?></td>
                                <td class="px-6 py-4 text-right">
                                    <?php if ($user['role'] !== 'Super Admin'): ?>
                                    <form method="POST" onsubmit="return confirm('Remove this user?');">
                                        <input type="hidden" name="action" value="delete_user">
                                        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                                        <button class="text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/20 p-2 rounded-lg transition-colors"><i data-lucide="trash-2" size="16"></i></button>
                                    </form>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Add Team Modal -->
    <div id="addTeamModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[32px] w-full max-w-lg shadow-2xl relative overflow-hidden">
            <button onclick="document.getElementById('addTeamModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500"><i data-lucide="x" size="24"></i></button>
            <h3 class="text-xl font-bold mb-6 text-slate-900 dark:text-white">Add Team Member</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add_user">
                <input type="text" name="name" placeholder="Full Name" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                <input type="email" name="email" placeholder="Email Address" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                <input type="password" name="password" placeholder="Password" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                
                <div>
                    <label class="block text-xs font-bold uppercase mb-2 text-slate-500 dark:text-neutral-500">Role</label>
                    <select name="role" id="roleSelect" onchange="togglePerms(this.value)" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                        <option value="Manager">Manager</option>
                        <option value="Technical Team">Technical Team</option>
                        <option value="Support Team">Support Team</option>
                        <option value="Super Admin">Super Admin (Full Access)</option>
                    </select>
                </div>

                <div id="permSection" class="bg-slate-50 dark:bg-neutral-950 p-6 rounded-2xl border border-slate-100 dark:border-neutral-800">
                    <p class="text-[10px] font-black uppercase mb-4 text-slate-400 tracking-widest">Access Permissions</p>
                    <div class="grid grid-cols-2 gap-x-4 gap-y-3">
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="dashboard" checked class="accent-orange-600"> Dashboard</label>
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="manage_tenants" class="accent-orange-600"> Tenants Control</label>
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="support_tickets" class="accent-orange-600"> Support Tickets</label>
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="system_requests" class="accent-orange-600"> System Requests</label>
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="biltax_shop" class="accent-orange-600"> Biltax Shop</label>
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="billing" class="accent-orange-600"> Billing & Revenue</label>
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="mailer" class="accent-orange-600"> Mailer System</label>
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="settings" class="accent-orange-600"> Global Settings</label>
                        <label class="flex items-center gap-2 text-xs font-bold text-slate-700 dark:text-white cursor-pointer"><input type="checkbox" name="permissions[]" value="manage_team" class="accent-orange-600"> Team Management</label>
                    </div>
                </div>

                <button type="submit" class="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-xl transition-all">Add User</button>
            </form>
        </div>
    </div>
    <script>lucide.createIcons(); function togglePerms(role) { document.getElementById('permSection').style.display = (role === 'Super Admin') ? 'none' : 'block'; }</script>
</body>
</html>