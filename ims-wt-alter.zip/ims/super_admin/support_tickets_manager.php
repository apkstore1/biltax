<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php'; // biltax_main connection

// Handle Status Update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_status') {
    $stmt = $pdo->prepare("UPDATE support_tickets SET status = ? WHERE id = ?");
    $stmt->execute([$_POST['status'], $_POST['ticket_id']]);
    header("Location: support_tickets_manager.php?id=" . $_POST['ticket_id']); exit;
}

// Handle Admin Reply
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'admin_reply') {
    $tid = $_POST['ticket_id'];
    $msg = $_POST['message'];
    
    $stmt = $pdo->prepare("INSERT INTO ticket_messages (ticket_id, sender_role, message) VALUES (?, 'admin', ?)");
    $stmt->execute([$tid, $msg]);
    
    $pdo->prepare("UPDATE support_tickets SET status = 'in_progress', last_reply_by = 'admin' WHERE id = ?")->execute([$tid]);
    header("Location: support_tickets_manager.php?id=$tid"); exit;
}

// Fetch All Tickets with Tenant Info
$stmt = $pdo->query("SELECT t.*, b.business_name FROM support_tickets t JOIN tenants b ON t.tenant_id = b.id ORDER BY t.updated_at DESC");
$all_tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Active Ticket
$active_ticket = null;
$messages = [];
if (isset($_GET['id'])) {
    $stmt = $pdo->prepare("SELECT t.*, b.business_name, b.email, b.phone FROM support_tickets t JOIN tenants b ON t.tenant_id = b.id WHERE t.id = ?");
    $stmt->execute([$_GET['id']]);
    $active_ticket = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($active_ticket) {
        $stmt_m = $pdo->prepare("SELECT * FROM ticket_messages WHERE ticket_id = ? ORDER BY created_at ASC");
        $stmt_m->execute([$active_ticket['id']]);
        $messages = $stmt_m->fetchAll(PDO::FETCH_ASSOC);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Support Manager | Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300 overflow-hidden">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 flex flex-col ml-64">
        <?php include 'topbar.php'; ?>
        <main class="flex-1 flex overflow-hidden">
            <!-- Sidebar: Ticket List -->
            <div class="w-80 border-r border-slate-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 flex flex-col overflow-hidden">
                <div class="p-6 border-b border-slate-100 dark:border-neutral-800">
                    <h2 class="font-bold text-slate-800 dark:text-white uppercase text-xs tracking-widest">Inbound Tickets</h2>
                </div>
                <div class="flex-1 overflow-y-auto">
                    <?php foreach($all_tickets as $t): ?>
                        <a href="?id=<?= $t['id'] ?>" class="block p-4 border-b border-slate-50 dark:border-neutral-800 hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors <?= ($active_ticket && $active_ticket['id'] == $t['id']) ? 'bg-blue-50 dark:bg-blue-500/10 border-l-4 border-blue-600' : '' ?>">
                            <div class="flex justify-between items-center mb-1">
                                <span class="text-[9px] font-black uppercase text-blue-600"><?= $t['business_name'] ?></span>
                                <?php if($t['last_reply_by'] === 'tenant' && $t['status'] !== 'closed'): ?>
                                    <span class="w-2 h-2 bg-rose-500 rounded-full animate-pulse"></span>
                                <?php endif; ?>
                            </div>
                            <h4 class="text-sm font-bold text-slate-900 line-clamp-1"><?= htmlspecialchars($t['subject']) ?></h4>
                            <p class="text-[10px] text-slate-500 mt-1"><?= date('d M, H:i', strtotime($t['updated_at'])) ?></p>
                        </a>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Main: Conversation -->
            <div class="flex-1 bg-slate-50 dark:bg-neutral-950 flex flex-col overflow-hidden">
                <?php if ($active_ticket): ?>
                    <div class="p-6 bg-white dark:bg-neutral-900 border-b border-slate-200 dark:border-neutral-800 flex justify-between items-center">
                        <div>
                            <h2 class="text-xl font-bold text-slate-900"><?= htmlspecialchars($active_ticket['subject']) ?></h2>
                            <p class="text-xs text-slate-500 dark:text-neutral-400"><?= $active_ticket['business_name'] ?> (<?= $active_ticket['email'] ?>)</p>
                        </div>
                        <form method="POST" class="flex gap-2">
                            <input type="hidden" name="action" value="update_status">
                            <input type="hidden" name="ticket_id" value="<?= $active_ticket['id'] ?>">
                            <select name="status" onchange="this.form.submit()" class="text-xs font-bold border dark:border-neutral-700 rounded-lg px-3 py-2 bg-white dark:bg-neutral-800 dark:text-white outline-none">
                                <option value="open" <?= $active_ticket['status'] == 'open' ? 'selected' : '' ?>>Open</option>
                                <option value="in_progress" <?= $active_ticket['status'] == 'in_progress' ? 'selected' : '' ?>>In Progress</option>
                                <option value="resolved" <?= $active_ticket['status'] == 'resolved' ? 'selected' : '' ?>>Resolved</option>
                                <option value="closed" <?= $active_ticket['status'] == 'closed' ? 'selected' : '' ?>>Closed</option>
                            </select>
                        </form>
                    </div>

                    <div class="flex-1 overflow-y-auto p-8 space-y-4">
                        <?php foreach($messages as $m): ?>
                            <div class="flex <?= $m['sender_role'] === 'admin' ? 'justify-end' : 'justify-start' ?>">
                                <div class="max-w-[70%] <?= $m['sender_role'] === 'admin' ? 'bg-slate-900 dark:bg-white text-white dark:text-slate-900 rounded-l-xl rounded-tr-xl' : 'bg-white dark:bg-neutral-800 text-slate-900 dark:text-white border border-slate-200 dark:border-neutral-700 rounded-r-xl rounded-tl-xl' ?> p-4 shadow-sm">
                                    <p class="text-sm"><?= nl2br(htmlspecialchars($m['message'])) ?></p>
                                    <p class="text-[9px] mt-2 opacity-50 font-bold uppercase"><?= $m['sender_role'] ?> • <?= date('H:i', strtotime($m['created_at'])) ?></p>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <div class="p-6 bg-white dark:bg-neutral-900 border-t border-slate-200 dark:border-neutral-800">
                        <form method="POST" class="space-y-4">
                            <input type="hidden" name="action" value="admin_reply">
                            <input type="hidden" name="ticket_id" value="<?= $active_ticket['id'] ?>">
                            <textarea name="message" required placeholder="Write your response..." rows="3" class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border dark:border-neutral-800 rounded-xl outline-none focus:border-blue-500 text-sm dark:text-white"></textarea>
                            <div class="flex justify-end">
                                <button type="submit" class="bg-blue-600 text-white px-8 py-2.5 rounded-xl font-bold text-sm shadow-lg shadow-blue-900/10 transition-all hover:bg-blue-700">Dispatch Reply</button>
                            </div>
                        </form>
                    </div>
                <?php else: ?>
                    <div class="flex-1 flex flex-col items-center justify-center text-slate-400">
                        <i data-lucide="life-buoy" size="48" class="mb-2"></i>
                        <p class="font-bold">Select a ticket to manage</p>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Right: Tenant Context Card -->
            <?php if ($active_ticket): ?>
            <div class="w-72 border-l border-slate-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 p-6 space-y-8 overflow-y-auto">
                <div>
                    <h3 class="text-[10px] font-black uppercase text-slate-400 mb-4 tracking-widest">Business Context</h3>
                    <div class="space-y-4">
                        <div>
                            <p class="text-[9px] font-bold text-slate-400 uppercase">Tenant Name</p>
                            <p class="text-xs font-black text-slate-900 dark:text-white"><?= $active_ticket['business_name'] ?></p>
                        </div>
                        <div>
                            <p class="text-[9px] font-bold text-slate-400 uppercase">Contact</p>
                            <p class="text-xs font-medium text-slate-600 dark:text-slate-400"><?= $active_ticket['phone'] ?></p>
                        </div>
                        <div class="pt-4 border-t">
                            <p class="text-[9px] font-bold text-slate-400 uppercase">Ticket Category</p>
                            <span class="inline-block mt-1 px-2 py-0.5 bg-slate-100 dark:bg-neutral-800 rounded text-[10px] font-black uppercase dark:text-slate-300"><?= $active_ticket['category'] ?></span>
                        </div>
                        <div>
                            <p class="text-[9px] font-bold text-slate-400 uppercase">Current Status</p>
                            <span class="inline-block mt-1 px-2 py-0.5 bg-orange-100 text-orange-600 rounded text-[10px] font-black uppercase"><?= $active_ticket['status'] ?></span>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </main>
    </div>
    <script>lucide.createIcons();</script>
</body>
</html>