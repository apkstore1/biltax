<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard
if (!has_admin_permission('dashboard')) {
    die("Access Denied: You do not have permission to send notifications.");
}

require_once 'config.php'; // Super Admin config (biltax_main connection)

$message_status = '';

// Handle Form Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['send_notif'])) {
        try {
            $target = $_POST['target_audience']; 
            $tenant_id = ($target === 'all') ? null : $_POST['tenant_id'];
            $type = $_POST['type']; 
            $title = $_POST['title'];
            $notif_message = $_POST['message'];
            $sender_id = $_SESSION['admin_id'] ?? 1; 

            $stmt = $pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$sender_id, $tenant_id, $title, $notif_message, $type]);
            
            $message_status = 'success';
        } catch (PDOException $e) {
            $message_status = 'error: ' . $e->getMessage();
        }
    } elseif (isset($_POST['delete_notif'])) {
        try {
            $notif_id = $_POST['notif_id'];
            $stmt = $pdo->prepare("DELETE FROM notifications WHERE id = ?");
            $stmt->execute([$notif_id]);
            $message_status = 'deleted';
        } catch (PDOException $e) {
            $message_status = 'error: ' . $e->getMessage();
        }
    }
}

// Fetch Tenants for dropdown
$tenants = $pdo->query("SELECT id, business_name FROM tenants ORDER BY business_name ASC")->fetchAll(PDO::FETCH_ASSOC);

// Fetch Notification History
$history = $pdo->query("
    SELECT n.*, t.business_name 
    FROM notifications n 
    LEFT JOIN tenants t ON n.tenant_id = t.id 
    ORDER BY n.created_at DESC 
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Broadcast Notifications - Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>

        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-5xl mx-auto">
                <header class="mb-10">
                    <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Broadcast Center</h1>
                    <p class="text-sm text-slate-500 dark:text-neutral-400">Send system updates or alerts to your tenants.</p>
                </header>

                <?php if ($message_status === 'success'): ?>
                    <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 rounded-2xl flex items-center gap-3">
                        <i data-lucide="check-circle"></i> Notification sent successfully!
                    </div>
                <?php elseif ($message_status === 'deleted'): ?>
                    <div class="mb-6 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-500 rounded-2xl flex items-center gap-3">
                        <i data-lucide="check-circle"></i> Notification deleted successfully!
                    </div>
                <?php endif; ?>

                <!-- Form Section -->
                <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-sm overflow-hidden mb-12">
                    <div class="p-8">
                        <form method="POST" class="space-y-6">
                            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div class="space-y-2">
                                    <label class="text-xs font-bold uppercase text-slate-500">Target Audience</label>
                                    <select name="target_audience" id="target_audience" onchange="toggleTenantSelect()" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all">
                                        <option value="all">Global (All Tenants)</option>
                                        <option value="specific">Specific Business</option>
                                    </select>
                                </div>

                                <div class="space-y-2" id="tenant_select_container" style="display: none;">
                                    <label class="text-xs font-bold uppercase text-slate-500">Select Business</label>
                                    <select name="tenant_id" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all">
                                        <?php foreach ($tenants as $t): ?>
                                            <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['business_name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>

                                <div class="space-y-2">
                                    <label class="text-xs font-bold uppercase text-slate-500">Message Type</label>
                                    <select name="type" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all">
                                        <option value="announcement">📢 Announcement</option>
                                        <option value="alert">⚠️ Important Alert</option>
                                        <option value="system">⚙️ System Update</option>
                                    </select>
                                </div>

                                <div class="md:col-span-2 space-y-2">
                                    <label class="text-xs font-bold uppercase text-slate-500">Title</label>
                                    <input type="text" name="title" required placeholder="Subject of the notification" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all">
                                </div>

                                <div class="md:col-span-2 space-y-2">
                                    <label class="text-xs font-bold uppercase text-slate-500">Message Content</label>
                                    <textarea name="message" required rows="4" placeholder="Enter your message here..." class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 dark:text-white transition-all"></textarea>
                                </div>
                            </div>

                            <button type="submit" name="send_notif" class="w-full bg-slate-900 dark:bg-white text-white dark:text-black font-bold py-4 rounded-xl shadow-lg transition-all active:scale-95 flex items-center justify-center gap-2">
                                <i data-lucide="send" size="18"></i> Broadcast Notification
                            </button>
                        </form>
                    </div>
                </div>

                <!-- History Section -->
                <div class="mt-8">
                    <h3 class="text-lg font-bold text-slate-900 dark:text-white mb-6">Recent Activity</h3>
                    <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl overflow-hidden shadow-sm">
                        <table class="w-full text-left">
                            <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                                <tr>
                                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500">Recipient</th>
                                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500">Type</th>
                                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500">Message</th>
                                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 text-right">Date</th>
                                    <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 text-right">Action</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                                <?php foreach ($history as $h): ?>
                                <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors">
                                    <td class="px-6 py-4">
                                        <span class="px-2 py-1 rounded-md text-[10px] font-black uppercase tracking-wider <?= $h['tenant_id'] ? 'bg-blue-100 text-blue-600' : 'bg-orange-100 text-orange-600' ?>">
                                            <?= $h['tenant_id'] ? htmlspecialchars($h['business_name']) : 'ALL USERS' ?>
                                        </span>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="flex items-center gap-2 text-xs font-bold capitalize">
                                            <?php 
                                                $icon = ($h['type'] == 'alert') ? 'alert-circle' : (($h['type'] == 'system') ? 'settings' : 'info');
                                                $color = ($h['type'] == 'alert') ? 'text-rose-500' : 'text-blue-500';
                                            ?>
                                            <i data-lucide="<?= $icon ?>" size="14" class="<?= $color ?>"></i>
                                            <?= $h['type'] ?>
                                        </div>
                                    </td>
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($h['title']) ?></div>
                                        <div class="text-xs text-slate-500 truncate max-w-xs"><?= htmlspecialchars($h['message']) ?></div>
                                    </td>
                                    <td class="px-6 py-4 text-right text-xs text-slate-400 font-mono">
                                        <?= date('M d, H:i', strtotime($h['created_at'])) ?>
                                    </td>
                                    <td class="px-6 py-4 text-right">
                                        <form method="POST" onsubmit="return confirm('Are you sure you want to delete this notification?');" class="inline">
                                            <input type="hidden" name="notif_id" value="<?= $h['id'] ?>">
                                            <button type="submit" name="delete_notif" class="p-2 text-slate-400 hover:text-rose-500 transition-colors">
                                                <i data-lucide="trash-2" size="16"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                                <?php if (empty($history)): ?>
                                    <tr><td colspan="5" class="px-6 py-10 text-center text-slate-400 italic text-sm">No notifications sent yet.</td></tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <script>
        function toggleTenantSelect() {
            const target = document.getElementById('target_audience').value;
            const container = document.getElementById('tenant_select_container');
            container.style.display = (target === 'specific') ? 'block' : 'none';
        }
        lucide.createIcons();
    </script>
</body>
</html>