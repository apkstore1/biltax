<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';
require_once '../config/db_connect.php';
require_once '../config/currency_helper.php';
require_once '../mailer/email_helper.php';

$msg = '';
$error = '';

// Fetch Global Admin Settings
$global_currency = 'USD';
$global_symbol = '$';
try {
    $stmt_admin = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
    $admin_settings = $stmt_admin->fetchAll(PDO::FETCH_KEY_PAIR);
    $global_currency = $admin_settings['global_currency'] ?? 'USD';
    $global_symbol = $admin_settings['global_currency_symbol'] ?? '$';
} catch (Exception $e) {}

$rates = getExchangeRates();
$global_rate = $rates[$global_currency] ?? 1.0;

// --- HELPERS ---
/**
 * Returns the relative date interval for PHP strtotime
 * @param string $cycle The cycle key from DB
 * @return string
 */
function getCycleInterval($cycle) {
    switch ($cycle) {
        case '15_days': return '+15 days';
        case '1_month': return '+1 month';
        case '3_months': return '+3 months';
        case '6_months': return '+6 months';
        case '1_year': return '+1 year';
        case '5_years': return '+5 years';
        default: return '+1 month';
    }
}

// --- Handle Approval Logic ---
// Self-healing: Fix foreign key constraint if it points to wrong table
try {
    // Ensure rejection_reason column exists
    $billing_cols = $pdo->query("SHOW COLUMNS FROM billing")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('rejection_reason', $billing_cols)) {
        $pdo->exec("ALTER TABLE billing ADD COLUMN rejection_reason TEXT AFTER status");
    }
    // Update status ENUM to include 'on_hold'
    $pdo->exec("ALTER TABLE billing MODIFY COLUMN status ENUM('pending', 'active', 'rejected', 'expired', 'on_hold') DEFAULT 'pending'");

    // Drop the old constraint mentioned in your error
    $pdo->exec("ALTER TABLE subscriptions DROP FOREIGN KEY IF EXISTS subscriptions_ibfk_2");
    // Add new constraint pointing to packages table
    $pdo->exec("ALTER TABLE subscriptions ADD CONSTRAINT subscriptions_ibfk_packages 
                FOREIGN KEY (plan_id) REFERENCES packages(id) ON DELETE CASCADE");
} catch (Exception $e) { /* Constraint might already be fixed or name differs */ }


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $billing_id = $_POST['billing_id'];

    try {
        if ($_POST['action'] === 'approve_payment') {
        $pdo->beginTransaction();

        // 1. Fetch record from billing table
        $stmt = $pdo->prepare("SELECT * FROM billing WHERE id = ? AND status IN ('pending', 'on_hold')");
        $stmt->execute([$billing_id]);
        $bill = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($bill) {
            $tid = $bill['tenant_id'];
            $pkg_id = $bill['package_id']; // The new package ID user wants
            $requested_cycle = $bill['billing_cycle'];
            $current_plan_id_on_request = $bill['current_plan_id']; // The plan ID active when user made request
            $current_expiry_date_on_request = $bill['current_expiry_date']; // The expiry date when user made request

            // Fetch current active subscription details for the tenant
            $stmt_current_sub = $pdo->prepare("SELECT plan_id, expiry_date FROM subscriptions WHERE tenant_id = ? AND status = 'active' ORDER BY expiry_date DESC LIMIT 1");
            $stmt_current_sub->execute([$tid]);
            $current_active_sub = $stmt_current_sub->fetch(PDO::FETCH_ASSOC);

            $start_date = date('Y-m-d'); // Default: Today (date of approval)
            $base_expiry_date = $start_date;

            // Determine if it's a renewal of the SAME plan and BEFORE expiry
            $is_same_plan_renewal = ($current_active_sub && isset($current_active_sub['plan_id']) && (int)$current_active_sub['plan_id'] === (int)$pkg_id); // Check if plan_id is set
            $is_before_expiry = ($current_active_sub && strtotime($current_active_sub['expiry_date']) >= strtotime(date('Y-m-d')));

            if ($is_same_plan_renewal && $is_before_expiry) {
                // Renewal of same plan before expiry: new start date is day after current expiry
                $start_date = date('Y-m-d', strtotime($current_active_sub['expiry_date'] . ' +1 day'));
                $base_expiry_date = $start_date; // Calculate new expiry from this start date
            }
            // If it's a different plan, or same plan but after expiry, start date is today (default)

            // Get interval for the requested billing cycle
            $interval_str = getCycleInterval($requested_cycle);
            $new_expiry_date = date('Y-m-d', strtotime($base_expiry_date . ' ' . $interval_str));

            // NEW: Fetch actual limits from the packages table for this package
            $stmt_pkg = $pdo->prepare("SELECT staff_limit, branch_limit FROM packages WHERE id = ?");
            $stmt_pkg->execute([$pkg_id]);
            $pkg_limits = $stmt_pkg->fetch(PDO::FETCH_ASSOC);

            $staff_limit = $pkg_limits['staff_limit'] ?? 5;
            $branch_limit = $pkg_limits['branch_limit'] ?? 1;

            // 2. Update billing table status to active
            $pdo->prepare("UPDATE billing SET status = 'active' WHERE id = ?")->execute([$billing_id]);

            // 3. Update tenants table and fetch info for email
            $stmt_t_info = $pdo->prepare("UPDATE tenants SET package_id = ?, staff_limit = ?, branch_limit = ? WHERE id = ? RETURNING owner_name, email");
            // Note: If RETURNING is not supported in your MySQL version, we use a separate SELECT
            $pdo->prepare("UPDATE tenants SET package_id = ?, staff_limit = ?, branch_limit = ? WHERE id = ?")->execute([$pkg_id, $staff_limit, $branch_limit, $tid]);
            $stmt_get_t = $pdo->prepare("SELECT owner_name, email FROM tenants WHERE id = ?");
            $stmt_get_t->execute([$tid]);
            $tenant_info = $stmt_get_t->fetch(PDO::FETCH_ASSOC);

            // 4. Update or Insert into subscriptions table
            $check_sub = $pdo->prepare("SELECT id FROM subscriptions WHERE tenant_id = ?");
            $check_sub->execute([$tid]);
            if ($check_sub->fetch()) {
                $pdo->prepare("UPDATE subscriptions SET plan_id = ?, start_date = ?, expiry_date = ?, status = 'active', billing_cycle = ? WHERE tenant_id = ?")
                    ->execute([$pkg_id, $start_date, $new_expiry_date, $requested_cycle, $tid]);
            } else {
                $pdo->prepare("INSERT INTO subscriptions (tenant_id, plan_id, start_date, expiry_date, status, billing_cycle) VALUES (?, ?, ?, ?, 'active', ?)")
                    ->execute([$tid, $pkg_id, $start_date, $new_expiry_date, $requested_cycle]);
            }

            $pdo->commit();

            // Send Activation Email
            if ($tenant_info) {
                sendBiltaxEmail($tenant_info['email'], 'Account Activated | Biltax', ['name' => $tenant_info['owner_name']], 'activation');
            }

            $msg = "Payment Approved! Tenant package has been updated and activated.";
        } else {
            throw new Exception("Billing record not found or already processed.");
        }
        } elseif ($_POST['action'] === 'hold_payment') {
            $pdo->prepare("UPDATE billing SET status = 'on_hold' WHERE id = ?")->execute([$billing_id]);
            $msg = "Payment request has been placed on hold.";
        } elseif ($_POST['action'] === 'reject_payment') {
            $reason = $_POST['rejection_reason'] ?: 'Invalid transaction details or incorrect amount.';
            $pdo->prepare("UPDATE billing SET status = 'rejected', rejection_reason = ? WHERE id = ?")->execute([$reason, $billing_id]);
            $msg = "Payment request rejected successfully.";
        }
    } catch (Exception $e) {
        if($pdo->inTransaction()) $pdo->rollBack();
        $error = $e->getMessage();
    }
}

// --- Fetch Pending Payments ---
$stmt = $pdo->query("SELECT b.*, t.business_name, t.unique_id, p.package_name 
                    FROM billing b 
                    JOIN tenants t ON b.tenant_id = t.id 
                    JOIN packages p ON b.package_id = p.id 
                    WHERE b.status IN ('pending', 'on_hold') 
                    ORDER BY b.created_at DESC");
$pending_payments = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Pending Payments | Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        <?php include 'topbar.php'; ?>
        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-6xl mx-auto">
                <header class="mb-10">
                    <h1 class="text-3xl font-black uppercase tracking-tight">Pending Payments</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Verify and Approve manual bank transfers</p>
                </header>

                <?php if($msg): ?><div class="p-4 bg-emerald-500/10 text-emerald-500 rounded-2xl mb-6 font-bold text-sm border border-emerald-500/20"><?= $msg ?></div><?php endif; ?>
                <?php if($error): ?><div class="p-4 bg-rose-500/10 text-rose-500 rounded-2xl mb-6 font-bold text-sm border border-rose-500/20"><?= $error ?></div><?php endif; ?>

                <div class="bg-white dark:bg-neutral-900 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl overflow-hidden">
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-200 dark:border-neutral-800">
                            <tr>
                                <th class="px-6 py-4">Tenant / Business</th>
                                <th class="px-6 py-4">Package</th>
                                <th class="px-6 py-4">Account Name</th>
                                <th class="px-6 py-4">Transaction ID (TID)</th>
                                <th class="px-6 py-4">Amount</th>
                                <th class="px-6 py-4 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                            <?php foreach($pending_payments as $pay): ?>
                            <tr class="text-sm">
                                <td class="px-6 py-4"><p class="font-black dark:text-white"><?= htmlspecialchars($pay['business_name']) ?></p><p class="text-[10px] text-slate-500"><?= $pay['unique_id'] ?></p></td>
                                <td class="px-6 py-4 font-bold text-orange-600"><?= htmlspecialchars($pay['package_name']) ?></td>
                                <td class="px-6 py-4 font-medium"><?= htmlspecialchars($pay['account_name']) ?></td>
                                <td class="px-6 py-4 font-mono font-black tracking-tighter"><?= htmlspecialchars($pay['transaction_id']) ?></td>
                                <td class="px-6 py-4 font-black"><?= $global_symbol ?><?= number_format($pay['amount'] * $global_rate, 2) ?></td>
                                <td class="px-6 py-4 text-right">
                                    <div class="flex justify-end gap-2">
                                        <form method="POST" onsubmit="return confirm('Verify and activate plan for <?= $pay['business_name'] ?>?')">
                                            <input type="hidden" name="action" value="approve_payment">
                                            <input type="hidden" name="billing_id" value="<?= $pay['id'] ?>">
                                            <button type="submit" class="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[9px] font-black uppercase shadow-lg shadow-emerald-600/20 active:scale-95 transition-all" title="Approve">Approve</button>
                                        </form>
                                        <?php if ($pay['status'] !== 'on_hold'): ?>
                                        <form method="POST">
                                            <input type="hidden" name="action" value="hold_payment">
                                            <input type="hidden" name="billing_id" value="<?= $pay['id'] ?>">
                                            <button type="submit" class="px-4 py-2 bg-amber-500 text-white rounded-xl text-[9px] font-black uppercase shadow-lg shadow-amber-600/20 active:scale-95 transition-all" title="Put on Hold">Hold</button>
                                        </form>
                                        <?php else: ?>
                                            <span class="px-4 py-2 bg-amber-100 text-amber-600 rounded-xl text-[9px] font-black uppercase border border-amber-200">On Hold</span>
                                        <?php endif; ?>
                                        <button onclick="openRejectModal(<?= $pay['id'] ?>, '<?= htmlspecialchars($pay['business_name']) ?>')" class="px-4 py-2 bg-rose-600 text-white rounded-xl text-[9px] font-black uppercase shadow-lg shadow-rose-600/20 active:scale-95 transition-all" title="Reject">Reject</button>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; if(empty($pending_payments)): ?>
                            <tr><td colspan="6" class="p-20 text-center text-slate-400 font-bold uppercase tracking-widest text-xs italic">No pending payments found.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Reject Modal -->
    <div id="rejectModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[100] p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('rejectModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Reject Payment</h2>
            <p id="reject_biz_name" class="text-xs text-rose-500 font-bold uppercase tracking-widest mb-6"></p>
            
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="reject_payment">
                <input type="hidden" name="billing_id" id="reject_billing_id">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Rejection Reason</label>
                    <textarea name="rejection_reason" required placeholder="e.g. Transaction ID not found in bank statement..." class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-rose-500 transition-all text-sm h-32"></textarea>
                </div>
                <button type="submit" class="w-full py-4 bg-rose-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-rose-600/20 active:scale-95 transition-all mt-4">Confirm Rejection</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function openRejectModal(id, bizName) {
            document.getElementById('reject_billing_id').value = id;
            document.getElementById('reject_biz_name').innerText = bizName;
            document.getElementById('rejectModal').classList.replace('hidden', 'flex');
        }
    </script>
</body>
</html>