<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard: Usually part of team/system management
if (!has_admin_permission('manage_team')) {
    die("Access Denied: You do not have permission to modify page access rules.");
}

require_once 'config.php'; // Assumes this connects to biltax_main

// --- Self-Healing: Ensure Tables Exist ---
try {
    // Ensure Page Access Controls table exists
    $pdo->exec("CREATE TABLE IF NOT EXISTS page_access_controls (
        id INT PRIMARY KEY AUTO_INCREMENT,
        page_slug VARCHAR(100) NOT NULL UNIQUE,
        page_title VARCHAR(255) NOT NULL,
        restriction_type ENUM('none', 'verification_required', 'request_based', 'upgrade_required') DEFAULT 'none',
        required_verification_task_id INT DEFAULT NULL,
        required_package_id INT DEFAULT NULL,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // --- Seed Data if Empty ---
    $pageCount = $pdo->query("SELECT COUNT(*) FROM page_access_controls")->fetchColumn();
    if ($pageCount == 0) {
        $pdo->exec("INSERT IGNORE INTO page_access_controls (page_slug, page_title, restriction_type, required_package_id) VALUES 
            ('dashboard', 'Main Dashboard', 'none', 1),
            ('inventory_list', 'Inventory Management', 'none', 1),
            ('pos_retail', 'Retail POS Terminal', 'none', 1), 
            ('pos_food', 'Food POS Terminal', 'none', 1),
            ('connect_partner', 'Partner Network (B2B)', 'verification_required', 1),
            ('b2b_orders', 'B2B Trade Orders', 'verification_required', 1),
            ('marketplace_hub', 'Biltax Hub Listing', 'verification_required', 2),
            ('staff_management', 'Staff & Permissions', 'upgrade_required', 2),
            ('advanced_reports', 'Financial Analytics', 'upgrade_required', 3),
            ('party_ledgers', 'Party Ledgers (Udhaar)', 'none', 1),
            ('suppliers', 'Supplier Management', 'none', 1),
            ('verification_center', 'Compliance Center', 'none', 1), 
            ('manage_branches', 'Store & Branches', 'none', 1), -- New page for branch management
            ('stock_transfer', 'Stock Transfer', 'none', 1),
            ('api_access', 'Developer API Keys', 'request_based', 3),
            ('bulk_import', 'Bulk Data Import', 'upgrade_required', 2)");
    }

    // Ensure basic packages exist for the dropdown
    $pkgCount = $pdo->query("SELECT COUNT(*) FROM packages")->fetchColumn();
    if ($pkgCount == 0) {
        $pdo->exec("INSERT INTO packages (package_name, staff_limit, monthly_price) VALUES 
            ('Starter', 5, 0.00),
            ('Business', 15, 49.00),
            ('Enterprise', 999, 149.00)");
    }

    // Ensure template verification tasks exist (tenant_id IS NULL)
    $taskCheck = $pdo->query("SELECT COUNT(*) FROM verification_tasks WHERE tenant_id IS NULL")->fetchColumn();
    if ($taskCheck == 0) {
        $pdo->exec("INSERT INTO verification_tasks (tenant_id, task_title, task_description, required_docs, priority, status) VALUES 
            (NULL, 'Business Identity', 'Verify your legal business name and ownership.', 'Owner ID, Business License', 'high', 'not_started'),
            (NULL, 'Tax Compliance', 'Verify your tax registration (NTN/VAT).', 'Tax Certificate', 'medium', 'not_started'),
            (NULL, 'B2B Trust Verification', 'Special verification for wholesale trade access.', 'Trade Reference, Bank Statement', 'medium', 'not_started')");
    }

    // Ensure Packages table exists (for dropdown)
    $pdo->exec("CREATE TABLE IF NOT EXISTS packages (
        id INT PRIMARY KEY AUTO_INCREMENT,
        package_name VARCHAR(50) NOT NULL,
        staff_limit INT NOT NULL,
        monthly_price DECIMAL(10, 2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Update Verification Tasks to allow NULL tenant_id for templates
    // Using try-catch for ALTER since it might already be correct
    try {
        $pdo->exec("ALTER TABLE verification_tasks MODIFY COLUMN tenant_id INT NULL");
    } catch (Exception $e) { /* Already modified or table doesn't exist yet */ }

} catch (Exception $e) {
    die("Database Setup Error: " . $e->getMessage());
}


// --- AJAX Update Handler ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_page') {
    header('Content-Type: application/json');
    try {
        $slug = trim($_POST['page_slug']);
        $title = trim($_POST['page_title']);
        
        $stmt = $pdo->prepare("INSERT INTO page_access_controls (page_slug, page_title, status) VALUES (?, ?, 'active')");
        $stmt->execute([$slug, $title]);

        echo json_encode(['success' => true, 'message' => 'New page added successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Slug might already exist or: ' . $e->getMessage()]);
    }
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_permission') {
    header('Content-Type: application/json');
    try {
        $id = $_POST['id'];
        $restriction = $_POST['restriction_type'];
        $task_id = !empty($_POST['verification_task']) ? $_POST['verification_task'] : null;
        $package_id = !empty($_POST['package_id']) ? $_POST['package_id'] : null;
        $status = $_POST['status'];

        $stmt = $pdo->prepare("UPDATE page_access_controls 
                               SET restriction_type = ?, required_verification_task_id = ?, required_package_id = ?, status = ? 
                               WHERE id = ?");
        $stmt->execute([$restriction, $task_id, $package_id, $status, $id]);

        echo json_encode(['success' => true, 'message' => 'Rules updated successfully!']);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// --- Fetch Data ---
$pages = $pdo->query("SELECT * FROM page_access_controls ORDER BY page_title ASC")->fetchAll(PDO::FETCH_ASSOC);
$packages = $pdo->query("SELECT id, package_name FROM packages ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
// Fetch template tasks (tenant_id IS NULL) for linking requirements
$task_templates = $pdo->query("SELECT id, task_title FROM verification_tasks WHERE tenant_id IS NULL ORDER BY task_title ASC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Page Access Controls | Biltax Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap');
        body { font-family: 'Inter', sans-serif; }
        .custom-toggle:checked + .toggle-bg { background-color: #ea580c; } /* orange-600 */
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    
    <div class="flex-1 ml-64">
        <?php include 'topbar.php'; ?>
        
        <main class="p-8">
            <header class="mb-10 flex justify-between items-end">
                <div>
                    <h1 class="text-3xl font-black uppercase tracking-tight">Access Gatekeeper</h1>
                    <p class="text-sm text-slate-500 font-bold uppercase tracking-widest text-orange-600">Monetization & Compliance Rules</p>
                </div>
                <div class="flex gap-3">
                    <button onclick="document.getElementById('addPageModal').classList.replace('hidden', 'flex')" class="px-6 py-3 bg-orange-600 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-orange-600/20 hover:bg-orange-700 transition-all">
                        <i data-lucide="plus" size="14" class="inline mr-1"></i> Add New Page
                    </button>
                    <div class="text-right">
                        <span class="px-4 py-2 bg-slate-100 dark:bg-neutral-800 text-slate-500 rounded-full text-[10px] font-black uppercase border border-slate-200 dark:border-neutral-700">
                            System-Wide Controls
                        </span>
                    </div>
                </div>
            </header>

            <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[40px] overflow-hidden shadow-2xl">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                            <th class="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Page / Module</th>
                            <th class="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Restriction Level</th>
                            <th class="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Requirement Link</th>
                            <th class="px-8 py-6 text-[10px] font-black uppercase tracking-widest text-slate-400">Status</th>
                            <th class="px-8 py-6 text-right text-[10px] font-black uppercase tracking-widest text-slate-400">Action</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                        <?php foreach($pages as $p): ?>
                        <tr class="group hover:bg-slate-50/50 dark:hover:bg-white/5 transition-all" id="row-<?= $p['id'] ?>">
                            <td class="px-8 py-6">
                                <div class="flex flex-col">
                                    <span class="font-black text-sm uppercase"><?= htmlspecialchars($p['page_title']) ?></span>
                                    <span class="text-[10px] font-mono text-slate-400">slug: <?= $p['page_slug'] ?></span>
                                </div>
                            </td>
                            <td class="px-8 py-6">
                                <select class="res-type w-full bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 px-3 py-2 rounded-xl text-xs font-bold outline-none focus:border-orange-600 transition-all">
                                    <option value="none" <?= $p['restriction_type'] == 'none' ? 'selected' : '' ?>>🟢 Open (None)</option>
                                    <option value="verification_required" <?= $p['restriction_type'] == 'verification_required' ? 'selected' : '' ?>>🛡️ Verify Needed</option>
                                    <option value="request_based" <?= $p['restriction_type'] == 'request_based' ? 'selected' : '' ?>>📩 Request Needed</option>
                                    <option value="upgrade_required" <?= $p['restriction_type'] == 'upgrade_required' ? 'selected' : '' ?>>💎 Upgrade Needed</option>
                                </select>
                            </td>
                            <td class="px-8 py-6">
                                <div class="flex flex-col gap-2">
                                    <!-- Package Select -->
                                    <div class="flex items-center gap-2">
                                        <span class="text-[9px] font-black text-slate-400 uppercase w-16">Package:</span>
                                        <select class="pkg-id flex-1 bg-transparent border-b border-slate-200 dark:border-neutral-800 text-[11px] font-bold outline-none focus:border-orange-600 transition-all">
                                            <option value="">Any Plan</option>
                                            <?php foreach($packages as $pkg): ?>
                                                <option value="<?= $pkg['id'] ?>" <?= $p['required_package_id'] == $pkg['id'] ? 'selected' : '' ?>><?= $pkg['package_name'] ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <!-- Verification Link (Mocking linking by task title for now) -->
                                    <div class="flex items-center gap-2">
                                        <span class="text-[9px] font-black text-slate-400 uppercase w-16">Task:</span>
                                        <select class="task-id flex-1 bg-transparent border-b border-slate-200 dark:border-neutral-800 text-[11px] font-bold outline-none focus:border-orange-600 transition-all">
                                            <option value="">No Task Linked</option>
                                            <?php foreach($task_templates as $tt): // Corrected to use actual task ID and title ?>
                                                <option value="<?= $tt['id'] ?>" <?= $p['required_verification_task_id'] == $tt['id'] ? 'selected' : '' ?>><?= htmlspecialchars($tt['task_title']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                </div>
                            </td>
                            <td class="px-8 py-6">
                                <label class="relative inline-flex items-center cursor-pointer">
                                    <input type="checkbox" value="" class="sr-only peer status-toggle" <?= $p['status'] == 'active' ? 'checked' : '' ?>>
                                    <div class="w-11 h-6 bg-slate-200 dark:bg-neutral-800 rounded-full peer peer-focus:ring-2 peer-focus:ring-orange-600 peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-orange-600"></div>
                                </label>
                            </td>
                            <td class="px-8 py-6 text-right">
                                <button onclick="saveRules(<?= $p['id'] ?>)" class="save-btn px-6 py-2 bg-slate-900 dark:bg-white text-white dark:text-black rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-orange-600 hover:text-white transition-all shadow-lg active:scale-95">
                                    Save Rules
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

            <!-- Add Page Modal -->
            <div id="addPageModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-[110] p-4">
                <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
                    <button onclick="document.getElementById('addPageModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500"><i data-lucide="x" size="20"></i></button>
                    
                    <h3 class="text-xl font-black mb-1 uppercase tracking-tight">Register New Page</h3>
                    <p class="text-xs text-slate-500 mb-6 font-bold uppercase tracking-widest">Add a page to start controlling its access.</p>
                    
                    <form id="addPageForm" class="space-y-4">
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Page Title</label>
                            <input type="text" name="page_title" required placeholder="e.g. Premium Analytics" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold">
                        </div>
                        <div>
                            <label class="block text-[10px] font-black uppercase text-slate-400 mb-2">Page Slug (File Name without .php)</label>
                            <input type="text" name="page_slug" required placeholder="e.g. premium_stats" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-mono">
                        </div>
                        
                        <div class="pt-4">
                            <button type="submit" class="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase text-xs tracking-widest shadow-xl shadow-slate-900/20 active:scale-95 transition-all">
                                Register Page Rule
                            </button>
                        </div>
                    </form>
                </div>
            </div>

            <!-- Feedback Toast -->
            <div id="toast" class="fixed bottom-10 right-10 transform translate-y-20 opacity-0 transition-all duration-300 flex items-center gap-3 bg-slate-900 dark:bg-white text-white dark:text-black px-6 py-4 rounded-2xl shadow-2xl z-[100]">
                <i data-lucide="check-circle" size="18" class="text-orange-500"></i>
                <span class="text-xs font-black uppercase tracking-widest" id="toast-msg">Settings Saved</span>
            </div>
        </main>
    </div>

    <script>
        lucide.createIcons();

        document.getElementById('addPageForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const formData = new FormData(e.target);
            formData.append('action', 'add_page');

            try {
                const response = await fetch('manage_page_permissions.php', {
                    method: 'POST',
                    body: formData
                });
                const result = await response.json();
                if (result.success) {
                    showToast(result.message);
                    setTimeout(() => location.reload(), 1000);
                } else {
                    alert(result.message);
                }
            } catch (err) {
                console.error(err);
                alert('An error occurred');
            }
        });

        async function saveRules(id) {
            const row = document.getElementById(`row-${id}`);
            const btn = row.querySelector('.save-btn');
            
            const data = {
                action: 'update_permission',
                id: id,
                restriction_type: row.querySelector('.res-type').value,
                package_id: row.querySelector('.pkg-id').value,
                verification_task: row.querySelector('.task-id').value,
                status: row.querySelector('.status-toggle').checked ? 'active' : 'inactive'
            };

            // UI Loading state
            const originalText = btn.innerHTML;
            btn.disabled = true;
            btn.innerHTML = `<div class="animate-spin h-3 w-3 border-2 border-current border-t-transparent rounded-full mx-auto"></div>`;

            try {
                const formData = new FormData();
                for (const key in data) formData.append(key, data[key]);

                const response = await fetch('manage_page_permissions.php', {
                    method: 'POST',
                    body: formData
                });

                const result = await response.json();
                if (result.success) {
                    showToast(result.message);
                    btn.classList.add('bg-emerald-600', 'text-white');
                    setTimeout(() => {
                        btn.classList.remove('bg-emerald-600', 'text-white');
                    }, 2000);
                } else {
                    alert('Error: ' + result.message);
                }
            } catch (error) {
                console.error(error);
            } finally {
                btn.disabled = false;
                btn.innerHTML = originalText;
            }
        }

        function showToast(msg) {
            const toast = document.getElementById('toast');
            const msgSpan = document.getElementById('toast-msg');
            msgSpan.innerText = msg;
            
            toast.classList.remove('translate-y-20', 'opacity-0');
            setTimeout(() => {
                toast.classList.add('translate-y-20', 'opacity-0');
            }, 3000);
        }

        // Auto-highlight based on restriction type
        document.querySelectorAll('.res-type').forEach(select => {
            select.addEventListener('change', (e) => {
                const row = e.target.closest('tr');
                const val = e.target.value;
                if (val === 'none') {
                    row.classList.remove('border-l-4', 'border-orange-600');
                } else {
                    row.classList.add('border-l-4', 'border-orange-600');
                }
            });
            // Trigger once for initial load
            if (select.value !== 'none') select.closest('tr').classList.add('border-l-4', 'border-orange-600');
        });
    </script>
</body>
</html>