<?php
require_once '../config.php';

try {
    // Ensure Central Config is used
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_MAIN, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Ensure column exists first
    $pdo->exec("ALTER TABLE tenants ADD COLUMN IF NOT EXISTS unique_id VARCHAR(20) UNIQUE AFTER id");

    // Fetch tenants without an ID
    $tenants = $pdo->query("SELECT id FROM tenants WHERE unique_id IS NULL OR unique_id = ''")->fetchAll(PDO::FETCH_ASSOC);

    echo "Found " . count($tenants) . " tenants to update.<br><br>";

    $update_stmt = $pdo->prepare("UPDATE tenants SET unique_id = ? WHERE id = ?");

    foreach ($tenants as $t) {
        $unique_id = '';
        while (true) {
            $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $res = '';
            for ($i = 0; $i < 6; $i++) { $res .= $chars[mt_rand(0, strlen($chars) - 1)]; }
            $temp_id = 'BTX-' . $res;
            
            $check = $pdo->prepare("SELECT COUNT(*) FROM tenants WHERE unique_id = ?");
            $check->execute([$temp_id]);
            if ($check->fetchColumn() == 0) { $unique_id = $temp_id; break; }
        }
        
        $update_stmt->execute([$unique_id, $t['id']]);
        echo "Updated Tenant #{$t['id']} -> <b>$unique_id</b><br>";
    }

    echo "<br><b>All existing tenants fixed successfully!</b>";
} catch (Exception $e) {
    die("Error: " . $e->getMessage());
}