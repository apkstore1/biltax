<?php
session_start();
require_once 'config.php';

// Redirect if already logged in
if (isset($_SESSION['super_admin_logged_in'])) {
    header("Location: dashboard.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = $_POST['password'];

    if (!empty($email) && !empty($password)) {
        $stmt = $pdo->prepare("SELECT * FROM admin_users WHERE email = ?");
        $stmt->execute([$email]);
        $admin = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['super_admin_logged_in'] = true;
            $_SESSION['super_admin_id'] = $admin['id'];
            $_SESSION['super_admin_name'] = $admin['name'];
            $_SESSION['super_admin_email'] = $admin['email'];
            $_SESSION['super_admin_role'] = $admin['role'];
            $_SESSION['super_admin_permissions'] = json_decode($admin['permissions'], true);
            header("Location: dashboard.php");
            exit;
        } else {
            $error = "Invalid email or password.";
        }
    } else {
        $error = "Please fill all fields.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Super Admin Login | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="../theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex items-center justify-center p-6">
    <div class="w-full max-w-md">
        <div class="text-center mb-10">
            <div class="w-20 h-20 bg-orange-600 rounded-[28px] flex items-center justify-center text-white shadow-2xl shadow-orange-900/30 mx-auto mb-6">
                <img src="../assets/Biltax-icon.png" class="w-12 h-12 brightness-0 invert" alt="Biltax">
            </div>
            <h1 class="text-3xl font-black uppercase tracking-tight">Access Control</h1>
            <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-2">Biltax Super Admin Gateway</p>
        </div>

        <div class="bg-white dark:bg-neutral-900 p-10 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-2xl">
            <?php if($error): ?>
                <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-500 rounded-2xl text-xs font-black uppercase text-center"><?= $error ?></div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest ml-1">Email</label>
                    <div class="relative">
                        <i data-lucide="mail" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                        <input type="email" name="email" required placeholder="admin@biltax.com" class="w-full pl-12 pr-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 tracking-widest ml-1">Password</label>
                    <div class="relative">
                        <i data-lucide="lock" class="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size="18"></i>
                        <input type="password" name="password" required placeholder="••••••••" class="w-full pl-12 pr-5 py-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 dark:text-white font-bold transition-all">
                    </div>
                </div>

                <button type="submit" class="w-full py-5 bg-orange-600 text-white rounded-3xl font-black uppercase tracking-widest shadow-xl shadow-orange-900/20 hover:scale-[1.01] active:scale-95 transition-all flex items-center justify-center gap-3">
                    Authorize Session <i data-lucide="arrow-right" size="18"></i>
                </button>
            </form>
        </div>

        <div class="mt-8 text-center">
            <p class="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Master Infrastructure Isolated &bull; v2.0</p>
            <button onclick="toggleTheme()" class="mt-4 text-xs font-black uppercase text-orange-500 hover:underline">Switch Visual Mode</button>
        </div>
    </div>
    <script>
        lucide.createIcons();
        // Apply theme from localStorage immediately
        if (localStorage.getItem('theme') === 'dark' || (!localStorage.getItem('theme') && window.matchMedia('(prefers-color-scheme: dark)').matches)) document.documentElement.classList.add('dark');
    </script>
</body>
</html>