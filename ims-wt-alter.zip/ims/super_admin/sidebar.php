<?php
require_once 'config.php';

// Fetch various counts for badges
$pending_verify_count = 0;
$unread_tkt_count = 0;
$pending_feature_count = 0;
$pending_payment_count = 0;

try {
    $pending_verify_count = $pdo->query("SELECT COUNT(*) FROM verification_tasks WHERE status = 'pending_review'")->fetchColumn();
    $unread_tkt_count = $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'open' OR last_reply_by = 'tenant'")->fetchColumn();
    $pending_feature_count = $pdo->query("SELECT COUNT(*) FROM feature_requests WHERE status = 'pending'")->fetchColumn();
    $pending_payment_count = $pdo->query("SELECT COUNT(*) FROM billing WHERE status = 'pending'")->fetchColumn();
} catch (Exception $e) {}
?>

<aside class="w-64 bg-white dark:bg-neutral-900 border-r border-slate-200 dark:border-neutral-800 p-6 flex flex-col gap-6 fixed h-full z-20 transition-colors duration-300 overflow-hidden">
    <div class="flex items-center gap-3 px-2">
        <div class="w-8 h-8 bg-orange-600 rounded-lg flex items-center justify-center text-white shadow-lg shadow-orange-900/20 overflow-hidden p-1">
            <img src="../assets/Biltax-icon.png" class="w-full h-full object-contain brightness-0 invert" alt="Biltax Logo">
        </div>
        <span class="text-lg font-bold tracking-tight text-slate-900 dark:text-white">Biltax Admin</span>
    </div>
    
    <nav class="space-y-1 flex-1 overflow-y-auto pr-2 custom-scrollbar">
        <?php
        $nav_items = [
            ['name' => 'Dashboard', 'icon' => 'layout-dashboard', 'link' => 'dashboard.php', 'permission' => 'dashboard'],
            [
                'name' => 'Clients & Tenants', 
                'icon' => 'users', 
                'link' => '#',
                'permission' => 'manage_tenants',
                'sub_items' => [
                    ['name' => 'Manage Tenants', 'icon' => 'user-plus', 'link' => 'manage_tenants.php'],
                    ['name' => 'Tenant Views', 'icon' => 'monitor', 'link' => 'tenant_views_manager.php'],
                    ['name' => 'Staff Roles', 'icon' => 'shield-check', 'link' => 'staff_roles_manager.php'],
                ]
            ],
            ['name' => 'Support Tickets', 'icon' => 'life-buoy', 'link' => 'support_tickets_manager.php', 'badge' => $unread_tkt_count, 'permission' => 'support_tickets'],
            [
                'name' => 'System Requests', 
                'icon' => 'git-pull-request', 
                'link' => '#',
                'permission' => 'system_requests',
                'badge' => ($pending_verify_count + $pending_feature_count),
                'sub_items' => [
                    ['name' => 'Verification Requests', 'icon' => 'shield-check', 'link' => 'verification_requests.php', 'badge' => $pending_verify_count],
                    ['name' => 'Feature Requests', 'icon' => 'zap', 'link' => 'feature_requests.php', 'badge' => $pending_feature_count],
                ]
            ],
            ['name' => 'Page Permissions', 'icon' => 'key', 'link' => 'manage_page_permissions.php', 'permission' => 'manage_team'],
            [
                'name' => 'Biltax Shop', 
                'icon' => 'shopping-cart', 
                'link' => '#',
                'permission' => 'biltax_shop',
                'sub_items' => [
                    ['name' => 'Inventory', 'icon' => 'package', 'link' => 'shop_products.php'],
                    ['name' => 'Orders', 'icon' => 'shopping-bag', 'link' => 'shop_orders.php'],
                ]
            ],
            ['name' => 'Team Management', 'icon' => 'shield', 'link' => 'manage_team.php', 'permission' => 'manage_team'],
            ['name' => 'Printer Engine', 'icon' => 'printer', 'link' => 'manage_printer_configs.php', 'permission' => 'settings'],
            ['name' => 'Notifications', 'icon' => 'bell', 'link' => 'notifications.php', 'permission' => 'dashboard'],
            [
                'name' => 'Billing', 
                'icon' => 'credit-card', 
                'link' => '#',
                'permission' => 'billing',
                'sub_items' => [
                    ['name' => 'Pending Payments', 'icon' => 'clock', 'link' => 'pending_payments.php', 'badge' => $pending_payment_count],
                    ['name' => 'Billing Overview', 'icon' => 'layout-list', 'link' => 'billing.php'],
                    ['name' => 'Billing Reports', 'icon' => 'file-text', 'link' => 'billing_reports.php'],
                    ['name' => 'Billing Control', 'icon' => 'settings-2', 'link' => 'admin_billing_control.php'],
                    ['name' => 'Payment Options', 'icon' => 'credit-card', 'link' => 'payment_options.php'],
                ]
            ],
            [
                'name' => 'Mailer', 
                'icon' => 'mail', 
                'link' => '#',
                'permission' => 'mailer',
                'sub_items' => [
                    ['name' => 'Mail Sender', 'icon' => 'send', 'link' => 'mailer_compose.php'],
                    ['name' => 'Email Templates', 'icon' => 'file-code', 'link' => 'mailer_templates.php'],
                ]
            ],
            ['name' => 'Customize Site', 'icon' => 'palette', 'link' => '../website_admin/index.php', 'permission' => 'settings'],
            ['name' => 'Settings', 'icon' => 'settings', 'link' => 'settings.php', 'permission' => 'settings'],
        ];
        $current_page = basename($_SERVER['PHP_SELF']);
        
        foreach ($nav_items as $item) {
            // RBAC Check
            if (isset($item['permission']) && !has_admin_permission($item['permission'])) {
                continue; // Skip this menu item
            }

            $has_sub = isset($item['sub_items']);
            $is_parent_active = false;
            $menu_id = '';
            $arrow_id = '';

            if ($has_sub) {
                // Generate unique IDs for sub-menu and arrow
                $menu_id = strtolower(str_replace(' ', '-', $item['name'])) . '-submenu';
                $arrow_id = strtolower(str_replace(' ', '-', $item['name'])) . '-arrow';

                foreach ($item['sub_items'] as $sub) {
                    if ($current_page === basename($sub['link'])) {
                        $is_parent_active = true;
                        break;
                    }
                }
            } else {
                $is_parent_active = ($current_page === basename($item['link'])) || ($item['link'] !== '#' && strpos($_SERVER['REQUEST_URI'], $item['link']) !== false);
            }

            // Logic for sub-menu notification dot
            $has_sub_badge = false;
            if ($has_sub) {
                foreach ($item['sub_items'] as $sub) {
                    if (isset($sub['badge']) && $sub['badge'] > 0) {
                        $has_sub_badge = true;
                        break;
                    }
                }
            }

            $parent_class = $is_parent_active 
                ? 'bg-orange-50 dark:bg-orange-500/10 text-orange-600 dark:text-orange-500 border-orange-200 dark:border-orange-500/20'
                : 'text-slate-500 dark:text-neutral-400 hover:bg-slate-50 dark:hover:bg-neutral-800 hover:text-slate-900 dark:hover:text-white border-transparent';
            
            $parent_badge_val = (isset($item['badge'])) ? (int)$item['badge'] : 0;
            $badge_html = ($parent_badge_val > 0) ? "<span class='ml-auto bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full animate-pulse'>{$parent_badge_val}</span>" : "";
            
            // Red dot for parent if sub-menu has notifications but parent has no numeric badge
            $dot_html = ($has_sub_badge && $parent_badge_val <= 0) 
                ? "<span class='absolute top-3 left-7 w-2 h-2 bg-rose-500 rounded-full border-2 border-white dark:border-neutral-900 animate-pulse'></span>" 
                : "";

            echo "<div class='space-y-1'>";
            echo "<a href=\"{$item['link']}\"";
            if ($has_sub) {
                echo " onclick=\"toggleDropdown('{$menu_id}', '{$arrow_id}', event)\"";
            }
            echo " class=\"relative flex items-center justify-between gap-3 px-4 py-3 rounded-xl border {$parent_class} font-medium transition-all duration-200 group\">
                    {$dot_html}
                    <div class='flex items-center gap-3'>
                        <i data-lucide=\"{$item['icon']}\" size=\"18\" class=\"transition-transform group-hover:scale-110\"></i>
                        <span>{$item['name']}</span>
                    </div>
                    {$badge_html}";
            if ($has_sub) {
                $icon_rotate = $is_parent_active ? 'rotate-180' : '';
                echo "<i data-lucide='chevron-down' id='{$arrow_id}' size='14' class='transition-transform {$icon_rotate}'></i>";
            }
            echo "</a>";

            if ($has_sub) {
                $submenu_hidden_class = $is_parent_active ? '' : 'hidden';
                echo "<div id='{$menu_id}' class='ml-6 border-l-2 border-slate-100 dark:border-neutral-800 pl-4 mt-2 space-y-2 {$submenu_hidden_class}'>";
                foreach ($item['sub_items'] as $sub) {
                    $sub_active = ($current_page === basename($sub['link']));
                    $sub_text = $sub_active ? 'text-orange-600 dark:text-orange-500 font-black' : 'text-slate-500 dark:text-neutral-400 hover:text-slate-900 dark:hover:text-white font-bold';
                    $sub_badge = (isset($sub['badge']) && $sub['badge'] > 0) ? "<span class='ml-auto bg-rose-500 text-white text-[9px] font-black px-1.5 py-0.5 rounded-full'>{$sub['badge']}</span>" : "";
                    
                    echo "<a href='{$sub['link']}' class='flex items-center justify-between gap-2 py-1.5 text-[13px] transition-colors {$sub_text}'>
                            <div class='flex items-center gap-2'>
                            <i data-lucide='{$sub['icon']}' size='14'></i>
                            <span>{$sub['name']}</span>
                            </div>
                            {$sub_badge}
                          </a>";
                }
                echo "</div>";
            }
            echo "</div>";
        }
        ?>
    </nav>

    <div class="pt-6 border-t border-slate-100 dark:border-neutral-800">
        <a href="logout.php" class="flex items-center gap-3 px-4 py-3 rounded-xl text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/10 transition-colors font-medium">
            <i data-lucide="log-out" size="18"></i>
            <span>Logout</span>
        </a>
    </div>
    <script>
        lucide.createIcons();

        // Auto-scroll sidebar to active menu item (Priority to Sub-menu)
        // 'center' block use karne se menu thora sa neche (darmiyan mein) hold hoga
        const activeMenu = document.querySelector('aside a.text-orange-600.font-black') || document.querySelector('aside a.bg-orange-50');
        if (activeMenu) {
            activeMenu.scrollIntoView({ block: 'center', behavior: 'instant' });
        }

        function toggleDropdown(menuId, arrowId, event) {
            event.preventDefault(); // Prevent default link behavior
            const menu = document.getElementById(menuId);
            const arrow = document.getElementById(arrowId);
            if (menu && arrow) {
                menu.classList.toggle('hidden');
                arrow.classList.toggle('rotate-180');
            }
        }
    </script>
    <style>
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: transparent; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e2e8f0; border-radius: 10px; }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb { background: #262626; }
    </style>
</aside>