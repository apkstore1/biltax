<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard
if (!has_admin_permission('settings')) {
    die("Access Denied: You do not have permission to manage printer configurations.");
}

// Database Connection to biltax_main
require_once '../config/db_connect.php';
try {
    $main_pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Section 1: Self-healing Tables
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS printer_types (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        has_fixed_size TINYINT(1) DEFAULT 0
    )");

    $main_pdo->exec("CREATE TABLE IF NOT EXISTS printer_sizes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        type_id INT NOT NULL,
        name VARCHAR(100) NOT NULL,
        width_mm DECIMAL(10,2),
        height_mm DECIMAL(10,2),
        labels_per_row INT DEFAULT 1,
        FOREIGN KEY (type_id) REFERENCES printer_types(id) ON DELETE CASCADE
    )");
} catch (Exception $e) { die("System Error: " . $e->getMessage()); }

// Handle Post Actions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        if ($_POST['action'] === 'add_type') {
            $has_fixed = isset($_POST['has_fixed_size']) ? 1 : 0;
            $stmt = $main_pdo->prepare("INSERT INTO printer_types (name, has_fixed_size) VALUES (?, ?)");
            $stmt->execute([$_POST['name'], $has_fixed]);
            
            if ($has_fixed) {
                $type_id = $main_pdo->lastInsertId();
                $stmt_size = $main_pdo->prepare("INSERT INTO printer_sizes (type_id, name, width_mm, height_mm, labels_per_row) VALUES (?, ?, ?, ?, ?)");
                $stmt_size->execute([$type_id, $_POST['name'], $_POST['width'], $_POST['height'], $_POST['labels_per_row']]);
            }
        } elseif ($_POST['action'] === 'add_size') {
            $stmt = $main_pdo->prepare("INSERT INTO printer_sizes (type_id, name, width_mm, height_mm, labels_per_row) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$_POST['type_id'], $_POST['name'], $_POST['width'], $_POST['height'], $_POST['labels_per_row']]);
        } elseif ($_POST['action'] === 'delete_type') {
            $stmt = $main_pdo->prepare("DELETE FROM printer_types WHERE id = ?");
            $stmt->execute([$_POST['id']]);
        } elseif ($_POST['action'] === 'delete_size') {
            $stmt = $main_pdo->prepare("DELETE FROM printer_sizes WHERE id = ?");
            $stmt->execute([$_POST['id']]);
        }
        header("Location: manage_printer_configs.php"); exit;
    }
}

$types = $main_pdo->query("SELECT * FROM printer_types")->fetchAll(PDO::FETCH_ASSOC);
$sizes = $main_pdo->query("SELECT s.*, t.name as type_name FROM printer_sizes s JOIN printer_types t ON s.type_id = t.id")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Printer Configs | Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <?php include 'sidebar.php'; ?>

    <div class="flex-1 ml-64 flex flex-col min-h-screen p-8">
        <div class="max-w-6xl mx-auto w-full">
            <header class="mb-10 flex justify-between items-center">
                <div>
                    <h1 class="text-3xl font-black text-slate-900 dark:text-white uppercase">Printer Engine Management</h1>
                    <p class="text-slate-500 font-bold uppercase text-xs tracking-widest">Global configurations for all tenants</p>
                </div>
            </header>

            <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
            <!-- Section 1: Printer Types -->
            <div class="bg-white dark:bg-neutral-900 p-8 rounded-[32px] shadow-sm border border-slate-200 dark:border-neutral-800">
                <h2 class="text-xl font-black mb-6 flex items-center gap-2 text-slate-900 dark:text-white"><i data-lucide="printer" class="text-orange-500"></i> Printer Types</h2>
                <form method="POST" class="mb-8 space-y-4">
                    <input type="hidden" name="action" value="add_type">
                    <div class="flex gap-2 items-end">
                        <div class="flex-1">
                            <label class="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-widest">Type Name</label>
                            <input type="text" name="name" placeholder="e.g. A4 Sheet" required class="w-full p-3 bg-slate-50 dark:bg-neutral-800 border border-slate-100 dark:border-neutral-700 rounded-xl outline-none focus:border-orange-500 text-slate-900 dark:text-white placeholder-slate-400">
                        </div>
                        <label class="flex items-center gap-2 p-3 bg-slate-50 dark:bg-neutral-800 rounded-xl cursor-pointer border border-transparent hover:border-orange-500/30 transition-all">
                            <input type="checkbox" name="has_fixed_size" id="fixed-size-trigger" class="w-4 h-4 accent-orange-600">
                            <span class="text-xs font-bold text-slate-500 uppercase tracking-tighter">Fixed?</span>
                        </label>
                        <button class="p-4 bg-orange-600 text-white rounded-xl font-bold shadow-lg shadow-orange-600/20 active:scale-95 transition-all"><i data-lucide="plus" size="20"></i></button>
                    </div>

                    <!-- Constant Size Inputs (Visible only when Fixed is checked) -->
                    <div id="fixed-dims-input" class="hidden grid grid-cols-3 gap-3 p-4 bg-orange-500/5 border border-orange-500/10 rounded-2xl animate-in fade-in slide-in-from-top-2 duration-300">
                        <div>
                            <label class="text-[9px] font-black text-orange-500 uppercase tracking-widest">Width (mm)</label>
                            <input type="number" step="0.1" name="width" placeholder="210" class="w-full p-2 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-700 rounded-lg text-xs font-bold dark:text-white outline-none">
                        </div>
                        <div>
                            <label class="text-[9px] font-black text-orange-500 uppercase tracking-widest">Height (mm)</label>
                            <input type="number" step="0.1" name="height" placeholder="297" class="w-full p-2 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-700 rounded-lg text-xs font-bold dark:text-white outline-none">
                        </div>
                        <div>
                            <label class="text-[9px] font-black text-orange-500 uppercase tracking-widest">Labels/Row</label>
                            <input type="number" name="labels_per_row" placeholder="4" class="w-full p-2 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-700 rounded-lg text-xs font-bold dark:text-white outline-none">
                        </div>
                    </div>
                </form>
                <div class="space-y-2">
                    <?php foreach($types as $t): ?>
                    <div class="flex justify-between items-center p-4 bg-slate-50 dark:bg-neutral-800 rounded-2xl">
                        <div>
                            <p class="font-bold text-slate-900 dark:text-white"><?= $t['name'] ?></p>
                            <span class="text-[10px] font-black uppercase <?= $t['has_fixed_size'] ? 'text-blue-500' : 'text-slate-400' ?>"><?= $t['has_fixed_size'] ? 'Fixed Dimensions' : 'Continuous' ?></span>
                        </div>
                        <form method="POST" onsubmit="return confirm('Delete type and its sizes?')">
                            <input type="hidden" name="action" value="delete_type">
                            <input type="hidden" name="id" value="<?= $t['id'] ?>">
                            <button class="text-slate-300 hover:text-rose-500 transition-colors"><i data-lucide="trash-2" size="18"></i></button>
                        </form>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>

            <!-- Section 2: Printer Sizes -->
            <div id="sizes-section-container" class="bg-white dark:bg-neutral-900 p-8 rounded-[32px] shadow-sm border border-slate-200 dark:border-neutral-800 transition-all duration-300">
                <h2 class="text-xl font-black mb-6 flex items-center gap-2 text-slate-900 dark:text-white"><i data-lucide="maximize"></i> Printer Sizes</h2>
                <form method="POST" class="grid grid-cols-2 gap-4 mb-8 p-6 bg-slate-50 dark:bg-neutral-950 rounded-3xl">
                    <input type="hidden" name="action" value="add_size">
                    <div class="col-span-2">
                        <label class="text-[10px] font-black text-slate-400 uppercase">Select Type</label>
                        <select name="type_id" required class="w-full p-3 bg-white dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-orange-500 font-bold">
                            <?php foreach($types as $t): ?>
                            <option value="<?= $t['id'] ?>"><?= $t['name'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="text-[10px] font-black text-slate-400 uppercase">Size Name</label>
                        <input type="text" name="name" placeholder="e.g. A4 24 Labels" required class="w-full p-3 bg-white dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-orange-500 font-bold placeholder-slate-400">
                    </div>
                    <div>
                        <label class="text-[10px] font-black text-slate-400 uppercase">Width (mm)</label>
                        <input type="number" step="0.1" name="width" placeholder="210" required class="w-full p-3 bg-white dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-orange-500 font-bold">
                    </div>
                    <div>
                        <label class="text-[10px] font-black text-slate-400 uppercase">Height (mm)</label>
                        <input type="number" step="0.1" name="height" placeholder="297" required class="w-full p-3 bg-white dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-orange-500 font-bold">
                    </div>
                    <div>
                        <label class="text-[10px] font-black text-slate-400 uppercase">Labels per Row</label>
                        <input type="number" name="labels_per_row" value="1" required class="w-full p-3 bg-white dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded-xl text-slate-900 dark:text-white outline-none focus:border-orange-500">
                    </div>
                    <button class="col-span-2 py-3 bg-slate-900 text-white font-bold rounded-xl uppercase text-xs tracking-widest hover:bg-orange-600 transition-colors">Add Global Size</button>
                </form>

                <div class="space-y-2 max-h-80 overflow-y-auto pr-2">
                    <?php foreach($sizes as $s): ?>
                    <div class="p-4 border border-slate-100 dark:border-neutral-800 rounded-2xl flex justify-between items-center group">
                        <div>
                            <p class="font-bold text-slate-900 dark:text-white"><?= $s['name'] ?></p>
                            <p class="text-[10px] text-slate-400 uppercase font-black"><?= $s['type_name'] ?> • <?= $s['width_mm'] ?>x<?= $s['height_mm'] ?>mm • Row: <?= $s['labels_per_row'] ?></p>
                        </div>
                        <form method="POST">
                            <input type="hidden" name="action" value="delete_size">
                            <input type="hidden" name="id" value="<?= $s['id'] ?>">
                            <button class="text-slate-300 hover:text-rose-500 transition-colors"><i data-lucide="x" size="18"></i></button>
                        </form>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            </div>
        </div>
    </div>
    <script>
        lucide.createIcons();

        const fixedTrigger = document.getElementById('fixed-size-trigger');
        const fixedFields = document.getElementById('fixed-dims-input');
        const sizesSection = document.getElementById('sizes-section-container');

        fixedTrigger.addEventListener('change', function() {
            fixedFields.classList.toggle('hidden', !this.checked);
            sizesSection.classList.toggle('opacity-30', this.checked);
            sizesSection.style.pointerEvents = this.checked ? 'none' : 'auto';
        });
    </script>
</body>
</html>