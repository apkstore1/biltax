<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';

// --- Self-Healing: Ensure Table Exists ---
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS feature_requests (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        module_key VARCHAR(50) NOT NULL,
        module_name VARCHAR(100),
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        admin_reason TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");
} catch (Exception $e) { /* Table exists */ }

// --- Handle Approval / Rejection ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    $req_id = $_POST['request_id'];
    $action = $_POST['action']; // 'approve' or 'reject'
    $reason = $_POST['reason'] ?? '';

    try {
        $pdo->beginTransaction();

        // Fetch request details
        $stmt = $pdo->prepare("SELECT * FROM feature_requests WHERE id = ?");
        $stmt->execute([$req_id]);
        $req = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($req) {
            if ($action === 'approve') {
                // 1. Enable Module for Tenant
                $ins = $pdo->prepare("INSERT INTO enabled_modules (tenant_id, module_key, is_active) VALUES (?, ?, 1) ON DUPLICATE KEY UPDATE is_active = 1");
                $ins->execute([$req['tenant_id'], $req['module_key']]);
                
                // 2. Update Request Status
                $upd = $pdo->prepare("UPDATE feature_requests SET status = 'approved' WHERE id = ?");
                $upd->execute([$req_id]);
            } else {
                // Update Request Status to Rejected
                $upd = $pdo->prepare("UPDATE feature_requests SET status = 'rejected', admin_reason = ? WHERE id = ?");
                $upd->execute([$reason, $req_id]);
            }
        }

        $pdo->commit();
        header("Location: feature_requests.php?msg=success");
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        die("Error: " . $e->getMessage());
    }
    exit;
}

// Fetch Requests
try {
    $status_filter = $_GET['status'] ?? 'pending';
    $query = "SELECT r.*, t.business_name, t.unique_id FROM feature_requests r JOIN tenants t ON r.tenant_id = t.id";
    if ($status_filter !== 'all') {
        $query .= " WHERE r.status = " . $pdo->quote($status_filter);
    }
    $query .= " ORDER BY r.created_at DESC";
    $requests = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $requests = [];
    $db_error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Feature Requests | Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <div class="flex-1 ml-64 p-8">
        <header class="mb-10 flex justify-between items-end">
            <div>
                <h1 class="text-3xl font-black uppercase tracking-tight">Feature Requests</h1>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Review and approve tenant module access</p>
            </div>
            <div class="flex gap-2 p-1 bg-white dark:bg-neutral-900 rounded-2xl border border-slate-200 dark:border-neutral-800">
                <?php foreach(['pending', 'approved', 'rejected', 'all'] as $st): ?>
                    <a href="?status=<?= $st ?>" class="px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all <?= $status_filter === $st ? 'bg-orange-600 text-white shadow-lg' : 'text-slate-400 hover:text-orange-500' ?>">
                        <?= $st ?>
                    </a>
                <?php endforeach; ?>
            </div>
        </header>

        <?php if(isset($db_error)): ?>
            <div class="mb-6 p-4 bg-rose-500/10 border border-rose-500/20 text-rose-600 rounded-2xl text-xs font-bold">Database Error: <?= $db_error ?></div>
        <?php endif; ?>

        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[32px] overflow-hidden shadow-sm">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-100 dark:border-neutral-800">
                    <tr class="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <th class="px-8 py-5">Business Name</th>
                        <th class="px-8 py-5">Requested Module</th>
                        <th class="px-8 py-5">Date</th>
                        <th class="px-8 py-5 text-right">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach($requests as $r): ?>
                    <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors">
                        <td class="px-8 py-5">
                            <div class="font-bold"><?= htmlspecialchars($r['business_name']) ?></div>
                            <div class="text-[10px] text-slate-400 font-mono">ID: <?= $r['unique_id'] ?></div>
                        </td>
                        <td class="px-8 py-5">
                            <span class="px-3 py-1 bg-orange-500/10 text-orange-600 rounded-full text-[10px] font-black uppercase border border-orange-500/20"><?= htmlspecialchars($r['module_name']) ?></span>
                        </td>
                        <td class="px-8 py-5 text-xs text-slate-500"><?= date('M d, Y', strtotime($r['created_at'])) ?></td>
                        <td class="px-8 py-5 text-right flex justify-end gap-3">
                            <?php if($r['status'] === 'pending'): ?>
                            <form method="POST" class="inline">
                                <input type="hidden" name="request_id" value="<?= $r['id'] ?>">
                                <input type="hidden" name="action" value="approve">
                                <button type="submit" class="px-4 py-2 bg-emerald-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-emerald-700 transition-all">Approve</button>
                            </form>
                            <button onclick="openRejectModal(<?= $r['id'] ?>)" class="px-4 py-2 bg-rose-600/10 text-rose-600 rounded-xl text-[10px] font-black uppercase tracking-widest hover:bg-rose-600 hover:text-white transition-all">Reject</button>
                            <?php else: ?>
                                <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase border <?= $r['status'] === 'approved' ? 'bg-emerald-500/10 text-emerald-600 border-emerald-500/20' : 'bg-rose-500/10 text-rose-600 border-rose-500/20' ?>"><?= $r['status'] ?></span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($requests)): ?>
                        <tr><td colspan="4" class="px-8 py-20 text-center text-slate-400 italic font-bold uppercase text-xs tracking-widest">No feature requests found</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Rejection Modal -->
    <div id="rejectModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
            <button onclick="closeModal()" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Reject Request</h2>
            <p class="text-xs text-slate-500 font-bold uppercase mb-6">Provide a reason for the tenant</p>
            <form method="POST">
                <input type="hidden" name="action" value="reject">
                <input type="hidden" name="request_id" id="reject_req_id">
                <textarea name="reason" required placeholder="e.g. Please upgrade your plan to access this feature." class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm h-32 mb-4"></textarea>
                <button type="submit" class="w-full py-4 bg-rose-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl">Confirm Rejection</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        function openRejectModal(id) {
            document.getElementById('reject_req_id').value = id;
            document.getElementById('rejectModal').classList.replace('hidden', 'flex');
        }
        function closeModal() {
            document.getElementById('rejectModal').classList.replace('flex', 'hidden');
        }
    </script>
</body>
</html>