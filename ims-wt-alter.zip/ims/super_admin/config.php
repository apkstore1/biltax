<?php
// --- Configuration ---
require_once __DIR__ . '/../config/db_connect.php';

// --- Connect to Main DB ---
try {
    $pdo = new PDO("mysql:host=".DB_HOST.";dbname=".DB_MAIN, DB_USER, DB_PASS);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    // A more user-friendly error for a production environment
    error_log("Database Connection Error: " . $e->getMessage());
    die("A critical database error occurred. Please check the logs or contact support.");
}
?>