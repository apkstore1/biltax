<?php
require_once 'auth_check.php'; // Authenticate Super Admin
require_once 'config.php';
require_once '../config/currency_helper.php';

// 1. Fetch Global Admin Settings
$global_currency = 'USD';
$global_symbol = '$';
try {
    $stmt_admin = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
    $admin_settings = $stmt_admin->fetchAll(PDO::FETCH_KEY_PAIR);
    $global_currency = $admin_settings['global_currency'] ?? 'USD';
    $global_symbol = $admin_settings['global_currency_symbol'] ?? '$';
} catch (Exception $e) {}

$rates = getExchangeRates();
$global_rate = $rates[$global_currency] ?? 1.0;

// 2. Aggregate Key Analytics
try {
    // High Level Stats
    $total_tenants = $pdo->query("SELECT COUNT(*) FROM tenants")->fetchColumn();
    $active_tenants = $pdo->query("SELECT COUNT(*) FROM tenants WHERE status = 'active'")->fetchColumn();
    
    // Revenue (Sum of approved billing records)
    $raw_revenue = $pdo->query("SELECT SUM(amount) FROM billing WHERE status = 'active'")->fetchColumn() ?: 0;
    $total_revenue = $raw_revenue * $global_rate;

    // Pending Actions
    $pending_payments = $pdo->query("SELECT COUNT(*) FROM billing WHERE status = 'pending'")->fetchColumn();
    $pending_verifications = $pdo->query("SELECT COUNT(*) FROM verification_tasks WHERE status = 'pending_review'")->fetchColumn();
    $pending_features = $pdo->query("SELECT COUNT(*) FROM feature_requests WHERE status = 'pending'")->fetchColumn();
    $pending_shop_orders = $pdo->query("SELECT COUNT(*) FROM shop_orders WHERE status = 'pending'")->fetchColumn();
    $open_tickets = $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'open' OR last_reply_by = 'tenant'")->fetchColumn();

    // Industry Distribution (Chart Data)
    $industry_data = $pdo->query("SELECT industry_type, COUNT(*) as count FROM tenants GROUP BY industry_type")->fetchAll(PDO::FETCH_ASSOC);
    $industry_labels = json_encode(array_column($industry_data, 'industry_type'));
    $industry_counts = json_encode(array_column($industry_data, 'count'));

    // Package Distribution (Chart Data)
    $package_data = $pdo->query("SELECT p.package_name, COUNT(t.id) as count 
                                FROM packages p 
                                LEFT JOIN tenants t ON p.id = t.package_id 
                                GROUP BY p.id")->fetchAll(PDO::FETCH_ASSOC);
    $package_labels = json_encode(array_column($package_data, 'package_name'));
    $package_counts = json_encode(array_column($package_data, 'count'));

    // Recent Tenants
    $recent_tenants = $pdo->query("SELECT business_name, industry_type, created_at FROM tenants ORDER BY created_at DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    $error = "Data Fetch Error: " . $e->getMessage();
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Biltax Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <!-- Theme Logic -->
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #171717; }
        ::-webkit-scrollbar-thumb { background: #404040; border-radius: 10px; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content Wrapper -->
    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        
        <!-- Top Bar -->
        <?php include 'topbar.php'; ?>

        <!-- Analytics Content -->
        <main class="p-8 flex-1 overflow-y-auto space-y-10">
            <div class="max-w-7xl mx-auto">
                
                <!-- High Level Summary -->
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
                    <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Lifetime Revenue</p>
                        <h3 class="text-3xl font-black text-emerald-500"><?= $global_symbol ?><?= number_format($total_revenue, 2) ?></h3>
                        <p class="text-[9px] text-slate-500 mt-2">Total approved payments</p>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Total Tenants</p>
                        <h3 class="text-3xl font-black dark:text-white"><?= number_format($total_tenants) ?></h3>
                        <p class="text-[9px] text-orange-500 font-bold mt-2 uppercase"><?= $active_tenants ?> Active Businesses</p>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-6 rounded-[32px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <p class="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1">Open Tickets</p>
                        <h3 class="text-3xl font-black text-blue-500"><?= number_format($open_tickets) ?></h3>
                        <p class="text-[9px] text-slate-500 mt-2">Awaiting admin response</p>
                    </div>
                    <div class="bg-indigo-600 p-6 rounded-[32px] text-white shadow-xl shadow-indigo-600/20">
                        <p class="text-[10px] font-black uppercase opacity-70 mb-1">System Health</p>
                        <h3 class="text-3xl font-black">99.9%</h3>
                        <p class="text-[9px] mt-2 font-bold uppercase tracking-widest">All instances online</p>
                    </div>
                </div>

                <!-- Action Required Center -->
                <div class="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-10">
                    <a href="pending_payments.php" class="bg-white dark:bg-neutral-900 p-5 rounded-3xl border-b-4 border-emerald-500 shadow-sm hover:scale-105 transition-all">
                        <div class="flex justify-between items-start">
                            <i data-lucide="banknote" class="text-emerald-500"></i>
                            <span class="bg-emerald-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full"><?= $pending_payments ?></span>
                        </div>
                        <p class="text-xs font-black uppercase mt-3 dark:text-white">Payments</p>
                    </a>
                    <a href="verification_requests.php" class="bg-white dark:bg-neutral-900 p-5 rounded-3xl border-b-4 border-indigo-500 shadow-sm hover:scale-105 transition-all">
                        <div class="flex justify-between items-start">
                            <i data-lucide="shield-check" class="text-indigo-500"></i>
                            <span class="bg-indigo-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full"><?= $pending_verifications ?></span>
                        </div>
                        <p class="text-xs font-black uppercase mt-3 dark:text-white">Verification</p>
                    </a>
                    <a href="feature_requests.php" class="bg-white dark:bg-neutral-900 p-5 rounded-3xl border-b-4 border-orange-500 shadow-sm hover:scale-105 transition-all">
                        <div class="flex justify-between items-start">
                            <i data-lucide="zap" class="text-orange-500"></i>
                            <span class="bg-orange-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full"><?= $pending_features ?></span>
                        </div>
                        <p class="text-xs font-black uppercase mt-3 dark:text-white">Features</p>
                    </a>
                    <a href="shop_orders.php" class="bg-white dark:bg-neutral-900 p-5 rounded-3xl border-b-4 border-purple-500 shadow-sm hover:scale-105 transition-all">
                        <div class="flex justify-between items-start">
                            <i data-lucide="shopping-bag" class="text-purple-500"></i>
                            <span class="bg-purple-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full"><?= $pending_shop_orders ?></span>
                        </div>
                        <p class="text-xs font-black uppercase mt-3 dark:text-white">Shop Orders</p>
                    </a>
                    <a href="support_tickets_manager.php" class="bg-white dark:bg-neutral-900 p-5 rounded-3xl border-b-4 border-rose-500 shadow-sm hover:scale-105 transition-all">
                        <div class="flex justify-between items-start">
                            <i data-lucide="life-buoy" class="text-rose-500"></i>
                            <span class="bg-rose-500 text-white text-[10px] font-black px-2 py-0.5 rounded-full"><?= $open_tickets ?></span>
                        </div>
                        <p class="text-xs font-black uppercase mt-3 dark:text-white">Tickets</p>
                    </a>
                </div>

                <!-- Charts Row -->
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-10">
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                        <h4 class="text-xs font-black uppercase text-slate-400 tracking-widest mb-6">Industry Distribution</h4>
                        <div class="h-64"><canvas id="industryChart"></canvas></div>
                    </div>
                    <div class="bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-xl">
                        <h4 class="text-xs font-black uppercase text-slate-400 tracking-widest mb-6">Package Popularity</h4>
                        <div class="h-64"><canvas id="packageChart"></canvas></div>
                    </div>
                </div>

                <!-- Recent Activity & New Signups -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div class="lg:col-span-2 bg-white dark:bg-neutral-900 p-8 rounded-[40px] border border-slate-200 dark:border-neutral-800 shadow-sm">
                        <h4 class="text-xs font-black uppercase text-orange-500 tracking-widest mb-6">Latest Signups</h4>
                        <div class="overflow-x-auto">
                            <table class="w-full text-left">
                                <thead class="text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-neutral-800">
                                    <tr>
                                        <th class="pb-4">Business Name</th>
                                        <th class="pb-4">Industry</th>
                                        <th class="pb-4 text-right">Join Date</th>
                                    </tr>
                                </thead>
                                <tbody class="divide-y divide-slate-50 dark:divide-neutral-800">
                                    <?php foreach($recent_tenants as $rt): ?>
                                    <tr class="text-sm">
                                        <td class="py-4 font-bold dark:text-white"><?= htmlspecialchars($rt['business_name']) ?></td>
                                        <td class="py-4">
                                            <span class="px-2 py-0.5 bg-slate-100 dark:bg-neutral-800 rounded text-[9px] font-black uppercase text-slate-600 dark:text-slate-400"><?= $rt['industry_type'] ?></span>
                                        </td>
                                        <td class="py-4 text-right text-xs text-slate-500"><?= date('M d, Y', strtotime($rt['created_at'])) ?></td>
                                    </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>

                    <div class="bg-slate-900 rounded-[40px] p-8 text-white flex flex-col justify-between shadow-2xl">
                        <div>
                            <h4 class="text-xs font-black uppercase text-orange-500 tracking-widest mb-4">Quick Insights</h4>
                            <p class="text-2xl font-black leading-tight">You have <?= ($pending_payments + $pending_verifications) ?> critical tasks pending.</p>
                            <p class="text-sm text-slate-400 mt-4 leading-relaxed">Most of your users are currently in the <span class="text-white font-bold"><?= count($industry_data) > 0 ? $industry_data[0]['industry_type'] : 'N/A' ?></span> sector using the <span class="text-white font-bold"><?= count($package_data) > 0 ? $package_data[0]['package_name'] : 'N/A' ?></span> plan.</p>
                        </div>
                        <a href="manage_tenants.php" class="mt-8 py-4 bg-orange-600 rounded-2xl text-center font-black uppercase tracking-widest text-xs hover:bg-orange-700 transition-all">Review All Tenants</a>
                    </div>
                </div>

            </div>
        </main>
    </div>

    <script>
        lucide.createIcons();

        // Industry Chart
        new Chart(document.getElementById('industryChart'), {
            type: 'doughnut',
            data: {
                labels: <?= $industry_labels ?>,
                datasets: [{
                    data: <?= $industry_counts ?>,
                    backgroundColor: ['#f97316', '#6366f1', '#10b981', '#a855f7', '#ec4899', '#3b82f6'],
                    borderWidth: 0,
                    hoverOffset: 20
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'bottom', labels: { color: '#94a3b8', font: { weight: 'bold', size: 10 }, padding: 20 } }
                },
                cutout: '70%'
            }
        });

        // Package Chart
        new Chart(document.getElementById('packageChart'), {
            type: 'bar',
            data: {
                labels: <?= $package_labels ?>,
                datasets: [{
                    label: 'Tenants',
                    data: <?= $package_counts ?>,
                    backgroundColor: 'rgba(249, 115, 22, 0.8)',
                    borderRadius: 12,
                    barThickness: 30
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: true, grid: { color: 'rgba(255,255,255,0.05)' }, ticks: { color: '#94a3b8' } },
                    x: { grid: { display: false }, ticks: { color: '#94a3b8', font: { weight: 'bold' } } }
                }
            }
        });
    </script>
</body>
</html>