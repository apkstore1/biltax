<?php
// alert_bar.php - Global Verification Alert Bar
// Dependancy: db_switch.php must be included before this.

if (isset($t_conf['id'])) {
    try {
        // Fetch the highest priority pending task (not started or rejected)
        // $m_pdo is defined globally in db_switch.php
        $stmt_alert_task = $m_pdo->prepare("
            SELECT task_title, priority 
            FROM verification_tasks 
            WHERE tenant_id = ? AND status IN ('not_started', 'rejected') 
            ORDER BY FIELD(priority, 'high', 'medium', 'low') LIMIT 1
        ");
        $stmt_alert_task->execute([$t_conf['id']]);
        $alert_task = $stmt_alert_task->fetch(PDO::FETCH_ASSOC);

        if ($alert_task) {
            $priority = $alert_task['priority'];
            $title = htmlspecialchars($alert_task['task_title']);
            
            // Configuration based on priority
            $classes = match($priority) {
                'high'   => ['bg' => 'bg-rose-600', 'icon' => 'alert-octagon', 'animate' => 'animate-pulse', 'bounce' => 'animate-bounce', 'msg' => "Action Required: Please complete your <strong>$title</strong> in the Verification Center."],
                'medium' => ['bg' => 'bg-amber-500', 'icon' => 'alert-triangle', 'animate' => '', 'bounce' => '', 'msg' => "Reminder: <strong>$title</strong> task is pending in the Verification Center."],
                'low'    => ['bg' => 'bg-emerald-600', 'icon' => 'info', 'animate' => '', 'bounce' => '', 'msg' => "Task Available: <strong>$title</strong> verification is ready for submission."],
                default  => ['bg' => 'bg-slate-600', 'icon' => 'bell', 'animate' => '', 'bounce' => '', 'msg' => "Verification update: <strong>$title</strong>"]
            };
?>
            <!-- Global Alert Bar Component -->
            <div id="global-verification-alert" onclick="window.location.href='verification_center.php'" 
                 class="<?= $classes['bg'] ?> <?= $classes['animate'] ?> text-white py-3 px-8 flex items-center justify-between shadow-2xl cursor-pointer hover:opacity-95 transition-all no-print sticky top-0 z-[45] mb-6 rounded-2xl">
                <div class="flex items-center gap-4">
                    <div class="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center">
                        <i data-lucide="<?= $classes['icon'] ?>" class="<?= $classes['bounce'] ?>" size="18"></i>
                    </div>
                    <span class="text-xs font-black uppercase tracking-widest"><?= $classes['msg'] ?></span>
                </div>
                <div class="flex items-center gap-6">
                    <div class="flex items-center gap-3">
                        <span class="hidden md:inline text-[9px] font-black uppercase bg-black/20 px-3 py-1 rounded-full border border-white/10">Verification Center</span>
                        <i data-lucide="chevron-right" size="16"></i>
                    </div>
                    <?php if (in_array($priority, ['medium', 'low'])): ?>
                        <button onclick="event.stopPropagation(); document.getElementById('global-verification-alert').style.display='none';" class="p-1.5 hover:bg-white/20 rounded-full transition-all" title="Dismiss">
                            <i data-lucide="x" size="16"></i>
                        </button>
                    <?php endif; ?>
                </div>
            </div>
<?php
        }
    } catch (Exception $e) { /* Fail silently to keep app running */ }
}