// Firebase Configuration (Replace with your actual Firebase project config)
const firebaseConfig = {
  apiKey: "AIzaSyDiDNzYytEywBOHLwboTUms5ubeB9iKrWE",
  authDomain: "biltax-chat.firebaseapp.com",
  databaseURL: "https://biltax-chat-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "biltax-chat",
  storageBucket: "biltax-chat.firebasestorage.app",
  messagingSenderId: "124310679032",
  appId: "1:124310679032:web:0b2a74707b82a9bad5ba0d",
  measurementId: "G-R2Q0E6NYLR"
};

// Initialize Firebase using the compat/namespace version for easier global access
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}

/**
 * Global Database Instance
 * This 'db' constant will be used to interact with Realtime Database
 * across all chat functions.
 */
const db = firebase.database();
console.log("Firebase B2B Chat System Initialized.");