<?php
require_once 'config/db_switch.php';

if (!$tenant_conn || !isset($_GET['sale_id'])) {
    die("Unauthorized or Invalid Request");
}

$sale_id = (int)$_GET['sale_id'];

// 1. Fetch Sale Details with Branch and Table Info
$stmt = $tenant_conn->prepare("SELECT s.*, b.branch_name, b.address as branch_address, t.table_number 
                               FROM sales s 
                               LEFT JOIN branches b ON s.branch_id = b.id 
                               LEFT JOIN kot k ON s.id = k.sale_id
                               LEFT JOIN restaurant_tables t ON k.table_id = t.id
                               WHERE s.id = ?");
$stmt->execute([$sale_id]);
$sale = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$sale) die("Sale record not found.");

// 2. Fetch Order Items
$stmt_items = $tenant_conn->prepare("SELECT si.*, p.name 
                                     FROM sale_items si 
                                     JOIN products p ON si.product_id = p.id 
                                     WHERE si.sale_id = ?");
$stmt_items->execute([$sale_id]);
$items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);

$business_name = $_SESSION['business_name'] ?? 'Biltax Restaurant';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Bill #<?= $sale_id ?></title>
    <style>
        body { font-family: 'Courier New', Courier, monospace; width: 80mm; margin: 0 auto; padding: 10px; color: #000; font-size: 12px; }
        .text-center { text-align: center; }
        .text-right { text-align: right; }
        .bold { font-weight: bold; }
        .divider { border-top: 1px dashed #000; margin: 5px 0; }
        table { width: 100%; border-collapse: collapse; }
        th { text-align: left; font-size: 10px; }
        .header { margin-bottom: 10px; }
        .footer { margin-top: 20px; font-size: 10px; }
        @media print {
            @page { margin: 0; }
            body { margin: 0; padding: 5mm; }
        }
    </style>
</head>
<body onload="window.print(); setTimeout(() => window.close(), 1000);">
    <div class="header text-center">
        <h2 style="margin: 0;"><?= htmlspecialchars($business_name) ?></h2>
        <div style="font-size: 10px;"><?= htmlspecialchars($sale['branch_name'] ?? '') ?></div>
        <div style="font-size: 10px;"><?= htmlspecialchars($sale['branch_address'] ?? '') ?></div>
    </div>

    <div class="divider"></div>
    
    <div>
        <span>Invoice: #<?= $sale_id ?></span><br>
        <span>Date: <?= date('d-M-Y H:i', strtotime($sale['created_at'])) ?></span><br>
        <?php if ($sale['table_number']): ?>
            <span class="bold">Table: <?= htmlspecialchars($sale['table_number']) ?></span><br>
        <?php endif; ?>
    </div>

    <div class="divider"></div>

    <table>
        <thead>
            <tr>
                <th>ITEM</th>
                <th class="text-center">QTY</th>
                <th class="text-right">PRICE</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
            <tr>
                <td><?= htmlspecialchars($item['name']) ?></td>
                <td class="text-center"><?= (int)$item['quantity'] ?></td>
                <td class="text-right"><?= number_format($item['price'] * $item['quantity'], 2) ?></td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="divider"></div>

    <div class="text-right">
        <div>Subtotal: <?= number_format($sale['total_amount'] + ($sale['discount_amount'] ?? 0) - ($sale['tax_amount'] ?? 0), 2) ?></div>
        <?php if (($sale['tax_amount'] ?? 0) > 0): ?>
            <div>Tax: <?= number_format($sale['tax_amount'], 2) ?></div>
        <?php endif; ?>
        <?php if (($sale['discount_amount'] ?? 0) > 0): ?>
            <div>Discount: -<?= number_format($sale['discount_amount'], 2) ?></div>
        <?php endif; ?>
        <div class="bold" style="font-size: 16px;">Total: <?= $currency_symbol . number_format($sale['total_amount'], 2) ?></div>
    </div>

    <div class="divider"></div>
    <div class="text-center">Payment: <?= htmlspecialchars($sale['payment_method']) ?></div>

    <div class="footer text-center">
        <p>Thank you for your visit!</p>
        <p>Powered by Biltax POS</p>
    </div>
</body>
</html>