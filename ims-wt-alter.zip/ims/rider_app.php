<?php
require_once 'config/db_switch.php';

// Session handling for Rider
if (isset($_POST['rider_login'])) {
    $phone = $_POST['phone'];
    $pass = $_POST['password'];
    $stmt = $tenant_conn->prepare("SELECT * FROM riders WHERE phone = ? AND is_active = 1");
    $stmt->execute([$phone]);
    $rider = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($rider && password_verify($pass, $rider['password'])) {
        $_SESSION['rider_id'] = $rider['id'];
        $_SESSION['rider_name'] = $rider['name'];
        header("Location: rider_app.php"); exit;
    } else { $error = "Invalid phone or password."; }
}

if (isset($_GET['logout'])) { session_destroy(); header("Location: rider_app.php"); exit; }

$is_logged_in = isset($_SESSION['rider_id']);
$rider_id = $_SESSION['rider_id'] ?? null;

// Fetch Assigned Orders from Main DB
$orders = [];
if ($is_logged_in) {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $stmt = $main_pdo->prepare("
        SELECT o.id, o.total_amount, o.delivery_status, o.created_at, t.business_name as customer, t.address, t.phone as customer_phone
        FROM b2b_orders o 
        JOIN tenants t ON o.sender_tenant_id = t.id 
        WHERE o.rider_id = ? AND o.delivery_status != 'delivered'
        ORDER BY o.id DESC");
    $stmt->execute([$rider_id]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Rider Portal | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;600;800&display=swap');
        body { font-family: 'Plus Jakarta Sans', sans-serif; -webkit-tap-highlight-color: transparent; }
        .rider-card { transition: transform 0.2s ease; }
        .rider-card:active { transform: scale(0.97); }
    </style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 min-h-screen">

    <?php if (!$is_logged_in): ?>
        <!-- Login Screen -->
        <div class="flex items-center justify-center p-6 min-h-screen">
            <div class="w-full max-w-sm bg-white dark:bg-neutral-900 p-8 rounded-[40px] shadow-2xl border border-slate-200 dark:border-neutral-800">
                <div class="text-center mb-8">
                    <div class="w-16 h-16 bg-orange-600 rounded-2xl flex items-center justify-center text-white mx-auto mb-4 shadow-lg shadow-orange-600/20">
                        <i data-lucide="bike" size="32"></i>
                    </div>
                    <h1 class="text-2xl font-800 dark:text-white uppercase tracking-tighter">Rider Login</h1>
                    <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1">Delivery Fleet Portal</p>
                </div>
                <?php if(isset($error)): ?>
                    <p class="mb-4 text-rose-500 text-center text-xs font-bold"><?= $error ?></p>
                <?php endif; ?>
                <form method="POST" class="space-y-4">
                    <input type="hidden" name="rider_login" value="1">
                    <input type="text" name="phone" placeholder="Phone Number" required class="w-full p-4 bg-slate-50 dark:bg-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm border border-slate-100 dark:border-neutral-700">
                    <input type="password" name="password" placeholder="Password" required class="w-full p-4 bg-slate-50 dark:bg-neutral-800 rounded-2xl outline-none dark:text-white font-bold text-sm border border-slate-100 dark:border-neutral-700">
                    <button type="submit" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 active:scale-95 transition-all mt-4">Launch Dashboard</button>
                </form>
            </div>
        </div>
    <?php else: ?>
        <!-- App Header -->
        <header class="sticky top-0 bg-white/80 dark:bg-neutral-900/80 backdrop-blur-lg border-b border-slate-100 dark:border-neutral-800 px-6 py-4 flex justify-between items-center z-50">
            <div>
                <h2 class="text-lg font-800 dark:text-white">Hello, <?= htmlspecialchars($_SESSION['rider_name']) ?></h2>
                <p class="text-[9px] font-black text-orange-500 uppercase tracking-widest">Active Shift</p>
            </div>
            <a href="?logout=1" class="text-slate-400 hover:text-rose-500 transition-colors"><i data-lucide="log-out" size="20"></i></a>
        </header>

        <main class="p-4 space-y-4">
            <div class="flex items-center justify-between mb-2">
                <h3 class="text-xs font-black text-slate-400 uppercase tracking-widest">Assigned Deliveries</h3>
                <span class="px-2 py-1 bg-orange-600 text-white text-[9px] font-black rounded-lg"><?= count($orders) ?> Orders</span>
            </div>

            <?php if (empty($orders)): ?>
                <div class="text-center py-20 opacity-30">
                    <i data-lucide="package-check" size="48" class="mx-auto mb-2 text-slate-400"></i>
                    <p class="font-bold text-sm">No pending deliveries.</p>
                </div>
            <?php endif; ?>

            <?php foreach($orders as $o): ?>
            <div class="rider-card bg-white dark:bg-neutral-900 rounded-[30px] border border-slate-200 dark:border-neutral-800 shadow-sm overflow-hidden">
                <div class="p-6">
                    <div class="flex justify-between items-start mb-4">
                        <div>
                            <p class="text-[9px] font-black text-orange-500 uppercase tracking-tighter">Order #<?= $o['id'] ?></p>
                            <h4 class="text-lg font-800 dark:text-white uppercase leading-tight"><?= htmlspecialchars($o['customer']) ?></h4>
                        </div>
                        <span class="px-3 py-1 bg-slate-100 dark:bg-neutral-800 text-slate-500 text-[9px] font-black uppercase rounded-full"><?= $o['delivery_status'] ?></span>
                    </div>

                    <div class="space-y-3 mb-6">
                        <div class="flex items-start gap-3">
                            <i data-lucide="map-pin" size="16" class="text-slate-400 mt-0.5"></i>
                            <p class="text-xs font-bold text-slate-500 dark:text-neutral-400"><?= htmlspecialchars($o['address'] ?: 'No address provided') ?></p>
                        </div>
                        <div class="flex items-center gap-3">
                            <i data-lucide="phone" size="16" class="text-slate-400"></i>
                            <a href="tel:<?= $o['customer_phone'] ?>" class="text-xs font-black text-blue-600 underline uppercase">Call Customer</a>
                        </div>
                    </div>

                    <div class="flex gap-2">
                        <?php if ($o['delivery_status'] === 'dispatched'): ?>
                            <button onclick="updateStatus(<?= $o['id'] ?>, 'picked_up')" class="flex-1 py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg">Start Journey</button>
                        <?php else: ?>
                            <button onclick="updateStatus(<?= $o['id'] ?>, 'delivered')" class="flex-1 py-4 bg-emerald-600 text-white rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-emerald-600/20">Mark Delivered</button>
                        <?php endif; ?>
                        <a href="https://www.google.com/maps/search/?api=1&query=<?= urlencode($o['address']) ?>" target="_blank" class="p-4 bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-slate-400 rounded-2xl">
                            <i data-lucide="navigation" size="18"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </main>
    <?php endif; ?>

    <script>
        lucide.createIcons();

        async function updateStatus(orderId, status) {
            let confirmMsg = status === 'delivered' ? "Confirm delivery completion?" : "Start journey for this order?";
            if (!confirm(confirmMsg)) return;

            try {
                const res = await fetch('b2b_actions.php?action=update_delivery_status', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        order_id: orderId,
                        status: status,
                        rider_id: <?= $rider_id ?: 'null' ?>
                    })
                });
                const data = await res.json();
                if (data.success) {
                    location.reload();
                } else {
                    alert(data.message || "Failed to update status");
                }
            } catch (e) { 
                console.error(e);
                alert("Connection Error. Please check your internet."); 
            }
        }
    </script>

    <style>
        /* Mobile App Feel Hacks */
        @media (max-width: 640px) {
            body { padding-bottom: 30px; }
        }
        .custom-scrollbar::-webkit-scrollbar { width: 0px; }
        .animate-pulse {
            animation: pulse 2s cubic-bezier(0.4, 0, 0.6, 1) infinite;
        }
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: .5; }
        }
    </style>
</body>
</html>