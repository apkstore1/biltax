<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

try {
    $stmt = $m_pdo->prepare("SELECT b.*, p.package_name 
                            FROM billing b 
                            JOIN packages p ON b.package_id = p.id 
                            WHERE b.tenant_id = ? 
                            ORDER BY b.created_at DESC");
    $stmt->execute([$t_conf['id']]);
    $history = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { $history = []; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Billing History | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen flex">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8 overflow-y-auto">
        <header class="flex justify-between items-center mb-10">
            <div>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Billing History</h1>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest">Track your past payments and receipts</p>
            </div>
            <div class="flex items-center gap-3">
                <a href="billing_plans_view.php" class="px-5 py-2.5 bg-orange-600 text-white rounded-xl text-[10px] font-black uppercase tracking-widest shadow-lg shadow-orange-600/20">Upgrade Plan</a>
                <?php include 'topbar.php'; ?>
            </div>
        </header>

        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-[40px] overflow-hidden shadow-xl">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 text-[10px] font-black text-slate-400 uppercase tracking-widest border-b border-slate-100 dark:border-neutral-800">
                    <tr>
                        <th class="px-8 py-5">Date</th>
                        <th class="px-8 py-5">Package / Plan</th>
                        <th class="px-8 py-5">Transaction ID</th>
                        <th class="px-8 py-5">Amount</th>
                        <th class="px-8 py-5 text-center">Status</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach($history as $h): 
                        $status_colors = [
                            'pending' => 'bg-amber-500/10 text-amber-500 border-amber-500/20',
                            'active' => 'bg-emerald-500/10 text-emerald-500 border-emerald-500/20',
                            'rejected' => 'bg-rose-500/10 text-rose-500 border-rose-500/20',
                            'expired' => 'bg-slate-500/10 text-slate-500 border-slate-500/20'
                        ];
                    ?>
                <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/30 transition-colors group/row">
                        <td class="px-8 py-5 text-xs text-slate-500"><?= date('M d, Y', strtotime($h['created_at'])) ?></td>
                        <td class="px-8 py-5 font-bold dark:text-white"><?= htmlspecialchars($h['package_name']) ?> <span class="text-[9px] uppercase opacity-50 ml-1">(<?= str_replace('_', ' ', $h['billing_cycle']) ?>)</span></td>
                        <td class="px-8 py-5 font-mono text-xs font-black tracking-tighter text-indigo-500 uppercase"><?= htmlspecialchars($h['transaction_id']) ?></td>
                        <td class="px-8 py-5 font-black dark:text-white"><?= $currency_symbol . number_format($h['amount'], 2) ?></td>
                        <td class="px-8 py-5 text-center">
                        <div class="relative group inline-block">
                            <span class="px-3 py-1 rounded-full text-[9px] font-black uppercase border <?= $status_colors[$h['status']] ?? $status_colors['pending'] ?> <?= $h['status'] === 'rejected' ? 'cursor-help' : '' ?>">
                                <?= $h['status'] ?>
                            </span>
                            <?php if($h['status'] === 'rejected' && !empty($h['rejection_reason'])): ?>
                            <!-- Hover Popup -->
                            <div class="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 hidden group-hover:block w-48 p-3 bg-slate-900 dark:bg-white text-white dark:text-black text-[10px] rounded-xl shadow-2xl z-50 pointer-events-none text-left border border-slate-700 dark:border-slate-200">
                                <p class="font-black text-rose-500 uppercase mb-1 flex items-center gap-1"><i data-lucide="info" size="10"></i> Reason:</p>
                                <p class="font-medium opacity-90 leading-relaxed"><?= htmlspecialchars($h['rejection_reason']) ?></p>
                                <div class="absolute top-full left-1/2 -translate-x-1/2 border-[6px] border-transparent border-t-slate-900 dark:border-t-white"></div>
                            </div>
                            <?php endif; ?>
                        </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php if(empty($history)): ?>
                        <tr><td colspan="5" class="p-20 text-center text-slate-400 italic font-bold tracking-widest text-xs uppercase">No payment history found.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
    <script>lucide.createIcons();</script>
</body>
</html>