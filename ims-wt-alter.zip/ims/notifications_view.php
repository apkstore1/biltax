<?php
require_once 'config/db_switch.php';
if (!$tenant_conn) { header("Location: login.php"); exit; }

try {
    $main_db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    
    $stmt = $main_db->prepare("SELECT id FROM tenants WHERE db_name = ?");
    $stmt->execute([$_SESSION['db_name']]);
    $tenant_id = $stmt->fetchColumn();

    // Get all notifications for this tenant
    $stmt = $main_db->prepare("SELECT * FROM notifications WHERE (tenant_id = ? OR tenant_id IS NULL) ORDER BY created_at DESC");
    $stmt->execute([$tenant_id]);
    $notifications = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $selected_id = $_GET['id'] ?? null;
    
    // If specifically viewed, mark it as read immediately
    if ($selected_id) {
        $mark = $main_db->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND (tenant_id = ? OR tenant_id IS NULL)");
        $mark->execute([$selected_id, $tenant_id]);
    }
} catch (PDOException $e) { die("System Error"); }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"><title>Notifications - Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
</head>
<body class="flex min-h-screen bg-slate-50 dark:bg-neutral-900 transition-colors duration-300">
    <?php include 'sidebar.php'; ?>
    <main class="flex-1 p-8">
        <div class="max-w-4xl mx-auto">
            <header class="flex justify-between items-center mb-10">
                <div>
                    <h2 class="text-3xl font-black text-slate-900 dark:text-white">All Notifications</h2>
                    <p class="text-slate-500">Stay updated with system alerts and announcements.</p>
                </div>
                <?php include 'topbar.php'; ?>
            </header>

            <div class="space-y-4">
                <?php foreach($notifications as $n): ?>
                    <div id="notif-<?= $n['id'] ?>" class="p-6 rounded-2xl border transition-all <?= ($selected_id == $n['id']) ? 'border-orange-500 ring-2 ring-orange-500/10' : 'border-slate-200 dark:border-neutral-800' ?> <?= $n['is_read'] ? 'bg-white dark:bg-neutral-950 opacity-80' : 'bg-orange-50 dark:bg-orange-500/5' ?>">
                        <div class="flex justify-between items-start mb-4">
                            <div class="flex items-center gap-3">
                                <?php 
                                    $icon = ($n['type'] == 'alert') ? 'alert-circle' : (($n['type'] == 'system') ? 'settings' : 'info');
                                    $color = ($n['type'] == 'alert') ? 'text-rose-500' : (($n['type'] == 'system') ? 'text-amber-500' : 'text-blue-500');
                                ?>
                                <div class="p-2 rounded-lg bg-white dark:bg-neutral-900 shadow-sm <?= $color ?>">
                                    <i data-lucide="<?= $icon ?>" size="20"></i>
                                </div>
                                <div>
                                    <h3 class="font-bold text-slate-900 dark:text-white"><?= htmlspecialchars($n['title']) ?></h3>
                                    <p class="text-[10px] text-slate-400 uppercase font-bold tracking-widest"><?= $n['type'] ?></p>
                                </div>
                            </div>
                            <span class="text-xs text-slate-400 font-mono"><?= date('d M Y, H:i', strtotime($n['created_at'])) ?></span>
                        </div>
                        <div class="text-sm text-slate-600 dark:text-neutral-400 leading-relaxed pl-12">
                            <?= nl2br(htmlspecialchars($n['message'])) ?>
                        </div>
                        
                        <?php if(strpos($n['title'], 'Low Stock') !== false): ?>
                            <div class="mt-4 pl-12">
                                <a href="purchase_entry.php" class="inline-flex items-center gap-2 text-xs font-black text-orange-500 hover:underline uppercase">
                                    Open Purchase Entry <i data-lucide="arrow-right" size="14"></i>
                                </a>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>

                <?php if(empty($notifications)): ?>
                    <div class="text-center py-20 bg-white dark:bg-neutral-950 rounded-3xl border border-dashed border-slate-200 dark:border-neutral-800">
                        <i data-lucide="bell-off" class="mx-auto text-slate-300 mb-4" size="48"></i>
                        <p class="text-slate-500 italic">No notifications found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>
    <script>
        lucide.createIcons();
        // Auto-scroll to selected notification
        const selected = document.getElementById('notif-<?= $selected_id ?>');
        if(selected) {
            selected.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    </script>
</body>
</html>