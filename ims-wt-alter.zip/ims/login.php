<?php
session_start();
// Agar user pehle se logged in hai toh dashboard par bhej do
if (isset($_SESSION['tenant_id']) && !empty($_SESSION['db_name'])) {
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-neutral-950 text-white min-h-screen flex items-center justify-center p-4">

    <div class="w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl p-8 shadow-2xl">
        <div class="flex items-center gap-3 mb-8">
            <div class="w-10 h-10 bg-orange-600 rounded-xl flex items-center justify-center text-white shadow-lg shadow-orange-900/20">
                <img src="assets/Biltax-icon.png" class="w-full h-full object-contain brightness-0 invert" alt="Biltax">
            </div>
            <div>
                <h1 class="text-xl font-bold tracking-tight text-white">Biltax</h1>
                <p class="text-[10px] font-bold text-orange-500 uppercase tracking-widest">Sign In</p>
            </div>
        </div>

        <div id="error-msg" class="hidden mb-4 p-4 bg-red-500/10 border border-red-500/20 text-red-500 rounded-xl text-sm"></div>

        <form id="loginForm" class="space-y-4">
            <div class="mb-6">
                <label class="block text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest ml-1">Account Type</label>
                <select id="login_type" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-5 py-4 text-white focus:border-orange-500 outline-none transition-all font-bold cursor-pointer" onchange="toggleLoginType()">
                    <option value="business">🏢 Business Owner / Admin</option>
                    <option value="staff">👨‍💼 Staff Member</option>
                </select>
            </div>

            <div>
                <label id="identifier-label" class="block text-xs font-bold text-neutral-500 uppercase mb-2">Email / Username</label>
                <input type="text" id="identifier" name="identifier" required class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all" placeholder="Enter your credentials">
            </div>
            <div id="business-id-container" class="hidden">
                <label class="block text-[10px] font-black text-slate-500 uppercase mb-2 tracking-widest">Business ID (Only for Staff)</label>
                <input type="text" id="business_id" name="business_id" class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-700 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all font-mono" placeholder="e.g. BTX-123456">
            </div>
            <div>
                <label class="block text-xs font-bold text-neutral-500 uppercase mb-2">Password</label>
                <input type="password" id="password" name="password" required class="w-full bg-neutral-950 border border-neutral-800 rounded-xl px-5 py-4 text-white placeholder-neutral-600 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none transition-all" placeholder="••••••••">
            </div>

            <button type="submit" class="w-full bg-white text-black hover:bg-neutral-200 px-8 py-4 rounded-xl font-bold flex items-center justify-center gap-2 transition-all mt-6">
                <span id="btn-text">Sign In</span>
                <i data-lucide="arrow-right" size="18"></i>
            </button>
        </form>

        <p class="text-neutral-500 text-sm mt-8 text-center">Don't have an account? <a href="register.php" class="text-white hover:text-orange-500 font-bold transition-colors">Register</a></p>
    </div>

    <script>
        lucide.createIcons();

        function toggleLoginType() {
            const type = document.getElementById('login_type').value;
            const bizIdContainer = document.getElementById('business-id-container');
            const bizIdInput = document.getElementById('business_id');
            const identifierLabel = document.getElementById('identifier-label');

            if (type === 'staff') {
                bizIdContainer.classList.remove('hidden');
                bizIdInput.required = true;
                identifierLabel.innerText = 'Staff Username';
            } else {
                bizIdContainer.classList.add('hidden');
                bizIdInput.required = false;
                bizIdInput.value = '';
                identifierLabel.innerText = 'Email Address';
            }
        }

        document.getElementById('loginForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const btn = document.querySelector('button[type="submit"]');
            const btnText = document.getElementById('btn-text');
            const errorDiv = document.getElementById('error-msg');

            btn.disabled = true;
            btn.classList.add('opacity-75');
            btnText.innerText = 'Verifying...';
            errorDiv.classList.add('hidden');

            const identifier = document.getElementById('identifier').value;
            const password = document.getElementById('password').value;
            const business_id = document.getElementById('business_id').value;

            try {
                const res = await fetch('auth/login_process.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ identifier, password, business_id })
                });
                
                const data = await res.json();

                if(data.status === 'success') {
                    window.location.href = data.redirect;
                } else {
                    throw new Error(data.message);
                }
            } catch (err) {
                errorDiv.innerText = err.message;
                errorDiv.classList.remove('hidden');
                btn.disabled = false;
                btn.classList.remove('opacity-75');
                btnText.innerText = 'Sign In';
            }
        });
    </script>
</body>
</html>