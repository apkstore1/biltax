<?php
require_once 'auth_check.php'; // Authenticate Super Admin

// RBAC Guard: Only allowed if has 'manage_tenants' permission
if (!has_admin_permission('manage_tenants')) {
    die("Access Denied: You do not have permission to manage tenants.");
}

require_once 'config.php';
require_once '../config/db_connect.php';
require_once '../config/currency_helper.php';

// --- Handle Actions (AJAX/Form) ---

// Self-healing: Ensure is_verified column exists in tenants table
try {
    $t_cols = $pdo->query("SHOW COLUMNS FROM tenants")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('is_verified', $t_cols)) $pdo->exec("ALTER TABLE tenants ADD COLUMN is_verified TINYINT(1) DEFAULT 0");
    if (!in_array('is_featured', $t_cols)) $pdo->exec("ALTER TABLE tenants ADD COLUMN is_featured TINYINT(1) DEFAULT 0");
    if (!in_array('staff_limit', $t_cols)) $pdo->exec("ALTER TABLE tenants ADD COLUMN staff_limit INT DEFAULT 5");
    if (!in_array('branch_limit', $t_cols)) $pdo->exec("ALTER TABLE tenants ADD COLUMN branch_limit INT DEFAULT 1");
    if (!in_array('storage_limit', $t_cols)) $pdo->exec("ALTER TABLE tenants ADD COLUMN storage_limit INT DEFAULT 1");

    // Shop System Tables (Biltax Shop)
    $pdo->exec("CREATE TABLE IF NOT EXISTS shop_products (
        id INT PRIMARY KEY AUTO_INCREMENT,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        price DECIMAL(15,2) NOT NULL,
        image_url TEXT,
        stock INT DEFAULT 0,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS shop_orders (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        total_amount DECIMAL(15,2) NOT NULL,
        status ENUM('pending', 'processing', 'fulfilled', 'cancelled') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS shop_order_items (
        id INT PRIMARY KEY AUTO_INCREMENT,
        order_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity INT NOT NULL,
        price DECIMAL(15,2) NOT NULL
    )");

    // Verification Tasks Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS verification_tasks (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        task_title VARCHAR(255) NOT NULL,
        task_description TEXT,
        required_docs TEXT, -- Comma-separated list or JSON
        priority ENUM('low', 'medium', 'high') DEFAULT 'low',
        status ENUM('not_started', 'pending_review', 'approved', 'rejected') DEFAULT 'not_started',
        admin_reason TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");

    // Feature Requests Table (Dedicated for Module Access)
    $pdo->exec("CREATE TABLE IF NOT EXISTS feature_requests (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        module_key VARCHAR(50) NOT NULL,
        module_name VARCHAR(100),
        status ENUM('pending', 'approved', 'rejected') DEFAULT 'pending',
        admin_reason TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");

    // Billing & Subscription History Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS billing (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        package_id INT NOT NULL,
        amount DECIMAL(15,2) NOT NULL,
        account_name VARCHAR(255),
        transaction_id VARCHAR(255) NOT NULL,
        current_plan_id INT DEFAULT NULL,
        current_expiry_date DATE DEFAULT NULL,
        billing_cycle VARCHAR(50) DEFAULT '1_month', -- Added billing cycle
        description TEXT,
        status ENUM('pending', 'active', 'rejected', 'expired') DEFAULT 'pending',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");
} catch (Exception $e) { /* Column might exist */ }

// 1. Change Tenant Status (Active/Inactive/Suspended/Locked)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'change_tenant_status') {
    $id = $_POST['id'];
    $new_status = $_POST['new_status'];

    $pdo->prepare("UPDATE tenants SET status = ? WHERE id = ?")->execute([$new_status, $id]);
    
    // Redirect to refresh page
    header("Location: manage_tenants.php?msg=status");
    exit;
}

// 1a. Toggle Verified Status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_verified') {
    $id = $_POST['id'];
    $current_val = $_POST['is_verified'];
    $new_val = ($current_val == 1) ? 0 : 1;

    $stmt = $pdo->prepare("UPDATE tenants SET is_verified = :v WHERE id = :id");
    $stmt->execute([':v' => $new_val, ':id' => $id]);
    
    header("Location: manage_tenants.php?msg=verified");
    exit;
}

// 1b. Toggle Featured Status
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_featured') {
    $id = $_POST['id'];
    $current_val = $_POST['is_featured'];
    $new_val = ($current_val == 1) ? 0 : 1;

    $stmt = $pdo->prepare("UPDATE tenants SET is_featured = :f WHERE id = :id");
    $stmt->execute([':f' => $new_val, ':id' => $id]);
    
    header("Location: manage_tenants.php?msg=featured");
    exit;
}

// 1c. Delete Tenant Branding Image (Logo/Shop)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_tenant_image') {
    $tenant_id = $_POST['tenant_id'];
    $img_type = $_POST['image_type']; // 'logo' or 'shop'
    
    $stmt = $pdo->prepare("SELECT logo_url, shop_image_url FROM tenants WHERE id = ?");
    $stmt->execute([$tenant_id]);
    $tenant_row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($tenant_row) {
        require_once '../config/CloudinaryStorage.php';
        $url = ($img_type === 'logo') ? $tenant_row['logo_url'] : $tenant_row['shop_image_url'];
        
        if (!empty($url)) {
            // Extract Cloudinary Public ID from URL
            $parts = explode('/', $url);
            $uploadIdx = array_search('upload', $parts);
            if ($uploadIdx !== false) {
                $start = $uploadIdx + 1;
                // Skip version string if present (starts with 'v')
                if (isset($parts[$start]) && strpos($parts[$start], 'v') === 0 && is_numeric(substr($parts[$start], 1))) {
                    $start++;
                }
                $id_with_ext = implode('/', array_slice($parts, $start));
                $public_id = explode('.', $id_with_ext)[0];
                deleteFromCloud($public_id);
            }
        }
        
        $col = ($img_type === 'logo') ? 'logo_url' : 'shop_image_url';
        $pdo->prepare("UPDATE tenants SET $col = NULL WHERE id = ?")->execute([$tenant_id]);
    }
    header("Location: manage_tenants.php?msg=image_deleted");
    exit;
}

// 1d. Push Verification Task
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'push_verification_task') {
    $target = $_POST['target_tenant']; // 'all' or tenant_id
    $title = $_POST['task_title'];
    $desc = $_POST['task_description'];
    $priority = $_POST['priority'];
    $docs = isset($_POST['required_docs']) ? implode(', ', $_POST['required_docs']) : '';

    try {
        if ($target === 'all') {
            $stmt_t = $pdo->query("SELECT id FROM tenants WHERE status = 'active'");
            $all_tids = $stmt_t->fetchAll(PDO::FETCH_COLUMN);
            $ins = $pdo->prepare("INSERT INTO verification_tasks (tenant_id, task_title, task_description, required_docs, priority) VALUES (?, ?, ?, ?, ?)");
            $notif_ins = $pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'verification_task')");
            foreach ($all_tids as $tid) {
                $ins->execute([$tid, $title, $desc, $docs, $priority]);
                $notif_ins->execute([$tid, "New Verification Task: " . $title, $desc]);
            }
        } else {
            $ins = $pdo->prepare("INSERT INTO verification_tasks (tenant_id, task_title, task_description, required_docs, priority) VALUES (?, ?, ?, ?, ?)");
            $ins->execute([$target, $title, $desc, $docs, $priority]);
            $pdo->prepare("INSERT INTO notifications (sender_id, tenant_id, title, message, type) VALUES (1, ?, ?, ?, 'verification_task')")->execute([$target, "New Verification Task: " . $title, $desc]);
        }
        header("Location: manage_tenants.php?msg=task_pushed");
    } catch (Exception $e) {
        header("Location: manage_tenants.php?msg=error&error=" . urlencode($e->getMessage()));
    }
    exit;
}

// 2. Fetch Tenant Database Stats (AJAX)
if (isset($_GET['action']) && $_GET['action'] === 'get_stats' && isset($_GET['db'])) {
    header('Content-Type: application/json');
    $tenant_db = $_GET['db'];
    
    try {
        // Fetch Global Admin Settings for Conversion
        $global_currency = 'USD';
        $global_symbol = '$';
        try {
            $stmt_admin = $pdo->query("SELECT setting_key, setting_value FROM system_settings");
            $admin_settings = $stmt_admin->fetchAll(PDO::FETCH_KEY_PAIR);
            $global_currency = $admin_settings['global_currency'] ?? 'USD';
            $global_symbol = $admin_settings['global_currency_symbol'] ?? '$';
        } catch (Exception $e) {}

        // Get Tenant Currency Code to calculate conversion
        $stmt_t = $pdo->prepare("SELECT currency_code FROM tenants WHERE db_name = ?");
        $stmt_t->execute([$tenant_db]);
        $tenant_currency = $stmt_t->fetchColumn() ?: 'USD';

        $rates = getExchangeRates();
        $admin_rate = $rates[$global_currency] ?? 1.0;
        $tenant_rate = $rates[$tenant_currency] ?? 1.0;

        // Connect to tenant specific DB
        $t_pdo = new PDO("mysql:host=".DB_HOST.";dbname=$tenant_db", DB_USER, DB_PASS);
        
        // Get Counts
        $products = $t_pdo->query("SELECT COUNT(*) FROM products")->fetchColumn();
        $sales = $t_pdo->query("SELECT COUNT(*) FROM sales")->fetchColumn();
        $raw_revenue = $t_pdo->query("SELECT SUM(total_amount) FROM sales")->fetchColumn() ?: 0;

        // Convert to Admin Global Currency
        $converted_revenue = ($raw_revenue / $tenant_rate) * $admin_rate;

        echo json_encode([
            'success' => true, 
            'products' => $products, 
            'sales' => $sales, 
            'revenue' => $converted_revenue,
            'symbol' => $global_symbol
        ]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => 'Could not connect to tenant DB: ' . $e->getMessage()]);
    }
    exit;
}

// 3. Update Tenant Details (Edit)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'edit_tenant') {
    $id = $_POST['tenant_id'];
    $business_name = $_POST['business_name'];
    $owner_name = $_POST['owner_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $industry_slug = $_POST['industry_type'];
    $package_id = $_POST['package_id'];
    $staff_limit = $_POST['staff_limit'];
    $branch_limit = $_POST['branch_limit'];
    $storage_limit = $_POST['storage_limit'];
    $password = $_POST['password'] ?? '';

    // Fetch Category ID for the selected industry
    $stmt = $pdo->prepare("SELECT id FROM business_categories WHERE slug = ?");
    $stmt->execute([$industry_slug]);
    $category_id = $stmt->fetchColumn();

    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $pdo->prepare("UPDATE tenants SET business_name = ?, owner_name = ?, email = ?, password = ?, phone = ?, address = ?, industry_type = ?, business_category_id = ?, package_id = ?, staff_limit = ?, branch_limit = ?, storage_limit = ? WHERE id = ?");
        $stmt->execute([$business_name, $owner_name, $email, $hashed_password, $phone, $address, $industry_slug, $category_id, $package_id, $staff_limit, $branch_limit, $storage_limit, $id]);
    } else {
        $stmt = $pdo->prepare("UPDATE tenants SET business_name = ?, owner_name = ?, email = ?, phone = ?, address = ?, industry_type = ?, business_category_id = ?, package_id = ?, staff_limit = ?, branch_limit = ?, storage_limit = ? WHERE id = ?");
        $stmt->execute([$business_name, $owner_name, $email, $phone, $address, $industry_slug, $category_id, $package_id, $staff_limit, $branch_limit, $storage_limit, $id]);
    }
    header("Location: manage_tenants.php?msg=edited");
    exit;
}

// 4. Delete Tenant Logic (Wipeout or Record only)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_tenant') {
    $id = $_POST['tenant_id'];
    $db_name = $_POST['db_name'];
    $delete_type = $_POST['delete_type']; // 'only_user' or 'complete'

    try {
        $pdo->beginTransaction();
        // Delete from main DB (Cascades will handle enabled_modules if configured, else manual delete)
        $pdo->prepare("DELETE FROM enabled_modules WHERE tenant_id = ?")->execute([$id]);
        $pdo->prepare("DELETE FROM tenants WHERE id = ?")->execute([$id]);
        $pdo->commit();

        // If complete wipeout, drop the database AFTER committing the record deletion.
        // This prevents the implicit commit issue in MySQL from breaking the PDO transaction.
        if ($delete_type === 'complete' && !empty($db_name)) {
            $pdo->exec("DROP DATABASE IF EXISTS `$db_name` ");
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        error_log("Delete Tenant Error: " . $e->getMessage());
    }
    header("Location: manage_tenants.php?msg=deleted");
    exit;
}

// Fetch Existing Tenant Data (Categories & Units) for Display
if (isset($_GET['action']) && $_GET['action'] === 'get_tenant_data' && isset($_GET['db'])) {
    header('Content-Type: application/json');
    $tenant_db = $_GET['db'];
    try {
        $t_pdo = new PDO("mysql:host=".DB_HOST.";dbname=$tenant_db", DB_USER, DB_PASS);
        
        // Self-healing using universal syntax
        $c_cols = $t_pdo->query("SHOW COLUMNS FROM categories")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('is_allowed', $c_cols)) $t_pdo->exec("ALTER TABLE categories ADD COLUMN is_allowed TINYINT(1) DEFAULT 1");

        $u_cols = $t_pdo->query("SHOW COLUMNS FROM units")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('is_allowed', $u_cols)) $t_pdo->exec("ALTER TABLE units ADD COLUMN is_allowed TINYINT(1) DEFAULT 1");

        $cats = $t_pdo->query("SELECT id, name, is_allowed FROM categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
        $units = $t_pdo->query("SELECT id, name, is_allowed FROM units ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
        echo json_encode([
            'success' => true,
            'categories' => $cats,
            'units' => $units
        ]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// 5a. Toggle Tenant Data Restriction
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'toggle_data_status') {
    $db = $_POST['db'];
    $type = $_POST['type']; 
    $id = $_POST['id'];
    $status = $_POST['status'];
    $table = ($type === 'category') ? 'categories' : 'units';
    try {
        $t_pdo = new PDO("mysql:host=".DB_HOST.";dbname=$db", DB_USER, DB_PASS);
        $stmt = $t_pdo->prepare("UPDATE $table SET is_allowed = ? WHERE id = ?");
        $stmt->execute([$status, $id]);
        echo json_encode(['success' => true]);
    } catch (Exception $e) { echo json_encode(['success' => false]); }
    exit;
}

// 5. Quick Add Category/Unit to Tenant DB
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'quick_add_tenant_data') {
    $tenant_id = $_POST['tenant_id'];
    $db_name = $_POST['db_name'];
    $type = $_POST['data_type']; // 'category' or 'unit'
    $value = trim($_POST['data_value']);

    if (!empty($value)) {
        try {
            // Connect directly to the specific tenant's DB
            $t_pdo = new PDO("mysql:host=".DB_HOST.";dbname=$db_name", DB_USER, DB_PASS);
            $t_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            
            if ($type === 'category') {
                $stmt = $t_pdo->prepare("INSERT INTO categories (name) VALUES (?)");
            } else {
                $stmt = $t_pdo->prepare("INSERT INTO units (name) VALUES (?)");
            }
            $stmt->execute([$value]);
            header("Location: manage_tenants.php?msg=data_added");
            exit;
        } catch (Exception $e) {
            $error_message = "Tenant DB Error: " . $e->getMessage();
        }
    }
}

// 5. Update Tenant Modules
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_modules') {
    $tenant_id = $_POST['tenant_id'];
    $modules = $_POST['modules'] ?? [];

    try {
        $pdo->beginTransaction();
        
        // Clear existing modules
        $stmt = $pdo->prepare("DELETE FROM enabled_modules WHERE tenant_id = ?");
        $stmt->execute([$tenant_id]);

        // Insert selected modules
        $stmt = $pdo->prepare("INSERT INTO enabled_modules (tenant_id, module_key) VALUES (?, ?)");
        foreach ($modules as $mod) {
            $stmt->execute([$tenant_id, $mod]);
        }

        // Sync feature_requests table:
        // Agar admin ne koi module disable (uncheck) kiya hai, toh uski 'approved' request delete kar do.
        // Is se woh feature tenant ke 'Explore' section mein wapas chala jayega.
        if (empty($modules)) {
            $pdo->prepare("DELETE FROM feature_requests WHERE tenant_id = ? AND status = 'approved'")->execute([$tenant_id]);
        } else {
            $placeholders = implode(',', array_fill(0, count($modules), '?'));
            $pdo->prepare("DELETE FROM feature_requests WHERE tenant_id = ? AND status = 'approved' AND module_key NOT IN ($placeholders)")
                ->execute(array_merge([$tenant_id], $modules));
        }

        $pdo->commit();
        header("Location: manage_tenants.php?msg=modules");
        exit;
    } catch (Exception $e) {
        $pdo->rollBack();
        $error_message = "Error updating modules: " . $e->getMessage();
    }
}

// 6. Fetch Tenant Modules (AJAX)
if (isset($_GET['action']) && $_GET['action'] === 'get_modules' && isset($_GET['id'])) {
    header('Content-Type: application/json');
    
    try {
        $mod_stmt = $pdo->prepare("SELECT module_key FROM enabled_modules WHERE tenant_id = ?");
        $mod_stmt->execute([$_GET['id']]);
        $modules = $mod_stmt->fetchAll(PDO::FETCH_COLUMN);

        echo json_encode(['success' => true, 'modules' => $modules]);
    } catch (Exception $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}

// 7. Add New Tenant (Admin Manual Creation)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'add_tenant') {
    $business_name = $_POST['business_name'];
    $owner_name = $_POST['owner_name'];
    $email = $_POST['email'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
    $phone = $_POST['phone'];
    $address = $_POST['address'];
    $industry_slug = $_POST['industry_type'];
    $package_id = $_POST['package_id'];
    $staff_limit = $_POST['staff_limit'] ?? 5;
    $branch_limit = $_POST['branch_limit'] ?? 1;
    $storage_limit = $_POST['storage_limit'] ?? 1;

    try {
        $pdo->beginTransaction();

        // Fetch Category ID
        $stmt = $pdo->prepare("SELECT id FROM business_categories WHERE slug = ?");
        $stmt->execute([$industry_slug]);
        $category_id = $stmt->fetchColumn();

        // Generate Unique ID
        $unique_id = '';
        while (true) {
            $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
            $res = '';
            for ($i = 0; $i < 6; $i++) { $res .= $chars[mt_rand(0, strlen($chars) - 1)]; }
            $temp_id = 'BTX-' . $res;
            $check = $pdo->prepare("SELECT COUNT(*) FROM tenants WHERE unique_id = ?");
            $check->execute([$temp_id]);
            if ($check->fetchColumn() == 0) { $unique_id = $temp_id; break; }
        }

        // Insert Tenant
        $stmt = $pdo->prepare("INSERT INTO tenants (unique_id, business_name, owner_name, email, password, industry_type, business_category_id, package_id, staff_limit, branch_limit, storage_limit, phone, address, db_name) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->execute([$unique_id, $business_name, $owner_name, $email, $password, $industry_slug, $category_id, $package_id, $staff_limit, $branch_limit, $storage_limit, $phone, $address, 'placeholder']);
        
        $tenant_id = $pdo->lastInsertId();

        // Generate DB Name
        $safe_name = preg_replace('/[^a-z0-9_]/', '', str_replace(' ', '_', strtolower($business_name)));
        if (empty($safe_name)) $safe_name = "client_" . $tenant_id;
        $new_db_name = "biltax_" . $safe_name . "_db";

        // Update Tenant DB Name
        $pdo->prepare("UPDATE tenants SET db_name = ? WHERE id = ?")->execute([$new_db_name, $tenant_id]);

        // Insert Selected Modules for the new tenant
        $selected_modules = $_POST['modules'] ?? [];
        $mod_stmt = $pdo->prepare("INSERT INTO enabled_modules (tenant_id, module_key) VALUES (?, ?)");
        foreach ($selected_modules as $mod_key) {
            $mod_stmt->execute([$tenant_id, $mod_key]);
        }

        // Create Database
        $pdo->exec("CREATE DATABASE `$new_db_name`");

        // Connect to New DB
        $t_pdo = new PDO("mysql:host=".DB_HOST.";dbname=$new_db_name", DB_USER, DB_PASS);
        $t_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        // Create Tables based on Industry
        switch (strtolower($industry_slug)) {
            case 'restaurant':
            case 'food':
                $t_pdo->exec("
                    CREATE TABLE IF NOT EXISTS categories (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL, is_allowed TINYINT(1) DEFAULT 1);
                    CREATE TABLE IF NOT EXISTS units (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50) NOT NULL, is_allowed TINYINT(1) DEFAULT 1);
                    INSERT INTO units (name) VALUES ('KG'), ('Liter'), ('Gram'), ('ML'), ('Piece'), ('Plate'), ('Bowl'), ('Box'), ('Dozen');
                    INSERT INTO categories (name) VALUES ('Appetizer'), ('Main Course'), ('Dessert'), ('Beverage'), ('Fast Food'), ('Salad');
                    
                    CREATE TABLE products (id INT PRIMARY KEY AUTO_INCREMENT, branch_id INT, name VARCHAR(255) NOT NULL, price DECIMAL(15, 2) NOT NULL DEFAULT 0.00, purchase_price DECIMAL(15, 2) DEFAULT 0.00, unit_id INT, category_id INT, category VARCHAR(100), description TEXT, stock_level DECIMAL(10,2) DEFAULT 0, is_raw TINYINT(1) DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    
                    CREATE TABLE recipes (id INT PRIMARY KEY AUTO_INCREMENT, product_id INT, ingredient_name VARCHAR(255), quantity VARCHAR(50), FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE);
                    CREATE TABLE IF NOT EXISTS restaurant_tables (id INT PRIMARY KEY AUTO_INCREMENT, branch_id INT, table_number VARCHAR(50) NOT NULL, capacity INT DEFAULT 2, status ENUM('available', 'occupied', 'reserved') DEFAULT 'available', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    CREATE TABLE sales (id INT PRIMARY KEY AUTO_INCREMENT, branch_id INT, total_amount DECIMAL(15,2) NOT NULL, payment_method VARCHAR(50) DEFAULT 'Cash', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    CREATE TABLE kot (id INT PRIMARY KEY AUTO_INCREMENT, sale_id INT, table_id INT, status ENUM('pending', 'preparing', 'served', 'cancelled') DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                ");
                break;
            case 'retail':
                $t_pdo->exec("
                    CREATE TABLE IF NOT EXISTS categories (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL);
                    CREATE TABLE IF NOT EXISTS units (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50) NOT NULL);
                    CREATE TABLE IF NOT EXISTS suppliers (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, company VARCHAR(100), phone VARCHAR(50), email VARCHAR(100), address TEXT);
                    INSERT INTO units (name) VALUES ('KG'), ('Liter'), ('Gram'), ('ML'), ('Piece'), ('Box'), ('Pack'), ('Dozen'), ('Meter'), ('Pair');
                    INSERT INTO categories (name) VALUES ('Electronics'), ('Grocery'), ('Clothing'), ('Pharmacy'), ('Stationery'), ('General');
                    CREATE TABLE products (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, sku VARCHAR(100) UNIQUE, barcode VARCHAR(100), sale_price DECIMAL(10, 2) NOT NULL, purchase_price DECIMAL(10, 2), category_id INT, unit_id INT, supplier_id INT, stock_level INT DEFAULT 0, alert_level INT DEFAULT 10, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP);
                    CREATE TABLE stock (id INT PRIMARY KEY AUTO_INCREMENT, product_id INT, quantity_change INT, reason VARCHAR(255), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (product_id) REFERENCES products(id));
                    CREATE TABLE sales (id INT PRIMARY KEY AUTO_INCREMENT, total_amount DECIMAL(10, 2) NOT NULL, discount_amount DECIMAL(10, 2) DEFAULT 0.00, payment_method VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    CREATE TABLE sale_items (id INT PRIMARY KEY AUTO_INCREMENT, sale_id INT, product_id INT, quantity INT, price DECIMAL(10, 2), FOREIGN KEY (sale_id) REFERENCES sales(id), FOREIGN KEY (product_id) REFERENCES products(id));");
                break;
            case 'wholesale':
            case 'service':
            case 'wholesale':
                $t_pdo->exec("CREATE TABLE products (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, sku VARCHAR(100), price DECIMAL(10, 2) NOT NULL, stock_quantity INT DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    CREATE TABLE party_ledgers (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, type ENUM('supplier', 'customer'), phone VARCHAR(50), balance DECIMAL(10, 2) DEFAULT 0.00, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    CREATE TABLE bulk_orders (id INT PRIMARY KEY AUTO_INCREMENT, party_id INT, total_amount DECIMAL(10, 2), status ENUM('pending', 'approved', 'shipped') DEFAULT 'pending', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (party_id) REFERENCES party_ledgers(id));");
                break;
            case 'service':
                $t_pdo->exec("CREATE TABLE customers (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, phone VARCHAR(50), email VARCHAR(100), address TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
                    CREATE TABLE job_cards (id INT PRIMARY KEY AUTO_INCREMENT, customer_id INT, description TEXT, status ENUM('received', 'in_progress', 'completed', 'delivered') DEFAULT 'received', estimated_cost DECIMAL(10, 2), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (customer_id) REFERENCES customers(id));
                    CREATE TABLE reminders (id INT PRIMARY KEY AUTO_INCREMENT, customer_id INT, message TEXT, due_date DATE, status ENUM('pending', 'sent') DEFAULT 'pending', FOREIGN KEY (customer_id) REFERENCES customers(id));");
                break;
        }

        $pdo->commit();
        header("Location: manage_tenants.php?msg=added");
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        $error_message = "Error: " . $e->getMessage();
    }
}

// --- Fetch All Tenants ---
$stmt = $pdo->query("SELECT * FROM tenants ORDER BY id DESC");
$tenants = $stmt->fetchAll(PDO::FETCH_ASSOC);

// --- Fetch Dropdowns ---
$categories = $pdo->query("SELECT * FROM business_categories WHERE is_active = 1")->fetchAll(PDO::FETCH_ASSOC);
$packages = $pdo->query("SELECT * FROM packages")->fetchAll(PDO::FETCH_ASSOC);
$available_modules = $pdo->query("SELECT * FROM modules WHERE status = 'active'")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Tenants - Biltax Super Admin</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <!-- Theme Logic -->
    <script src="../theme.js"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
        ::-webkit-scrollbar { width: 6px; }
        ::-webkit-scrollbar-track { background: #171717; }
        ::-webkit-scrollbar-thumb { background: #404040; border-radius: 10px; }
    </style>
</head>
<body class="bg-neutral-50 dark:bg-neutral-950 text-slate-900 dark:text-white min-h-screen flex transition-colors duration-300">

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Main Content Wrapper -->
    <div class="flex-1 ml-64 flex flex-col min-h-screen">
        
        <!-- Top Bar -->
        <?php include 'topbar.php'; ?>

        <!-- Tenants List Content -->
        <main class="p-8 flex-1 overflow-y-auto">
            <div class="max-w-7xl mx-auto">
                <header class="flex justify-between items-start mb-10">
                    <div>
                        <h1 class="text-2xl font-bold tracking-tight text-slate-900 dark:text-white">Manage Tenants</h1>
                        <p class="text-sm text-slate-500 dark:text-neutral-400">View, activate, or deactivate tenant accounts.</p>
                        <?php if (isset($error_message)): ?>
                            <p class="text-red-500 text-sm mt-2"><?php echo htmlspecialchars($error_message); ?></p>
                        <?php endif; ?>
                    </div>
                    <button onclick="document.getElementById('pushTaskModal').classList.replace('hidden', 'flex')" class="bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-xl font-bold text-sm flex items-center gap-2 shadow-lg shadow-indigo-900/20 transition-all whitespace-nowrap">
                        <i data-lucide="send" size="18"></i> Push Verification
                    </button>
                    <div class="text-right">
                        <p class="text-3xl font-black text-slate-900 dark:text-white"><?php echo count($tenants); ?></p>
                        <p class="text-xs text-slate-500 dark:text-neutral-500 uppercase tracking-wider">Total Tenants</p>
                    </div>
                </header>

                <!-- Success Messages -->
                <?php if (isset($_GET['msg'])): ?>
                    <div class="mb-8 p-4 bg-emerald-500/10 border border-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center gap-3 animate-pulse-once">
                        <div class="w-8 h-8 rounded-full bg-emerald-500/20 flex items-center justify-center">
                            <i data-lucide="check" size="18"></i>
                        </div>
                        <p class="text-sm font-bold">
                            <?php 
                                if($_GET['msg'] == 'added') echo "New business tenant registered successfully!";
                                elseif($_GET['msg'] == 'edited') echo "Tenant profile and credentials updated.";
                                elseif($_GET['msg'] == 'deleted') echo "Tenant record and database have been wiped out.";
                                elseif($_GET['msg'] == 'status') echo "Account status has been changed.";
                                elseif($_GET['msg'] == 'modules') echo "Feature modules for this tenant have been reconfigured.";
                                elseif($_GET['msg'] == 'data_added') echo "New data successfully injected into tenant database.";
                                elseif($_GET['msg'] == 'verified') echo "Trusted badge status updated for the business.";
                                elseif($_GET['msg'] == 'featured') echo "Featured status updated successfully.";
                                elseif($_GET['msg'] == 'image_deleted') echo "Tenant branding image has been removed from cloud storage and profile.";
                                elseif($_GET['msg'] == 'task_pushed') echo "Verification request has been broadcasted successfully.";
                                elseif($_GET['msg'] == 'error') echo "Operation failed: " . htmlspecialchars($_GET['error'] ?? 'Unknown error');
                            ?>
                        </p>
                    </div>
                <?php endif; ?>

                <!-- Tenants Table -->
                <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-2xl relative">
                    <table class="w-full text-left">
                        <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800 rounded-t-2xl">
                            <tr>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">ID</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Business / Database</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Owner Info</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Industry</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500">Status</th>
                                <th class="px-6 py-4 text-xs font-bold uppercase text-slate-500 dark:text-neutral-500 text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                            <?php foreach ($tenants as $t): ?>
                            <tr class="hover:bg-slate-50 dark:hover:bg-neutral-800/50 transition-colors relative hover:z-20">
                                <td class="px-6 py-4 text-slate-500 dark:text-neutral-400">#<?php echo $t['id']; ?></td>
                                <td class="px-6 py-4">
                                    <p class="font-bold text-slate-900 dark:text-white"><?php echo htmlspecialchars($t['business_name']); ?></p>
                                    <div class="flex gap-2 mt-1">
                                    <?php if ($t['is_verified']): ?>
                                        <span class="inline-flex items-center gap-1 text-[9px] font-black uppercase text-blue-500">
                                            <i data-lucide="badge-check" size="10"></i> Trusted
                                        </span>
                                    <?php endif; ?>
                                    <?php if ($t['is_featured']): ?>
                                        <span class="inline-flex items-center gap-1 text-[9px] font-black uppercase text-orange-500">
                                            <i data-lucide="zap" size="10"></i> Featured
                                        </span>
                                    <?php endif; ?>
                                    </div>
                                    <p class="text-xs text-slate-500 dark:text-neutral-500 font-mono mt-1"><?php echo htmlspecialchars($t['db_name']); ?></p>
                                </td>
                                <td class="px-6 py-4">
                                    <p class="text-sm text-slate-700 dark:text-neutral-300"><?php echo htmlspecialchars($t['owner_name']); ?></p>
                                    <p class="text-xs text-slate-500 dark:text-neutral-500"><?php echo htmlspecialchars($t['email']); ?></p>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-100 dark:bg-neutral-800 text-slate-600 dark:text-neutral-300 border border-slate-200 dark:border-neutral-700 capitalize">
                                        <?php echo htmlspecialchars($t['industry_type']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <?php if ($t['status'] === 'active'): ?>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-green-100 dark:bg-green-500/10 text-green-600 dark:text-green-500 border border-green-200 dark:border-green-500/20">Active</span>
                                    <?php else: ?>
                                        <span class="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-red-100 dark:bg-red-500/10 text-red-600 dark:text-red-500 border border-red-200 dark:border-red-500/20">Inactive</span>
                                    <?php endif; ?>
                                </td>
                                <td class="px-6 py-4 text-right">
                                    <div class="inline-block text-left group relative">
                                        <button class="flex items-center gap-1 px-3 py-2 bg-slate-100 dark:bg-neutral-800 rounded-xl text-xs font-bold hover:bg-orange-600 hover:text-white transition-all">
                                            Actions <i data-lucide="chevron-down" size="14"></i>
                                        </button>
                                        <div class="absolute right-0 top-full mt-0 w-48 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-xl shadow-xl z-[100] hidden group-hover:block overflow-hidden">
                                            <button onclick='openEditModal(<?php echo htmlspecialchars(json_encode($t), ENT_QUOTES, "UTF-8"); ?>)' class="w-full text-left px-4 py-2.5 text-xs font-bold hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2"><i data-lucide="edit-3" size="14"></i> Edit Tenant</button>
                                            <button onclick="manageModules(<?php echo $t['id']; ?>, '<?php echo htmlspecialchars($t['business_name']); ?>')" class="w-full text-left px-4 py-2.5 text-xs font-bold hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2"><i data-lucide="layers" size="14"></i> Manage Modules</button>
                                            <button onclick='openQuickAddDataModal(<?php echo htmlspecialchars(json_encode($t), ENT_QUOTES, "UTF-8"); ?>)' class="w-full text-left px-4 py-2.5 text-xs font-bold hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2 border-b border-slate-100 dark:border-neutral-800"><i data-lucide="plus-square" size="14"></i> Add Cat/Unit (DB)</button>
                                            <form method="POST">
                                                <input type="hidden" name="action" value="toggle_verified">
                                                <input type="hidden" name="id" value="<?php echo $t['id']; ?>">
                                                <input type="hidden" name="is_verified" value="<?php echo $t['is_verified']; ?>">
                                                <button type="submit" class="w-full text-left px-4 py-2.5 text-xs font-bold hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2 <?php echo $t['is_verified'] ? 'text-slate-400' : 'text-blue-500'; ?>">
                                                    <i data-lucide="badge-check" size="14"></i> <?php echo $t['is_verified'] ? 'Remove Trusted' : 'Give Trusted Badge'; ?>
                                                </button>
                                            </form>
                                            <form method="POST">
                                                <input type="hidden" name="action" value="toggle_featured">
                                                <input type="hidden" name="id" value="<?php echo $t['id']; ?>">
                                                <input type="hidden" name="is_featured" value="<?php echo $t['is_featured']; ?>">
                                                <button type="submit" class="w-full text-left px-4 py-2.5 text-xs font-bold hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2 <?php echo $t['is_featured'] ? 'text-slate-400' : 'text-orange-500'; ?>">
                                                    <i data-lucide="zap" size="14"></i> <?php echo $t['is_featured'] ? 'Remove Featured' : 'Mark as Featured'; ?>
                                                </button>
                                            </form>
                                            <button onclick="viewStats('<?php echo $t['db_name']; ?>', '<?php echo htmlspecialchars($t['business_name']); ?>')" class="w-full text-left px-4 py-2.5 text-xs font-bold hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2"><i data-lucide="bar-chart-2" size="14"></i> View Stats</button>
                                            <button onclick='openStatusModal(<?php echo htmlspecialchars(json_encode($t), ENT_QUOTES, "UTF-8"); ?>)' class="w-full text-left px-4 py-2.5 text-xs font-bold text-amber-500 hover:bg-slate-50 dark:hover:bg-neutral-800 flex items-center gap-2 border-t border-slate-100 dark:border-neutral-800">
                                                <i data-lucide="power" size="14"></i> Change Status
                                            </button>
                                            <button onclick='openDeleteModal(<?php echo htmlspecialchars(json_encode($t), ENT_QUOTES, "UTF-8"); ?>)' class="w-full text-left px-4 py-2.5 text-xs font-bold text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 flex items-center gap-2 border-t border-slate-100 dark:border-neutral-800">
                                                <i data-lucide="trash-2" size="14"></i> Delete Tenant
                                            </button>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <!-- Stats Modal -->
    <div id="statsModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-2xl w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('statsModal').classList.add('hidden')" class="absolute top-4 right-4 text-slate-400 hover:text-slate-900 dark:hover:text-white"><i data-lucide="x" size="20"></i></button>
            
            <h3 id="modalTitle" class="text-xl font-bold mb-1 text-slate-900 dark:text-white">Database Stats</h3>
            <p class="text-xs text-slate-500 dark:text-neutral-500 mb-6 font-mono" id="modalDb"></p>

            <div class="grid grid-cols-2 gap-4">
                <div class="bg-slate-50 dark:bg-neutral-950 p-4 rounded-xl border border-slate-200 dark:border-neutral-800">
                    <p class="text-xs text-slate-500 dark:text-neutral-500 uppercase">Products</p>
                    <p class="text-2xl font-bold text-slate-900 dark:text-white mt-1" id="statProducts">-</p>
                </div>
                <div class="bg-slate-50 dark:bg-neutral-950 p-4 rounded-xl border border-slate-200 dark:border-neutral-800">
                    <p class="text-xs text-slate-500 dark:text-neutral-500 uppercase">Total Sales</p>
                    <p class="text-2xl font-bold text-slate-900 dark:text-white mt-1" id="statSales">-</p>
                </div>
                <div class="bg-slate-50 dark:bg-neutral-950 p-4 rounded-xl border border-slate-200 dark:border-neutral-800 col-span-2">
                    <p class="text-xs text-slate-500 dark:text-neutral-500 uppercase">Total Revenue</p>
                    <p class="text-3xl font-black text-green-600 dark:text-green-500 mt-1" id="statRevenue">-</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Manage Modules Modal -->
    <div id="modulesModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-2xl w-full max-w-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button onclick="document.getElementById('modulesModal').classList.add('hidden')" class="absolute top-4 right-4 text-slate-400 hover:text-slate-900 dark:hover:text-white"><i data-lucide="x" size="20"></i></button>
            
            <h3 class="text-xl font-bold mb-1 text-slate-900 dark:text-white">Manage Modules</h3>
            <p class="text-xs text-slate-500 dark:text-neutral-500 mb-6" id="moduleModalTitle">Customize features for this tenant</p>

            <form method="POST">
                <input type="hidden" name="action" value="update_modules">
                <input type="hidden" name="tenant_id" id="modTenantId">

                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <!-- Core Modules -->
                    <div class="space-y-3">
                        <h4 class="text-xs font-bold uppercase text-orange-500">Core Features</h4>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="dashboard" checked onclick="return false;" class="accent-orange-600"> Dashboard (Required)</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="settings" checked onclick="return false;" class="accent-orange-600"> Settings (Required)</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="reports" class="accent-orange-600 module-check"> Reports & Analytics</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="staff" class="accent-orange-600 module-check"> Staff Management</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="business_logo" class="accent-orange-600 module-check"> Business Logo</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="shop_image_upload" class="accent-orange-600 module-check"> Shop Image Upload</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="verification_center" class="accent-orange-600 module-check"> Verification Center</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="manage_branches" class="accent-orange-600 module-check"> Store & Branches (Multi-Store)</label>
                    </div>

                    <!-- POS & Retail -->
                    <div class="space-y-3">
                        <h4 class="text-xs font-bold uppercase text-blue-500">POS & Retail</h4>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="food_pos" class="accent-orange-600 module-check"> Food POS</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="retail_pos" class="accent-orange-600 module-check"> Retail POS</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="wholesale_pos" class="accent-orange-600 module-check"> Wholesale POS</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="service_pos" class="accent-orange-600 module-check"> Service POS</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="sales_reports" class="accent-orange-600 module-check"> Sales Reports</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="receipt_reprint" class="accent-orange-600 module-check"> Receipt Reprint</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="barcodes" class="accent-orange-600 module-check"> Barcode Scanner</label>
                    </div>

                    <!-- Inventory & Supply -->
                    <div class="space-y-3">
                        <h4 class="text-xs font-bold uppercase text-green-500">Inventory & Supply</h4>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="inventory" class="accent-orange-600 module-check"> Inventory Management</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="suppliers" class="accent-orange-600 module-check"> Suppliers</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="purchases" class="accent-orange-600 module-check"> Purchases</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="b2b_orders" class="accent-orange-600 module-check"> B2B Orders</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="marketplace_main" class="accent-orange-600 module-check"> Biltax Hub (Main)</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="biltax_hub" class="accent-orange-600 module-check"> Marketplace</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="shop_module" class="accent-orange-600 module-check"> Shop</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="pos_returns" class="accent-orange-600 module-check"> POS Returns</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="b2b_returns" class="accent-orange-600 module-check"> B2B Returns</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="vendors" class="accent-orange-600 module-check"> Vendors Management</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="marketplace_listing_visibility" class="accent-orange-600 module-check"> Marketplace Visibility Slider</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="vendor_orders" class="accent-orange-600 module-check"> Vendor Orders</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="marketplace" class="accent-orange-600 module-check"> Marketplace Listing</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="raw_material_system" class="accent-orange-600 module-check"> Raw Material System</label>
                    </div>

                    <!-- Industry Specific -->
                    <div class="space-y-3">
                        <h4 class="text-xs font-bold uppercase text-purple-500">Specialized Features</h4>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="tables" class="accent-orange-600 module-check"> Table Management (Rest.)</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="kot" class="accent-orange-600 module-check"> Kitchen Orders / KOT</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="recipes" class="accent-orange-600 module-check"> Recipes & Ingredients</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="bulk_sales" class="accent-orange-600 module-check"> Bulk Sales (Wholesale)</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="ledgers" class="accent-orange-600 module-check"> Party Ledgers (Udhaar)</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="partner_network" class="accent-orange-600 module-check"> Partner Network (B2B)</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="b2b_chat" class="accent-orange-600 module-check"> B2B Chat System</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="chat_images" class="accent-orange-600 module-check"> Chat Image Sharing</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="live_chat" class="accent-orange-600 module-check"> Live Chat Support</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="jobs" class="accent-orange-600 module-check"> Service Jobs</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="customers" class="accent-orange-600 module-check"> CRM / Customers</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="reminders" class="accent-orange-600 module-check"> Auto Reminders</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="payment_qr" class="accent-orange-600 module-check"> Payment QR Generator</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="whatsapp_email_sharing" class="accent-orange-600 module-check"> WhatsApp & Email Sharing</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="invoice_builder" class="accent-orange-600 module-check"> Custom Invoice Builder</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="rider_tracking" class="accent-orange-600 module-check"> Rider Tracking System</label>
                    </div>

                    <!-- Finance And Accounts -->
                    <div class="space-y-3">
                        <h4 class="text-xs font-bold uppercase text-purple-500">Finance & Accounts</h4>
                       <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="finance_management" class="accent-orange-600 module-check"> Finance Core</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="payroll_system" class="accent-orange-600 module-check"> Payroll System</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="expense_tracker" class="accent-orange-600 module-check"> Expense Tracker</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="accounts_payable" class="accent-orange-600 module-check"> Accounts Payable</label>
                    </div>

                    <!-- Support Modules -->
                    <div class="space-y-3">
                        <h4 class="text-xs font-bold uppercase text-red-500">Support & Help</h4>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="support_tickets" class="accent-orange-600 module-check"> Support Tickets</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="documentation" class="accent-orange-600 module-check"> Documentation</label>
                        <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="knowledge_base" class="accent-orange-600 module-check"> Knowledge Base</label>
                    </div>
                </div>

                <div class="mt-8 pt-4 border-t border-slate-100 dark:border-neutral-800 flex justify-end gap-3">
                    <button type="button" onclick="document.getElementById('modulesModal').classList.add('hidden')" class="px-4 py-2 text-sm font-bold text-slate-500 hover:text-slate-900 dark:text-neutral-400 dark:hover:text-white transition-colors">Cancel</button>
                    <button type="submit" class="bg-slate-900 dark:bg-white text-white dark:text-black hover:opacity-90 px-6 py-2 rounded-xl font-bold text-sm transition-all shadow-lg">Save Configuration</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Add Tenant Modal -->
    <div id="addTenantModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-2xl w-full max-w-2xl shadow-2xl relative max-h-[90vh] overflow-y-auto">
            <button onclick="document.getElementById('addTenantModal').classList.add('hidden')" class="absolute top-4 right-4 text-slate-400 hover:text-slate-900 dark:hover:text-white"><i data-lucide="x" size="20"></i></button>
            
            <h3 class="text-xl font-bold mb-6 text-slate-900 dark:text-white">Add New Tenant</h3>
            
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="add_tenant">
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Business Name</label>
                        <input type="text" name="business_name" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Owner Name</label>
                        <input type="text" name="owner_name" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Email</label>
                        <input type="email" name="email" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Password</label>
                        <input type="password" name="password" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Phone</label>
                        <input type="text" name="phone" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">City / Address</label>
                        <input type="text" name="address" class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                    </div>
                </div>
                <div class="grid grid-cols-4 gap-4">
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Industry</label>
                        <select name="industry_type" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['slug']; ?>"><?php echo htmlspecialchars($cat['category_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Package</label>
                        <select name="package_id" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white">
                            <?php foreach ($packages as $pkg): ?>
                                <option value="<?php echo $pkg['id']; ?>"><?php echo htmlspecialchars($pkg['package_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Staff Limit</label>
                        <input type="number" name="staff_limit" value="5" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white font-bold text-orange-600">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Branch Limit</label>
                        <input type="number" name="branch_limit" value="1" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white font-bold text-blue-600">
                    </div>
                    <div>
                        <label class="block text-xs font-bold uppercase mb-1 text-slate-500 dark:text-neutral-500">Storage (MB)</label>
                        <input type="number" name="storage_limit" value="1" required class="w-full px-3 py-2 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-lg outline-none text-slate-900 dark:text-white font-bold text-purple-600">
                    </div>
                </div>

                <!-- Enable Modules Section -->
                <div class="pt-6 border-t border-slate-100 dark:border-neutral-800">
                    <h4 class="text-xs font-bold uppercase text-orange-500 mb-4">Assign Industry Modules & POS</h4>
                    <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <div class="space-y-2">
                            <p class="text-[10px] font-black text-slate-400 uppercase tracking-tighter">POS Terminals</p>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="food_pos" class="w-4 h-4 accent-orange-600 rounded"> Food POS
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="retail_pos" class="w-4 h-4 accent-orange-600 rounded"> Retail POS
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="wholesale_pos" class="w-4 h-4 accent-orange-600 rounded"> Wholesale POS
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="service_pos" class="w-4 h-4 accent-orange-600 rounded"> Service POS
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="receipt_reprint" class="w-4 h-4 accent-orange-600 rounded"> Receipt Reprint
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="inventory" class="w-4 h-4 accent-orange-600 rounded"> Inventory
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="staff" class="w-4 h-4 accent-orange-600 rounded"> Staff Management
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="business_logo" class="w-4 h-4 accent-orange-600 rounded"> Business Logo
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="shop_image_upload" class="w-4 h-4 accent-orange-600 rounded"> Shop Image Upload
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="verification_center" class="w-4 h-4 accent-orange-600 rounded"> Verification Center
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="manage_branches" class="w-4 h-4 accent-orange-600 rounded"> Store & Branches
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="purchases" class="w-4 h-4 accent-orange-600 rounded"> Purchases
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="b2b_orders" class="w-4 h-4 accent-orange-600 rounded"> B2B Orders
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="marketplace_main" class="w-4 h-4 accent-orange-600 rounded"> Biltax Hub (Main)
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="biltax_hub" class="w-4 h-4 accent-orange-600 rounded"> Marketplace
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="pos_returns" class="w-4 h-4 accent-orange-600 rounded"> POS Returns
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="b2b_returns" class="w-4 h-4 accent-orange-600 rounded"> B2B Returns
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="raw_material_system" class="w-4 h-4 accent-orange-600 rounded"> Raw Material System
                            </label>
                        </div>
                        <div class="space-y-2">
                            <p class="text-[10px] font-black text-slate-400 uppercase tracking-tighter">Specialized</p>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="shop_module" class="w-4 h-4 accent-orange-600 rounded"> Shop
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="tables" class="w-4 h-4 accent-orange-600 rounded"> Restaurant Tables
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="ledgers" class="w-4 h-4 accent-orange-600 rounded"> Party Ledgers
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="partner_network" class="w-4 h-4 accent-orange-600 rounded"> Partner Network
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="b2b_chat" class="w-4 h-4 accent-orange-600 rounded"> B2B Chat System
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="chat_images" class="w-4 h-4 accent-orange-600 rounded"> Chat Image Sharing
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="live_chat" class="w-4 h-4 accent-orange-600 rounded"> Live Chat Support
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="jobs" class="w-4 h-4 accent-orange-600 rounded"> Service Jobs
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="marketplace" class="w-4 h-4 accent-orange-600 rounded"> Marketplace Listing
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="marketplace_listing_visibility" class="w-4 h-4 accent-orange-600 rounded"> Marketplace Visibility Slider
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="vendors" class="w-4 h-4 accent-orange-600 rounded"> Vendors Management
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="vendor_orders" class="w-4 h-4 accent-orange-600 rounded"> Vendor Orders History
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="payment_qr" class="w-4 h-4 accent-orange-600 rounded"> Payment QR Generator
                            </label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="invoice_builder" class="w-4 h-4 accent-orange-600 rounded"> Custom Invoice Builder
                            </label>                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300 cursor-pointer hover:bg-slate-50 dark:hover:bg-neutral-800 p-1 rounded transition-colors">
                                <input type="checkbox" name="modules[]" value="rider_tracking" class="w-4 h-4 accent-orange-600 rounded"> Rider Tracking System
                            </label>
                        </div>

                        <!-- Finance And Accounts -->
                        <div class="space-y-3">
                            <h4 class="text-xs font-bold uppercase text-purple-500">Financials</h4>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="finance_management" class="accent-orange-600"> Finance Core</label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="payroll_system" class="w-4 h-4 accent-orange-600 rounded"> Payroll System</label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="expense_tracker" class="w-4 h-4 accent-orange-600 rounded"> Expense Tracker</label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="finance_reports" class="w-4 h-4 accent-orange-600 rounded"> Finance Reports</label>
                            <label class="flex items-center gap-2 text-sm text-slate-700 dark:text-slate-300"><input type="checkbox" name="modules[]" value="accounts_payable" class="w-4 h-4 accent-orange-600 rounded"> Accounts Payable</label>
                        </div>
                    </div>
                </div>

                <div class="flex gap-4 pt-6">
                    <button type="button" onclick="document.getElementById('addTenantModal').classList.add('hidden'); document.getElementById('addTenantModal').classList.remove('flex')" class="flex-1 py-3 text-sm font-bold text-slate-500">Cancel</button>
                    <button type="submit" class="flex-[2] bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-xl shadow-lg shadow-orange-600/20 transition-all active:scale-95">Create Tenant Account</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Edit Tenant Modal -->
    <div id="editTenantModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-2xl w-full max-w-xl shadow-2xl relative">
            <button onclick="document.getElementById('editTenantModal').classList.add('hidden')" class="absolute top-4 right-4 text-slate-400 hover:text-white"><i data-lucide="x" size="20"></i></button>
            <h3 class="text-xl font-bold mb-6 text-slate-900 dark:text-white">Edit Tenant Details</h3>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="edit_tenant">
                <input type="hidden" name="tenant_id" id="edit_tenant_id">

                <!-- Image Previews with Delete -->
                <div class="grid grid-cols-2 gap-4">
                    <div id="edit_logo_preview_container" class="hidden p-3 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <img id="edit_logo_img" src="" class="w-10 h-10 object-contain rounded-lg border bg-white p-1">
                            <span class="text-[9px] font-black uppercase text-slate-400">Logo</span>
                        </div>
                        <button type="button" onclick="deleteImage('logo')" class="text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-2 rounded-lg transition-all"><i data-lucide="trash-2" size="14"></i></button>
                    </div>
                    <div id="edit_shop_preview_container" class="hidden p-3 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-200 dark:border-neutral-800 flex items-center justify-between">
                        <div class="flex items-center gap-2">
                            <img id="edit_shop_img" src="" class="w-10 h-10 object-cover rounded-lg border bg-white">
                            <span class="text-[9px] font-black uppercase text-slate-400">Shop</span>
                        </div>
                        <button type="button" onclick="deleteImage('shop')" class="text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-500/10 p-2 rounded-lg transition-all"><i data-lucide="trash-2" size="14"></i></button>
                    </div>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Business Name</label>
                        <input type="text" name="business_name" id="edit_business_name" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Owner Name</label>
                        <input type="text" name="owner_name" id="edit_owner_name" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Email Address</label>
                    <input type="email" name="email" id="edit_email" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm font-mono">
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">New Password (Leave blank to keep current)</label>
                    <input type="password" name="password" placeholder="••••••••" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Phone</label>
                        <input type="text" name="phone" id="edit_phone" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Address</label>
                        <input type="text" name="address" id="edit_address" class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                    </div>
                </div>
                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Industry</label>
                        <select name="industry_type" id="edit_industry_type" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?php echo $cat['slug']; ?>"><?php echo htmlspecialchars($cat['category_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Package</label>
                        <select name="package_id" id="edit_package_id" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                            <?php foreach ($packages as $pkg): ?>
                                <option value="<?php echo $pkg['id']; ?>"><?php echo htmlspecialchars($pkg['package_name']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                <div class="grid grid-cols-3 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Staff Limit</label>
                        <input type="number" name="staff_limit" id="edit_staff_limit" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm font-bold text-orange-600">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Branch Limit</label>
                        <input type="number" name="branch_limit" id="edit_branch_limit" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm font-bold text-blue-600">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Storage (MB)</label>
                        <input type="number" name="storage_limit" id="edit_storage_limit" required class="w-full px-3 py-2.5 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm font-bold text-purple-600">
                    </div>
                </div>
                <button type="submit" class="w-full bg-orange-600 hover:bg-orange-700 text-white font-bold py-3 rounded-xl transition-all shadow-lg shadow-orange-600/20">Update Tenant Account</button>
            </form>
        </div>
    </div>

    <!-- Change Status Modal -->
    <div id="statusModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('statusModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500 transition-colors"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Update Status</h2>
            <p class="text-xs text-orange-500 font-bold uppercase tracking-widest mb-6">Change Access Level</p>
            
            <div class="space-y-4 mb-6 p-4 bg-slate-50 dark:bg-neutral-950 rounded-3xl border border-slate-100 dark:border-neutral-800">
                <div><p class="text-[9px] font-black uppercase text-slate-400">Business</p><p id="status_biz_name" class="text-sm font-bold dark:text-white"></p></div>
                <div class="flex justify-between">
                    <div><p class="text-[9px] font-black uppercase text-slate-400">Unique ID</p><p id="status_unique_id" class="text-xs font-mono font-bold text-orange-600"></p></div>
                    <div class="text-right"><p class="text-[9px] font-black uppercase text-slate-400">Email</p><p id="status_email" class="text-xs font-bold dark:text-slate-300"></p></div>
                </div>
            </div>

            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="change_tenant_status">
                <input type="hidden" name="id" id="status_tenant_id">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2 ml-1">Account Status</label>
                    <select name="new_status" id="status_dropdown" required class="w-full px-5 py-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none focus:border-orange-500 transition-all text-sm font-bold dark:text-white">
                        <option value="active">Active (Normal Access)</option>
                        <option value="inactive">Inactive (Locked / No Action)</option>
                        <option value="suspended">Suspended (Blocked Screen)</option>
                        <option value="locked">Locked (Subscription Expired)</option>
                    </select>
                </div>
                <button type="submit" class="w-full py-4 bg-slate-900 dark:bg-white text-white dark:text-black rounded-2xl font-black uppercase tracking-widest shadow-xl active:scale-95 transition-all mt-4">Save Status</button>
            </form>
        </div>
    </div>

    <!-- Quick Add Tenant Data Modal -->
    <div id="quickDataModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl w-full max-w-md shadow-2xl relative">
            <button onclick="document.getElementById('quickDataModal').classList.add('hidden')" class="absolute top-4 right-4 text-slate-400 hover:text-white"><i data-lucide="x" size="20"></i></button>
            
            <div class="text-center mb-6">
                <div class="w-16 h-16 bg-blue-500/10 text-blue-500 rounded-full flex items-center justify-center mx-auto mb-4">
                    <i data-lucide="database" size="32"></i>
                </div>
                <h3 class="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Inject DB Data</h3>
                <p class="text-xs text-slate-500 mt-1" id="quickDataBizName"></p>
            </div>

            <form method="POST" class="space-y-4">
                <input type="hidden" name="action" value="quick_add_tenant_data">
                <input type="hidden" name="tenant_id" id="qd_tenant_id">
                <input type="hidden" name="db_name" id="qd_db_name">

                <div>
                    <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Data Type</label>
                    <select name="data_type" id="qd_data_type" onchange="toggleExistingDataList()" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm font-bold text-orange-500">
                        <option value="category">New Category</option>
                        <option value="unit">New Unit of Measure</option>
                    </select>
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase mb-1 text-slate-500">Value / Name</label>
                    <input type="text" name="data_value" placeholder="e.g. Household or Carton" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none text-sm">
                </div>

                <!-- Existing Items Display -->
                <div class="p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl">
                    <p class="text-[10px] font-black uppercase text-slate-400 mb-2 tracking-widest">Database Items (Check to Allow)</p>
                    <div id="existingDataList" class="flex flex-wrap gap-1.5 max-h-32 overflow-y-auto">
                        <!-- Items injected here -->
                    </div>
                </div>

                <button type="submit" class="w-full bg-slate-900 dark:bg-white text-white dark:text-black font-black py-4 rounded-2xl transition-all shadow-lg active:scale-95 text-sm uppercase tracking-widest mt-2">Add to Tenant DB</button>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-3xl w-full max-w-md shadow-2xl relative text-center">
            <div class="w-20 h-20 bg-rose-50 dark:bg-rose-500/10 text-rose-500 rounded-full flex items-center justify-center mx-auto mb-6">
                <i data-lucide="alert-triangle" size="40"></i>
            </div>
            <h3 class="text-xl font-black text-slate-900 dark:text-white uppercase tracking-tight">Delete Business</h3>
            <p class="text-sm text-slate-500 mt-2 mb-8">Are you sure you want to delete <span id="del_biz_name" class="font-bold text-orange-500"></span>? This action cannot be reversed.</p>
            
            <form method="POST" class="space-y-3">
                <input type="hidden" name="action" value="delete_tenant">
                <input type="hidden" name="tenant_id" id="del_tenant_id">
                <input type="hidden" name="db_name" id="del_db_name">
                
                <button type="submit" name="delete_type" value="only_user" class="w-full py-3 bg-slate-100 dark:bg-neutral-800 text-slate-900 dark:text-white font-bold rounded-xl hover:bg-slate-200 transition-all text-sm">Delete Record Only</button>
                <button type="submit" name="delete_type" value="complete" class="w-full py-3 bg-rose-600 text-white font-bold rounded-xl hover:bg-rose-700 transition-all shadow-lg shadow-rose-600/20 text-sm">Wipeout Record & Database</button>
                <button type="button" onclick="document.getElementById('deleteModal').classList.add('hidden')" class="w-full py-2 text-xs font-bold text-slate-400 hover:text-slate-600">Keep Business</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();

        async function viewStats(dbName, businessName) {
            document.getElementById('statsModal').classList.remove('hidden');
            document.getElementById('statsModal').classList.add('flex');
            document.getElementById('modalTitle').innerText = businessName;
            document.getElementById('modalDb').innerText = dbName;

            const res = await fetch(`manage_tenants.php?action=get_stats&db=${dbName}`);
            const data = await res.json();

            if(data.success) {
                document.getElementById('statProducts').innerText = data.products;
                document.getElementById('statSales').innerText = data.sales;
                document.getElementById('statRevenue').innerText = data.symbol + parseFloat(data.revenue).toFixed(2);
            } else {
                alert('Error fetching stats: ' + data.message);
            }
        }

        async function manageModules(id, businessName) {
            document.getElementById('modulesModal').classList.remove('hidden');
            document.getElementById('modulesModal').classList.add('flex');
            document.getElementById('moduleModalTitle').innerText = 'Editing features for: ' + businessName;
            document.getElementById('modTenantId').value = id;

            // Reset checkboxes
            document.querySelectorAll('.module-check').forEach(c => c.checked = false);

            // Fetch current modules
            const res = await fetch(`manage_tenants.php?action=get_modules&id=${id}`);
            const data = await res.json();

            if(data.success) {
                data.modules.forEach(mod => {
                    const checkbox = document.querySelector(`input[value="${mod}"]`);
                    if(checkbox) checkbox.checked = true;
                });
            }
        }

        function openStatusModal(tenant) {
            document.getElementById('statusModal').classList.remove('hidden');
            document.getElementById('statusModal').classList.add('flex');
            
            document.getElementById('status_tenant_id').value = tenant.id;
            document.getElementById('status_biz_name').innerText = tenant.business_name;
            document.getElementById('status_unique_id').innerText = tenant.unique_id;
            document.getElementById('status_email').innerText = tenant.email;
            document.getElementById('status_dropdown').value = tenant.status;
            
            lucide.createIcons();
        }

        function openEditModal(tenant) {
            document.getElementById('editTenantModal').classList.remove('hidden');
            document.getElementById('editTenantModal').classList.add('flex');
            
            document.getElementById('edit_tenant_id').value = tenant.id;
            document.getElementById('edit_business_name').value = tenant.business_name;
            document.getElementById('edit_owner_name').value = tenant.owner_name;
            document.getElementById('edit_email').value = tenant.email;
            document.getElementById('edit_phone').value = tenant.phone || '';
            document.getElementById('edit_address').value = tenant.address || '';
            document.getElementById('edit_industry_type').value = tenant.industry_type;
            document.getElementById('edit_package_id').value = tenant.package_id;
            document.getElementById('edit_staff_limit').value = tenant.staff_limit || 5;
            document.getElementById('edit_branch_limit').value = tenant.branch_limit || 1;
            document.getElementById('edit_storage_limit').value = tenant.storage_limit || 1;

            // Image Previews
            const logoCont = document.getElementById('edit_logo_preview_container');
            const shopCont = document.getElementById('edit_shop_preview_container');
            
            if (tenant.logo_url) {
                logoCont.classList.remove('hidden');
                document.getElementById('edit_logo_img').src = tenant.logo_url;
            } else {
                logoCont.classList.add('hidden');
            }

            if (tenant.shop_image_url) {
                shopCont.classList.remove('hidden');
                document.getElementById('edit_shop_img').src = tenant.shop_image_url;
            } else {
                shopCont.classList.add('hidden');
            }
            
            lucide.createIcons();
        }

        function openDeleteModal(tenant) {
            document.getElementById('deleteModal').classList.remove('hidden');
            document.getElementById('deleteModal').classList.add('flex');
            
            document.getElementById('del_tenant_id').value = tenant.id;
            document.getElementById('del_biz_name').innerText = tenant.business_name;
            document.getElementById('del_db_name').value = tenant.db_name;
        }

        function deleteImage(type) {
            if (!confirm(`Are you sure you want to delete this ${type}? This cannot be undone.`)) return;
            const form = document.createElement('form');
            form.method = 'POST';
            const act = document.createElement('input'); act.type='hidden'; act.name='action'; act.value='delete_tenant_image'; form.appendChild(act);
            const tid = document.createElement('input'); tid.type='hidden'; tid.name='tenant_id'; tid.value=document.getElementById('edit_tenant_id').value; form.appendChild(tid);
            const itype = document.createElement('input'); itype.type='hidden'; itype.name='image_type'; itype.value=type; form.appendChild(itype);
            document.body.appendChild(form);
            form.submit();
        }

        let currentTenantData = { categories: [], units: [] };

        async function openQuickAddDataModal(tenant) {
            document.getElementById('quickDataModal').classList.remove('hidden');
            document.getElementById('quickDataModal').classList.add('flex');
            
            document.getElementById('quickDataBizName').innerText = 'Adding to: ' + tenant.business_name;
            document.getElementById('qd_tenant_id').value = tenant.id;
            document.getElementById('qd_db_name').value = tenant.db_name;

            // Reset and Show Loading
            const list = document.getElementById('existingDataList');
            list.innerHTML = '<p class="text-[10px] italic text-slate-500">Retrieving DB items...</p>';

            // Fetch data
            const res = await fetch(`manage_tenants.php?action=get_tenant_data&db=${tenant.db_name}`);
            const data = await res.json();

            if(data.success) {
                currentTenantData.categories = data.categories;
                currentTenantData.units = data.units;
                toggleExistingDataList();
            } else {
                list.innerHTML = '<p class="text-[10px] text-rose-500">Database connection failed.</p>';
            }
        }

        async function toggleItemStatus(id, checked) {
            const db = document.getElementById('qd_db_name').value;
            const type = document.getElementById('qd_data_type').value;
            const formData = new FormData();
            formData.append('action', 'toggle_data_status');
            formData.append('db', db);
            formData.append('type', type);
            formData.append('id', id);
            formData.append('status', checked ? 1 : 0);
            await fetch('manage_tenants.php', { method: 'POST', body: formData });
        }

        function toggleExistingDataList() {
            const type = document.getElementById('qd_data_type').value;
            const list = document.getElementById('existingDataList');
            const items = (type === 'category') ? currentTenantData.categories : currentTenantData.units;

            if(items.length === 0) {
                list.innerHTML = '<p class="text-[10px] italic text-slate-500">No items configured yet.</p>';
                return;
            }

            list.innerHTML = items.map(i => `
                <label class="flex items-center gap-1.5 px-2 py-1 bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-lg text-[10px] font-bold text-slate-600 dark:text-neutral-300 cursor-pointer">
                    <input type="checkbox" onchange="toggleItemStatus(${i.id}, this.checked)" ${i.is_allowed == 1 ? 'checked' : ''} class="w-3 h-3 accent-orange-500">
                    ${i.name}
                </label>
            `).join('');
        }
    </script>

    <!-- Push Verification Task Modal -->
    <div id="pushTaskModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative overflow-hidden">
            <button type="button" onclick="document.getElementById('pushTaskModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-orange-500 transition-colors"><i data-lucide="x" size="24"></i></button>
            
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Push Verification</h2>
            <p class="text-xs text-indigo-500 font-bold uppercase tracking-widest mb-8">Request compliance documents</p>

            <form method="POST" class="space-y-5">
                <input type="hidden" name="action" value="push_verification_task">
                
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Target Audience</label>
                    <select name="target_tenant" required class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold">
                        <option value="all">📢 All Active Tenants</option>
                        <?php foreach($tenants as $t): ?>
                            <option value="<?= $t['id'] ?>"><?= htmlspecialchars($t['business_name']) ?> (#<?= $t['unique_id'] ?>)</option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Task Title</label>
                    <input type="text" name="task_title" required placeholder="e.g. Verify Your NTN" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold">
                </div>

                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Instructions</label>
                    <textarea name="task_description" required placeholder="Tell the user why this is needed..." class="w-full p-4 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm h-24"></textarea>
                </div>

                <div class="grid grid-cols-2 gap-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Priority</label>
                        <select name="priority" class="w-full px-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none dark:text-white text-sm font-bold">
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High (Red Alert)</option>
                        </select>
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Required Documents</label>
                        <div class="grid grid-cols-1 gap-1">
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400"><input type="checkbox" name="required_docs[]" value="ID Front" class="accent-orange-600"> ID Front</label>
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400"><input type="checkbox" name="required_docs[]" value="ID Back" class="accent-orange-600"> ID Back</label>
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400"><input type="checkbox" name="required_docs[]" value="Utility Bill" class="accent-orange-600"> Utility Bill</label>
                            <label class="flex items-center gap-2 text-[10px] font-bold text-slate-600 dark:text-slate-400"><input type="checkbox" name="required_docs[]" value="Tax Doc" class="accent-orange-600"> Tax Doc</label>
                        </div>
                    </div>
                </div>

                <button type="submit" class="w-full py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-indigo-600/20 mt-4">Broadcast Request</button>
            </form>
        </div>
    </div>
    <script>
        // Ensure all icons (including those in modals at the bottom) are rendered
        lucide.createIcons();
    </script>
</body>
</html>