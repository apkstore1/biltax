<?php
require_once 'config/db_switch.php';

// Response header set karein
header('Content-Type: application/json');

// Check karein ke tenant connected hai ya nahi
if (!$tenant_conn) {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$route = $_GET['route'] ?? '';
$action = $_GET['action'] ?? ''; // For specific actions within a route
$method = $_SERVER['REQUEST_METHOD'];
$industry = strtolower(trim($_SESSION['industry_type'] ?? 'retail'));

// Self-healing: Ensure required products columns exist without column dependency
try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN is_expirable TINYINT(1) DEFAULT 0"); } catch(Exception $e) {}
try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN alert_level INT DEFAULT 10"); } catch(Exception $e) {}
try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN unit_id INT DEFAULT NULL"); } catch(Exception $e) {}
try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN price DECIMAL(15,2) DEFAULT 0.00"); } catch(Exception $e) {}
try { $tenant_conn->exec("ALTER TABLE products ADD COLUMN stock_level DECIMAL(10,2) DEFAULT 0"); } catch(Exception $e) {}

// Self-healing for customers table: Add missing address column
try { $tenant_conn->exec("ALTER TABLE customers ADD COLUMN address TEXT"); } catch(Exception $e) {}

// Self-healing for sales table: Add return_status column
try { $tenant_conn->exec("ALTER TABLE sales ADD COLUMN return_status ENUM('no_returns', 'partial_return', 'full_return') DEFAULT 'no_returns'"); } catch(Exception $e) {}
// Self-healing for sales table: Add branch_id column (Fixes Checkout Error)
try { $tenant_conn->exec("ALTER TABLE sales ADD COLUMN branch_id INT"); } catch(Exception $e) {}
// Self-healing for sale_items table: Add returned_quantity column
try { $tenant_conn->exec("ALTER TABLE sale_items ADD COLUMN returned_quantity DECIMAL(10,2) DEFAULT 0"); } catch(Exception $e) {}
// Self-healing for sales table: Add tax_amount column for billing accuracy
try { $tenant_conn->exec("ALTER TABLE sales ADD COLUMN tax_amount DECIMAL(10,2) DEFAULT 0.00"); } catch(Exception $e) {}
// Self-healing for sales table: Add customer_id for wholesale/bulk sales
try { $tenant_conn->exec("ALTER TABLE sales ADD COLUMN customer_id INT DEFAULT NULL"); } catch(Exception $e) {}
// Self-healing for sales table: Add discount_amount
try { $tenant_conn->exec("ALTER TABLE sales ADD COLUMN discount_amount DECIMAL(10,2) DEFAULT 0.00"); } catch(Exception $e) {}

// Self-healing: Ensure pos_returns table exists
try {
    $tenant_conn->exec("CREATE TABLE IF NOT EXISTS pos_returns (
        id INT PRIMARY KEY AUTO_INCREMENT,
        branch_id INT NOT NULL,
        sale_id INT NOT NULL,
        product_id INT NOT NULL,
        quantity DECIMAL(10,2) NOT NULL,
        reason TEXT,
        status ENUM('pending', 'completed', 'cancelled') DEFAULT 'completed',
        refund_amount DECIMAL(15,2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    try { $tenant_conn->exec("ALTER TABLE pos_returns ADD COLUMN branch_id INT AFTER id"); } catch(Exception $e) {}
    try { $tenant_conn->exec("ALTER TABLE pos_returns ADD COLUMN status ENUM('pending', 'completed', 'cancelled') DEFAULT 'completed' AFTER reason"); } catch(Exception $e) {}
    try { $tenant_conn->exec("ALTER TABLE pos_returns ADD COLUMN refund_amount DECIMAL(15,2) DEFAULT 0 AFTER status"); } catch(Exception $e) {}
} catch (Exception $e) { /* Table might not exist yet, or other issue */ }

// Build Product System: Self-healing
try {
    $tenant_conn->exec("CREATE TABLE IF NOT EXISTS product_components (id INT PRIMARY KEY AUTO_INCREMENT, product_id INT NOT NULL, component_id INT NOT NULL, quantity DECIMAL(10,3) NOT NULL)");
} catch(Exception $e) {}

switch ($route) {
    case 'recipe/get':
        try {
            $pid = $_GET['product_id'] ?? 0;
            $stmt = $tenant_conn->prepare("SELECT r.*, p.name, u.name as unit, r.component_id as ingredient_id
                                           FROM product_components r 
                                           JOIN products p ON r.component_id = p.id 
                                           LEFT JOIN units u ON p.unit_id = u.id 
                                           WHERE r.product_id = ?");
            $stmt->execute([$pid]);
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
        } catch (Exception $e) {
            echo json_encode([]);
        }
        break;

    case 'recipe/save':
        try {
            if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$input) throw new Exception("No data received");

            $pid = $input['product_id'];
            $ingredients = $input['ingredients'] ?? [];

            $tenant_conn->beginTransaction();
            $tenant_conn->prepare("DELETE FROM product_components WHERE product_id = ?")->execute([$pid]);
            $stmt = $tenant_conn->prepare("INSERT INTO product_components (product_id, component_id, quantity) VALUES (?, ?, ?)");
            foreach ($ingredients as $ing) {
                $qty = (float)($ing['qty'] ?? 0);
                if ($qty > 0) $stmt->execute([$pid, $ing['id'] ?? $ing['ingredient_id'], $qty]);
            }
            $tenant_conn->commit();
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            if (isset($tenant_conn) && $tenant_conn->inTransaction()) $tenant_conn->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'finance/payroll/configs/get':
        try {
            $stmt = $tenant_conn->query("SELECT * FROM payroll_configs");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
        } catch (Exception $e) { echo json_encode([]); }
        break;

    case 'finance/payroll/configs/save':
        if ($method !== 'POST') { echo json_encode(['success' => false]); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        try {
            $stmt = $tenant_conn->prepare("INSERT INTO payroll_configs (user_id, base_salary, allowances, deductions) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE base_salary = ?, allowances = ?, deductions = ?");
            $stmt->execute([
                $input['user_id'], $input['base_salary'], $input['allowances'], $input['deductions'],
                $input['base_salary'], $input['allowances'], $input['deductions']
            ]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
        break;

    case 'finance/payroll/payments/get':
        try {
            $stmt = $tenant_conn->query("SELECT sp.*, u.name as staff_name FROM salary_payments sp JOIN users u ON sp.user_id = u.id ORDER BY sp.payment_date DESC");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
        } catch (Exception $e) { echo json_encode([]); }
        break;

    case 'finance/categories/get':
        try {
            $stmt = $tenant_conn->query("SELECT * FROM expense_categories ORDER BY name ASC");
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
        } catch (Exception $e) { echo json_encode([]); }
        break;

    // --- Finance & Accounts Module Routes ---
    case 'finance/expenses/get':
        try {
            $active_branch = $_SESSION['active_branch_id'] ?? null;
            $sql = "SELECT e.*, c.name as category_name FROM expenses e LEFT JOIN expense_categories c ON e.category_id = c.id";
            if ($active_branch !== 'all') {
                $stmt = $tenant_conn->prepare($sql . " WHERE e.branch_id = ? ORDER BY e.expense_date DESC");
                $stmt->execute([$active_branch]);
            } else {
                $stmt = $tenant_conn->query($sql . " ORDER BY e.expense_date DESC");
            }
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
        } catch (Exception $e) { echo json_encode([]); }
        break;

    case 'finance/expenses/add':
        if ($method !== 'POST') { echo json_encode(['success' => false]); exit; }
        $input = $_POST; // Use $_POST for multipart/form-data support
        try {
            require_once 'config/CloudinaryStorage.php';
            $receipt_url = null;
            if (isset($_FILES['receipt']) && $_FILES['receipt']['error'] === 0) {
                $receipt_url = uploadToCloud($_FILES['receipt']['tmp_name'], 'biltax_expenses', 'exp_'.time());
            }

            $branch_id = ($_SESSION['active_branch_id'] === 'all') ? get_active_stock_branch_id('all') : $_SESSION['active_branch_id'];
            $stmt = $tenant_conn->prepare("INSERT INTO expenses (branch_id, category_id, amount, payment_method, description, expense_date, receipt_url) VALUES (?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $branch_id,
                $input['category_id'],
                $input['amount'],
                $input['payment_method'] ?? 'Cash',
                $input['description'] ?? '',
                $input['expense_date'] ?? date('Y-m-d'),
                $receipt_url
            ]);
            
            // Record in Ledger for Cash Position
            $stmt_ledger = $tenant_conn->prepare("INSERT INTO ledgers (branch_id, party_name, party_type, description, debit, credit) VALUES (?, 'Expense Payment', 'supplier', ?, ?, 0)");
            $stmt_ledger->execute([$branch_id, $input['description'] ?: 'Daily Expense', $input['amount']]);

            echo json_encode(['success' => true]);
        } catch (Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
        break;

    case 'finance/payroll/pay':
        if ($method !== 'POST') { echo json_encode(['success' => false]); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        try {
            $tenant_conn->beginTransaction();
            $branch_id = ($_SESSION['active_branch_id'] === 'all') ? get_active_stock_branch_id('all') : $_SESSION['active_branch_id'];
            
            // 1. Record Salary Payment
            $stmt = $tenant_conn->prepare("INSERT INTO salary_payments (branch_id, user_id, amount_paid, payment_date, month_year, payment_method) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([
                $branch_id,
                $input['user_id'],
                $input['amount'],
                date('Y-m-d'),
                $input['month_year'],
                $input['payment_method'] ?? 'Cash'
            ]);
            $pay_id = $tenant_conn->lastInsertId();

            // Record in Transaction Ledger under 'Salaries'
            $stmt_ledger = $tenant_conn->prepare("INSERT INTO ledgers (branch_id, party_name, party_type, description, debit, credit) VALUES (?, 'Staff Payroll', 'supplier', ?, ?, 0)");
            $stmt_ledger->execute([$branch_id, "Salary Payout ($input[month_year])", $input['amount']]);

            // 2. Automatically record as an expense for P&L reporting
            $stmt_cat = $tenant_conn->prepare("SELECT id FROM expense_categories WHERE name = 'Salaries' LIMIT 1");
            $stmt_cat->execute();
            $cat_id = $stmt_cat->fetchColumn();
            if (!$cat_id) {
                $tenant_conn->exec("INSERT INTO expense_categories (name) VALUES ('Salaries')");
                $cat_id = $tenant_conn->lastInsertId();
            }

            $stmt_exp = $tenant_conn->prepare("INSERT INTO expenses (branch_id, category_id, amount, payment_method, description, expense_date) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt_exp->execute([
                $branch_id,
                $cat_id,
                $input['amount'],
                $input['payment_method'] ?? 'Cash',
                "Salary Payout for User #" . $input['user_id'] . " ($input[month_year])",
                date('Y-m-d')
            ]);

            $tenant_conn->commit();
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            if ($tenant_conn->inTransaction()) $tenant_conn->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'finance/payables/get':
        try {
            $active_branch = $_SESSION['active_branch_id'] ?? 'all';
            $branch_cond = ($active_branch === 'all') ? "" : " AND branch_id = :bid";
            $sql = "SELECT party_name, SUM(credit) as total_credit, SUM(debit) as total_debit 
                    FROM ledgers 
                    WHERE party_type = 'supplier' $branch_cond 
                    GROUP BY party_name 
                    HAVING (total_credit - total_debit) != 0";
            $stmt = $tenant_conn->prepare($sql);
            if ($active_branch !== 'all') $stmt->bindValue(':bid', $active_branch);
            $stmt->execute();
            echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
        } catch (Exception $e) { echo json_encode([]); }
        break;

    case 'finance/payables/pay':
        if ($method !== 'POST') { echo json_encode(['success' => false]); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        try {
            $branch_id = ($_SESSION['active_branch_id'] === 'all') ? get_active_stock_branch_id('all') : $_SESSION['active_branch_id'];
            
            $stmt = $tenant_conn->prepare("INSERT INTO ledgers (branch_id, party_name, party_type, description, debit, credit) VALUES (?, ?, 'supplier', ?, ?, 0)");
            $stmt->execute([
                $branch_id,
                $input['party_name'],
                $input['description'] ?: 'Manual Payment to Supplier',
                $input['amount']
            ]);
            
            echo json_encode(['success' => true]);
        } catch (Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
        break;

    case 'production/build':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) { echo json_encode(['success' => false, 'message' => 'No data received']); exit; }

        $product_id = (int)$input['product_id'];
        $produce_qty = (float)$input['quantity'];

        if ($produce_qty <= 0) { echo json_encode(['success' => false, 'message' => 'Quantity must be greater than zero']); exit; }

        try {
            $tenant_conn->beginTransaction();

            // 1. Fetch components/recipe
            $stmt = $tenant_conn->prepare("SELECT component_id, quantity FROM product_components WHERE product_id = ?");
            $stmt->execute([$product_id]);
            $components = $stmt->fetchAll(PDO::FETCH_ASSOC);

            if (empty($components)) throw new Exception("No recipe/components found for this product. Please set the formula first.");

            $active_branch = $_SESSION['active_branch_id'] ?? null;
            $stock_source_id = get_active_stock_branch_id($active_branch);

            // 2. Loop through components and deduct raw materials
            foreach ($components as $c) {
                $deduct_qty = $c['quantity'] * $produce_qty;
                
                $stmt_deduct = $tenant_conn->prepare("UPDATE products SET stock_level = stock_level - ? WHERE id = ? AND branch_id = ?");
                $stmt_deduct->execute([$deduct_qty, $c['component_id'], $stock_source_id]);

                // Record stock movement for component
                $stmt_log = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)");
                $stmt_log->execute([$c['component_id'], -$deduct_qty, "Used in Production of #$product_id (Qty: $produce_qty)"]);
            }

            // 3. Increase finished product stock
            $stmt_add = $tenant_conn->prepare("UPDATE products SET stock_level = stock_level + ? WHERE id = ? AND branch_id = ?");
            $stmt_add->execute([$produce_qty, $product_id, $stock_source_id]);

            // Record stock movement for finished product
            $stmt_log_final = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)");
            $stmt_log_final->execute([$product_id, $produce_qty, "Manual Production / Assembly Build"]);

            $tenant_conn->commit();
            echo json_encode(['success' => true, 'message' => "Successfully produced $produce_qty units."]);
        } catch (Exception $e) {
            if ($tenant_conn->inTransaction()) $tenant_conn->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'jobs/update_status':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        try {
            $jid = (int)$input['id'];
            $status = $input['status'];
            
            // If marking delivered, update customer's last service date
            if ($status === 'delivered') {
                $stmt_info = $tenant_conn->prepare("SELECT customer_id FROM job_cards WHERE id = ?");
                $stmt_info->execute([$jid]);
                $cid = $stmt_info->fetchColumn();
                if ($cid) {
                    $tenant_conn->prepare("UPDATE customers SET last_service_date = CURRENT_DATE WHERE id = ?")->execute([$cid]);
                }
            }

            $stmt = $tenant_conn->prepare("UPDATE job_cards SET status = ? WHERE id = ?");
            $stmt->execute([$status, $jid]);
            echo json_encode(['success' => true]);
        } catch(Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
        exit;

    case 'jobs/update_checklist':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        try {
            $job_id = (int)$input['job_id'];
            $index = (int)$input['index'];
            $completed = (bool)$input['completed'];

            $stmt = $tenant_conn->prepare("SELECT task_completion_data FROM job_cards WHERE id = ?");
            $stmt->execute([$job_id]);
            $current_data = json_decode($stmt->fetchColumn(), true) ?: [];

            if (isset($current_data[$index])) {
                $current_data[$index]['completed'] = $completed;
                $stmt_update = $tenant_conn->prepare("UPDATE job_cards SET task_completion_data = ? WHERE id = ?");
                $stmt_update->execute([json_encode($current_data), $job_id]);
                echo json_encode(['success' => true]);
            } else {
                echo json_encode(['success' => false, 'message' => 'Checklist item not found.']);
            }
        } catch(Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
        exit;

    case 'dashboard/stats':
        try {
            $active_branch = $_SESSION['active_branch_id'] ?? null;
            $stock_branch = get_active_stock_branch_id($active_branch);
            $is_all = ($active_branch === 'all');

            // 1. Total Products Count
            $sql_count = "SELECT COUNT(*) FROM products" . ($is_all ? "" : " WHERE branch_id = ?");
            $stmt_count = $tenant_conn->prepare($sql_count);
            $is_all ? $stmt_count->execute() : $stmt_count->execute([$stock_branch]);
            $productCount = $stmt_count->fetchColumn() ?: 0;

            // 2. Low Stock Alerts (Wholesale mein stock_quantity ho sakta hai, Retail mein stock_level)
            // Hum pehle check karte hain ke column kaunsa maujood hai
            $stockCol = 'stock_level';
            $checkCol = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'stock_quantity'")->fetch();
            if ($checkCol) $stockCol = 'stock_quantity';

            $sql_low = "SELECT COUNT(*) FROM products WHERE $stockCol <= alert_level" . ($is_all ? "" : " AND branch_id = ?");
            $stmt_low = $tenant_conn->prepare($sql_low);
            $is_all ? $stmt_low->execute() : $stmt_low->execute([$stock_branch]);
            $lowStockCount = $stmt_low->fetchColumn() ?: 0;

            // 3. Revenue Calculation
            $revenue = 0;
            try {
                $sql_rev = "SELECT SUM(total_amount) FROM sales" . ($is_all ? "" : " WHERE branch_id = ?");
                $stmt_rev = $tenant_conn->prepare($sql_rev);
                $is_all ? $stmt_rev->execute() : $stmt_rev->execute([$stock_branch]);
                $revenue = $stmt_rev->fetchColumn() ?: 0;
            } catch (Exception $e) { $revenue = 0; }

            // 4. Recent Sales for Dashboard List
            $recentSales = [];
            try {
                $sql_rec = "SELECT * FROM sales " . ($is_all ? "" : "WHERE branch_id = ? ") . "ORDER BY created_at DESC LIMIT 5";
                $stmt_rec = $tenant_conn->prepare($sql_rec);
                $is_all ? $stmt_rec->execute() : $stmt_rec->execute([$stock_branch]);
                $recentSales = $stmt_rec->fetchAll(PDO::FETCH_ASSOC);
            } catch (Exception $e) { $recentSales = []; }

            $response = [
                'revenue' => (float)$revenue,
                'productCount' => (int)$productCount,
                'lowStockCount' => (int)$lowStockCount,
                'recentSales' => $recentSales,
                'currency' => $currency_symbol,
                'industry' => $industry,
                'storageUsage' => (float)$current_storage_usage,
                'storageLimit' => (int)$storage_limit
            ];

            // Restaurant Specific Stats
            if ($industry === 'restaurant') {
                // Active Tables (Occupied)
                $table_sql = "SELECT COUNT(*) FROM restaurant_tables WHERE status = 'occupied'" . ($is_all ? "" : " AND branch_id = ?");
                $stmt_tab = $tenant_conn->prepare($table_sql);
                $is_all ? $stmt_tab->execute() : $stmt_tab->execute([$active_branch]);
                $response['activeTables'] = (int)$stmt_tab->fetchColumn();

                // Total Tables
                $total_tab_sql = "SELECT COUNT(*) FROM restaurant_tables" . ($is_all ? "" : " WHERE branch_id = ?");
                $stmt_tot_tab = $tenant_conn->prepare($total_tab_sql);
                $is_all ? $stmt_tot_tab->execute() : $stmt_tot_tab->execute([$active_branch]);
                $response['totalTables'] = (int)$stmt_tot_tab->fetchColumn();

                // Pending KOTs
                try {
                    // We check if sale is today's for dashboard context
                    $kot_sql = "SELECT COUNT(*) FROM kot k JOIN sales s ON k.sale_id = s.id WHERE k.status IN ('pending', 'preparing')" . ($is_all ? "" : " AND s.branch_id = ?");
                    $stmt_kot = $tenant_conn->prepare($kot_sql);
                    $is_all ? $stmt_kot->execute() : $stmt_kot->execute([$active_branch]);
                    $response['pendingKots'] = (int)$stmt_kot->fetchColumn();
                } catch(Exception $e) { $response['pendingKots'] = 0; }
            }

            // Service Specific Stats
            if ($industry === 'service') {
                try {
                    // Total Customers
                    $stmt_cust = $tenant_conn->prepare("SELECT COUNT(*) FROM customers");
                    $stmt_cust->execute();
                    $response['totalCustomers'] = (int)$stmt_cust->fetchColumn();

                    // Active Jobs (Not Delivered/Cancelled)
                    $stmt_jobs = $tenant_conn->prepare("SELECT COUNT(*) FROM job_cards WHERE status NOT IN ('delivered', 'cancelled')");
                    $stmt_jobs->execute();
                    $response['activeJobs'] = (int)$stmt_jobs->fetchColumn();

                    // Pending Reminders
                    $stmt_rem = $tenant_conn->prepare("SELECT COUNT(*) FROM reminders WHERE status = 'pending'");
                    $stmt_rem->execute();
                    $response['pendingReminders'] = (int)$stmt_rem->fetchColumn();
                } catch (Exception $e) { /* Tables might be missing or empty */ }
            }

            echo json_encode($response);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'error' => $e->getMessage()]);
        }
        break;

    case 'kot':
        $active_branch = $_SESSION['active_branch_id'] ?? null;
        $is_all = ($active_branch === 'all');
        // Use LEFT JOIN for tables to show Takeaway/No-table orders
        // Filter by s.branch_id instead of t.branch_id to ensure all orders show
        $sql = "SELECT k.id, k.status, k.created_at, t.table_number, s.id as sale_id 
                FROM kot k 
                LEFT JOIN restaurant_tables t ON k.table_id = t.id 
                JOIN sales s ON k.sale_id = s.id 
                WHERE k.status IN ('pending', 'preparing')";
        if (!$is_all) {
            $sql .= " AND s.branch_id = ?";
        }
        $sql .= " ORDER BY k.id ASC";
        
        $stmt = $tenant_conn->prepare($sql);
        if ($is_all) {
            $stmt->execute();
        } else {
            $stmt->execute([$active_branch]);
        }
        $kots = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        foreach($kots as &$kot) {
            $stmt_items = $tenant_conn->prepare("SELECT si.quantity, p.name FROM sale_items si JOIN products p ON si.product_id = p.id WHERE si.sale_id = ?");
            $stmt_items->execute([$kot['sale_id']]);
            $kot['items'] = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
        }
        echo json_encode($kots);
        break;

    case 'kot/update_status':
        if ($method !== 'POST') { echo json_encode(['success' => false]); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        try {
            $stmt = $tenant_conn->prepare("UPDATE kot SET status = ? WHERE id = ?");
            $stmt->execute([$input['status'], $input['id']]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) { echo json_encode(['success' => false]); }
        break;

    case 'tables':
        $active_branch = $_SESSION['active_branch_id'] ?? null;
        $sql = "SELECT * FROM restaurant_tables" . ($active_branch === 'all' ? "" : " WHERE branch_id = ?") . " ORDER BY table_number ASC";
        $stmt = $tenant_conn->prepare($sql);
        $active_branch === 'all' ? $stmt->execute() : $stmt->execute([$active_branch]);
        echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC) ?: []);
        break;

    case 'tables/add':
        if ($method !== 'POST') { echo json_encode(['success' => false]); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        $active_branch = $_SESSION['active_branch_id'] ?? null;
        $branch_id = ($active_branch === 'all') ? get_active_stock_branch_id('all') : $active_branch;
        
        try {
            $stmt = $tenant_conn->prepare("INSERT INTO restaurant_tables (branch_id, table_number, capacity, status) VALUES (?, ?, ?, 'available')");
            $stmt->execute([$branch_id, $input['table_number'], $input['capacity']]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
        break;

    case 'tables/update_status':
        $input = json_decode(file_get_contents('php://input'), true);
        try {
            $stmt = $tenant_conn->prepare("UPDATE restaurant_tables SET status = ? WHERE id = ?");
            $stmt->execute([$input['status'], $input['id']]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) { echo json_encode(['success' => false]); }
        break;

    case 'products':
        if (!has_module('inventory') && !has_module('recipes')) {
            echo json_encode([]);
            exit;
        }

        // Resolve which branch stock to show
        // Priority given to GET parameter (for transfers) then session
        $active_branch = $_GET['branch_id'] ?? $_SESSION['active_branch_id'] ?? null;
        $is_all = ($active_branch === 'all');
        $stock_branch = $is_all ? null : get_active_stock_branch_id($active_branch);

        $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
        $main_id = $stmt_main->fetchColumn();

        $where = "";
        $params = [];
        if (!$is_all) {
            $where = ($stock_branch == $main_id) ? " WHERE (branch_id = ? OR branch_id IS NULL)" : " WHERE branch_id = ?";
            $params = [$stock_branch];
        }

        // Filter for Raw Materials only (used in Stock Management / Transfer for Restaurants)
        if ($industry === 'restaurant' && isset($_GET['raw_only'])) {
            $where .= ($where === "" ? " WHERE " : " AND ") . "is_raw = 1";
        } elseif (has_module('raw_material_system') && isset($_GET['raw_only'])) {
            $where .= ($where === "" ? " WHERE " : " AND ") . "is_raw_component = 1";
        } elseif ($industry === 'restaurant') {
            $where .= ($where === "" ? " WHERE " : " AND ") . "is_raw = 0";
        }

        if (isset($_GET['type']) && $_GET['type'] === 'expiry') {
            $where .= ($where === "" ? " WHERE " : " AND ") . "p.is_expirable = 1";
        }

        // Join with units to get unit_name for display in Recipe Builder
        $stmt = $tenant_conn->prepare("SELECT p.*, u.name as unit_name,
                                       (SELECT expiry_date FROM stock WHERE product_id = p.id AND expiry_date IS NOT NULL ORDER BY id DESC LIMIT 1) as expiry_date
                                       FROM products p 
                                       LEFT JOIN units u ON p.unit_id = u.id $where ORDER BY p.id DESC");
        $stmt->execute($params);
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

        foreach($products as &$p) { // Add is_expirable to product data
            // Robust Price Logic: Check both columns and pick the one that has a value
            $db_price = (float)($p['price'] ?? 0);
            $db_sale_price = (float)($p['sale_price'] ?? 0);
            
            $p['price'] = ($db_price > 0) ? $db_price : (($db_sale_price > 0) ? $db_sale_price : 0.00);
            $p['stock_level'] = (int)($p['stock_level'] ?? $p['stock_quantity'] ?? 0);
            $p['reorder_point'] = (int)($p['alert_level'] ?? 10);
            $p['currency'] = $currency_symbol;
        }
        echo json_encode($products);
        break;

    case 'products/search':
        try {
            if (!has_module('inventory') && !has_module('recipes')) {
                echo json_encode([]);
                exit;
            }

            $q = $_GET['q'] ?? '';
            $active_branch = $_SESSION['active_branch_id'] ?? null;
            $is_all = ($active_branch === 'all');
            $stock_branch = $is_all ? null : get_active_stock_branch_id($active_branch);

            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $main_id = $stmt_main->fetchColumn();

            $sql = "SELECT *, (SELECT expiry_date FROM stock WHERE product_id = products.id AND expiry_date IS NOT NULL ORDER BY id DESC LIMIT 1) as expiry_date FROM products";
            $where_clauses = [];
            $params = [];

            if (!$is_all) {
                $where_clauses[] = ($stock_branch == $main_id) ? "(branch_id = ? OR branch_id IS NULL)" : "branch_id = ?";
                $params[] = $stock_branch;
            }

            // Restaurant Mode Filter Logic:
            // 1. Purchase context: Show Raw Materials OR Items with Stock tracking.
            // 2. Default (POS): Show only finished Dishes (is_raw = 0).
            if ($industry === 'restaurant') {
                if (isset($_GET['purchase_context'])) {
                    $where_clauses[] = "(is_raw = 1 OR has_stock = 1)";
                } elseif (has_module('raw_material_system') && isset($_GET['raw_only'])) {
                    $where_clauses[] = "is_raw_component = 1";
                } else {
                    $where_clauses[] = "is_raw = 0";
                }
            }

            if (!empty($q)) {
                $where_clauses[] = "(name LIKE ? OR sku LIKE ?)";
                $params[] = "%$q%";
                $params[] = "%$q%";
            }

            if (!empty($where_clauses)) { // If 'q' is empty, this condition will be false, and no LIMIT will be applied.
                $sql .= " WHERE " . implode(" AND ", $where_clauses);
            }

            $stmt = $tenant_conn->prepare($sql); // Removed LIMIT 15 to show all products
            $stmt->execute($params);
            $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
            
            foreach($products as &$p) {
                $p['stock_level'] = (int)($p['stock_level'] ?? $p['stock_quantity'] ?? 0);
                // Fail-safe price logic for search results
                $db_price = (float)($p['price'] ?? 0);
                $db_sale_price = (float)($p['sale_price'] ?? 0);

                $p['price'] = ($db_price > 0) ? $db_price : (($db_sale_price > 0) ? $db_sale_price : 0.00);
                $p['is_expirable'] = (int)($p['is_expirable'] ?? 0); // Include is_expirable
                $p['currency'] = $currency_symbol;
            }
            
            echo json_encode($products ?: []);
        } catch (Exception $e) { echo json_encode([]); }
        break;

    case 'products/add':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        $input = json_decode(file_get_contents('php://input'), true) ?? $_POST;
        
        $active_branch = $_SESSION['active_branch_id'] ?? null;
        $target_branch = get_active_stock_branch_id($active_branch);

        try {
            $stmt = $tenant_conn->prepare("
                INSERT INTO products (
                    branch_id, name, sku, barcode, sale_price, purchase_price, 
                    category_id, unit_id, supplier_id, stock_level, alert_level
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            
            $stmt->execute([
                $target_branch,
                $input['name'],
                $input['sku'] ?? null,
                $input['barcode'] ?? null,
                $input['sale_price'],
                $input['purchase_price'] ?? 0,
                $input['category_id'] ?? null,
                $input['unit_id'] ?? null,
                $input['supplier_id'] ?? null,
                $input['stock_level'] ?? 0,
                $input['alert_level'] ?? 10
            ]);

            echo json_encode(['success' => true, 'message' => 'Product added successfully to branch ID: ' . $target_branch]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Add failed: ' . $e->getMessage()]);
        }
        break;

    case 'customers':
        try {
            // Fetch regular customers
            $customers = $tenant_conn->query("SELECT id, name, phone, 'customer' as party_type FROM customers")->fetchAll(PDO::FETCH_ASSOC);
            
            // Fetch vendors to show in bulk sale/unified dropdowns
            $vendors = [];
            try {
                $vendors = $tenant_conn->query("SELECT id, name, phone, 'vendor' as party_type FROM vendors")->fetchAll(PDO::FETCH_ASSOC);
            } catch(Exception $e) {
                // Table might not exist for some tenants
            }

            // Merge both lists
            $all_parties = array_merge($customers, $vendors);
            echo json_encode($all_parties ?: []);
        } catch (Exception $e) {
            echo json_encode([]);
        }
        break;

    case 'suppliers':
        // Fetch suppliers for the dashboard/POS
        try {
            $suppliers = $tenant_conn->query("SELECT * FROM suppliers ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($suppliers ?: []);
        } catch (Exception $e) {
            echo json_encode([]);
        }
        break;

    case 'sales/detailed':
        try {
            $start = $_GET['start'] ?? date('Y-m-d', strtotime('-30 days'));
            $end = $_GET['end'] ?? date('Y-m-d');
            $search = $_GET['search'] ?? '';
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = 15;
            $offset = ($page - 1) * $limit;

            // Use branch_id from GET if provided, otherwise fallback to session context
            $active_branch = $_GET['branch_id'] ?? $_SESSION['active_branch_id'] ?? null;
            $is_all = ($active_branch === 'all');

            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $main_id = $stmt_main->fetchColumn();

            $branch_cond = "";
            $report_params = [$start, $end];
            if (!$is_all) {
                $branch_cond = ($active_branch == $main_id) ? " AND (s.branch_id = ? OR s.branch_id IS NULL)" : " AND s.branch_id = ?";
                $report_params[] = $active_branch;
            }

            $where = "WHERE DATE(s.created_at) BETWEEN ? AND ? $branch_cond ";
            $params = $report_params;

            if (!empty($search)) {
                $where .= " AND (s.id LIKE ? OR p.name LIKE ?)";
                $params[] = "%$search%"; $params[] = "%$search%";
            }

            $p_cost_col = ($industry === 'restaurant') ? "p.price" : "p.purchase_price";

            // 1. Fetch Detailed Items with Calculations
            $query = "SELECT 
                        s.created_at as date,
                        s.id as invoice_id,
                        s.return_status,
                        s.customer_id,
                        cust.name as customer_name,
                        si.returned_quantity,
                        p.name as product_name,
                        c.name as category_name,
                        (si.quantity - si.returned_quantity) as qty,
                        s.discount_amount as discount,
                        s.tax_amount as tax,
                        $p_cost_col as unit_cost,
                        si.price as unit_sale_price,
                        ((si.quantity - si.returned_quantity) * $p_cost_col) as total_cost,
                        ((si.quantity - si.returned_quantity) * si.price) as total_sale,
                        ((si.price - $p_cost_col) * (si.quantity - si.returned_quantity)) as net_profit
                      FROM sale_items si
                      INNER JOIN sales s ON si.sale_id = s.id
                      LEFT JOIN products p ON si.product_id = p.id 
                      LEFT JOIN categories c ON p.category_id = c.id
                      LEFT JOIN customers cust ON s.customer_id = cust.id
                      $where 
                      ORDER BY s.created_at DESC 
                      LIMIT $limit OFFSET $offset";
            
            $stmt = $tenant_conn->prepare($query);
            $stmt->execute($params);
            $sales = $stmt->fetchAll(PDO::FETCH_ASSOC);

            // 2. Summary Calculations
            // We need to use the same joins for stats if searching, otherwise simple queries
            $statsJoin = " FROM sales s INNER JOIN sale_items si ON s.id = si.sale_id LEFT JOIN products p ON si.product_id = p.id LEFT JOIN customers cust ON s.customer_id = cust.id ";
            
            // Correct Revenue calculation: Sum of total_amount from unique sales matching the criteria
            $revenue = $tenant_conn->prepare("SELECT SUM(total_amount) FROM sales s WHERE s.id IN (SELECT DISTINCT s.id $statsJoin $where)");
            $revenue->execute($params);
            $totalRevenue = $revenue->fetchColumn() ?: 0;

            $items = $tenant_conn->prepare("SELECT SUM(si.quantity - si.returned_quantity) $statsJoin $where");
            $items->execute($params);
            $totalItems = $items->fetchColumn() ?: 0;

            $invoices = $tenant_conn->prepare("SELECT COUNT(DISTINCT s.id) $statsJoin $where");
            $invoices->execute($params);
            $totalInvoices = $invoices->fetchColumn() ?: 0;

            // Correct Profit Calculation: (Net Profit per Item) - (Total Unique Discounts)
            $profitQuery = "SELECT SUM((si.price - $p_cost_col) * (si.quantity - si.returned_quantity)) $statsJoin $where";
            $profitStmt = $tenant_conn->prepare($profitQuery);
            $profitStmt->execute($params);
            $grossProfit = $profitStmt->fetchColumn() ?: 0;

            $discountQuery = "SELECT SUM(discount_amount) FROM sales s WHERE s.id IN (SELECT DISTINCT s.id $statsJoin $where)";
            $discountStmt = $tenant_conn->prepare($discountQuery);
            $discountStmt->execute($params);
            $totalDiscounts = $discountStmt->fetchColumn() ?: 0;

            $totalProfit = $grossProfit - $totalDiscounts;

            echo json_encode([
                'sales' => $sales,
                'stats' => [
                    'revenue' => (float)$totalRevenue,
                    'profit' => (float)$totalProfit,
                    'items' => (int)$totalItems,
                    'invoices' => (int)$totalInvoices,
                    'currency' => $currency_symbol
                ]
            ]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'sales/report':
        try {
            $active_branch = $_SESSION['active_branch_id'] ?? null;
            $is_all = ($active_branch === 'all');
            
            $query = "SELECT DATE(created_at) as date, SUM(total_amount) as total FROM sales";
            if (!$is_all) {
                $query .= " WHERE branch_id = ?";
            }
            $query .= " GROUP BY DATE(created_at) ORDER BY date ASC LIMIT 7";
            
            $stmt = $tenant_conn->prepare($query);
            $is_all ? $stmt->execute() : $stmt->execute([$active_branch]);
            $report = $stmt->fetchAll(PDO::FETCH_ASSOC);
            echo json_encode($report ?: []);
        } catch (Exception $e) {
            echo json_encode([]);
        }
        break;

    case 'pos/checkout':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) { echo json_encode(['success' => false, 'message' => 'No data received']); exit; }

        // Self-healing: Ensure discounts table and sales discount column exists OUTSIDE the transaction
        // DDL statements like CREATE TABLE cause implicit commits in MySQL
        $tenant_conn->exec("CREATE TABLE IF NOT EXISTS discounts (id INT PRIMARY KEY AUTO_INCREMENT, sale_id INT, amount DECIMAL(10, 2), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (sale_id) REFERENCES sales(id))");
        
        // Ensure discount_amount column exists in sales table
        $s_cols = $tenant_conn->query("SHOW COLUMNS FROM sales")->fetchAll(PDO::FETCH_COLUMN);
        if (!in_array('discount_amount', $s_cols)) {
            $tenant_conn->exec("ALTER TABLE sales ADD COLUMN discount_amount DECIMAL(10, 2) DEFAULT 0.00 AFTER total_amount");
        }

        try {
            // 1. Enforce Business Rules: Discount Validation
            $discount_val = (float)($input['discount_amount'] ?? 0);
            $tax_val = (float)($input['tax_amount'] ?? 0);
            $total_val = (float)$input['total_amount'];
            
            if ($discount_val > 0 && $discount_limit_type !== 'disabled') {
                if ($discount_limit_type === 'fixed') {
                    if (round($discount_val, 2) > round($max_discount_limit, 2)) {
                        throw new Exception("Discount limit exceeded. Maximum allowed is {$currency_symbol}{$max_discount_limit}.");
                    }
                } else {
                    // Reconstruct subtotal to verify discount percentage
                    $subtotal = ($total_val + $discount_val) - $tax_val;
                    if ($subtotal > 0) {
                        $discount_pct = ($discount_val / $subtotal) * 100;
                        if (round($discount_pct, 2) > round($max_discount_limit, 2)) {
                            throw new Exception("Discount limit exceeded. Maximum allowed is {$max_discount_limit}%.");
                        }
                    }
                }
            }

            $active_branch = $_SESSION['active_branch_id'] ?? null;
            // Resolve Sale Branch: If 'All' is selected, default to Main Branch
            $sale_branch_id = ($active_branch === 'all') ? get_active_stock_branch_id('all') : $active_branch;
            $stock_source_id = get_active_stock_branch_id($active_branch);

            $tenant_conn->beginTransaction();
            // 2. Create Sale Record with Tax and Discount
            $stmt = $tenant_conn->prepare("INSERT INTO sales (branch_id, total_amount, payment_method, discount_amount, tax_amount) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$sale_branch_id, $total_val, $input['payment_method'] ?? 'Cash', $discount_val, $tax_val]);
            $sale_id = $tenant_conn->lastInsertId();

            // 2. Process Items
            foreach ($input['items'] as $item) {
                $unit_price = isset($item['price']) ? (float)$item['price'] : 0.00;

                // Insert Sale Item
                $stmt = $tenant_conn->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->execute([$sale_id, $item['id'], $item['quantity'], $unit_price]);

                // Update Product Stock
                // Checking which column exists (stock_level for Retail, stock_quantity for Wholesale)
                $stockCol = 'stock_level';
                $checkCol = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'stock_quantity'")->fetch();
                if ($checkCol) $stockCol = 'stock_quantity';

                $stmt = $tenant_conn->prepare("UPDATE products SET $stockCol = $stockCol - ? WHERE id = ? AND branch_id = ?");
                $stmt->execute([$item['quantity'], $item['id'], $stock_source_id]);
                
                // --- RESTAURANT RECIPE DEDUCTION ---
                if ($industry === 'restaurant') {
                    $stmt_rec = $tenant_conn->prepare("SELECT ingredient_id, quantity FROM recipes WHERE product_id = ?");
                    $stmt_rec->execute([$item['id']]);
                    $recipe = $stmt_rec->fetchAll(PDO::FETCH_ASSOC);
                    
                    foreach ($recipe as $ri) {
                        $total_ing_deduct = $ri['quantity'] * $item['quantity'];
                        $stmt_deduct_ing = $tenant_conn->prepare("UPDATE products SET stock_level = stock_level - ? WHERE id = ? AND branch_id = ?");
                        $stmt_deduct_ing->execute([$total_ing_deduct, $ri['ingredient_id'], $stock_source_id]);
                        
                        try { $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")->execute([$ri['ingredient_id'], -$total_ing_deduct, "Recipe: Dish #$sale_id"]); } catch(Exception $e) {}
                    }
                }

                // Record Stock Movement (only if stock table exists - standard for Retail)
                try {
                    $stmt = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)");
                    $stmt->execute([$item['id'], -($item['quantity']), "Sale #$sale_id"]);
                } catch(Exception $e) {}
            }

            // 2.5 Create KOT for Restaurant Context
            if ($industry === 'restaurant') {
                $table_id = !empty($input['table_id']) ? $input['table_id'] : null;
                // If kot_list is false (OFF), set status to 'served' directly so it's hidden from kitchen
                $kot_status = (isset($input['kot_list']) && $input['kot_list'] === false) ? 'served' : 'pending';
                $stmt_kot = $tenant_conn->prepare("INSERT INTO kot (sale_id, table_id, status) VALUES (?, ?, ?)");
                $stmt_kot->execute([$sale_id, $table_id, $kot_status]);
            }

            // 3. Record Discount (if any)
            if (isset($input['discount_amount']) && $input['discount_amount'] > 0) {
                $stmt = $tenant_conn->prepare("INSERT INTO discounts (sale_id, amount) VALUES (?, ?)");
                $stmt->execute([$sale_id, $input['discount_amount']]);
            }

            $tenant_conn->commit();
            echo json_encode(['success' => true, 'sale_id' => $sale_id]);
        } catch (Exception $e) {
            if ($tenant_conn->inTransaction()) $tenant_conn->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'bulk_sales/checkout':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        if (!has_module('bulk_sales')) { echo json_encode(['success' => false, 'message' => 'Module disabled']); exit; }
        
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input || empty($input['items'])) { echo json_encode(['success' => false, 'message' => 'No items in cart']); exit; }

        try {
            $tenant_conn->beginTransaction();
            
            $active_branch = $_SESSION['active_branch_id'] ?? null;
            $sale_branch_id = ($active_branch === 'all') ? get_active_stock_branch_id('all') : $active_branch;
            $stock_source_id = get_active_stock_branch_id($active_branch);
            
            $raw_party = $input['customer_id'] ?? '0';
            $customer_id = null;
            $party_name = 'Walk-in Customer';
            $party_type = 'customer';

            // Unified Party Handling (Customer vs Vendor)
            if (strpos($raw_party, ':') !== false) {
                list($type, $pid) = explode(':', $raw_party);
                if ($type === 'vendor') {
                    $stmt_v = $tenant_conn->prepare("SELECT name FROM vendors WHERE id = ?");
                    $stmt_v->execute([$pid]);
                    $party_name = $stmt_v->fetchColumn() ?: 'Unknown Vendor';
                    $party_type = 'supplier';

                    // Ensure a proxy record exists in customers table for reporting accuracy
                    $stmt_c_find = $tenant_conn->prepare("SELECT id FROM customers WHERE name = ? LIMIT 1");
                    $stmt_c_find->execute([$party_name]);
                    $customer_id = $stmt_c_find->fetchColumn();
                    
                    if (!$customer_id) {
                        $tenant_conn->prepare("INSERT INTO customers (name) VALUES (?)")->execute([$party_name]);
                        $customer_id = $tenant_conn->lastInsertId();
                    }
                } else {
                    $customer_id = (int)$pid;
                    $stmt_c_name = $tenant_conn->prepare("SELECT name FROM customers WHERE id = ?");
                    $stmt_c_name->execute([$customer_id]);
                    $party_name = $stmt_c_name->fetchColumn() ?: 'Walk-in Customer';
                    $party_type = 'customer';
                }
            } elseif ((int)$raw_party > 0) {
                $customer_id = (int)$raw_party;
            }

            $total_val = (float)$input['total_amount'];
            $discount_val = (float)($input['discount_amount'] ?? 0);

            // Enforce Business Rules: Discount Validation
            if ($discount_val > 0 && $discount_limit_type !== 'disabled') {
                if ($discount_limit_type === 'fixed') {
                    if (round($discount_val, 2) > round($max_discount_limit, 2)) {
                        throw new Exception("Discount limit exceeded. Maximum allowed is {$currency_symbol}{$max_discount_limit}.");
                    }
                } else {
                    // Reconstruct subtotal to verify discount percentage
                    $subtotal = $total_val + $discount_val;
                    if ($subtotal > 0) {
                        $discount_pct = ($discount_val / $subtotal) * 100;
                        if (round($discount_pct, 2) > round($max_discount_limit, 2)) {
                            throw new Exception("Discount limit exceeded. Maximum allowed is {$max_discount_limit}%.");
                        }
                    }
                }
            }

            // 1. Create Sale Record
            $stmt = $tenant_conn->prepare("INSERT INTO sales (branch_id, customer_id, total_amount, discount_amount, payment_method, status) VALUES (?, ?, ?, ?, ?, 'completed')");
            $stmt->execute([$sale_branch_id, $customer_id ?: null, $total_val, $discount_val, $input['payment_method'] ?? 'Cash']);
            $sale_id = $tenant_conn->lastInsertId();

            // 2. Process Items
            foreach ($input['items'] as $item) {
                $unit_price = isset($item['price']) ? (float)$item['price'] : 0.00;

                // Insert Item
                $stmt = $tenant_conn->prepare("INSERT INTO sale_items (sale_id, product_id, quantity, price) VALUES (?, ?, ?, ?)");
                $stmt->execute([$sale_id, $item['id'], $item['qty'], $unit_price]);

                // Update Stock
                $stockCol = 'stock_level';
                $checkCol = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'stock_quantity'")->fetch();
                if ($checkCol) $stockCol = 'stock_quantity';

                $stmt = $tenant_conn->prepare("UPDATE products SET $stockCol = $stockCol - ? WHERE id = ? AND branch_id = ?");
                $stmt->execute([$item['qty'], $item['id'], $stock_source_id]);

                // Movement Record
                try {
                    $stmt = $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)");
                    $stmt->execute([$item['id'], -($item['qty']), "Bulk Sale #$sale_id"]);
                } catch(Exception $e) {}
            }

            // 3. Optional: Add to Unified Ledger (from ledgers.php context)
            if ($customer_id > 0 && has_module('bulk_sales')) {
                try {
                    // Note: We use the unified 'ledgers' table schema
                    $stmt_ledger = $tenant_conn->prepare("INSERT INTO ledgers (branch_id, party_name, party_type, description, debit, credit) VALUES (?, ?, ?, ?, ?, 0)");
                    $stmt_ledger->execute([$sale_branch_id, $party_name, $party_type, "Bulk Sale Invoice #$sale_id", $total_val]);
                } catch(Exception $e) {}
            }

            $tenant_conn->commit();
            echo json_encode(['success' => true, 'sale_id' => $sale_id, 'message' => 'Bulk sale processed successfully']);
        } catch (Exception $e) {
            if ($tenant_conn->inTransaction()) $tenant_conn->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'billing/update_currency':
        if ($method !== 'POST') { echo json_encode(['success' => false]); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        $tenant_id = $_SESSION['tenant_id'] ?? null;
        
        if (!$tenant_id || !isset($input['currency_code'])) {
            echo json_encode(['success' => false, 'message' => 'Invalid Request']);
            exit;
        }

        try {
            $main_db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
            $stmt = $main_db->prepare("UPDATE tenants SET currency_code = ?, currency_symbol = ? WHERE id = ?");
            $stmt->execute([$input['currency_code'], $input['currency_symbol'], $tenant_id]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'payment/verify':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input) { $input = $_POST; }

        $tenant_id = $_SESSION['tenant_id'] ?? null;
        if (!$tenant_id) { echo json_encode(['success' => false, 'message' => 'Unauthorized']); exit; }

        try {
            // Use the existing main DB connection from db_switch.php instead of reconnecting
            $db = $m_pdo;
            if (!$db) {
                $db = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
                $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            }

            // SELF-HEALING: Ensure missing columns exist in the billing table before insert
            $db->exec("CREATE TABLE IF NOT EXISTS billing (
                id INT PRIMARY KEY AUTO_INCREMENT,
                tenant_id INT NOT NULL,
                package_id INT NOT NULL,
                amount DECIMAL(15,2) NOT NULL,
                account_name VARCHAR(255),
                transaction_id VARCHAR(255) NOT NULL,
                billing_cycle VARCHAR(50) DEFAULT '1_month',
                current_plan_id INT DEFAULT NULL,
                current_expiry_date DATE DEFAULT NULL,
                description TEXT,
                rejection_reason TEXT,
                status ENUM('pending', 'active', 'rejected', 'expired', 'on_hold') DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
            )");

            // Check for missing columns (Self-healing)
            $billing_cols = $db->query("SHOW COLUMNS FROM billing")->fetchAll(PDO::FETCH_COLUMN);
            if (!in_array('billing_cycle', $billing_cols)) $db->exec("ALTER TABLE billing ADD billing_cycle VARCHAR(50) DEFAULT '1_month'");
            if (!in_array('current_plan_id', $billing_cols)) $db->exec("ALTER TABLE billing ADD current_plan_id INT DEFAULT NULL");
            if (!in_array('current_expiry_date', $billing_cols)) $db->exec("ALTER TABLE billing ADD current_expiry_date DATE DEFAULT NULL");

            // Sanitize numeric and date fields that might be "null" strings from JavaScript
            $pkg_id = (!empty($input['package_id']) && $input['package_id'] !== 'null') ? (int)$input['package_id'] : 0;
            $amount = (!empty($input['amount']) && $input['amount'] !== 'null') ? (float)$input['amount'] : 0.00;
            $cur_plan = (!empty($input['current_plan_id']) && $input['current_plan_id'] !== 'null') ? (int)$input['current_plan_id'] : null;
            $cur_expiry = (!empty($input['current_expiry_date']) && $input['current_expiry_date'] !== 'null') ? $input['current_expiry_date'] : null;

            // Storing data in the 'billing' table
            $stmt = $db->prepare("INSERT INTO billing
                (tenant_id, package_id, amount, account_name, transaction_id, description, billing_cycle, current_plan_id, current_expiry_date, status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending')");
            
            $stmt->execute([
                $tenant_id,
                $pkg_id,
                $amount,
                $input['account_name'] ?? '',
                $input['transaction_id'] ?? '',
                $input['description'] ?? null,
                $input['billing_cycle'] ?? '1_month',
                $cur_plan,
                $cur_expiry
            ]);

            echo json_encode(['success' => true, 'message' => 'Payment details submitted. Admin will verify shortly.']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Submission failed: ' . $e->getMessage()]);
        }
        break;

    case 'pos/return':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        
        $input = json_decode(file_get_contents('php://input'), true);
        if (!$input || !isset($input['sale_id']) || !isset($input['items'])) { echo json_encode(['success' => false, 'message' => 'Invalid data received']); exit; }

        $sale_id = $input['sale_id'];
        $return_items = $input['items'];
        $total_refund_amount = 0;

        $active_branch = $_SESSION['active_branch_id'] ?? null;
        $stock_source_id = get_active_stock_branch_id($active_branch);

        try {
            $tenant_conn->beginTransaction();

            // Get Main Branch ID for legacy data support
            $stmt_main = $tenant_conn->query("SELECT id FROM branches WHERE is_main = 1 LIMIT 1");
            $main_id = $stmt_main->fetchColumn();

            // Fetch sale details to calculate refund based on original price
            // Restriction: Only allow searching invoices belonging to current branch (including legacy if Main)
            $branch_cond_sql = ($active_branch == $main_id) ? " AND (branch_id = ? OR branch_id IS NULL)" : " AND branch_id = ?";
            $stmt_sale = $tenant_conn->prepare("SELECT total_amount FROM sales WHERE id = ? $branch_cond_sql");
            $stmt_sale->execute([$sale_id, $active_branch]);
            $sale_info = $stmt_sale->fetch(PDO::FETCH_ASSOC);
            if (!$sale_info) throw new Exception("Sale not found.");

            foreach ($return_items as $item) {
                $product_id = $item['product_id'];
                $return_qty = $item['quantity'];
                $reason = $item['reason'];

                // Get original sale item price
                $stmt_sale_item = $tenant_conn->prepare("SELECT price, quantity, returned_quantity FROM sale_items WHERE sale_id = ? AND product_id = ?");
                $stmt_sale_item->execute([$sale_id, $product_id]);
                $sale_item_info = $stmt_sale_item->fetch(PDO::FETCH_ASSOC);

                if (!$sale_item_info) throw new Exception("Product not found in sale items.");
                
                $available_to_return = $sale_item_info['quantity'] - $sale_item_info['returned_quantity'];
                if ($return_qty > $available_to_return) throw new Exception("Cannot return more than the remaining quantity ($available_to_return left) for product ID $product_id.");

                $refund_per_item = $sale_item_info['price'];
                $item_refund = $refund_per_item * $return_qty;
                $total_refund_amount += $item_refund;

                // 1. Record Return with Branch ID
                $stmt = $tenant_conn->prepare("INSERT INTO pos_returns (branch_id, sale_id, product_id, quantity, reason, refund_amount, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'completed')");
                $stmt->execute([$stock_source_id, $sale_id, $product_id, $return_qty, $reason, $item_refund]);

                // 2. Update Product Stock (Add back to inventory)
                $stockCol = 'stock_level';
                $checkCol = $tenant_conn->query("SHOW COLUMNS FROM products LIKE 'stock_quantity'")->fetch();
                if ($checkCol) $stockCol = 'stock_quantity';
                $stmt = $tenant_conn->prepare("UPDATE products SET $stockCol = $stockCol + ? WHERE id = ? AND branch_id = ?");
                $stmt->execute([$return_qty, $product_id, $stock_source_id]);

                // 3. Update returned_quantity in sale_items
                // This is crucial to track what was returned from the original sale
                $stmt_update_sale_item = $tenant_conn->prepare("UPDATE sale_items SET returned_quantity = returned_quantity + ? WHERE sale_id = ? AND product_id = ?");
                $stmt_update_sale_item->execute([$return_qty, $sale_id, $product_id]);

                // 4. Record Stock Movement (only if stock table exists)
                try { $tenant_conn->prepare("INSERT INTO stock (product_id, quantity_change, reason) VALUES (?, ?, ?)")->execute([$product_id, $return_qty, "POS Return (Sale #$sale_id)"]); } catch(Exception $e) {}
            }

            // After all items are processed, update the main sales record
            // Adjust total_amount in sales table
            $stmt_update_sale_total = $tenant_conn->prepare("UPDATE sales SET total_amount = total_amount - ? WHERE id = ?");
            $stmt_update_sale_total->execute([$total_refund_amount, $sale_id]);

            // Determine overall return status for the sale
            $stmt_check_total_sold = $tenant_conn->prepare("SELECT SUM(quantity) FROM sale_items WHERE sale_id = ?");
            $stmt_check_total_sold->execute([$sale_id]);
            $total_sold_for_sale = $stmt_check_total_sold->fetchColumn() ?: 0;

            $stmt_check_total_returned = $tenant_conn->prepare("SELECT SUM(returned_quantity) FROM sale_items WHERE sale_id = ?");
            $stmt_check_total_returned->execute([$sale_id]);
            $total_returned_for_sale = $stmt_check_total_returned->fetchColumn() ?: 0;

            $new_sale_return_status = 'no_returns';
            if ($total_returned_for_sale > 0 && $total_returned_for_sale < $total_sold_for_sale) {
                $new_sale_return_status = 'partial_return';
            } elseif ($total_returned_for_sale > 0 && $total_returned_for_sale >= $total_sold_for_sale) { // Use >= for full return as items could be removed from sale_items
                $new_sale_return_status = 'full_return';
            }

            $stmt_update_sale_status = $tenant_conn->prepare("UPDATE sales SET return_status = ? WHERE id = ?");
            $stmt_update_sale_status->execute([$new_sale_return_status, $sale_id]);

            $tenant_conn->commit();
            echo json_encode(['success' => true, 'message' => 'Return processed.', 'refund_amount' => $total_refund_amount]);
        } catch (Exception $e) {
            if ($tenant_conn->inTransaction()) $tenant_conn->rollBack();
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'settings':
        // Fetch Marketplace status from main DB
        $marketplace_listing_status = 0;
        $marketplace_listing_visibility = 0; // Renamed from dummy_status
        try {
            $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
            $stmt = $main_pdo->prepare("SELECT marketplace_listing_status, marketplace_listing_visibility FROM tenants WHERE db_name = ?");
            $stmt->execute([$_SESSION['db_name']]);
            $t_data = $stmt->fetch(PDO::FETCH_ASSOC);
            $marketplace_listing_status = $t_data['marketplace_listing_status'] ?? 0;
            $marketplace_listing_visibility = $t_data['marketplace_listing_visibility'] ?? 0; // Renamed from dummy_setting
        } catch(Exception $e) {}

        echo json_encode([
            'business_name' => $_SESSION['business_name'] ?? 'Biltax',
            'global_tax_rate' => (float)$global_tax_rate,
            'currency' => $currency_symbol,
            'max_discount_limit' => (float)$max_discount_limit,
            'marketplace_listing_status' => (int)$marketplace_listing_status,
            'marketplace_listing_visibility' => (int)$marketplace_listing_visibility,
            'storageUsage' => (float)$current_storage_usage,
            'storageLimit' => (int)$storage_limit
        ]);
        break;

    case 'feature_request':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        
        $module_key = $_POST['module_key'] ?? $_POST['module_key'] ?? null;
        $module_name = $_POST['module_name'] ?? $_POST['module_name'] ?? 'Unknown Feature';

        if (!$module_key) {
            echo json_encode(['success' => false, 'message' => 'Module key is required.']);
            exit;
        }

        try {
            // Check if a similar request is already pending
            $stmt_check = $m_pdo->prepare("SELECT COUNT(*) FROM feature_requests WHERE tenant_id = ? AND module_key = ? AND status = 'pending'");
            $stmt_check->execute([$t_conf['id'], $module_key]);
            if ($stmt_check->fetchColumn() > 0) {
                echo json_encode(['success' => false, 'message' => 'This feature request is already pending.']);
                exit;
            }

            $stmt = $m_pdo->prepare("INSERT INTO feature_requests (tenant_id, module_key, module_name) VALUES (?, ?, ?)");
            $stmt->execute([$t_conf['id'], $module_key, $module_name]);
            echo json_encode(['success' => true, 'message' => 'Feature request submitted successfully.']);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => 'Database error: ' . $e->getMessage()]);
        }
        break;

    case 'invoice/fetch':
        $order_id = $_GET['order_id'] ?? null;
        $type = $_GET['type'] ?? 'sale'; // sale, purchase, b2b, bulk

        try {
            $data = [];
            if ($type === 'sale') {
                $stmt = $tenant_conn->prepare("SELECT s.*, c.name as customer_name, c.phone as customer_phone, c.email as customer_email FROM sales s LEFT JOIN customers c ON s.customer_id = c.id WHERE s.id = ?");
                $stmt->execute([$order_id]);
                $data['order'] = $stmt->fetch(PDO::FETCH_ASSOC);
                
                $stmt_items = $tenant_conn->prepare("SELECT si.*, p.name FROM sale_items si JOIN products p ON si.product_id = p.id WHERE si.sale_id = ?");
                $stmt_items->execute([$order_id]);
                $data['items'] = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
            } 
            elseif ($type === 'purchase') {
                $stmt = $tenant_conn->prepare("SELECT p.*, s.name as supplier_name FROM purchases p LEFT JOIN suppliers s ON p.supplier_id = s.id WHERE p.id = ?");
                $stmt->execute([$order_id]);
                $data['order'] = $stmt->fetch(PDO::FETCH_ASSOC);

                $stmt_items = $tenant_conn->prepare("SELECT pi.*, p.name FROM purchase_items pi JOIN products p ON pi.product_id = p.id WHERE pi.purchase_id = ?");
                $stmt_items->execute([$order_id]);
                $data['items'] = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
            }
            elseif ($type === 'job') { // New logic for Service Job Invoice
                $stmt = $tenant_conn->prepare("SELECT j.*, c.name as customer_name, c.phone as customer_phone, c.email as customer_email, s.service_name 
                                               FROM job_cards j 
                                               LEFT JOIN customers c ON j.customer_id = c.id 
                                               LEFT JOIN services s ON j.service_id = s.id 
                                               WHERE j.id = ?");
                $stmt->execute([$order_id]);
                $data['order'] = $stmt->fetch(PDO::FETCH_ASSOC);

                if ($data['order']) {
                    // Price detection: Priority 1: total_cost, Priority 2: estimated_cost, Priority 3: 0
                    $final_price = 0;
                    if (!empty($data['order']['total_cost']) && $data['order']['total_cost'] > 0) {
                        $final_price = (float)$data['order']['total_cost'];
                    } else {
                        $final_price = (float)($data['order']['estimated_cost'] ?? 0);
                    }
                    
                    $data['order']['total_amount'] = $final_price;

                    $data['items'] = [
                        [
                            'name' => $data['order']['service_name'] . " - " . $data['order']['device_model'],
                            'quantity' => 1,
                            'price' => $final_price
                        ]
                    ];
                } else {
                    $data['items'] = [];
                }
            }
            elseif ($type === 'b2b') {
                $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
                $stmt = $main_pdo->prepare("SELECT o.*, s.business_name as sender_name, r.business_name as receiver_name 
                                           FROM b2b_orders o 
                                           JOIN tenants s ON o.sender_tenant_id = s.id 
                                           JOIN tenants r ON o.receiver_tenant_id = r.id 
                                           WHERE o.id = ?");
                $stmt->execute([$order_id]);
                $data['order'] = $stmt->fetch(PDO::FETCH_ASSOC);

                $stmt_items = $main_pdo->prepare("SELECT * FROM b2b_order_items WHERE order_id = ?");
                $stmt_items->execute([$order_id]);
                $b2b_items = $stmt_items->fetchAll(PDO::FETCH_ASSOC);
                
                // Map product names from provider side
                foreach($b2b_items as &$bi) {
                    $p_stmt = $tenant_conn->prepare("SELECT name FROM products WHERE id = ?");
                    $p_stmt->execute([$bi['subscriber_item_id']]);
                    $bi['name'] = $p_stmt->fetchColumn() ?: "Mapped Product";
                }
                $data['items'] = $b2b_items;
            }

            if (!$data['order']) throw new Exception("Order not found");
            echo json_encode(['success' => true, 'data' => $data]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'sales/get_sale_for_reprint':
        if (ob_get_length()) ob_clean(); // Clear any previous warnings/notices
        $order_id = $_GET['sale_id'] ?? null;
        if (!$order_id) { echo json_encode(['success' => false, 'message' => 'Sale ID is required.']); exit; }

        try {
            $stmt = $tenant_conn->prepare("SELECT s.*, c.name as customer_name, c.phone as customer_phone, c.address FROM sales s LEFT JOIN customers c ON s.customer_id = c.id WHERE s.id = ?");
            $stmt->execute([$order_id]);
            $order_data = $stmt->fetch(PDO::FETCH_ASSOC);

            if (!$order_data) { throw new Exception("Sale not found."); }
            
            $stmt_items = $tenant_conn->prepare("SELECT si.price, si.quantity as qty, p.name, u.name as unit_name FROM sale_items si JOIN products p ON si.product_id = p.id LEFT JOIN units u ON p.unit_id = u.id WHERE si.sale_id = ?");
            $stmt_items->execute([$order_id]);
            $items_data = $stmt_items->fetchAll(PDO::FETCH_ASSOC);

            // Format data to match lastSaleInfo structure in pos.php
            $formatted_data = [
                'id' => $order_data['id'], 
                'items' => $items_data, 
                'total' => (float)$order_data['total_amount'], 
                'discount' => (float)($order_data['discount_amount'] ?? 0), 
                'subtotal' => (float)$order_data['total_amount'] + (float)($order_data['discount_amount'] ?? 0), 
                'method' => $order_data['payment_method'] ?? 'Cash'
            ];

            echo json_encode(['success' => true, 'data' => $formatted_data]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'notifications/counts':
        try {
            if (!$t_conf || !isset($t_conf['id'])) {
                echo json_encode(['success' => false, 'message' => 'Tenant not identified.']);
                exit;
            }
            $tenant_id = $t_conf['id'];

            // Trigger sync functions to ensure latest data is in notifications table
            syncLowStockAlerts(DB_HOST, DB_USER, DB_PASS, $tenant_conn, $_SESSION['db_name']);
            syncExpiringStockAlerts(DB_HOST, DB_USER, DB_PASS, $tenant_conn, $_SESSION['db_name']);
            syncServiceRemindersAlerts(DB_HOST, DB_USER, DB_PASS, $tenant_conn, $_SESSION['db_name']);
            syncB2BAlerts(DB_HOST, DB_USER, DB_PASS, $tenant_conn, $_SESSION['db_name']);
            if (isset($m_pdo) && $m_pdo instanceof PDO && $tenant_id) {
                syncSubscriptionExpiryNotifications($m_pdo, $tenant_id);
            }

            // Fetch unread notification counts for various types
            $counts = [];
            $total_unread_notifications = 0;

            // General unread notifications
            $stmt_gen = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND is_read = 0");
            $stmt_gen->execute([$tenant_id]);
            $total_unread_notifications = $stmt_gen->fetchColumn();

            // Low Stock Alerts
            $stmt_low_stock = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND type = 'system' AND title LIKE '%Low Stock Alert%' AND is_read = 0");
            $stmt_low_stock->execute([$tenant_id]);
            $counts['low_stock'] = $stmt_low_stock->fetchColumn();

            // Expiring Stock Alerts
            $stmt_expiring_stock = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND type = 'expiry_alert' AND is_read = 0");
            $stmt_expiring_stock->execute([$tenant_id]);
            $counts['expiring_stock'] = $stmt_expiring_stock->fetchColumn();

            // Verification Requests
            $stmt_verification = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND type = 'verification_task' AND is_read = 0");
            $stmt_verification->execute([$tenant_id]);
            $counts['verification_requests'] = $stmt_verification->fetchColumn();

            // Partner Requests / New B2B Orders
            $stmt_b2b = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND type = 'b2b_order' AND is_read = 0");
            $stmt_b2b->execute([$tenant_id]);
            $counts['b2b_orders'] = $stmt_b2b->fetchColumn();

            // Service Reminders
            $stmt_reminders = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND type = 'service_reminder' AND is_read = 0");
            $stmt_reminders->execute([$tenant_id]);
            $counts['service_reminders'] = $stmt_reminders->fetchColumn();

            // Support Tickets (Placeholder, assuming a 'support_ticket' type exists in notifications)
            $stmt_support = $m_pdo->prepare("SELECT COUNT(*) FROM notifications WHERE tenant_id = ? AND type = 'support_ticket' AND is_read = 0");
            $stmt_support->execute([$tenant_id]);
            $counts['support_tickets'] = $stmt_support->fetchColumn();

            echo json_encode(['success' => true, 'total_unread' => $total_unread_notifications, 'counts' => $counts]);
        } catch (Exception $e) {
            echo json_encode(['success' => false, 'message' => $e->getMessage()]);
        }
        break;

    case 'notifications/mark_read':
        if ($method !== 'POST') { echo json_encode(['success' => false, 'message' => 'Invalid method']); exit; }
        $input = json_decode(file_get_contents('php://input'), true);
        $notification_id = $input['id'] ?? null;
        try {
            $stmt = $m_pdo->prepare("UPDATE notifications SET is_read = 1 WHERE id = ? AND tenant_id = ?");
            $stmt->execute([$notification_id, $t_conf['id']]);
            echo json_encode(['success' => true]);
        } catch (Exception $e) { echo json_encode(['success' => false, 'message' => $e->getMessage()]); }
        break;

    case 'super_admin/return':
        if (isset($_SESSION['super_admin_backup'])) {
            // Restore Super Admin session
            $_SESSION = $_SESSION['super_admin_backup'];
            unset($_SESSION['super_admin_backup']); // Clear backup
            echo json_encode(['success' => true, 'redirect' => 'super_admin/dashboard.php']);
        } else {
            echo json_encode(['success' => false, 'message' => 'No Super Admin session to restore.']);
        }
        exit;
    default:
        echo json_encode(['success' => false, 'message' => 'Route not found']);
        break;
}