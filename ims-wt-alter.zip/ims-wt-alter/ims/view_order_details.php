<?php
require_once 'config/db_switch.php';
if (!isset($_SESSION['tenant_id'])) header("Location: login.php");

$order_id = $_GET['id'] ?? null;
$type = $_GET['type'] ?? 'partner';
if (!$order_id) die("Order ID missing.");

$main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);

if ($type === 'manual') {
    $party_label = "Supplier";
    // 1. Fetch Manual Order Metadata from Tenant DB
    $stmt = $tenant_conn->prepare("SELECT p.id, p.total_amount, p.created_at, p.status, p.payment_status, s.name as supplier_name 
                                  FROM purchases p 
                                  LEFT JOIN suppliers s ON p.supplier_id = s.id 
                                  WHERE p.id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    // 2. Fetch Items from Tenant DB (mapped to B2B structure for the loop)
    $stmt = $tenant_conn->prepare("SELECT pi.product_id as subscriber_item_id, pi.quantity, pi.purchase_price as price 
                                  FROM purchase_items pi 
                                  WHERE pi.purchase_id = ?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    // Fetch B2B Order Metadata from Main DB
    // Access allowed if user is either Sender or Receiver
    $stmt = $main_pdo->prepare("SELECT o.*, 
                                o.sender_branch_id,
                                o.receiver_branch_id,
                                sender.business_name as sender_name, 
                                receiver.business_name as receiver_name 
                                FROM b2b_orders o 
                                JOIN tenants sender ON o.sender_tenant_id = sender.id 
                                JOIN tenants receiver ON o.receiver_tenant_id = receiver.id 
                                WHERE o.id = ? AND (o.sender_tenant_id = ? OR o.receiver_tenant_id = ?)"); // No branch filtering here, show all orders for the tenant
    $stmt->execute([$order_id, $_SESSION['tenant_id'], $_SESSION['tenant_id']]);
    $order = $stmt->fetch(PDO::FETCH_ASSOC);

    $is_receiver = ($order['receiver_tenant_id'] == $_SESSION['tenant_id']);
    $display_party_name = $is_receiver ? $order['sender_name'] : $order['receiver_name'];
    $party_label = $is_receiver ? "Customer" : "Supplier";

    // Self-healing for dispute columns
    $b2b_cols = $main_pdo->query("SHOW COLUMNS FROM b2b_orders")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('dispute_reason', $b2b_cols)) {
        $main_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN dispute_reason TEXT");
    }
    if (!in_array('dispute_image', $b2b_cols)) {
        $main_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN dispute_image VARCHAR(255)");
    }


    // Fetch B2B Items
    $stmt = $main_pdo->prepare("SELECT oi.* FROM b2b_order_items oi WHERE oi.order_id = ?");
    $stmt->execute([$order_id]);
    $items = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Fetch any active return requests for this order
$r_stmt = $main_pdo->prepare("SELECT * FROM b2b_return_requests WHERE order_id = ?");
$r_stmt->execute([$order_id]);
$active_returns = $r_stmt->fetchAll(PDO::FETCH_ASSOC);

// Create a lookup map for returns to highlight items in the table
$return_map = [];
foreach ($active_returns as $ar) {
    $return_map[$ar['subscriber_item_id']] = $ar;
}

if (!$order) die("Order not found or access denied.");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Order Details #<?= $order_id ?> | Biltax</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <script src="theme.js"></script>
    <style>@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;900&display=swap'); body { font-family: 'Inter', sans-serif; }</style>
</head>
<body class="bg-slate-50 dark:bg-neutral-950 transition-colors duration-300 min-h-screen p-8">
    <div class="max-w-4xl mx-auto">
        <header class="flex justify-between items-center mb-8">
            <div>
                <a href="javascript:history.back()" class="text-xs font-bold text-orange-600 uppercase flex items-center gap-1 mb-2 hover:underline"><i data-lucide="arrow-left" size="14"></i> Back to History</a>
                <h1 class="text-3xl font-black dark:text-white uppercase tracking-tight">Order #<?= strtoupper($type) ?>-<?= $order_id ?></h1>
                <p class="text-xs text-slate-500 font-bold uppercase tracking-widest mt-1"><?= $party_label ?>: <?= htmlspecialchars($display_party_name ?? $order['supplier_name']) ?></p>
            </div>
            <div class="flex items-center gap-2">
                <div class="px-4 py-2 rounded-full text-[10px] font-black uppercase border border-orange-500/20 bg-orange-500/10 text-orange-500"><?= $order['status'] ?></div>
                <?php if ($order['payment_status'] ?? 'Unpaid'): ?>
                    <span class="text-[8px] font-black uppercase px-1.5 py-0.5 rounded-md <?= ($order['payment_status'] === 'Paid' ? 'bg-emerald-500/10 text-emerald-500' : 'bg-rose-500/10 text-rose-500') ?>">
                        <?= $order['payment_status'] ?>
                    </span>
                <?php endif; ?>
            </div>
        </header>

        <div class="bg-white dark:bg-neutral-900 rounded-[32px] shadow-2xl border border-slate-200 dark:border-neutral-800 overflow-hidden mb-8">
            <table class="w-full text-left">
                <thead class="bg-slate-50 dark:bg-neutral-950 border-b border-slate-200 dark:border-neutral-800">
                    <tr class="text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <th class="px-8 py-5">Item Name</th>
                        <th class="px-8 py-5 text-center">Qty</th>
                        <th class="px-8 py-5 text-right">Unit Cost</th>
                        <th class="px-8 py-5 text-right">Total</th>
                        <?php if ($order['status'] === 'finalized' && ($type === 'manual' || (isset($is_receiver) && !$is_receiver))): ?>
                            <th class="px-8 py-5 text-right">Actions</th>
                        <?php endif; ?>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-100 dark:divide-neutral-800">
                    <?php foreach($items as $i): 
                        // Get local name based on who is viewing (provider uses provider_item_id, subscriber uses subscriber_item_id)
                        $local_id = ($type !== 'manual' && $is_receiver) ? $i['provider_item_id'] : ($i['subscriber_item_id'] ?? $i['product_id']);
                        $p_stmt = $tenant_conn->prepare("SELECT name FROM products WHERE id = ?");
                        $p_stmt->execute([$local_id]);
                        $local_name = $p_stmt->fetchColumn() ?: "Unknown Product";
                        
                        $has_return = isset($return_map[$i['subscriber_item_id']]);
                        $ret_info = $has_return ? $return_map[$i['subscriber_item_id']] : null;
                    ?>
                    <tr class="dark:text-white">
                        <td class="px-8 py-5">
                            <div class="font-bold"><?= htmlspecialchars($local_name) ?></div>
                            <?php if ($has_return): ?>
                                <div class="mt-1"><span class="text-[9px] font-black uppercase px-2 py-0.5 bg-rose-500/10 text-rose-600 rounded border border-rose-500/20 italic">Return <?= $ret_info['status'] ?>: <?= $ret_info['qty'] ?> units</span></div>
                            <?php endif; ?>
                        </td>
                        <td class="px-8 py-5 text-center font-mono"><?= $i['quantity'] ?></td>
                        <td class="px-8 py-5 text-right font-mono text-slate-500"><?= $currency_symbol ?><?= number_format($i['price'], 2) ?></td>
                        <td class="px-8 py-5 text-right font-black text-emerald-500"><?= $currency_symbol ?><?= number_format($i['price'] * $i['quantity'], 2) ?></td>
                        <?php if ($order['status'] === 'finalized' && ($type === 'manual' || (isset($is_receiver) && !$is_receiver))): ?>
                            <td class="px-8 py-5 text-right">
                                <button onclick="openSingleReturnModal(<?= $i['subscriber_item_id'] ?>, '<?= htmlspecialchars($local_name) ?>', <?= $i['quantity'] ?>)" class="text-[10px] font-black uppercase px-3 py-1 bg-rose-600 text-white rounded-lg hover:bg-rose-700 shadow-md shadow-rose-600/20 transition-all">
                                    Return Item
                                </button>
                            </td>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <div class="p-8 bg-slate-50 dark:bg-neutral-950 border-t border-slate-200 dark:border-neutral-800 flex justify-between items-center">
                <span class="text-xs font-black uppercase text-slate-400">Agreed Total</span>
                <div class="text-right">
                    <span class="text-3xl font-black dark:text-white"><?= $currency_symbol ?><?= number_format($order['total_amount'], 2) ?></span>
                </div>
            </div>
        </div>

        <?php if (!empty($active_returns)): ?>
            <div class="bg-white dark:bg-neutral-900 rounded-3xl shadow-xl border border-slate-200 dark:border-neutral-800 p-8 mb-8">
                <h3 class="text-xs font-black uppercase text-orange-500 mb-4 tracking-widest">Active Return Requests</h3>
                <div class="space-y-3">
                    <?php foreach($active_returns as $ar): 
                        $p_stmt = $tenant_conn->prepare("SELECT name FROM products WHERE id = ?");
                        $p_stmt->execute([$ar['subscriber_item_id']]);
                        $r_name = $p_stmt->fetchColumn();
                    ?>
                        <div class="flex justify-between items-center p-4 bg-slate-50 dark:bg-neutral-950 rounded-2xl border border-slate-100 dark:border-neutral-800">
                            <div>
                                <div class="text-sm font-bold dark:text-white"><?= htmlspecialchars($r_name) ?></div>
                                <div class="text-[10px] text-slate-500 uppercase font-black">Qty: <?= $ar['qty'] ?> • Status: <span class="text-orange-500"><?= $ar['status'] ?></span></div>
                            </div>
                            <?php if($ar['status'] === 'pending'): ?>
                                <button onclick="cancelReturn(<?= $ar['id'] ?>)" class="text-[10px] font-black uppercase text-rose-500 hover:underline">Cancel Request</button>
                            <?php endif; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
                <p class="text-[9px] text-slate-400 mt-4 italic font-medium">* Note: Stock for returning items is currently locked and deducted from your inventory.</p>
            </div>
        <?php endif; ?>

        <?php if ($order['status'] === 'disputed' && $type !== 'manual'): ?>
            <div class="p-6 bg-rose-500/10 border border-rose-500/20 rounded-2xl mb-8">
                <h3 class="text-rose-500 font-black uppercase text-xs mb-2 flex items-center gap-2"><i data-lucide="alert-triangle" size="16"></i> Order Disputed</h3>
                <p class="text-sm text-slate-400 italic">"<?= htmlspecialchars($order['dispute_reason'] ?? 'No reason provided.') ?>"</p>
                <?php if(!empty($order['dispute_image'])): ?>
                    <a href="<?= $order['dispute_image'] ?>" target="_blank" class="text-[10px] text-blue-500 mt-2 inline-block font-bold uppercase hover:underline">View Attached Proof</a>
                <?php endif; ?>
            </div> 
        <?php elseif ($order['status'] === 'shipped' && !$is_receiver): ?>
            <button onclick="confirmStockIn()" id="stockBtn" class="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all flex items-center justify-center gap-3">
                <i data-lucide="package-check"></i> Confirm Receipt
            </button>
        <?php elseif ($order['status'] === 'received' && !$is_receiver): ?>
            <a href="b2b_price_review.php?order_id=<?= $order_id ?>&type=<?= $type ?>" class="w-full py-5 bg-blue-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-blue-600/20 hover:bg-blue-700 transition-all flex items-center justify-center gap-3">
                <i data-lucide="shield-check"></i> Price Review Pending - Finalize Now
            </a>
        <?php elseif ($type === 'manual'): ?>
            <div class="mt-8 space-y-4">
                <?php if ($order['status'] === 'pending'): ?>
                    <button onclick="updateManualStatus('received')" class="w-full py-5 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-indigo-600/20 hover:bg-indigo-700 transition-all flex items-center justify-center gap-3">
                        <i data-lucide="package-check"></i> Mark as Received
                    </button>
                <?php endif; ?>

                <?php if (($order['status'] === 'received' || $order['status'] === 'finalized') && $order['payment_status'] === 'Unpaid'): ?>
                    <button onclick="updateManualPaymentStatus('Paid')" class="w-full py-5 bg-emerald-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-emerald-600/20 hover:bg-emerald-700 transition-all flex items-center justify-center gap-3">
                        <i data-lucide="dollar-sign"></i> Mark as Paid
                    </button>
                <?php endif; ?>

                <?php if ($order['status'] !== 'finalized' && $order['status'] !== 'cancelled'): ?>
                    <button onclick="updateManualStatus('finalized')" class="w-full py-5 bg-slate-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-slate-600/20 hover:bg-slate-700 transition-all flex items-center justify-center gap-3">
                        <i data-lucide="check-circle"></i> Mark as Finalized
                    </button>
                <?php endif; ?>

                <?php if ($order['status'] !== 'finalized' && $order['status'] !== 'cancelled'): ?>
                    <button onclick="updateManualStatus('cancelled')" class="w-full py-3 bg-rose-600/10 text-rose-500 rounded-2xl font-black uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all text-xs">
                        <i data-lucide="x-circle"></i> Cancel Purchase
                    </button>
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (in_array($order['status'], ['shipped', 'received']) && !$is_receiver): ?>
            <button onclick="document.getElementById('disputeModal').classList.replace('hidden', 'flex')" class="w-full mt-4 py-3 bg-white dark:bg-neutral-900 border border-rose-500/50 text-rose-500 rounded-2xl font-black uppercase tracking-widest hover:bg-rose-500 hover:text-white transition-all text-xs">
                Report Issue / Dispute
            </button>
        <?php endif; ?>
    </div>

    <!-- Dispute Modal -->
    <div id="disputeModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('disputeModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Raise Dispute</h2>
            <p class="text-xs text-rose-500 font-bold uppercase tracking-widest mb-6 tracking-tighter">Frozen payment until resolved</p>
            
            <form id="disputeForm" onsubmit="submitDispute(event)" class="space-y-4">
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Issue Details</label>
                    <textarea id="disputeReason" required placeholder="Describe what's wrong (damaged items, wrong quantity...)" class="w-full p-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm h-32"></textarea>
                </div>
                <div>
                    <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Proof Image (Optional)</label>
                    <input type="file" id="disputeFile" accept="image/*" class="w-full text-xs text-slate-400 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-xs file:font-black file:bg-orange-600 file:text-white hover:file:bg-orange-700">
                </div>
                <button type="submit" id="disputeSubmitBtn" class="w-full py-4 bg-rose-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-rose-600/20">Submit Report</button>
            </form>
        </div>
    </div>

    <!-- Single Item Return Modal -->
    <div id="singleReturnModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 p-8 rounded-[40px] w-full max-w-lg shadow-2xl relative">
            <button onclick="document.getElementById('singleReturnModal').classList.replace('flex', 'hidden')" class="absolute top-6 right-6 text-slate-400 hover:text-white"><i data-lucide="x" size="24"></i></button>
            <h2 class="text-2xl font-black dark:text-white uppercase mb-1">Return Items</h2>
            <p id="returnItemTitle" class="text-xs text-orange-500 font-bold uppercase mb-6 tracking-widest"></p>
            
            <form onsubmit="submitSingleReturn(event)" class="space-y-4">
                <input type="hidden" id="return_sub_item_id">
                <div class="space-y-4">
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Return Quantity (Max: <span id="maxQtyLabel"></span>)</label>
                        <input type="number" id="return_qty" required min="1" class="w-full p-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm font-bold">
                    </div>
                    <div>
                        <label class="block text-[10px] font-black uppercase text-slate-500 mb-2">Reason for Return</label>
                        <textarea id="return_reason" required placeholder="e.g. Damaged during shipping, Wrong item size..." class="w-full p-4 bg-slate-50 dark:bg-neutral-900 border border-slate-200 dark:border-neutral-800 rounded-2xl outline-none dark:text-white text-sm h-32"></textarea>
                    </div>
                </div>
                <button type="submit" id="singleReturnSubmitBtn" class="w-full py-4 bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest shadow-xl shadow-orange-600/20 transition-all hover:bg-orange-700">Submit Return Request</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        async function confirmStockIn() {
            if (!confirm("Have you physically received these items? This will update your inventory levels.")) return;
            
            const btn = document.getElementById('stockBtn');
            btn.disabled = true;
            btn.innerHTML = '<i class="animate-spin" data-lucide="loader-2"></i> Confirming...';
            lucide.createIcons();

            try {
                const res = await fetch(`./b2b_actions.php?action=update_status&id=<?= $order_id ?>&status=received`);
                const data = await res.json();
                if (data.success) {
                    window.location.href = "b2b_price_review.php?order_id=<?= $order_id ?>";
                } else {
                    alert(data.message);
                    btn.disabled = false;
                }
            } catch (e) { alert("Network Error"); btn.disabled = false; }
        }

        function openSingleReturnModal(id, name, maxQty) {
            document.getElementById('return_sub_item_id').value = id;
            document.getElementById('returnItemTitle').innerText = name;
            document.getElementById('maxQtyLabel').innerText = maxQty;
            const qtyInput = document.getElementById('return_qty');
            qtyInput.max = maxQty;
            qtyInput.value = maxQty; // Auto-fill max quantity
            setTimeout(() => qtyInput.select(), 100); // Select the text for quick editing
            document.getElementById('singleReturnModal').classList.replace('hidden', 'flex');
            lucide.createIcons();
        }

        async function submitSingleReturn(e) {
            e.preventDefault();
            const btn = document.getElementById('singleReturnSubmitBtn');
            const sub_id = document.getElementById('return_sub_item_id').value;
            const qty = document.getElementById('return_qty').value;
            const reason = document.getElementById('return_reason').value;
            const maxQty = parseFloat(document.getElementById('maxQtyLabel').innerText);

            if (parseFloat(qty) > maxQty) {
                alert("Error: You cannot return more than " + maxQty + " units.");
                btn.disabled = false;
                return;
            }

            btn.disabled = true;
            btn.innerText = 'Submitting...';

            try {
                const res = await fetch('./b2b_actions.php?action=request_return', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ order_id: <?= $order_id ?>, items: [{ subscriber_item_id: sub_id, qty: qty, reason: reason }] })
                });
                const data = await res.json();
                if (data.success) {
                    alert("Return request submitted!");
                    location.reload();
                } else alert(data.message);
            } catch (e) { console.error(e); alert("Network error: " + e.message); }
            btn.disabled = false;
        }

        async function updateManualStatus(status) {
            if (!confirm(`Are you sure you want to mark this purchase as ${status.toUpperCase()}?`)) return;
            try {
                const res = await fetch('create_purchase.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'update_manual_purchase_status', purchase_id: <?= $order_id ?>, status: status })
                });
                const data = await res.json();
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else alert("Error: " + data.message);
            } catch (e) { console.error(e); alert("Network error occurred: " + e.message); }
        }

        async function updateManualPaymentStatus(paymentStatus) {
            if (!confirm(`Are you sure you want to mark this purchase as ${paymentStatus.toUpperCase()}?`)) return;
            try {
                const res = await fetch('create_purchase.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'update_manual_purchase_status', purchase_id: <?= $order_id ?>, payment_status: paymentStatus })
                });
                const data = await res.json();
                if (data.success) {
                    alert(data.message);
                    location.reload();
                } else alert("Error: " + data.message);
            } catch (e) { console.error(e); alert("Network error occurred: " + e.message); }
        }

        async function cancelReturn(returnId) {
            if(!confirm("Are you sure you want to cancel this return? Stock will be released back to your inventory.")) return;
            try {
                const res = await fetch('./b2b_actions.php?action=cancel_return', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ return_id: returnId })
                });
                const data = await res.json();
                if(data.success) {
                    alert("Return request cancelled.");
                    location.reload();
                } else alert(data.message);
            } catch(e) { alert("Error cancelling return"); }
        }

        async function submitDispute(e) {
            e.preventDefault();
            const btn = document.getElementById('disputeSubmitBtn');
            const reason = document.getElementById('disputeReason').value;
            const fileInput = document.getElementById('disputeFile');
            
            const formData = new FormData();
            formData.append('action', 'dispute_order');
            formData.append('id', <?= $order_id ?>);
            formData.append('reason', reason);
            if(fileInput.files[0]) formData.append('proof', fileInput.files[0]);

            btn.disabled = true;
            btn.innerText = 'Reporting...';

            try {
                const res = await fetch('./b2b_actions.php', {
                    method: 'POST',
                    body: formData
                });
                const data = await res.json();
                if (data.success) {
                    alert("Issue reported. Status changed to Disputed.");
                    location.reload();
                } else alert(data.message);
            } catch (e) { alert("Error submitting dispute"); }
            btn.disabled = false;
        }
    </script>
</body>
</html>