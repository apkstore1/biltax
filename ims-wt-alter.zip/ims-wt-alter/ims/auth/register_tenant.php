<?php
/**
 * Tenant Registration Script
 * Refactored to handle dynamic Categories and Packages with Smart Schema Logic.
 */

header("Content-Type: application/json");
require_once '../config/db_connect.php';

// --- Main Database Connection ---
try {
    // Connect to MySQL server first (without selecting DB)
    $main_pdo = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Create Database if not exists
    $main_pdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_MAIN . "`");
    $main_pdo->exec("USE `" . DB_MAIN . "`");

    // Create Tenants Table if not exists
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS tenants (
        id INT PRIMARY KEY AUTO_INCREMENT,
        business_name VARCHAR(255) NOT NULL,
        owner_name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        industry_type VARCHAR(50),
        business_category_id INT,
        package_id INT,
        staff_limit INT DEFAULT 5,
        branch_limit INT DEFAULT 1,
        phone VARCHAR(50),
        storage_limit INT DEFAULT 1, -- Added storage_limit
        address TEXT,
        db_name VARCHAR(255) NOT NULL,
        tax_rate DECIMAL(5,2) DEFAULT 0.00,
        max_discount_limit DECIMAL(15,2) DEFAULT 100.00,
        discount_limit_type ENUM('percentage', 'fixed', 'disabled') DEFAULT 'fixed',
        status VARCHAR(50) DEFAULT 'active',
        logo_url VARCHAR(255),
        shop_image_url VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // --- PATCH: Ensure columns exist for legacy tables (Self-Healing) ---
    $current_cols = $main_pdo->query("SHOW COLUMNS FROM tenants")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('business_category_id', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN business_category_id INT");
    }
    if (!in_array('package_id', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN package_id INT");
    }
    if (!in_array('allowed_units', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN allowed_units TEXT"); // Comma separated values
    }
    if (!in_array('unique_id', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN unique_id VARCHAR(20) UNIQUE AFTER id");
    }
    if (!in_array('staff_limit', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN staff_limit INT DEFAULT 5");
    }
    if (!in_array('branch_limit', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN branch_limit INT DEFAULT 1");
    }
    if (!in_array('storage_limit', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN storage_limit INT DEFAULT 1");
    }
    if (!in_array('country', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN country VARCHAR(100)");
    }
    if (!in_array('tax_rate', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN tax_rate DECIMAL(5,2) DEFAULT 0.00");
    }
    if (!in_array('max_discount_limit', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN max_discount_limit DECIMAL(15,2) DEFAULT 100.00");
    }
    if (!in_array('discount_limit_type', $current_cols)) {
        $main_pdo->exec("ALTER TABLE tenants ADD COLUMN discount_limit_type ENUM('percentage', 'fixed', 'disabled') DEFAULT 'fixed'");
    }

    // Create Packages Table
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS packages (
        id INT PRIMARY KEY AUTO_INCREMENT,
        package_name VARCHAR(50) NOT NULL,
        staff_limit INT NOT NULL DEFAULT 5,
        branch_limit INT NOT NULL DEFAULT 1,
        monthly_price DECIMAL(10, 2) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
    $pkg_cols = $main_pdo->query("SHOW COLUMNS FROM packages")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('storage_limit', $pkg_cols)) {
        $main_pdo->exec("ALTER TABLE packages ADD COLUMN storage_limit INT NOT NULL DEFAULT 1");
    }

    // Seed Packages if empty
    $pkgCount = $main_pdo->query("SELECT COUNT(*) FROM packages")->fetchColumn();
    if ($pkgCount == 0) {
        $main_pdo->exec("INSERT INTO packages (package_name, staff_limit, branch_limit, monthly_price) VALUES 
            ('Starter', 3, 1, 0.00),
            ('Pro', 10, 5, 29.99),
            ('Unlimited', 9999, 999, 99.99)
        ");
    }

    // Create Business Categories Table (Replaces Industries)
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS business_categories (
        id INT PRIMARY KEY AUTO_INCREMENT,
        category_name VARCHAR(50) NOT NULL UNIQUE,
        slug VARCHAR(50) NOT NULL UNIQUE,
        icon_class VARCHAR(50),
        description TEXT,
        is_active TINYINT(1) DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Seed Business Categories
    $catCount = $main_pdo->query("SELECT COUNT(*) FROM business_categories")->fetchColumn();
    if ($catCount == 0) {
        $main_pdo->exec("INSERT INTO business_categories (category_name, slug, icon_class, description) VALUES 
            ('Retail Shop', 'retail', 'shopping-bag', 'Clothing, Electronics, Grocery'),
            ('Restaurant & Cafe', 'restaurant', 'utensils', 'Restaurants, Cafes, Food Trucks'),
            ('Wholesale Distribution', 'wholesale', 'container', 'Distribution, Bulk Selling'),
            ('Service Business', 'service', 'wrench', 'Repair Shop, Salon, Consultancy')
        ");
    }

    // Create Modules Table
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS modules (
        id INT PRIMARY KEY AUTO_INCREMENT,
        module_key VARCHAR(50) NOT NULL UNIQUE,
        module_name VARCHAR(50) NOT NULL UNIQUE,
        status ENUM('active', 'inactive') DEFAULT 'active'
    )");
    $m_cols = $main_pdo->query("SHOW COLUMNS FROM modules")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('module_key', $m_cols)) {
        $main_pdo->exec("ALTER TABLE modules ADD COLUMN module_key VARCHAR(50) NOT NULL UNIQUE AFTER id");
    }

    // Create Category Modules Table (Link)
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS category_modules (
        id INT PRIMARY KEY AUTO_INCREMENT,
        category_id INT NOT NULL,
        module_key VARCHAR(50) NOT NULL,
        FOREIGN KEY (category_id) REFERENCES business_categories(id) ON DELETE CASCADE
    )");

    // Seed Category Modules if empty (Basics for each industry)
    $cmCount = $main_pdo->query("SELECT COUNT(*) FROM category_modules")->fetchColumn();
    if ($cmCount == 0) {
        $main_pdo->exec("INSERT INTO category_modules (category_id, module_key) VALUES 
            (1, 'retail_pos'), (1, 'inventory'), (1, 'reports'), (1, 'settings'),
            (2, 'food_pos'), (2, 'tables'), (2, 'kot'), (2, 'recipes'), (2, 'settings'),
            (3, 'bulk_sales'), (3, 'ledgers'), (3, 'inventory'), (3, 'settings'),
            (4, 'jobs'), (4, 'customers'), (4, 'reminders'), (4, 'settings')");
    }

    // Create Package Features Table (Link)
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS package_features (
        id INT PRIMARY KEY AUTO_INCREMENT,
        package_id INT NOT NULL,
        module_id INT NOT NULL,
        FOREIGN KEY (package_id) REFERENCES packages(id) ON DELETE CASCADE,
        FOREIGN KEY (module_id) REFERENCES modules(id) ON DELETE CASCADE
    )");

    // Create Enabled Modules Table (For Tenant-Specific Features)
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS enabled_modules (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        module_key VARCHAR(50) NOT NULL,
        is_active TINYINT(1) DEFAULT 1,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE,
        UNIQUE KEY unique_module (tenant_id, module_key)
    )");

    // --- NEW: Create Subscriptions Table ---
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS subscriptions (
        id INT PRIMARY KEY AUTO_INCREMENT,
        tenant_id INT NOT NULL,
        plan_id INT NOT NULL,
        billing_cycle ENUM('primary', 'secondary', 'monthly', 'yearly') DEFAULT 'primary',
        start_date DATE NOT NULL,
        expiry_date DATE NOT NULL,
        status ENUM('active', 'expired', 'cancelled', 'trial', 'pending_activation') DEFAULT 'active',
        transaction_id VARCHAR(100) DEFAULT NULL,
        pending_plan_id INT DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
    )");
    // Ensure ENUM is updated if table already exists with old values
    try { $main_pdo->exec("ALTER TABLE subscriptions MODIFY COLUMN billing_cycle ENUM('primary', 'secondary', 'monthly', 'yearly') DEFAULT 'primary'"); } catch(Exception $e) {}

} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['status' => 'error', 'message' => 'Main database connection failed: ' . $e->getMessage()]));
}

// Agar browser mein open kiya jaye (GET request) toh sirf database update ho aur error na aaye.
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(200);
    echo json_encode(['status' => 'success', 'message' => 'Database schema updated successfully. Registration endpoint is active.']);
    exit;
}

// --- Get Data from Request ---
$input = json_decode(file_get_contents('php://input'), true);

$business_name = $input['business_name'] ?? null;
$owner_name    = $input['owner_name'] ?? null; // Now a required field
$email         = $input['email'] ?? null;
$password      = $input['password'] ?? null; // Assuming password comes from form
$industry_type = $input['industry_type'] ?? null;
$country       = $input['country'] ?? 'Pakistan';
$phone         = $input['phone'] ?? null;
$address       = $input['address'] ?? null;
$package_type  = $input['package_type'] ?? 'starter';

// --- Validate Input ---
if (!$business_name || !$owner_name || !$email || !$password || !$industry_type) {
    http_response_code(400);
    die(json_encode(['status' => 'error', 'message' => 'Required fields are missing: business_name, owner_name, email, password, industry_type.']));
}

// --- Registration Process ---
$new_tenant_db_name = null;

try {
    // 1. Start transaction on the main database
    $main_pdo->beginTransaction();

    // 2a. Fetch Category ID from Slug
    $stmt = $main_pdo->prepare("SELECT id FROM business_categories WHERE slug = :slug");
    $stmt->execute([':slug' => $industry_type]);
    $category_id = $stmt->fetchColumn();
    if (!$category_id) {
        throw new Exception("Invalid Industry Category.");
    }

    // 2b. Fetch Package ID from Slug/Name
    // Frontend sends 'starter', DB has 'Starter'.
    $stmt = $main_pdo->prepare("SELECT id, staff_limit, branch_limit, storage_limit FROM packages WHERE package_name LIKE :name");
    $stmt->execute([':name' => $package_type]); // Assuming package_type is like 'Starter'
    $pkg_data = $stmt->fetch(PDO::FETCH_ASSOC);
    $package_id = $pkg_data['id'] ?? 1; // Default to Starter
    $storage_limit = $pkg_data['storage_limit'] ?? 1; // Now correctly fetching from DB
    $pkg_staff_limit = $pkg_data['staff_limit'] ?? 5; // Default staff limit
    $pkg_branch_limit = $pkg_data['branch_limit'] ?? 1;

    // 2. Hash the password for security
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Generate a truly unique ID (BTX-XXXXXX)
    $unique_id = '';
    while (true) {
        $chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
        $res = '';
        for ($i = 0; $i < 6; $i++) { $res .= $chars[mt_rand(0, strlen($chars) - 1)]; }
        $temp_id = 'BTX-' . $res;
        
        $check = $main_pdo->prepare("SELECT COUNT(*) FROM tenants WHERE unique_id = ?");
        $check->execute([$temp_id]);
        if ($check->fetchColumn() == 0) { $unique_id = $temp_id; break; }
    }

    // 3. Insert tenant with a placeholder db_name
    $stmt = $main_pdo->prepare("INSERT INTO tenants (unique_id, business_name, owner_name, email, password, industry_type, country, business_category_id, package_id, staff_limit, branch_limit, storage_limit, phone, address, db_name) VALUES (:uid, :b_name, :o_name, :email, :pass, :i_type, :country, :cat_id, :pkg_id, :s_limit, :b_limit, :storage_limit, :phone, :address, :db_name)"
    );
    $stmt->execute([
        ':uid'     => $unique_id,
        ':b_name'  => $business_name,
        ':o_name'  => $owner_name,
        ':email'   => $email,
        ':pass'    => $hashed_password,
        ':i_type'  => $industry_type,
        ':country' => $country,
        ':cat_id'  => $category_id,
        ':pkg_id'  => $package_id,
        ':s_limit' => $pkg_staff_limit, // Save initial limit from package
        ':storage_limit' => $storage_limit, // Save initial storage limit from package
        ':b_limit' => $pkg_branch_limit,
        ':phone'   => $phone,
        ':address' => $address,
        ':db_name' => 'placeholder'
    ]);

    // 4. Get the new tenant's ID and create the final database name
    $tenant_id = $main_pdo->lastInsertId();
    
    // Generate DB name: biltax_{sanitized_business_name}_db
    $safe_name = preg_replace('/[^a-z0-9_]/', '', str_replace(' ', '_', strtolower($business_name)));
    if (empty($safe_name)) $safe_name = "client_" . $tenant_id;
    $new_tenant_db_name = "biltax_" . $safe_name . "_db";

    // 5. Update the tenant record with the correct db_name
    $update_stmt = $main_pdo->prepare("UPDATE tenants SET db_name = :db_name WHERE id = :id");
    $update_stmt->execute([':db_name' => $new_tenant_db_name, ':id' => $tenant_id]);

    // --- NEW: Initialize 14-Day Trial Subscription ---
    $trial_expiry = date('Y-m-d', strtotime('+14 days'));
    $stmt_sub = $main_pdo->prepare("INSERT INTO subscriptions (tenant_id, plan_id, billing_cycle, start_date, expiry_date, status) VALUES (?, ?, 'primary', CURDATE(), ?, 'trial')");
    // Default to Starter Plan (ID 1)
    $stmt_sub->execute([$tenant_id, 1, $trial_expiry]);

    // 6. Create the new database for the tenant
    $root_pdo = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
    $root_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $root_pdo->exec("CREATE DATABASE `$new_tenant_db_name`");

    // 7. Connect to the new tenant database
    $tenant_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$new_tenant_db_name", DB_USER, DB_PASS);
    $tenant_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // --- Create Base Multi-Branch Tables ---
    $tenant_pdo->exec("CREATE TABLE IF NOT EXISTS branches (
        id INT PRIMARY KEY AUTO_INCREMENT,
        branch_name VARCHAR(255) NOT NULL,
        address TEXT,
        has_own_stock TINYINT(1) DEFAULT 1,
        is_main TINYINT(1) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Seed Main Branch
    $stmt_br = $tenant_pdo->prepare("INSERT INTO branches (branch_name, address, has_own_stock, is_main) VALUES (?, ?, 1, 1)");
    $stmt_br->execute(['Main Account', $address]);
    $main_branch_id = $tenant_pdo->lastInsertId();

    // 8. Smart Schema Logic: Create tables based on Industry
    switch (strtolower($industry_type)) {
        case 'restaurant':
        case 'food':
            $tenant_pdo->exec("
                CREATE TABLE IF NOT EXISTS categories (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL, is_allowed TINYINT(1) DEFAULT 1);
                CREATE TABLE IF NOT EXISTS units (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50) NOT NULL, is_allowed TINYINT(1) DEFAULT 1);
                CREATE TABLE IF NOT EXISTS suppliers (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, company VARCHAR(100), phone VARCHAR(50), email VARCHAR(100), address TEXT);

                INSERT INTO units (name) VALUES ('KG'), ('Liter'), ('Gram'), ('ML'), ('Piece'), ('Box'), ('Pack'), ('Dozen');
                INSERT INTO categories (name) VALUES ('Appetizers'), ('Main Course'), ('Desserts'), ('Beverages'), ('General');

                CREATE TABLE products (
                    id INT PRIMARY KEY AUTO_INCREMENT, branch_id INT, name VARCHAR(255) NOT NULL, sku VARCHAR(100),
                    sale_price DECIMAL(10, 2) NOT NULL, purchase_price DECIMAL(10, 2),
                    category_id INT, unit_id INT, supplier_id INT, stock_level INT DEFAULT 0, alert_level INT DEFAULT 10,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY branch_sku_idx (branch_id, sku)
                );
                CREATE TABLE recipes (
                    id INT PRIMARY KEY AUTO_INCREMENT, product_id INT, ingredient_name VARCHAR(255), 
                    quantity VARCHAR(50), FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE CASCADE
                );
                CREATE TABLE restaurant_tables (
                    id INT PRIMARY KEY AUTO_INCREMENT, branch_id INT, table_number VARCHAR(50) NOT NULL, 
                    capacity INT DEFAULT 2, status ENUM('available', 'occupied', 'reserved') DEFAULT 'available',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE orders (
                    id INT PRIMARY KEY AUTO_INCREMENT, table_id INT, total_amount DECIMAL(10, 2) DEFAULT 0.00,
                    status ENUM('pending', 'cooking', 'served', 'paid') DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (table_id) REFERENCES tables(id)
                );
            ");
            break;

        case 'retail':
            $tenant_pdo->exec("
                CREATE TABLE IF NOT EXISTS categories (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL, is_allowed TINYINT(1) DEFAULT 1);
                CREATE TABLE IF NOT EXISTS units (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50) NOT NULL, is_allowed TINYINT(1) DEFAULT 1);
                CREATE TABLE IF NOT EXISTS suppliers (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, company VARCHAR(100), phone VARCHAR(50), email VARCHAR(100), address TEXT);
                
                INSERT INTO units (name) VALUES ('KG'), ('Liter'), ('Gram'), ('ML'), ('Piece'), ('Box'), ('Pack'), ('Dozen'), ('Meter'), ('Pair');
                INSERT INTO categories (name) VALUES ('Electronics'), ('Grocery'), ('Clothing'), ('Pharmacy'), ('Stationery'), ('General'), ('Hardware'), ('Cosmetics');

                CREATE TABLE products (
                    id INT PRIMARY KEY AUTO_INCREMENT, branch_id INT, name VARCHAR(255) NOT NULL, sku VARCHAR(100),
                    barcode VARCHAR(100), sale_price DECIMAL(10, 2) NOT NULL, purchase_price DECIMAL(10, 2),
                    category_id INT, unit_id INT, supplier_id INT, stock_level INT DEFAULT 0, alert_level INT DEFAULT 10,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY branch_sku_idx (branch_id, sku)
                );
                CREATE TABLE stock (
                    id INT PRIMARY KEY AUTO_INCREMENT, product_id INT, quantity_change INT, 
                    reason VARCHAR(255), expiry_date DATE DEFAULT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (product_id) REFERENCES products(id)
                );
                CREATE TABLE sales (
                    id INT PRIMARY KEY AUTO_INCREMENT, total_amount DECIMAL(10, 2) NOT NULL, discount_amount DECIMAL(10, 2) DEFAULT 0.00,
                    payment_method VARCHAR(50), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE sale_items (
                    id INT PRIMARY KEY AUTO_INCREMENT, sale_id INT, product_id INT, quantity INT,
                    price DECIMAL(10, 2), FOREIGN KEY (sale_id) REFERENCES sales(id),
                    FOREIGN KEY (product_id) REFERENCES products(id)
                );
            ");
            break;

        case 'wholesale':
            $tenant_pdo->exec("
                CREATE TABLE IF NOT EXISTS categories (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(100) NOT NULL, is_allowed TINYINT(1) DEFAULT 1);
                CREATE TABLE IF NOT EXISTS units (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(50) NOT NULL, is_allowed TINYINT(1) DEFAULT 1);
                CREATE TABLE IF NOT EXISTS suppliers (id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, company VARCHAR(100), phone VARCHAR(50), email VARCHAR(100), address TEXT);

                INSERT INTO units (name) VALUES ('KG'), ('Liter'), ('Gram'), ('ML'), ('Piece'), ('Box'), ('Pack'), ('Dozen');
                INSERT INTO categories (name) VALUES ('Electronics'), ('Grocery'), ('Clothing'), ('Stationery'), ('General');

                CREATE TABLE products (
                    id INT PRIMARY KEY AUTO_INCREMENT, branch_id INT, name VARCHAR(255) NOT NULL, sku VARCHAR(100),
                    sale_price DECIMAL(10, 2) NOT NULL, purchase_price DECIMAL(10, 2),
                    category_id INT, unit_id INT, supplier_id INT, stock_level INT DEFAULT 0, alert_level INT DEFAULT 10,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
                    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    UNIQUE KEY branch_sku_idx (branch_id, sku)
                );
                CREATE TABLE party_ledgers (
                    id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, type ENUM('supplier', 'customer'),
                    phone VARCHAR(50), balance DECIMAL(10, 2) DEFAULT 0.00, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE bulk_orders (
                    id INT PRIMARY KEY AUTO_INCREMENT, party_id INT, total_amount DECIMAL(10, 2),
                    status ENUM('pending', 'approved', 'shipped') DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, FOREIGN KEY (party_id) REFERENCES party_ledgers(id)
                );
            ");
            break;

        case 'service':
            $tenant_pdo->exec("
                CREATE TABLE customers (
                    id INT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(255) NOT NULL, phone VARCHAR(50),
                    email VARCHAR(100), address TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                );
                CREATE TABLE job_cards (
                    id INT PRIMARY KEY AUTO_INCREMENT, customer_id INT, description TEXT,
                    status ENUM('received', 'in_progress', 'completed', 'delivered') DEFAULT 'received',
                    estimated_cost DECIMAL(10, 2), created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (customer_id) REFERENCES customers(id)
                );
                CREATE TABLE reminders (
                    id INT PRIMARY KEY AUTO_INCREMENT, customer_id INT, message TEXT,
                    due_date DATE, status ENUM('pending', 'sent') DEFAULT 'pending',
                    FOREIGN KEY (customer_id) REFERENCES customers(id)
                );
            ");
            break;
    }

    // 8a. Assign Default Modules based on Industry from category_modules table
    $stmt_modules = $main_pdo->prepare("SELECT module_key FROM category_modules WHERE category_id = ?");
    $stmt_modules->execute([$category_id]);
    $modules_to_enable = $stmt_modules->fetchAll(PDO::FETCH_COLUMN);
    
    $mod_stmt = $main_pdo->prepare("INSERT INTO enabled_modules (tenant_id, module_key) VALUES (:tid, :key) ON DUPLICATE KEY UPDATE is_active = 1"); // Added ON DUPLICATE KEY UPDATE
    foreach ($modules_to_enable as $mod_key) {
        $mod_stmt->execute([':tid' => $tenant_id, ':key' => $mod_key]);
    }

    // 9. If everything is successful, commit the transaction
    $main_pdo->commit();

    http_response_code(201);
    echo json_encode(['status' => 'success', 'message' => 'Tenant registered successfully.', 'tenant_id' => $tenant_id, 'database_created' => $new_tenant_db_name]);

} catch (PDOException $e) {
    // If any error occurs, roll back the main transaction
    if ($main_pdo->inTransaction()) {
        $main_pdo->rollBack();
    }

    // If the new database was created before the error, drop it to keep things clean
    if ($new_tenant_db_name) {
        $root_pdo = new PDO("mysql:host=" . DB_HOST, DB_USER, DB_PASS);
        $root_pdo->exec("DROP DATABASE IF EXISTS `$new_tenant_db_name`");
    }

    http_response_code(500);
    echo json_encode(['status' => 'error', 'message' => 'Registration failed: ' . ($e->getCode() == 23000 ? 'Email already exists.' : $e->getMessage())]);
}