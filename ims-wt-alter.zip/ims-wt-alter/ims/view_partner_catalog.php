<?php
session_start();
// Debugging: Error reporting on karein taake 500 ki jagah asli error dikhe
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ensure the user is logged in as a tenant (subscriber)
if (!isset($_SESSION['tenant_id']) || !isset($_SESSION['db_name'])) {
    header('Location: /login.php'); // Redirect to login page
    exit;
}

$subscriber_tenant_id = $_SESSION['tenant_id'];
$subscriber_db_name = $_SESSION['db_name']; // Not directly used here, but good to have

require_once 'config/db_connect.php';

$main_pdo = null;
try {
    $main_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=" . DB_MAIN, DB_USER, DB_PASS);
    $main_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Self-healing: B2B Orders Tables
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS b2b_orders (
        id INT PRIMARY KEY AUTO_INCREMENT,
        sender_tenant_id INT NOT NULL,
        receiver_tenant_id INT NOT NULL,
        status ENUM('pending', 'shipped', 'received', 'finalized') DEFAULT 'pending',
        sender_branch_id INT DEFAULT NULL,
        receiver_branch_id INT DEFAULT NULL,
        total_amount DECIMAL(15,2) DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    $main_pdo->exec("CREATE TABLE IF NOT EXISTS b2b_order_items (
        id INT PRIMARY KEY AUTO_INCREMENT,
        order_id INT NOT NULL,
        provider_item_id INT NOT NULL,
        subscriber_item_id INT DEFAULT NULL,
        quantity DECIMAL(10,2) NOT NULL,
        price DECIMAL(15,2) NOT NULL,
        uom VARCHAR(50) DEFAULT 'pcs'
    )");
    
    $b2b_cols = $main_pdo->query("SHOW COLUMNS FROM b2b_orders")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('sender_branch_id', $b2b_cols)) {
        $main_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN sender_branch_id INT DEFAULT NULL AFTER sender_tenant_id");
    }
    if (!in_array('receiver_branch_id', $b2b_cols)) {
        $main_pdo->exec("ALTER TABLE b2b_orders ADD COLUMN receiver_branch_id INT DEFAULT NULL AFTER receiver_tenant_id");
    }
    
    // Self-healing: Ensure b2b_product_mappings exists in main database
    $main_pdo->exec("CREATE TABLE IF NOT EXISTS b2b_product_mappings (
        id INT PRIMARY KEY AUTO_INCREMENT,
        provider_tenant_id INT NOT NULL,
        subscriber_tenant_id INT NOT NULL,
        provider_item_id INT NOT NULL,
        subscriber_item_id INT DEFAULT NULL,
        auto_sync_cost TINYINT(1) DEFAULT 1,
        last_sync_at TIMESTAMP NULL,
        INDEX (provider_tenant_id), INDEX (subscriber_tenant_id)
    )");
} catch (PDOException $e) {
    die("Error connecting to main database: " . $e->getMessage());
}

// Get provider_tenant_id from URL
$provider_tenant_id = $_GET['provider_id'] ?? null;

if (!$provider_tenant_id) {
    die("Provider ID is missing.");
}

// 1. Verify connection status (Using sender/receiver logic to match connect_partner.php)
$stmt = $main_pdo->prepare("SELECT status FROM tenant_connections 
    WHERE ((sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)) 
    AND status = 'accepted'");
$stmt->execute([$provider_tenant_id, $subscriber_tenant_id, $subscriber_tenant_id, $provider_tenant_id]);
$connection_status = $stmt->fetchColumn();

if (!$connection_status) {
    die("Access Denied: You are not connected to this partner or the request is pending.");
}

// 1a. Fetch Subscriber's (Your) Currency Symbol
$stmt = $main_pdo->prepare("SELECT currency_symbol FROM tenants WHERE id = ?");
$stmt->execute([$subscriber_tenant_id]);
$subscriber_currency = $stmt->fetchColumn() ?: '$';

// 2. Get provider's database name and business name
$stmt = $main_pdo->prepare("SELECT db_name, business_name FROM tenants WHERE id = ?");
$stmt->execute([$provider_tenant_id]);
$provider_info = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$provider_info) {
    die("Provider not found.");
}

$provider_db_name = $provider_info['db_name'];
$provider_business_name = $provider_info['business_name'];

// 3. Connect to provider's database
$provider_pdo = null;
try {
    $provider_pdo = new PDO("mysql:host=" . DB_HOST . ";dbname=$provider_db_name", DB_USER, DB_PASS);
    $provider_pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Self-healing: Ensure Provider's products table has B2B columns
    $p_cols = $provider_pdo->query("SHOW COLUMNS FROM products")->fetchAll(PDO::FETCH_COLUMN);
    if (!in_array('is_b2b_public', $p_cols)) {
        $provider_pdo->exec("ALTER TABLE products ADD COLUMN is_b2b_public TINYINT(1) DEFAULT 0");
    }
    if (!in_array('allow_partner_view', $p_cols)) {
        $provider_pdo->exec("ALTER TABLE products ADD COLUMN allow_partner_view TINYINT(1) DEFAULT 0");
    }
    if (!in_array('is_active', $p_cols)) {
        $provider_pdo->exec("ALTER TABLE products ADD COLUMN is_active TINYINT(1) DEFAULT 1");
    }
} catch (PDOException $e) {
    die("Error connecting to provider's database: " . $e->getMessage());
}

// 4. Fetch products from provider's database
// Assuming products table has 'name', 'category_id', 'sku', 'sale_price'
// And categories table has 'name'
$products = [];
try {
    $stmt = $provider_pdo->query("
        SELECT 
            p.id as product_id, 
            p.name as product_name, 
            c.name as category_name, 
            p.sku, 
            p.sale_price 
        FROM products p
        LEFT JOIN categories c ON p.category_id = c.id
        WHERE (p.is_active = 1 OR p.is_active IS NULL)
        AND (p.is_b2b_public = 1 OR p.allow_partner_view = 1)
        ORDER BY p.name ASC
    ");
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Handle cases where 'is_active' or 'category_id' might not exist in older tenant DBs
    // Fallback query without is_active and category_name
    try {
        $stmt = $provider_pdo->query("
            SELECT 
                p.id as product_id, 
                p.name as product_name, 
                NULL as category_name, 
                p.sku, 
                p.sale_price 
            FROM products p
            WHERE (p.is_b2b_public = 1 OR p.allow_partner_view = 1)
            ORDER BY p.name ASC
        ");
        $products = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } catch (PDOException $e2) {
        die("Error fetching products from provider's database: " . $e2->getMessage());
    }
}


// 5. Fetch existing mappings for the current subscriber and provider
$mapped_products = [];
$stmt = $main_pdo->prepare("SELECT provider_item_id FROM b2b_product_mappings WHERE provider_tenant_id = ? AND subscriber_tenant_id = ?");
$stmt->execute([$provider_tenant_id, $subscriber_tenant_id]);
foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $item_id) {
    $mapped_products[$item_id] = true;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Partner Catalog - <?php echo htmlspecialchars($provider_business_name); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Theme Logic -->
    <script src="theme.js"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;800&display=swap');
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-neutral-50 text-slate-900 min-h-screen p-8 transition-colors duration-300 dark:bg-neutral-900 dark:text-neutral-200">

    <div class="max-w-7xl mx-auto">
        <header class="mb-8 flex justify-between items-center">
            <div>
                <h1 class="text-3xl font-black tracking-tight text-slate-900 dark:text-white">Partner Catalog</h1>
                <p class="text-sm text-orange-500 uppercase tracking-widest">Viewing products from: <?php echo htmlspecialchars($provider_business_name); ?></p>
            </div>
            
            <div class="flex items-center gap-3">
                <button onclick="toggleTheme()" class="p-2 rounded-xl text-slate-400 hover:text-orange-500 hover:bg-slate-50 dark:hover:bg-neutral-800 transition-colors flex items-center gap-2">
                    <i id="theme-icon" data-lucide="sun" size="18"></i>
                </button>
                <a href="connect_partner.php" class="inline-flex items-center gap-2 px-4 py-2 bg-orange-600 text-white rounded-xl font-bold text-sm hover:bg-orange-700 transition-colors">
                    <i data-lucide="arrow-left" size="16"></i> Back to Dashboard
                </a>
            </div>
        </header>

        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-2xl shadow-xl overflow-hidden">
            <table class="min-w-full divide-y divide-slate-200 dark:divide-neutral-800">
                <thead class="bg-slate-50 dark:bg-neutral-950">
                    <tr>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Product Name</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Category</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">SKU</th>
                        <th scope="col" class="px-6 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Price</th>
                        <th scope="col" class="px-6 py-3 text-center text-xs font-medium text-slate-500 uppercase tracking-wider">Status / Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-slate-200 dark:divide-neutral-800">
                    <?php if (empty($products)): ?>
                        <tr>
                            <td colspan="5" class="px-6 py-4 text-center text-slate-500 italic">No products found in this catalog.</td>
                        </tr>
                    <?php else: ?>
                        <?php foreach ($products as $product): ?>
                            <tr class="hover:bg-slate-50 dark:hover:bg-neutral-900/50 transition-colors">
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-slate-900 dark:text-white"><?php echo htmlspecialchars($product['product_name']); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-neutral-400"><?php echo htmlspecialchars($product['category_name'] ?? 'N/A'); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-slate-500 dark:text-neutral-400"><?php echo htmlspecialchars($product['sku'] ?? 'N/A'); ?></td>
                                <td class="px-6 py-4 whitespace-nowrap text-sm font-bold text-green-600 dark:text-green-500"><?php echo $subscriber_currency; ?><?php echo number_format($product['sale_price'] ?? 0, 2); ?></td>
                                <td id="actions_<?= $product['product_id'] ?>" class="px-6 py-4 whitespace-nowrap text-center text-sm font-medium">
                                    <?php if (isset($mapped_products[$product['product_id']])): ?>
                                        <div class="flex items-center justify-center gap-2">
                                            <input type="number" id="qty_<?= $product['product_id'] ?>" value="1" min="1" class="w-16 px-2 py-1 bg-slate-100 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded text-center text-sm">
                                            <button onclick="addToOrder(<?= $product['product_id'] ?>, '<?= addslashes($product['product_name']) ?>', <?= $product['sale_price'] ?>)" class="inline-flex items-center px-3 py-1.5 bg-emerald-600 text-white rounded-md text-xs font-bold hover:bg-emerald-700">
                                                <i data-lucide="shopping-cart" size="14" class="mr-1"></i> Add to PO
                                            </button>
                                        </div>
                                    <?php else: ?>
                                        <div class="flex items-center justify-center space-x-2">
                                            <button onclick="importProduct(<?= $provider_tenant_id ?>, <?= $product['product_id'] ?>, '<?= addslashes($product['product_name']) ?>', <?= $product['sale_price'] ?>)" class="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded-md shadow-sm text-white bg-orange-600 hover:bg-orange-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-orange-500">
                                                <i data-lucide="plus" size="14" class="mr-1"></i> Import as New
                                            </button>
                                            <button onclick="linkProduct(<?= $provider_tenant_id ?>, <?= $product['product_id'] ?>, '<?= addslashes($product['product_name']) ?>', <?= $product['sale_price'] ?>)" class="inline-flex items-center px-3 py-1.5 border border-gray-300 text-xs font-medium rounded-md shadow-sm text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:bg-neutral-800 dark:text-neutral-200 dark:border-neutral-700 dark:hover:bg-neutral-700">
                                                <i data-lucide="link" size="14" class="mr-1"></i> Link to Existing
                                            </button>
                                        </div>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Floating Checkout Button -->
    <div id="checkoutBar" class="fixed bottom-8 right-8 hidden animate-bounce">
        <button onclick="checkoutOrder()" class="flex items-center gap-3 px-6 py-4 bg-orange-600 text-white rounded-2xl font-black shadow-2xl hover:scale-105 transition-all">
            <i data-lucide="send" size="20"></i>
            Checkout PO (<span id="cartCount">0</span> items)
        </button>
    </div>

    <!-- Link to Existing Modal -->
    <div id="linkModal" class="fixed inset-0 bg-black/80 hidden items-center justify-center backdrop-blur-sm z-50 p-4">
        <div class="bg-white dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 p-6 rounded-3xl w-full max-w-lg shadow-2xl relative text-left">
            <button onclick="closeLinkModal()" class="absolute top-4 right-4 text-slate-400 hover:text-white"><i data-lucide="x" size="20"></i></button>
            <h3 class="text-xl font-black mb-1 text-slate-900 dark:text-white uppercase tracking-tight">Link to Existing Product</h3>
            <p class="text-xs text-slate-500 mb-6 uppercase tracking-widest">Select an item from your inventory</p>
            
            <input type="hidden" id="linkProviderItemId">
            <div class="space-y-4">
                <div class="relative">
                    <i data-lucide="search" class="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size="16"></i>
                    <input type="text" id="subscriberProductSearch" onkeyup="searchSubscriberProducts(this.value)" placeholder="Search your products..." class="w-full pl-10 pr-4 py-3 bg-slate-50 dark:bg-neutral-950 border border-slate-200 dark:border-neutral-800 rounded-xl outline-none focus:border-orange-500 text-white text-sm">
                </div>
                
                <div id="searchResults" class="max-h-60 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
                    <!-- Search results will appear here -->
                </div>
            </div>
        </div>
    </div>

    <script>
        lucide.createIcons();

        const currencySymbol = '<?php echo $subscriber_currency; ?>';
        let poCart = []; // Stores items for the current purchase order
        let lockedProviderBranchId = null; // Stores the provider's branch ID once an item is added to cart

        function addToOrder(id, name, price) {
            const currentProviderBranchId = document.getElementById('partnerBranchSelect')?.value || '';

            if (poCart.length === 0) {
                // If cart is empty, lock to this branch
                lockedProviderBranchId = currentProviderBranchId;
            } else if (lockedProviderBranchId !== currentProviderBranchId) {
                // If cart has items and the currently selected branch is different, prevent adding
                alert("You can only add items from one provider branch per order. Please clear your cart to select a different branch.");
                return;
            }

            const qty = parseFloat(document.getElementById('qty_' + id).value);
            const existing = poCart.find(i => i.id === id);
            if (existing) existing.qty += qty;
            else poCart.push({ id, name, price, qty });
            
            updateCartUI();
        }

        function updateCartUI() {
            const bar = document.getElementById('checkoutBar');
            const count = document.getElementById('cartCount');
            const hasItems = poCart.length > 0;

            // 1. Strictly lock/unlock ALL branch dropdowns found on the page
            const dropdownIds = ['partnerBranchSelect', 'targetBranchId'];
            dropdownIds.forEach(id => {
                const el = document.getElementById(id);
                if (el) {
                    el.disabled = hasItems;
                    if (hasItems) {
                        el.classList.add('opacity-50', 'cursor-not-allowed');
                    } else {
                        el.classList.remove('opacity-50', 'cursor-not-allowed');
                    }
                }
            });

            // 2. Toggle warning labels
            const labelIds = ['branchLockedMsgModal', 'branchLockedMsg'];
            labelIds.forEach(id => {
                const msg = document.getElementById(id);
                if (msg) hasItems ? msg.classList.remove('hidden') : msg.classList.add('hidden');
            });

            // 3. Highlight the selection container if locked
            const container = document.getElementById('partnerBranchContainer');
            if (container) hasItems ? container.classList.add('border-orange-500/30') : container.classList.remove('border-orange-500/30');

            if (poCart.length > 0) {
                bar.classList.remove('hidden');
                count.innerText = poCart.length;
            } else {
                bar.classList.add('hidden');
                lockedProviderBranchId = null; 
            }
        }

        function clearCart() {
            if (!confirm("Clear current cart and unlock provider branch selection?")) return;
            poCart = [];
            lockedProviderBranchId = null; // Reset locked branch
            updateCartUI();
        }

        async function checkoutOrder() {
            if (!confirm(`Send Purchase Order with ${poCart.length} items to ${"<?php echo $provider_business_name ?>"}?`)) return;
            
            // Use the lockedProviderBranchId. If it's null (e.g., only one branch and dropdown was hidden),
            // fallback to selectedPartnerBranchId (which would be the single branch ID).
            // If both are null, send empty string, b2b_actions.php will handle default routing.
            const finalReceiverBranchId = lockedProviderBranchId || selectedPartnerBranchId || '';

            try {
                const response = await fetch('b2b_actions.php?action=place_order', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        provider_id: providerId,
                        items: poCart, // poCart items don't need branch ID, as the whole order is for one branch
                        receiver_branch_id: finalReceiverBranchId // Send the locked provider branch
                    })
                });
                const res = await response.json();
                if (res.success) {
                    alert("Order placed successfully! Redirecting to orders...");
                    window.location.href = "b2b_orders.php";
                } else {
                    alert(res.message);
                }
            } catch (e) { alert("Checkout failed"); }
        }

        const providerId = <?php echo $provider_tenant_id; ?>;

        async function importProduct(providerTenantId, providerItemId, productName, salePrice) {
            if (!confirm(`Import "${productName}" as a new product in your inventory?`)) return;
            document.getElementById(`actions_${providerItemId}`).innerHTML = '<span class="text-xs italic text-slate-400">Processing...</span>';
            
            try {
                const response = await fetch('b2b_actions.php?action=import', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ provider_id: parseInt(providerTenantId), item_id: parseInt(providerItemId), product_name: productName })
                });
                if (!response.ok) throw new Error("Server returned 404 or 500");
                const res = await response.json();
                if (res.success) updateRowToMapped(providerItemId, productName, salePrice);
                else { alert("Error: " + res.message); location.reload(); }
            } catch (e) { 
                console.error(e);
                alert("Network error: Check console for details."); 
            }
        }

        let currentLinkingPrice = 0;
        let currentLinkingName = '';
        function linkProduct(providerTenantId, providerItemId, productName, salePrice) {
            document.getElementById('linkProviderItemId').value = providerItemId;
            currentLinkingPrice = salePrice;
            currentLinkingName = productName;
            document.getElementById('linkModal').classList.remove('hidden');
            document.getElementById('linkModal').classList.add('flex');
            searchSubscriberProducts(''); // Load initial list
        }

        function closeLinkModal() {
            document.getElementById('linkModal').classList.add('hidden');
            document.getElementById('linkModal').classList.remove('flex');
        }

        async function searchSubscriberProducts(query) {
            const res = await fetch(`./b2b_actions.php?action=search&q=${encodeURIComponent(query)}`);
            const data = await res.json();
            const container = document.getElementById('searchResults');
            container.innerHTML = '';

            if (data.success && data.results && data.results.length > 0) {
                data.results.forEach(prod => {
                    const div = document.createElement('div');
                    div.className = "p-3 bg-neutral-800 hover:bg-orange-600/20 border border-neutral-700 rounded-xl cursor-pointer transition-all flex justify-between items-center group";
                    div.innerHTML = `<div><div class="text-sm font-bold text-white">${prod.name}</div><div class="text-[10px] text-neutral-400">${prod.sku || 'No SKU'}</div></div><i data-lucide="link-2" size="14" class="text-neutral-500 group-hover:text-orange-500"></i>`;
                    div.onclick = () => confirmLink(prod.id);
                    container.appendChild(div);
                });
                lucide.createIcons();
            } else {
                container.innerHTML = '<div class="text-center text-xs text-neutral-500 py-4 italic">No products found</div>';
            }
        }

        async function confirmLink(subscriberItemId) {
            const providerItemId = document.getElementById('linkProviderItemId').value;
            const response = await fetch('./b2b_actions.php?action=link', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ provider_id: providerId, provider_item_id: providerItemId, subscriber_item_id: subscriberItemId })
            });
            const res = await response.json();
            if (res.success) {
                closeLinkModal();
                updateRowToMapped(providerItemId, currentLinkingName, currentLinkingPrice);
            } else alert(res.message || "Linking failed");
        }

        function updateRowToMapped(providerItemId, productName, salePrice) {
            const actionCell = document.getElementById(`actions_${providerItemId}`);
            if (!actionCell) return;

            actionCell.innerHTML = `
                <div class="flex items-center justify-center gap-2">
                    <input type="number" id="qty_${providerItemId}" value="1" min="1" class="w-16 px-2 py-1 bg-slate-100 dark:bg-neutral-800 border border-slate-200 dark:border-neutral-700 rounded text-center text-sm">
                    <button onclick="addToOrder(${providerItemId}, '${productName.replace(/'/g, "\\'")}', ${salePrice})" class="inline-flex items-center px-3 py-1.5 bg-emerald-600 text-white rounded-md text-xs font-bold hover:bg-emerald-700">
                        <i data-lucide="shopping-cart" size="14" class="mr-1"></i> Add to PO
                    </button>
                </div>
            `;
            lucide.createIcons();
        }
    </script>
</body>
</html>